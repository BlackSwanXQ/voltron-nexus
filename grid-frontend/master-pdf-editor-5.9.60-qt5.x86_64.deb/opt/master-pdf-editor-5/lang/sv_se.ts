<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="410"/>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="127"/>
        <source>Registered version.</source>
        <translation>Registrerad version.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="179"/>
        <source>Purchased On:</source>
        <translation>Köpt den:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="187"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Underhållsplanen upphör:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation>Registreringsinfo</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation>Licensavtal</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="126"/>
        <source>Not Registered version.</source>
        <translation>Icke registrerad version.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation>Versionsinformation</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation>Kompilerad med</translation>
    </message>
    <message>
        <source>Legal Notices</source>
        <translation type="vanished">Juridiska notiser</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="258"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>Denna mjukvara använder, med tillstånd, följande upphovsrättsskyddad mjukvara.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="99"/>
        <source>Please, renew your license</source>
        <translation>Förnya gärna licensen</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Third-Party Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>Dokumentåtgärder</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>Åtgärder</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation>Dokumentet stängs</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation>Dokumentet sparas</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation>Dokumentet sparades</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation>Dokumentet skrivs ut</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>Dokumentet skrevs ut</translation>
    </message>
</context>
<context>
    <name>AddOpenFilesDialog</name>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="14"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="22"/>
        <source>Open PDF files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>File Name</source>
        <translation type="unfinished">Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>Size</source>
        <translation type="unfinished">Storlek</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="32"/>
        <source>Add Files</source>
        <translation type="unfinished">Lägga till filer</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation>Avancerade utskriftsinställningar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation>Skriv ut som bild</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation>Kölägg som delmängd</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="97"/>
        <source>Сompatible with Laser Engraving</source>
        <translation>Kompatibel med lasergravyr</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="246"/>
        <source>Borders and Colors</source>
        <translation>Kantlinjer och färger</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="256"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="261"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="266"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="271"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="276"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="281"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="286"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="291"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="296"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="301"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="306"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="314"/>
        <source>Border Color</source>
        <translation>Kantfärg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="321"/>
        <source>Fill Color</source>
        <translation>Fyllnadsfärg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="329"/>
        <source>Solid</source>
        <translation>Solid</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="334"/>
        <source>Dashed</source>
        <translation>Streckad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="349"/>
        <source>Line Width</source>
        <translation>Linjetjocklek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="342"/>
        <source>Line Style</source>
        <translation>Linjestil</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>Visa på utskrift</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>Visa på skärm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Bevara position och storlek på vattenstämpeln vid utskrift på olika sidstorlekar</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>Bakgrund</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="335"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="349"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="357"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="367"/>
        <source>Source</source>
        <translation>Källa</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="405"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="411"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="508"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="514"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="540"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="660"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="449"/>
        <source>File</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Antal sidor:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="383"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="484"/>
        <source>Page Number</source>
        <translation>Sidnummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="422"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="373"/>
        <source>Scale</source>
        <translation>Skala</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="44"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation>Opacitet</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation>Skala relativt till målsida</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="140"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="187"/>
        <source>Vertical distance</source>
        <translation>Vertikalt avstånd</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="506"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="514"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="531"/>
        <source>of</source>
        <translation type="unfinished">av</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="538"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="166"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="246"/>
        <source>from</source>
        <translation>från</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="282"/>
        <source>Top</source>
        <translation>Överkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="265"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="287"/>
        <source>Center</source>
        <translation>Centrera</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="292"/>
        <source>Bottom</source>
        <translation>Underkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="180"/>
        <source>Horizontal distance</source>
        <translation>Horisontellt avstånd</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="260"/>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="270"/>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="173"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="566"/>
        <source>Page Range Options...</source>
        <translation>Sidintervall...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save Settings</source>
        <translation>Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save current settings as:</source>
        <translation>Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="241"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="337"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="371"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="415"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">PDF-filer (*.pdf *.PDF)</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="vanished">Ett fel inträffade när dokumentet skulle öppnas!</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="316"/>
        <source>Saved Settings</source>
        <translation>Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="228"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="233"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="238"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alla filer som stöds (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="201"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="207"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatesNumberingOptionsDialog</name>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="32"/>
        <source>Start Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="39"/>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="59"/>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="69"/>
        <source>Number of Digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="14"/>
        <source>Bates Numbering Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source>The value must be between </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source> and </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Bokmärkesegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="115"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="129"/>
        <source>Plain</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="134"/>
        <source>Italic</source>
        <translation>Kursiv</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="139"/>
        <source>Bold</source>
        <translation>Fet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="144"/>
        <source>Italic &amp; Bold</source>
        <translation>Fet &amp; Kursiv</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="165"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="179"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="292"/>
        <source>Actions</source>
        <translation>Åtgärder</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="351"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="332"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="185"/>
        <source>Add an Action</source>
        <translation>Lägg till åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="220"/>
        <source>Trigger</source>
        <translation>Utlösare</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="204"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="212"/>
        <source>Mouse Up</source>
        <translation>Mus upp</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="228"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sidvy</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="233"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="238"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="243"/>
        <source>Reset form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="248"/>
        <source>Show/Hide fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="253"/>
        <source>Submit a form</source>
        <translation>Skicka ett formulär</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="258"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="266"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Sidnummer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="86"/>
        <source>Set current position</source>
        <translation>Ange aktuell position</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="96"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="78"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="220"/>
        <source>Do you want to set the current position?</source>
        <translation>Vill du ange aktuell position?</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="222"/>
        <source>Custom</source>
        <translation>Anpassa</translation>
    </message>
</context>
<context>
    <name>BookmarksForm</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="20"/>
        <source>Bookmarks</source>
        <translation type="unfinished">Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="38"/>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="69"/>
        <source>Set destanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="100"/>
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="131"/>
        <source>Properties</source>
        <translation type="unfinished">Egenskaper</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="162"/>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="193"/>
        <source>Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="224"/>
        <source>Delete all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation>Certifikathanterare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation>Dina certifikat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation>Importera</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation>Exportera</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation>Pålitliga systemcertifikat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="44"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Alla filer som stöds (*.p12 *.pfx *.cer *.crt *.pem);; p12-filer (*.p12);; pfx-filer (*.pfx);; Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="102"/>
        <source>A password is required to open certificate:</source>
        <translation>Lösenord krävs för att öppna certifikatet:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="114"/>
        <source>Error!</source>
        <translation>Fel!</translation>
    </message>
    <message>
        <source>Are you sure you want to delete ceritficate?</source>
        <translation type="vanished">Vill du verkligen ta bort certifikatet?</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>pfx Files (*.pfx)</source>
        <translation>pfx-filer (*.pfx)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>crt Files (*.crt)</source>
        <translation>crt-filer (*.crt)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="162"/>
        <source>Save File</source>
        <translation>Spara fil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="171"/>
        <source>Please, specify private key password:</source>
        <translation>Specificera privat nyckellösenord:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="126"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation>Vill du verkligen ta bort certifikatet?</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation>Skapa nytt dokument från filer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="181"/>
        <source>Add Files</source>
        <translation>Lägga till filer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="164"/>
        <source>Add Folder</source>
        <translation>Lägg till mapp</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="211"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="267"/>
        <source>Up</source>
        <translation>Upp</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="298"/>
        <source>Down</source>
        <translation>Ner</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="237"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="278"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="196"/>
        <source>Page Range</source>
        <translation>Sidintervall</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>File Name</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="124"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Spara</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="84"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="126"/>
        <source>Add Headers and Footers to Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>Total pages</source>
        <translation>Antal sidor</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="198"/>
        <source>Size</source>
        <translation type="unfinished">Storlek</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="197"/>
        <source>Total Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="488"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="921"/>
        <source>Save As PDF</source>
        <translation>Spara som PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="490"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="923"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-filer (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1002"/>
        <source>File</source>
        <translation type="unfinished">Arkiv</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1003"/>
        <source>has already been added to the list. Please choose a different file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source> is already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1052"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1074"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>are already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Öppna</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Alla filer (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="600"/>
        <source>Select directory</source>
        <translation>Välj mapp</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="956"/>
        <source>Save failed</source>
        <translation>Kunde inte spara</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Filen kanske är skrivskyddad eller används av ett annat program.</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="34"/>
        <source>Output</source>
        <translation>Utdata</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="101"/>
        <source>Append to Current Document </source>
        <translation>Lägg till i aktuellt dokument </translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="108"/>
        <source>Create New Document</source>
        <translation>Skapa nytt dokument</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="43"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="20"/>
        <source>Add files to which Headers and Footers or Bates Numbers should be placed. Bates Numbers will appear in the specified order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="27"/>
        <source>Save and close files after numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="49"/>
        <source>Before current page</source>
        <translation>Före aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="59"/>
        <source>After last page</source>
        <translation>Efter sista sidan</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="66"/>
        <source>After current page</source>
        <translation>Efter aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="76"/>
        <source>Before first page</source>
        <translation>Före första sidan</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="309"/>
        <source>Show</source>
        <translation type="unfinished">Visa</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Alla filer som stöds (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="137"/>
        <source>Import Bookmarks</source>
        <translation>Importera bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Insert Pages</source>
        <translation>Infoga sidor</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="550"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Alla filer som stöds (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="42"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="49"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="553"/>
        <source>All Supported Files (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Alla filer som stöds (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Alla filer (*)</translation>
    </message>
</context>
<context>
    <name>DeleteAcrossPagesDialog</name>
    <message>
        <location filename="../../src/DeleteAcrossPagesDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="14"/>
        <source>Delete Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="23"/>
        <source>Do you want to delete all headers, footers and Bates numbers on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="obsolete">Vill du ta bort sidhuvuden och sidfötter från dokumentet?</translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="22"/>
        <source>Do you want to delete all watermarks on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="27"/>
        <source>Do you want to delete all backgrounds on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Ta bort sidor</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="50"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Borttagna sidor kan inte återställas med ångerfunktionen.</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>Distansverktyg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>Pekarposition</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>Enheter och markeringsinställningar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation>Skalfrekvens:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation>in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation>Anteckning:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>Mätning</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>Avstånd:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>Vinkel:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="32"/>
        <source>Distance</source>
        <translation>Avstånd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="36"/>
        <source>Perimeter</source>
        <translation>Omkrets</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="43"/>
        <source>Area</source>
        <translation>Area</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="46"/>
        <source> sq</source>
        <translation> sq</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="222"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="225"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="229"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
</context>
<context>
    <name>DlgChangeFont</name>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="14"/>
        <source>Change Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="39"/>
        <source>Current font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="46"/>
        <source>Change to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="66"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">Ändra automatiskt teckensnitt vid textredigering</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="84"/>
        <source>Exact match only</source>
        <translation type="unfinished">Endast exakt matchning</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="21"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished">Teckensnittet innehåller inte dessa tecken.
Försök välja ett annat teckensnitt.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="28"/>
        <source>Change</source>
        <translation type="unfinished">Ändra</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Teckensnitt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt teckensnitt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>Ikonplacering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>Anpassa till gränserna</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>När skalning skall ske:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>Proportionerligt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>Icke-proportionerligt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>Knapp</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>Skala:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>Ikonen är för stor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Använd denna dialog för att ändra hur ikonen skalas för att passa i knappen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>Ikonen är för liten</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>Sidnummer och datumformat</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>Datumformat</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>Sidnummerformat</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>Startsidenummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="51"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="18"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="20"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="21"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>of</source>
        <translation>av</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="53"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="27"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="29"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="14"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="16"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation>Sidintervall</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Jämna sidor</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Udda sidor</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Redigera text</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Spara bild som fil</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Objektegenskaper...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Klipp ut</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="41"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Klistra in</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="48"/>
        <source>Add Sticky Note</source>
        <translation>Lägg till anteckning</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="49"/>
        <source>Highlight Text</source>
        <translation>Belys text</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="50"/>
        <source>Strikeout Text</source>
        <translation>Stryk över text</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="51"/>
        <source>Underline Text</source>
        <translation>Stryk under text</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>Add Bookmark</source>
        <translation>Lägg till bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2456"/>
        <location filename="../../src/docpage/docpage.cpp" line="2496"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sida</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2465"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2475"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2486"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3975"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="70"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="82"/>
        <source>Set Status</source>
        <translation>Ange status</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1087"/>
        <location filename="../../src/docpage/docpage.cpp" line="1090"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1678"/>
        <source>The selected area has been copied</source>
        <translation>Det markerade området har kopierats</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">Kopiera</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Klipp ut</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Klistra in</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="131"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="132"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Redigera Text</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="136"/>
        <source>Signature options</source>
        <translation>Signaturalternativ</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Ångra</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="139"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="2622"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Open Image</source>
        <translation>Öppna bild</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="vanished">FEL vid bildinläsning!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="140"/>
        <source>Set Fit to Page</source>
        <translation>Anpassa till sidan</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="141"/>
        <source>Save Image to file</source>
        <translation>Spara bild som fil</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Spara som...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1940"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG-filer (*.png);;BMP-filer (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1950"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG -filer (*.png)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Bildfiler (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Bildfiler (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>ERROR Loading Image !</source>
        <translation type="vanished">FEL vid bildinläsning!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="134"/>
        <source>Edit Image</source>
        <translation>Redigera bild</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="143"/>
        <source>Edit Path Nodes</source>
        <translation>Redigera sökvägsnoder</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1656"/>
        <source>Edit the image and press Replace</source>
        <translation>Redigera bilden och tryck &quot;Ersätt&quot;</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1658"/>
        <source>Replace</source>
        <translation>Ersätt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1659"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2593"/>
        <source>Delete Node</source>
        <translation>Ta bort nod</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Bildfiler (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="594"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="609"/>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="137"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="135"/>
        <source>Replace Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1650"/>
        <source>An error occurred when attempting to open external application for editing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>JavaScript-redigerare</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">Gå till en sida</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">Överkant</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Vänster</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">Sidnummer</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">Zoom (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Öppna/Kör en fil</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">Redigera en fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>Visa</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>Välj fält</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>Avmarkera alla</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>Dölj</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>Metod</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="187"/>
        <source>Show/Hide Fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="221"/>
        <source>Reset Form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="vanished">Ange en fil:</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="vanished">Ange en webbsida:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Alternativ</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="vanished">Zoomläge</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Anpassa</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Ärvt zoomläge</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Anpassa sidan</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">Anpassa bredden</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>Lokal fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation>E-post</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation>Anonym</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>Användarnamn och lösenord</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>Användarnamn</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="115"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="117"/>
        <source>All Files (*.*)</source>
        <translation>Alla filer (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="191"/>
        <source>Select Field</source>
        <translation>Välj fält</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a file:</source>
        <translation>Ange en fil:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Gå till en sida</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation>Sidnummer</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation>Zoomläge</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Enter a web site:</source>
        <translation>Ange en webbsida:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="171"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="173"/>
        <source>All Files (*.*)</source>
        <translation>Alla filer (*.*)</translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="vanished">XYZ</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="vanished">Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="114"/>
        <source>Named Action</source>
        <translation>Namngiven åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation>Anpassa bredd</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation>Anpassa höjd</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation>Anpassa synligt</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditTabOrderDlg</name>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="14"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="20"/>
        <source>Forms</source>
        <translation type="unfinished">Formulär</translation>
    </message>
</context>
<context>
    <name>ExportCSVDialog</name>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="20"/>
        <source>Export to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="50"/>
        <source>File Name</source>
        <translation type="unfinished">Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="78"/>
        <source>Browse</source>
        <translation type="unfinished">Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="88"/>
        <source>Separator</source>
        <translation type="unfinished">Separator</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="103"/>
        <source>Semicolon ( ; )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="129"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="146"/>
        <source>Comma ( , )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="153"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="38"/>
        <source>untitled</source>
        <translation type="unfinished">namnlös</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="47"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="111"/>
        <source>Export to csv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="113"/>
        <source>csv files (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished">Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="77"/>
        <source>Extract pages as a single file</source>
        <translation>Extrahera sidor som enskild fil</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Extrahera sidor</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="141"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="130"/>
        <source>Save As PDF</source>
        <translation>Spara som PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="132"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-filer (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Filen kanske är skrivskyddad eller används av ett annat program.</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>The file &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>&quot; already exists. Do you wish to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="43"/>
        <source>Export Pages</source>
        <translation>Exportera sidor</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="vanished">Exportera sidor</translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="vanished">Exportera bokmärken</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="124"/>
        <source>Export bookmarks</source>
        <translation>Exportera bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="134"/>
        <source>Delete pages after extracting</source>
        <translation>Ta bort sidor efter extrahering</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="23"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation>Exportera till text</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="64"/>
        <source>Extract pages as a single file</source>
        <translation>Extrahera sidor som enskild fil</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="35"/>
        <source>untitled</source>
        <translation type="unfinished">namnlös</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="43"/>
        <source>Export</source>
        <translation>Exportera</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation>txt-filer (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Filen kanske är skrivskyddad eller används av ett annat program.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Dokumentegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Dokumentinfo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Ämne</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Författare</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Nyckelord</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Skapad av</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Producent</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>Startvy</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Bilder</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>Teckensnitt som används i detta dokument</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Dokumentskydd</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Användarlösenord</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Ägarlösenord</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>Lösenordskryptering</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>Ingen kryptering</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>Utskrift</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>Skriv ut med hög upplösning</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Extrahera text och grafik</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Avancerad text- och grafikextrahering</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>Ändra dokument</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Ändra notiser och formulärfält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Fyll i befintligt formulär eller signaturfält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Hantera sidor och bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Öppna på sidan:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>av :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>PDF-information</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Sidläge:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation>Endast sida</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation>Bokmärkesfält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation>Sidfält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation>Bilagefält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation>Lagerfält</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="vanished">Helskärm</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation>Ändra</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation>Rättigheter</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation>Extrahera dokumentets innehåll</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation>Innehållskopiering för åtkomst</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation>Kommentera</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="723"/>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="724"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Dokumentet är åtkomstskyddat. Ange lösenord:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="746"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Felaktigt lösenord. Ange ägarlösenord.</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation>Användargränssnitt</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation>Dölj verktygsfältet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation>Dölj menyfältet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation>Dölj fönsterkontrollerna</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation>Fönsteralternativ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation>Centrera fönstret på skärmen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation>Visa dokumenttitel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation>Öppna i helskärmsläge</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation>Layout och plats</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation>Navigeringsflik:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation>Sidlayout:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="248"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation>Enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation>Löpande enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation>Bokuppslag (två sidor)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Löpande bokuppslag (två sidor)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation>Bokuppslag (Omslag)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>Löpande bokuppslag (Omslag)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation>Zooma</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation>Egentlig storlek</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation>Anpassa bredd</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="268"/>
        <source>Fit Height</source>
        <translation>Anpassa höjd</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="273"/>
        <source>Fit Visible</source>
        <translation>Anpassa synligt</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation>Åtgärder</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation>Åtgärder vid dokumentöppning</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation>Lägg till åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sidvy</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation>Skicka ett formulär</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translation>Certifikatkryptering</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Utseende</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Alternativ</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Åtgärder</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Ta bort</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Stäng</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Färg</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Lägg till</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Låst</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Namn</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Kantlinjer och färger</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Lägg till åtgärd</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientering</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Linjestil</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Tjocklek</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Fyllnadsfärg</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Kantfärg</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Upp</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Ner</translation>
    </message>
</context>
<context>
    <name>HeaderAndFooterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save Settings</source>
        <translation type="unfinished">Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="365"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="569"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="593"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="621"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished">Sidhuvud &amp; sidfot</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="166"/>
        <source>Margins</source>
        <translation type="unfinished">Marginal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="257"/>
        <source>Units</source>
        <translation type="unfinished">Enheter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="291"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="296"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="301"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">Vänster marginal</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">Höger marginal</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="obsolete">Övre marginal</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="obsolete">Undre marginal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="328"/>
        <source>Saved Settings</source>
        <translation type="unfinished">Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="347"/>
        <source>Delete</source>
        <translation type="unfinished">Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="361"/>
        <source>None</source>
        <translation type="unfinished">Ingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="369"/>
        <source>Save</source>
        <translation type="unfinished">Spara</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="522"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="536"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="553"/>
        <source>of</source>
        <translation type="unfinished">av</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="560"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="588"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">Sidintervall...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="150"/>
        <source>Page number and date format</source>
        <translation type="unfinished">Sidnummer och datumformat</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="28"/>
        <source>Show Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="41"/>
        <source>Insert Page Number</source>
        <translation type="unfinished">Infoga sidnummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="48"/>
        <source>Insert Date</source>
        <translation type="unfinished">Infoga datum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="55"/>
        <source>Insert Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="70"/>
        <source>Font</source>
        <translation type="unfinished">Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="76"/>
        <source>Color</source>
        <translation type="unfinished">Färg</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="96"/>
        <source>Size</source>
        <translation type="unfinished">Storlek</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="116"/>
        <source>Font Family</source>
        <translation type="unfinished">Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="178"/>
        <source>Top</source>
        <translation type="unfinished">Överkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="188"/>
        <source>Right</source>
        <translation type="unfinished">Höger</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="198"/>
        <source>Left</source>
        <translation type="unfinished">Vänster</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="247"/>
        <source>Bottom</source>
        <translation type="unfinished">Underkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Use Page Range of the currently edited Pagemark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="408"/>
        <source>Right Footer Text</source>
        <translation type="unfinished">Höger sidfotstext</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="469"/>
        <source>Center Header Text</source>
        <translation type="unfinished">Centrerad  sidhuvudtext</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="439"/>
        <source>Left Footer Text</source>
        <translation type="unfinished">Vänster sidfotstext</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="476"/>
        <source>Right Header Text</source>
        <translation type="unfinished">Höger sidhuvudtext</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="432"/>
        <source>Center Footer Text</source>
        <translation type="unfinished">Centrerad sidfotstext</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="425"/>
        <source>Left Header Text</source>
        <translation type="unfinished">Vänster sidhuvudtext</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation type="vanished">Sidhuvud &amp; sidfot</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="vanished">Marginal</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="vanished">Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="vanished">Vänster marginal</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="vanished">Höger marginal</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="vanished">Övre marginal</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="vanished">Undre marginal</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Teckensnitt</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Färg</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Storlek</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="vanished">Teckensnitt</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation type="vanished">Höger sidfotstext</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation type="vanished">Centrerad  sidhuvudtext</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation type="vanished">Vänster sidfotstext</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation type="vanished">Höger sidhuvudtext</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation type="vanished">Centrerad sidfotstext</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation type="vanished">Vänster sidhuvudtext</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Inställningar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Ta bort</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Ingen</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Spara</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="vanished">Sidintervall...</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation type="vanished">Sidnummer och datumformat</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation type="vanished">Infoga sidnummer</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation type="vanished">Infoga datum</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="vanished">Spara inställningar</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="vanished">Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="vanished">Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="vanished">Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="vanished"> ?</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation type="vanished">Sparade inställningar</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="vanished">Marginal</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="vanished">millimeter</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="vanished">Infoga sidor</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="vanished">Filnamn</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="vanished">Bläddra</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="vanished">Position</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="vanished">Efter sista sidan</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="vanished">Före första sidan</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Öppna fil</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="vanished">PDF-filer (*.pdf)</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Antal sidor:</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation type="vanished">Fel vid inläsning: Denna PDF är åtkomstskyddad.</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="vanished">Före aktuell sida</translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="vanished">Efter aktuell sida</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="vanished">Importera bokmärken</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">Lösenord</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="vanished">Denna fil är åtkomstskyddad. Ange ett lösenord:</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation type="vanished">Fel vid inläsning: Denna PDF är åtkomstskyddad.</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation>Formulär</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>Installera språk</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="165"/>
        <source>Install</source>
        <translation>Installera</translation>
    </message>
</context>
<context>
    <name>InteractiveCPDFReader</name>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="39"/>
        <source>Словарь в форме хранящейся в памяти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="52"/>
        <source>Команда(или help для их описания) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="88"/>
        <source>Вводимые ключи</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="101"/>
        <source>Черновик для записей</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="130"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="146"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="162"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="178"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="194"/>
        <source>5</source>
        <translation type="unfinished">5</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="207"/>
        <source>Скопировать текущий 
словарь в черновик</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>JavaScript-konsoll</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>Kör</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>Alltid överst</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation>Funktionsnamn</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>JavaScript-redigerare</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Funktionsnamn</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>JavaScript</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="126"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="205"/>
        <source>Press shortcut</source>
        <translation>Tryck genväg</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>Tangentbordsgenvägar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation>Återställ alla</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation>Genväg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation>Kommando</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacApplication</name>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="465"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="470"/>
        <source>Actual Size</source>
        <translation type="unfinished">Egentlig storlek</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="478"/>
        <source>Zoom In</source>
        <translation type="unfinished">Zooma in</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Föregående sida</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Nästa sida</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="542"/>
        <source>Highlight color</source>
        <translation>Belysningsfärg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="562"/>
        <source>Required field highlight color</source>
        <translation>Belysningsfärg för obligatoriska fält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3370"/>
        <source>Please choose the interface language</source>
        <translation>Välj språk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3442"/>
        <source>Check for Updates Automatically</source>
        <translation>Sök automatiskt efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3461"/>
        <source>Weekly</source>
        <translation>Varje vecka</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3466"/>
        <source>Monthly</source>
        <translation>Varje månad</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3456"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="894"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1236"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2044"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2272"/>
        <source>Smooth text and images</source>
        <translation>Utjämnad text och bild</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1324"/>
        <source>Time before a move or resize starts:</source>
        <translation>Tid innan flytt eller storleksändring startar:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1317"/>
        <source>Select item by hovering the mouse</source>
        <translation>Välj objekt genom att hovra med muspekaren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Built-in</source>
        <translation>Inbyggd</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="522"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3390"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Starta om programmet för att tillämpa ändringarna.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Update</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="vanished">Arabiska</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="vanished">Bulgariska</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="vanished">Katalanska</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="vanished">Förenklad kinesiska</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="vanished">Traditionell kinesiska</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="vanished">Tjeckiska</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="vanished">Danska</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="vanished">Holländska</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">Engelska</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="vanished">Estniska</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="vanished">Finska</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="vanished">Franska</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="vanished">Galisiska</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="vanished">Tyska</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="vanished">Grekiska</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="vanished">Hebreiska</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="vanished">Ungerska</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="vanished">Irländska</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="vanished">Italienska</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished">Japanska</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="vanished">Koreanska</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="vanished">Lettiska</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="vanished">Litauiska</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="vanished">Norska Bokmål</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="vanished">Nynorska</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished">Polska</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="vanished">Portugisiska</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="vanished">Portugisiska Brasilien</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="vanished">Rumänska</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">Ryska</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="vanished">Serbiska</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="vanished">Slovakiska</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="vanished">Slovenska</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="vanished">Spanska</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="vanished">Svenska</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="vanished">Thailändska</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="vanished">Turkiska</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="vanished">Ukrainska</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="vanished">Velenciska</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Vietnamesiska</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="203"/>
        <source>Saving Documents</source>
        <translation>Sparar dokument</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Create backup file</source>
        <translation>Skapa säkerhetskopia</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Välj mapp för &quot;Spara som&quot;</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Last used folder</source>
        <translation>Senast använda mapp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Original documents folder</source>
        <translation>Ursprunglig mapp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1144"/>
        <source>Default font</source>
        <translation>Standardteckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation>Redigering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2855"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2900"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1530"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1847"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1162"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1854"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2512"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="vanished">Armeniska</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="151"/>
        <source>Restore last session when application start</source>
        <translation>Återställ senaste session vid programstart</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="158"/>
        <source>Restore last view settings when reopening</source>
        <translation>Återställ senaste vyinställning vid återöppnande</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1593"/>
        <source>Enable JavaScript</source>
        <translation>Aktivera JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="598"/>
        <source> Always hide document message bar </source>
        <translation> Dölj alltid meddelandefältet </translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2109"/>
        <source>Default Layout and Zoom</source>
        <translation>Standardlayout och zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2224"/>
        <source>Default page layout</source>
        <translation>Standard sidlayout</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2122"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2232"/>
        <source>Automatic</source>
        <translation>Automatiskt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2204"/>
        <source>Single Page</source>
        <translation>Enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2209"/>
        <source>Facing Pages</source>
        <translation>Bokupslag</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2255"/>
        <source>Zoom</source>
        <translation>Zooma</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2127"/>
        <source>Actual Size</source>
        <translation>Egentlig storlek</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="984"/>
        <source>Show warning when opening links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <source>Convert static XFA into normal PDF when opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1224"/>
        <source>Page scrolling options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <source>Configure scroll value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1297"/>
        <source>Enable scroll without delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1137"/>
        <source>Create Pencil lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1979"/>
        <source>Create Pencil and Brush lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2132"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2137"/>
        <source>Fit Width</source>
        <translation>Anpassa bredden</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2142"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2147"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2152"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2157"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2162"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2167"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2172"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2177"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2182"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2187"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="747"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2401"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2288"/>
        <source>Bitmap Images</source>
        <translation>Bitmap-bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2295"/>
        <source>Vector Images</source>
        <translation>Vektor-bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2383"/>
        <source>Replace Document Colors</source>
        <translation>Ersätt dokumentfärger</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2408"/>
        <source>Page Background</source>
        <translation>Sidbakgrund</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation>Visning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="vanished"> Visa alltid objektgranskaren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2425"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="vanished">Fusion Dark Style</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="464"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="479"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="2041"/>
        <source>Select directory</source>
        <translation>Välj mapp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1061"/>
        <source>Automatically change font when editing text</source>
        <translation>Ändra automatiskt teckensnitt vid textredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2318"/>
        <source>Resolution</source>
        <translation>Upplösning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2334"/>
        <source>Custom</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2324"/>
        <source>System PPI</source>
        <translation>System-PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>Icons in menus</source>
        <translation>Ikoner i menyer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Öppna dokument i ny flik, i samma fönster (kräver omstart)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="342"/>
        <source>Enable scroll wheel zooming</source>
        <translation>Aktivera mushjulszoom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1663"/>
        <source>Author</source>
        <translation>Författare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2098"/>
        <source>Pop-up Opacity</source>
        <translation>Popup-opacitet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1564"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1820"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2075"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1687"/>
        <source>Sticky Note</source>
        <translation>Anteckning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1803"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1557"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1835"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1946"/>
        <source>Opacity</source>
        <translation>Opacitet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Highlight Text</source>
        <translation>Belys</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1697"/>
        <source>Strikeout Text</source>
        <translation>Stryk över</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1702"/>
        <source>Underline Text</source>
        <translation>Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1537"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1928"/>
        <source>Line Width</source>
        <translation>Linjetjocklek</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation>Kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="656"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="727"/>
        <source>Check Mark</source>
        <translation>Bock</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="728"/>
        <source>Circle</source>
        <translation>Cirkel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="838"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <source>Cross</source>
        <translation>Kryss</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Infoga text</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="733"/>
        <source>Key</source>
        <translation>Tangent</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="734"/>
        <source>New Paragraph</source>
        <translation>Nytt stycke</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="735"/>
        <source>Text Note</source>
        <translation>Textnotis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="736"/>
        <source>Paragraph</source>
        <translation>Stycke</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="737"/>
        <source>Right Arrow</source>
        <translation>Höger pil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="738"/>
        <source>Right Pointer</source>
        <translation>Höger pekare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="853"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="739"/>
        <source>Star</source>
        <translation>Stjärna</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="740"/>
        <source>Up Arrow</source>
        <translation>Pil upp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="741"/>
        <source>Up Left Arrow</source>
        <translation>Upp vänster pil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="742"/>
        <source>Graph</source>
        <translation>Diagram</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="743"/>
        <source>Paper Clip</source>
        <translation>Gem</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="744"/>
        <source>Attachment</source>
        <translation>Bilagor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="745"/>
        <source>Tag</source>
        <translation>Tagg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1605"/>
        <source>Show errors and  messages in console</source>
        <translation>Visa fel och meddelanden i konsollen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="606"/>
        <source>Link</source>
        <translation>Länk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="248"/>
        <source>Autosave interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="299"/>
        <source>Autosave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="175"/>
        <source>Show Quick actions on text and comments selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Lock file from opening by other instances of Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Enable logging to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="398"/>
        <source>Log files directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Edit Box</source>
        <translation>Redigeringsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="616"/>
        <source>Check box</source>
        <translation>Kryssruta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <source>Radio button</source>
        <translation>Alternativknapp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Combo box</source>
        <translation>Kombinationsruta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>List box</source>
        <translation>Listruta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Button</source>
        <translation>Knapp</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="641"/>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="662"/>
        <source>Borders and Colors</source>
        <translation>Kantlinjer och färger</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="669"/>
        <source>Thin</source>
        <translation>Tunn</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="674"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="679"/>
        <source>Thick</source>
        <translation>Tjock</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="687"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Border Color</source>
        <translation>Kantfärg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="694"/>
        <source>Fill Color</source>
        <translation>Fyllnadsfärg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="702"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="929"/>
        <source>Solid</source>
        <translation>Solid</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="934"/>
        <source>Dashed</source>
        <translation>Streckad</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="712"/>
        <source>Beveled</source>
        <translation>Avfasad</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="717"/>
        <source>Inset</source>
        <translation>Infälld</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="722"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="939"/>
        <source>Underline</source>
        <translation>Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="921"/>
        <source>Line Style</source>
        <translation>Linjestil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="737"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="900"/>
        <source>Line Thickness</source>
        <translation>Linjetjocklek</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Maximum CPU usage for OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3471"/>
        <source>Once in 3 months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="263"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2527"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="801"/>
        <source>Font</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="947"/>
        <source>Highlight</source>
        <translation>Belys</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="958"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="963"/>
        <source>Invert</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="968"/>
        <source>OutLine</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Insert</source>
        <translation>Infoga</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="828"/>
        <source>Check</source>
        <translation>Bock</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="843"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="848"/>
        <source>Square</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation>Stödlinjer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation>Nätverk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1384"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1411"/>
        <source>Width between lines</source>
        <translation>Bredd mellan linjer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1444"/>
        <source>Height between lines</source>
        <translation>Höjd mellan linjer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Left offset</source>
        <translation>Förskjutning vänster</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1391"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1484"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1520"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1437"/>
        <source>Top offset</source>
        <translation>Förskjutning överkant</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1451"/>
        <source>Subdivision</source>
        <translation>Indelning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1615"/>
        <source>Enable safe reading mode</source>
        <translation>Aktivera säkert läsläge</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1707"/>
        <source>Measurements</source>
        <translation>Mätning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1712"/>
        <source>Drawing</source>
        <translation>Rita</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1098"/>
        <source>Selected text color</source>
        <translation>Aktuell textfärg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Fusion</source>
        <translation type="vanished">Fusion</translation>
    </message>
    <message>
        <source>Plastique</source>
        <translation type="vanished">Plastique</translation>
    </message>
    <message>
        <source>CleanLooks</source>
        <translation type="vanished">CleanLooks</translation>
    </message>
    <message>
        <source>Motif</source>
        <translation type="vanished">Motif</translation>
    </message>
    <message>
        <source>CDE</source>
        <translation type="vanished">CDE</translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="vanished">Mörk stil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2431"/>
        <source>Application Style</source>
        <translation>Programstil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2610"/>
        <source>Use default program</source>
        <translation>Använd standardprogram</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>evolution</source>
        <translation>Evolution</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2634"/>
        <source>kmail</source>
        <translation>KMail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2639"/>
        <source>thunderbird</source>
        <translation>Thunderbird</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2647"/>
        <source>Use SMTP</source>
        <translation>Använd SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2670"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2758"/>
        <source>Email address</source>
        <translation>E-postadress</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Secure connections</source>
        <translation>Säker anslutning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2726"/>
        <source>NONE</source>
        <translation>INGEN</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2736"/>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2718"/>
        <source>SMTP server</source>
        <translation>SMTP-server</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>User</source>
        <translation>Användare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2744"/>
        <source>SMTP port</source>
        <translation>SMTP-port</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2691"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3101"/>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2950"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>Standardsökväg till tesseract ocr-datafiler</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2923"/>
        <source>Additional tesseract ocr config file</source>
        <translation>Anpassad tesseract ocr config-fil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2943"/>
        <source>Install languages</source>
        <translation>Installera språk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2980"/>
        <source>Direct internet connection</source>
        <translation>Direktanslutning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2990"/>
        <source>Manual proxy configuration</source>
        <translation>Manuell proxykonfiguration</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3006"/>
        <source>HTTP Proxy</source>
        <translation>HTTP proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3013"/>
        <source>SOCKS 5 Proxy</source>
        <translation>SOCKS 5 Proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3023"/>
        <source>Host</source>
        <translation>Värddator</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3033"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2679"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3076"/>
        <source>Authentication</source>
        <translation>Autentisering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3091"/>
        <source>User name</source>
        <translation>Användarnamn</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="501"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1929"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1949"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1969"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2519"/>
        <source>Icon set</source>
        <translation>Ikonuppsättning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation>Tangentbord</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="349"/>
        <source>Show Start page</source>
        <translation>Visa startsida</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1419"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1424"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1429"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="450"/>
        <source>Load all objects separately</source>
        <translation>Läs in alla objekt separat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1353"/>
        <source>Always show Object Inspector</source>
        <translation>Visa alltid objektgranskaren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2262"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Tillåt inte filer att aktivera helskärmsläge vid öppning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1717"/>
        <source>Typewriter</source>
        <translation>Skrivmaskin</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>Light</source>
        <translation>Ljus</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>Dark</source>
        <translation>Mörk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <source>Exact match only</source>
        <translation>Endast exakt matchning</translation>
    </message>
    <message>
        <source>Redation</source>
        <translation type="vanished">Sekretessredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation>Certifikat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1360"/>
        <source>Save last editing Tool</source>
        <translation>Spara senaste redigeringsverktyget</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3228"/>
        <source>Default paths for system certificates</source>
        <translation>Standardsökvägar för systemcertifikat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3176"/>
        <source>Certificate Manager</source>
        <translation>Certifikathanterare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="810"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>I Windows lagras alla certifikat i systemmappen.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="421"/>
        <source>Alternative method for PDF render</source>
        <translation>Alternativ metod för PDF-rendering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="473"/>
        <source>Memory/Speed</source>
        <translation>Minne/Hastighet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="480"/>
        <source>Minimize memory usage</source>
        <translation>Minimera minnesanvändning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="485"/>
        <source>Maximal render speed</source>
        <translation>Maximal renderingshastighet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="829"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1139"/>
        <source>System Theme</source>
        <translation>Systemtema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3238"/>
        <source>Database for Certificate Manager</source>
        <translation>Databas för certifikathanterare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3298"/>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3254"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3271"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3305"/>
        <source>Path for DB:</source>
        <translation>Sökväg till databas:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation>Sekretessredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="815"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>I macOS lagras alla certifikat i systemmappen.</translation>
    </message>
    <message>
        <source>Farsi</source>
        <translation type="vanished">Farsi</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation>Tillåt öppning av samma dokument i flera flikar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="998"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1004"/>
        <source>Add full path to filename in export file</source>
        <translation>Lägg till fullständig sökväg till filnamnet i exportfil</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="991"/>
        <source>Recreate pdf forms when opening</source>
        <translation>Återskapa PDF-formulär vid öppning</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="830"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1143"/>
        <source>Light Theme</source>
        <translation>Ljust tema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="831"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1147"/>
        <source>Dark Theme</source>
        <translation>Mörkt tema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation>Vektygsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2499"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2504"/>
        <source>Office Pro</source>
        <translation>Office Pro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1367"/>
        <source>Edit Text Elements as Blocks</source>
        <translation>Redigera textelement som block</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2041"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2489"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2532"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2537"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Save recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2217"/>
        <source>Navigation Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Page Only</source>
        <translation type="unfinished">Endast sida</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished">Bokmärkesfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2247"/>
        <source>Pages Panel</source>
        <translation type="unfinished">Sidfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3334"/>
        <source>Strong verification of signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="255"/>
        <source>PDF Specification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Ta bort objekt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="139"/>
        <source>File</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="159"/>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <source>New</source>
        <translation>Nytt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Save As...</source>
        <translation>Spara som...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="896"/>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2432"/>
        <source>Recent Files</source>
        <translation>Tidigare filer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="743"/>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Exit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="938"/>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>First Page</source>
        <translation>Första sidan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Previous Page</source>
        <translation>Föregående sida</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Next Page</source>
        <translation>Nästa sida</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Last Page</source>
        <translation>Sista sidan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="207"/>
        <source>Zoom</source>
        <translation>Zooma</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="604"/>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <source>Zoom In</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Zoom Out</source>
        <translation>Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Actual Size</source>
        <translation>Egentlig storlek</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="291"/>
        <source>Toolbars</source>
        <translation>Vektygsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <source>Statusbar</source>
        <translation>Statusfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="289"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>Hand Tool</source>
        <translation>Handverktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Register...</source>
        <translation>Registrering...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Sök efter uppdatering</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">Exportera till</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <location filename="../../src/mainwindow.ui" line="771"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Förstora sidminiatyrer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Förminska sidminiatyrer</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Infoga sidor från PDF</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Extrahera sidor till PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Highlight Fields</source>
        <translation>Belys alla fält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <location filename="../../src/mainwindow.cpp" line="5944"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1127"/>
        <source>Properties</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2003"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Infoga</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1161"/>
        <source>Highlight Text</source>
        <translation>Belys</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <source>Underline Text</source>
        <translation>Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1169"/>
        <source>Strikeout Text</source>
        <translation>Styk över</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2011"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="71"/>
        <source>Attachment</source>
        <translation>Bilaga</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>Check box</source>
        <translation>Kryssruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1278"/>
        <source>Radio button</source>
        <translation>Alternativknapp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <location filename="../../src/mainwindow.ui" line="1302"/>
        <source>Button</source>
        <translation>Knapp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>List box</source>
        <translation>Listruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1286"/>
        <source>Combo box</source>
        <translation>Kombinationsruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Edit Box</source>
        <translation>Redigeringsruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2802"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Dokumentet &quot;%s&quot; har ändrats.
Vill du spara ändringarna?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="279"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="58"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2619"/>
        <source>Cannot open file :
</source>
        <translation>Kan inte öppna filen:
</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="203"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">Din version är den senaste!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Edit Document</source>
        <translation>Redigera dokument</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1242"/>
        <source>Link</source>
        <translation>Länk</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="426"/>
        <location filename="../../src/mainwindow.ui" line="1386"/>
        <source>Comments</source>
        <translation>Kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>Add Sticky Note</source>
        <translation>Lägg till anteckning</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <location filename="../../src/mainwindow.cpp" line="5976"/>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="590"/>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="709"/>
        <source>There was an error opening the document !</source>
        <translation>Ett fel inträffade när dokumentet skulle öppnas!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1075"/>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <source>Page layout</source>
        <translation>Sidlayout</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Infoga en tom sida </translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Infoga sidor</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Ta bort sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1995"/>
        <source>Pages</source>
        <translation>Sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Redo</source>
        <translation>Upprepa</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="880"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Create a new blank PDF</source>
        <translation>Skapa ny tom PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="505"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Skriv ut (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skriv ut dokumentet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="732"/>
        <location filename="../../src/mainwindow.ui" line="735"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1191"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <source>Send to Back</source>
        <translation>Placera underst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Placera underst&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Placera markerat objekt underst.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_mac_tool_bars.cpp" line="20"/>
        <source>Main</source>
        <translation>Primär</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1325"/>
        <source>Home page</source>
        <translation>Hemsida</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ångra (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ångra senaste åtgärden&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="635"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Contents</source>
        <translation>Innehåll</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Upprepa (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;Upprepa föregående ångrade åtgärd.&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klipp ut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klipp ut markerade objekt och placer dem i urklipp&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopiera (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopiera markerade objekt och placer dem i urklipp&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="796"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Select Text</source>
        <translation>Markera text</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2618"/>
        <source>Open failed</source>
        <translation>Kunde inte öppna</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="232"/>
        <source>Empty recent files list</source>
        <translation>Rensa tidigare filer</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation type="vanished">Export slutförd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1081"/>
        <location filename="../../src/mainwindow.cpp" line="1212"/>
        <location filename="../../src/mainwindow.cpp" line="3025"/>
        <location filename="../../src/mainwindow.cpp" line="4331"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <location filename="../../src/mainwindow.cpp" line="4569"/>
        <source>Save failed</source>
        <translation>Kunde inte spara</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Filen kanske är skrivskyddad eller används av annat program.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6062"/>
        <location filename="../../src/mainwindow.cpp" line="6064"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="vanished">Alla filer (*.pdf *.xps);;PDF-filer (*.pdf);;XPS-filer (*.xps)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>Find</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Find Next</source>
        <translation>Sök nästa</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="57"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Ny version finns tillgänglig!
Vill du ladda ner den nu?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>Close Without Saving</source>
        <translation>Stäng utan att spara</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2813"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <location filename="../../src/mainwindow.ui" line="1089"/>
        <source>Rotate Pages</source>
        <translation>Rotera sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Move Pages</source>
        <translation>Flytta sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1930"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Edit Text</source>
        <translation>Redigera text</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Object Inspector</source>
        <translation>Objektgranskare</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1117"/>
        <location filename="../../src/mainwindow.cpp" line="7130"/>
        <location filename="../../src/mainwindow.cpp" line="7192"/>
        <location filename="../../src/mainwindow.cpp" line="7341"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>Align Objects</source>
        <translation>Justera objekt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1210"/>
        <location filename="../../src/mainwindow.ui" line="1213"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <location filename="../../src/mainwindow.ui" line="1705"/>
        <source>Line</source>
        <translation>Linje</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1218"/>
        <location filename="../../src/mainwindow.ui" line="1221"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <location filename="../../src/mainwindow.ui" line="1727"/>
        <source>Rectangle</source>
        <translation>Rektangel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1226"/>
        <location filename="../../src/mainwindow.ui" line="1229"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Ellipse</source>
        <translation>Ellips</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Utskriftsgranskning</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Left</source>
        <translation>Justera mot vänsterkant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>Align Right</source>
        <translation>Justera mot högerkant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1048"/>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Align Top</source>
        <translation>Justera mot överkant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Align Bottom</source>
        <translation>Justera mot underkant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1307"/>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <location filename="../../src/mainwindow.ui" line="966"/>
        <source>Set Fit to Page</source>
        <translation>Anpassa till sidan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3066"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Ett fel inträffade vid signaturverifiering!</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klistra in (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klistra in från urklipp&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="167"/>
        <source>Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="245"/>
        <source>Navigation Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Forms</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="510"/>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Home</source>
        <translation>Hem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>End</source>
        <translation>Slut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>Reset Forms</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Fit Width</source>
        <translation>Anpassa bredd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="757"/>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Facing Pages</source>
        <translation>Bokuppslag</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Delete Pages</source>
        <translation>Ta bort sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Edit Forms</source>
        <translation>Redigera formulär</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <source>Bring to Front</source>
        <translation>Placera överst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Placera överst&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Placera markerat objekt överst.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1097"/>
        <location filename="../../src/mainwindow.ui" line="1100"/>
        <source>Extract Pages...</source>
        <translation>Extrahera sidor...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1108"/>
        <location filename="../../src/mainwindow.ui" line="1111"/>
        <source>Insert Pages...</source>
        <translation>Infoga sidor...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <location filename="../../src/mainwindow.ui" line="1237"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <location filename="../../src/mainwindow.ui" line="1749"/>
        <source>Pencil</source>
        <translation>Penna</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1159"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-filer (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Open a PDF file</source>
        <translation>Öppna en PDF-fil</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1262"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="vanished">Spara i XPS, stöds för närvarande inte.
Välj PDF för att spara.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="vanished">Öppna objektgranskaren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation>Beskär sidor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">Föreg./Nästa</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">Redigeringsverktyg</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">Sidan:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1906"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="649"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1056"/>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <source>Insert Blank Pages</source>
        <translation>Infoga tomma sidor</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation type="vanished">Ctrl+Shift+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1410"/>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotera 90 grader medurs</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1418"/>
        <location filename="../../src/mainwindow.ui" line="1421"/>
        <location filename="../../src/mainwindow.ui" line="1424"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotera 90 grader moturs</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7139"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7201"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-filer (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <source>Export Form Data...</source>
        <translation>Exportera formulärdata...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1434"/>
        <source>Import Form Data...</source>
        <translation>Importera formulärdata...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1439"/>
        <source>Export Comments Data...</source>
        <translation>Exportera kommentarsdata...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1444"/>
        <source>Import Comments Data...</source>
        <translation>Importera kommentarsdata...</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Öppna fil (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Öppna en PDF- eller XPS-fil&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="544"/>
        <source>Select text for copying and pasting</source>
        <translation>Markera text för kopiering och inklistring</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Spara (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Spara dokumentet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Save the document</source>
        <translation>Spara dokumentet</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Spara som PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Spara dokumentet med nytt namn&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="710"/>
        <source>Save the document with a new name</source>
        <translation>Spara dokumentet med nytt namn</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>Print the document</source>
        <translation>Skriv ut dokumentet</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera dokument (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Välj och redigera text, bilder, notiser, formulärfält ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="793"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Välj och redigera text, bilder, notiser, formulärfält ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="810"/>
        <source>Select text for editing</source>
        <translation>Markera text för redigering</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Ta bort objekt (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Ta bort markerade objekt&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Ta bort markerade objekt</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nytt (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Skapa en ny tom PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="916"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Klipp ut markerade objekt och placera i urklipp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="930"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Kopiera markerade objekt och placera i urklipp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Paste from the Clipboard</source>
        <translation>Klistra in från urklipp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <source>Undo the last action</source>
        <translation>Ångra senaste åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Redo the previously undone action.</source>
        <translation>Upprepa föregående ångrade åtgärd.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Send to Back selected object.</source>
        <translation>Placera markerat objekt underst.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Bring to Front selected object.</source>
        <translation>Placera markerat objekt överst.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Egenskaper (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Öppna ett fönster med dokumentegenskaper&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Open window with document properties</source>
        <translation>Öppna fönster med dokumentegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Anteckning&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klicka på sidan för att placera en notis vid den positionen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <source>Click the page to add a note at that position</source>
        <translation>Klicka på sidan för att placera en notis vid den positionen</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Infoga text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Infoga ny text på aktuell sida&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Insert new text to current page</source>
        <translation>Infoga ny text på aktuell sida</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Infoga bild (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Infoga ny bild på aktuell sida&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>Insert new image to current page</source>
        <translation>Infoga ny bild på aktuell sida</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Infoga länk (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Infoga ny länk på aktuell sida&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>Insert new link to current page</source>
        <translation>Infoga ny länk på aktuell sida</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Markera text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera text för kopiering och inklistring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1449"/>
        <source>Save Optimized As...</source>
        <translation>Spara optimerad som...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation type="vanished">Tecken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5939"/>
        <source>Font type</source>
        <translation>Teckensnittstyp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5941"/>
        <source>Font Embedded</source>
        <translation>Inbäddat teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5950"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5959"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5967"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5972"/>
        <location filename="../../src/mainwindow.cpp" line="6196"/>
        <source>Width</source>
        <translation>Bredd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5973"/>
        <location filename="../../src/mainwindow.cpp" line="6197"/>
        <source>Height</source>
        <translation>Höjd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5974"/>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5980"/>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5984"/>
        <source>Shading</source>
        <translation>Skuggor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="1946"/>
        <source>Objects</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6224"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6005"/>
        <location filename="../../src/mainwindow.cpp" line="6211"/>
        <source>Selected</source>
        <translation>Markerat</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1463"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1620"/>
        <location filename="../../src/mainwindow.cpp" line="1647"/>
        <source>Can&apos;t find :</source>
        <translation>Kan inte hitta:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5943"/>
        <source>Font Not Embedded</source>
        <translation>Teckensnitt ej inbäddat</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera formulär (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Välj formulär och anteckningar för redigering&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Välj text för redigering&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Handverktyg (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Använd handverktyget för att flytta sidor, öppna länkar och markera text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="624"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1476"/>
        <source>Document JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1481"/>
        <source>Document Actions</source>
        <translation>Dokumentåtgärder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Replace Document Colors</source>
        <translation>Ersätt dokumentfärger</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Utskriftsgranskning (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Granska dokumentet före utskrift.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Paste to Multiple Pages</source>
        <translation>Klistra in på flera sidor</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste to Multiple Pages (Ctrl+Shig+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard to Multiple Pages&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klistra in på flera sidor (Ctrl+Shig+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klistra in från urklipp på flera sidor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2075"/>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Shift+V</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation type="vanished">Din installerade Qt-version</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>JavaScript Console</source>
        <translation>JavaScript-konsoll</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>Page Properties</source>
        <translation>Sidegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="376"/>
        <source>Watermark</source>
        <translation>Vattenstämpel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Background</source>
        <translation>Bakgrund</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="430"/>
        <source>Measurements</source>
        <translation>Mätning</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <location filename="../../src/mainwindow.cpp" line="3180"/>
        <source>Drawing</source>
        <translation>Rita</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">Stämplar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Blank PDF</source>
        <translation>Tom PDF</translation>
    </message>
    <message>
        <source>Shift+I</source>
        <translation type="vanished">Shift+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1521"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1537"/>
        <source>Menu Bar</source>
        <translation>Menyfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1540"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>Show Cover Page During Facing</source>
        <translation>Visa omslagssida vid bokuppslag</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Full Screen</source>
        <translation>Helskärm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1559"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1590"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Align Center Horizontal</source>
        <translation>Centrera horisontellt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Vertical</source>
        <translation>Centrera vertikalt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <source>Find Previous</source>
        <translation>Sök föregående</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <source>Shift+T</source>
        <translation type="vanished">Shift+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1619"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;E-postleverans&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skicka fil via e-post&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <location filename="../../src/mainwindow.ui" line="1644"/>
        <source>Grid</source>
        <translation>Stödlinjer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1647"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Snap to Grid</source>
        <translation>Fäst vid stödlinje</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1661"/>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <location filename="../../src/mainwindow.ui" line="1672"/>
        <source>Distance Tool</source>
        <translation>Distansverktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <location filename="../../src/mainwindow.ui" line="1683"/>
        <source>Perimeter Tool</source>
        <translation>Omkretsverktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <location filename="../../src/mainwindow.ui" line="1694"/>
        <source>Area Tool</source>
        <translation>Ytverktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <location filename="../../src/mainwindow.ui" line="1716"/>
        <source>Arrow</source>
        <translation>Pil</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <location filename="../../src/mainwindow.ui" line="1760"/>
        <source>Attach a File as a Comment</source>
        <translation>Bifoga en fil som kommentar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <source>From Scanner</source>
        <translation>Från skanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <location filename="../../src/mainwindow.ui" line="1771"/>
        <source>Create a new document from scanner</source>
        <translation>Skapa nytt dokument från skanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <source>From Files</source>
        <translation>Från filer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <location filename="../../src/mainwindow.ui" line="1782"/>
        <source>Create a new document from files</source>
        <translation>Skapa nytt dokument från filer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <location filename="../../src/mainwindow.ui" line="1801"/>
        <source>Brush</source>
        <translation>Pensel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF Editor kan inte hitta sidhuvuden eller sidfötter i dokumentet.</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="vanished">Vill du ta bort sidhuvuden och sidfötter från dokumentet?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3606"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor kan inte hitta några vattenstämplar i dokumentet.</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="vanished">Vill du ta bort vattenstämplarna från dokumentet?</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="vanished">Master PDF Editor kan inte hitta någon bakgrund i dokumentet.</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="vanished">Vill du ta bort bakgrunden från dokumentet?</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Bildiler (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Öppna fil (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Öppna en PDF- eller XPS-fil&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Spara (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Spara dokumentet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Spara som PDF(Ctrl+Shift+S&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Spara dokumentet med nytt namn&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ta bort objekt (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ta bort markerade objekt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nytt (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skapa en ny tom PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny text på aktuell sida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga bild (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny bild på aktuell sida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga länk (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny länk på aktuell sida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Egenskaper (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Öppna ett fönster med dokumentegenskaper&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="367"/>
        <source>Header and Footer</source>
        <translation>Sidhuvud och sidfot</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>Check Box</source>
        <translation>Kryssruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Radio Button</source>
        <translation>Alternativknapp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Combo Box</source>
        <translation>Kombinationsruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <source>List Box</source>
        <translation>Listruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Text Field</source>
        <translation>Textfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Menu</source>
        <translation>Menyfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1820"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5938"/>
        <source>Characters</source>
        <translation>Tecken</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Alla filer (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="215"/>
        <source>Page Display</source>
        <translation>Sidvisning</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Go To</source>
        <translation>Sidnavigering</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="237"/>
        <location filename="../../src/mainwindow.ui" line="2019"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1721"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Starta om programmet för att tillämpa ändringarna.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1633"/>
        <source>Send file via email</source>
        <translation>Skicka fil via e-post</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation type="vanished">Alla filer som stöds (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</translation>
    </message>
    <message>
        <source>Text Box</source>
        <translation type="vanished">Textruta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Callout</source>
        <translation>Pratbubbla</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1835"/>
        <source>Formatted Text</source>
        <translation>Formaterad text</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga Formaterad text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny Formaterad text på aktuell sida&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Typewriter</source>
        <translation>Skrivmaskin</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera formulär (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Välj formulär för redigering&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <location filename="../../src/mainwindow.ui" line="1877"/>
        <source>Redaction</source>
        <translation>Sekretessredigering</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+6)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Handverktyg (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Använd handverktyget för att flytta sidor, öppna länkar och markera text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {6)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+7)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Markera text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera text för kopiering och inklistring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {7)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <source>Alt+7</source>
        <translation>Alt+7</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <source>Check for Updates</source>
        <translation>Sök efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Mark for Redaction</source>
        <translation>Markera för sekretessredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1851"/>
        <source>Apply Redactions</source>
        <translation>Tillämpa sekretessredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1856"/>
        <source>Redaction Properties</source>
        <translation>Sekretessredigeringsalternativ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1864"/>
        <source>Show Redaction ToolBar</source>
        <translation>Visa verktygsfält för sekretessredigering</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1869"/>
        <source>Search and Redact</source>
        <translation>Sök och sekretessredigera</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1882"/>
        <source>Certificate Manager</source>
        <translation>Certifikathanterare</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1887"/>
        <source>Send Backward</source>
        <translation>Skicka bakåt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1892"/>
        <source>Bring Forward</source>
        <translation>Skicka framåt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1900"/>
        <source>Edit Vector Images</source>
        <translation>Redigera vektorbilder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1911"/>
        <source>Next View</source>
        <translation>Nästa vy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1916"/>
        <source>Previous View</source>
        <translation>Föregående vy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1924"/>
        <source>Edit Images</source>
        <translation>Redigera bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1935"/>
        <location filename="../../src/mainwindow.cpp" line="3307"/>
        <source>Show Comments List</source>
        <translation>Visa kommentarslista</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="462"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation>Du har inte behörighet för detta krypterade dokument.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="464"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>Det är krypterat med certifikat som saknas i ditt system.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="477"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1043"/>
        <source>File is opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1045"/>
        <source>Use Save As... to save your work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2897"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3147"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="100"/>
        <source>All Reviewers</source>
        <translation>Alla granskare</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3285"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="80"/>
        <source>Hide All Comments</source>
        <translation>Dölj alla kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3290"/>
        <source>Show All Comments</source>
        <translation>Visa alla kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3592"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3627"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3634"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5319"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>Master PDF Editor kan inte hitta någon sekretessredigering i detta dokument!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6199"/>
        <source>Format</source>
        <translation type="unfinished">Format</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6900"/>
        <source>Failed to restore last open session:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7437"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7438"/>
        <source>Document doesn&apos;t contain any tables with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="79"/>
        <source>Comment View</source>
        <translation>Kommentarsvy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="93"/>
        <source>Show by Type</source>
        <translation>Visa efter typ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3171"/>
        <source>All Types</source>
        <translation>Alla typer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3176"/>
        <source>Notes</source>
        <translation>Anteckningar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3184"/>
        <source>Text Editing Markups</source>
        <translation>Textredigeringsmarkeringar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3188"/>
        <source>Stamps</source>
        <translation>Stämplar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3192"/>
        <source>Attachments</source>
        <translation>Bilagor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="97"/>
        <source>Show by Reviewer</source>
        <translation>Visa efter granskare</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="107"/>
        <source>Show by Status</source>
        <translation>Visa efter status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3217"/>
        <source>All Status</source>
        <translation>All status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3222"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Visa</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="45"/>
        <source>You already have the latest version!</source>
        <translation>Du har redan senaste version!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>Alla filer som stöds (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF-filer (*.pdf *.PDF);;FDF-filer (*.fdf *.FDF);;XPS-filer (*.xps *.XPS);;TIFF-filer (*.tif *.tiff);;Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3303"/>
        <source>Hide Comments List</source>
        <translation>Dölj kommentarslistan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>File is locked by another Master PDF Editor instance, it will be opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="433"/>
        <source>You will be able to save your work, but only to another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="vanished">pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="616"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="635"/>
        <source>Place Initials</source>
        <translation>Placera initialer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="617"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="636"/>
        <source>Create New Initials</source>
        <translation>Skapa nya initialer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="619"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="638"/>
        <source>Open Containing Folder</source>
        <translation>Öppna målmapp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Öppna fil&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Öppna en PDF- eller XPS-fil&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Handverktyg&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Använd handverktyget för att flytta sidor, öppna länkar och markera text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Markera text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera text för kopiering och inklistring.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Spara&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Spara dokumentet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Spara som...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Spara dokumentet med nytt namn.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>System Print...</source>
        <translation>Systemutskrift...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Systemutskriftsdialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skriv ut med hjälp av systemdialogen...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera dokument&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera och redigera text, bilder, notiser, formulärfält ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera textobjekt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera text för redigering.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ta bort objekt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ta bort de markerade objekten&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera formulär&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera formulärfält för redigering.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nytt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skapa en ny tom PDF.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Skriv ut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Skriv ut dokumentet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="913"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klipp ut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klipp ut de markerade objekten och placera dem i urklipp.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopiera&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopiera de markerade objekten och placera dem i urklipp.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klistra in&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klistra in från urklipp.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ångra&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ångra senaste åtgärden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Upprepa&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Upprepa den senast ångrade åtgärden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1130"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Egenskaper&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Öppna ett fönster med dokumentsegenskaper.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny text på aktuell sida.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga bild&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny bild på aktuell sida.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Infoga länk&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Infoga ny länk på aktuell sida.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Ctrl+Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera vektorbilder&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera vektorbilder för redigering.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redigera bilder&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Markera bitmap-bilder för redigering.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1987"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2027"/>
        <source>Signatures</source>
        <translation type="unfinished">Signaturer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2035"/>
        <source>Layers</source>
        <translation type="unfinished">Lager</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2043"/>
        <source>Object TreeView</source>
        <translation type="unfinished">Objektträdvy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2051"/>
        <source>Document Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2056"/>
        <source>Organize Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2064"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished">Redigera textelement som block</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2069"/>
        <location filename="../../src/mainwindow.ui" line="2072"/>
        <source>Paste at Copy Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2080"/>
        <source>Pages to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2088"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2096"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2101"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2104"/>
        <source>Manage Header And Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2109"/>
        <source>Add To Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2114"/>
        <source>Open session from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2119"/>
        <source>Save session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2124"/>
        <source>Managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2129"/>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2134"/>
        <source>Action</source>
        <translation type="unfinished">Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2139"/>
        <source>Clear recent sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2144"/>
        <source>Save session to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2149"/>
        <source>Current Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2154"/>
        <source>Save session to managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2159"/>
        <source>Save and close current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2164"/>
        <source>Delete across pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="149"/>
        <source>Export</source>
        <translation>Exportera</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Pages to Images</source>
        <translation>Sidor till bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Pages to Text</source>
        <translation>Sidor till text</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1951"/>
        <source>Extract all Images</source>
        <translation>Extrahera alla bilder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1434"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG-bilder (*.png);;BMP-bilder (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1956"/>
        <source>Reload</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1964"/>
        <source>Take a Snapshot</source>
        <translation>Ta en ögonblicksbild</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="249"/>
        <source>Red</source>
        <translation>Röd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="254"/>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="259"/>
        <source>Yellow</source>
        <translation>Gul</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="264"/>
        <source>Green</source>
        <translation>Grön</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="63"/>
        <source>What&apos;s new</source>
        <translation>Vad är nytt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="551"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>Filen du försöker öppna, innehåller kommentarer eller formulärdata som ska placeras på</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>This document cannot be found.</source>
        <translation>Detta dokument kan inte hittas.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>Vill du bläddra och försöka hitta detta dokumen?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1672"/>
        <source>Saved Settings</source>
        <translation>Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="26"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation>Kan inte ansluta! Kontrollera att du är ansluten till internet och försök uppdatera igen.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1969"/>
        <source>Toolbar Settings</source>
        <translation>Inställningar för verktygsfält</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">E-postleverans</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Infoga text</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Anteckning</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="vanished">Enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1977"/>
        <source>Continuous</source>
        <translation>Fortlöpande</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Textblock</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <source>Insert Initials</source>
        <translation>Infoga initialer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5159"/>
        <location filename="../../src/mainwindow.cpp" line="5181"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Vill du verkligen återställa alla inställningar för verktygsfälten, till standardinställning?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="302"/>
        <source>Reset toolbars</source>
        <translation>Återställ verktygsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Minimum tools</source>
        <translation type="unfinished">Minsta anatal verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="61"/>
        <source>New Paragraph</source>
        <translation type="unfinished">Nytt stycke</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="114"/>
        <source>Delete All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="116"/>
        <source>Delete All Visible Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="299"/>
        <source>Maximum tools</source>
        <translation type="unfinished">Max antal verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="82"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="250"/>
        <location filename="../../src/mainwindow_update.cpp" line="357"/>
        <source>Error</source>
        <translation type="unfinished">Fel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="252"/>
        <location filename="../../src/mainwindow_update.cpp" line="359"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished">Aktivering misslyckades! Kontrollera internetanslutningen.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="297"/>
        <source>License is expired!</source>
        <translation type="unfinished">Licensen har upphört att gälla!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="71"/>
        <location filename="../../src/mainwindow_update.cpp" line="300"/>
        <location filename="../../src/mainwindow_update.cpp" line="504"/>
        <source>Renew</source>
        <translation type="unfinished">Förnya</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="68"/>
        <source>WARNING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="338"/>
        <source>Too many activations!</source>
        <translation type="unfinished">Många aktiveringar!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="394"/>
        <source>Server connection lost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="445"/>
        <source>Failed to connect to License server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="516"/>
        <source>Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <source>Label</source>
        <translation type="unfinished">Etikett</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6222"/>
        <source>Rotate</source>
        <translation type="unfinished">Rotera</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="54"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="55"/>
        <source>Circle</source>
        <translation type="unfinished">Cirkel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="56"/>
        <source>Comment</source>
        <translation type="unfinished">Kommentar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="57"/>
        <source>Cross</source>
        <translation type="unfinished">Kryss</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="60"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="62"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="63"/>
        <source>Paragraph</source>
        <translation type="unfinished">Stycke</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Right Arrow</source>
        <translation type="unfinished">Höger pil</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="65"/>
        <source>Right Pointer</source>
        <translation type="unfinished">Höger pekare</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="66"/>
        <source>Star</source>
        <translation type="unfinished">Stjärna</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="67"/>
        <source>Up Arrow</source>
        <translation type="unfinished">Pil upp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="68"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">Upp vänster pil</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="69"/>
        <source>Graph</source>
        <translation type="unfinished">Diagram</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="70"/>
        <source>Paper Clip</source>
        <translation type="unfinished">Gem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="72"/>
        <source>Tag</source>
        <translation type="unfinished">Tagg</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1982"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="62"/>
        <source>Failed opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="67"/>
        <source>File is already opened and opening same file in multiple tabs option is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="72"/>
        <source>File does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="319"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="323"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>Current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="376"/>
        <source>Error loading session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="20"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="27"/>
        <source>Close</source>
        <translation type="unfinished">Stäng</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="34"/>
        <source>Edit</source>
        <translation type="unfinished">Redigera</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="41"/>
        <source>Remove</source>
        <translation type="unfinished">Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="48"/>
        <source>Zoom In</source>
        <translation type="unfinished">Zooma in</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished">Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="65"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="72"/>
        <source>Zoom Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="79"/>
        <source>Show</source>
        <translation type="unfinished">Visa</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="14"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="82"/>
        <source>Manage Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="113"/>
        <source>All</source>
        <translation type="unfinished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="117"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="510"/>
        <source>Header and Footer</source>
        <translation type="unfinished">Sidhuvud och sidfot</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="119"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="513"/>
        <source>Bates Numbering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="263"/>
        <source>All Pages</source>
        <translation type="unfinished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="516"/>
        <source>Type</source>
        <translation type="unfinished">Typ</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="517"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="518"/>
        <source>Page Range</source>
        <translation type="unfinished">Sidintervall</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="519"/>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Left</source>
        <translation type="unfinished">Vänster</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Center</source>
        <translation type="unfinished">Centrera</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Right</source>
        <translation type="unfinished">Höger</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="525"/>
        <source>Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="635"/>
        <source>Remove Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="639"/>
        <source>Do you want to remove selected Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="643"/>
        <source>Do you want to remove selected headers/footers from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="657"/>
        <source>Remove all Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="658"/>
        <source>Do you want to remove all headers, footers and Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>Identifierad text</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="25"/>
        <source>Not Text</source>
        <translation>Inte text</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Flytta sidor</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="43"/>
        <source>Destination</source>
        <translation>Målplats</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="55"/>
        <source>To:</source>
        <translation>Till:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="65"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>First</source>
        <translation>Först</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="121"/>
        <source>Last</source>
        <translation>Sist</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Sidstorlek</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="49"/>
        <source>Width</source>
        <translation>Bredd</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="86"/>
        <source>Height</source>
        <translation>Höjd</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="vanished">A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="vanished">A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="vanished">A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="vanished">A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="vanished">A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="vanished">A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="vanished">A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="vanished">A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="vanished">A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="vanished">A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="vanished">A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="vanished">Anpassad sidstorlek</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>Portrait</source>
        <translation>Stående</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>Landscape</source>
        <translation>Liggande</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="151"/>
        <source>Contents Size</source>
        <translation>Innehållsstorlek</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>Left margin</source>
        <translation>Vänster marginal</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="203"/>
        <source>Top margin</source>
        <translation>Övre marginal</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="183"/>
        <source>Right margin</source>
        <translation>Höger marginal</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Bottom margin</source>
        <translation>Undre marginal</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="246"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="252"/>
        <source>Before current page</source>
        <translation>Före aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="269"/>
        <source>After current page</source>
        <translation>Efter aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="276"/>
        <source>After last page</source>
        <translation>Efter sista sidan</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="262"/>
        <source>Before first page</source>
        <translation>Före första sidan</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="286"/>
        <source>Number of pages</source>
        <translation>Antal sidor</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="312"/>
        <source>Page(s)</source>
        <translation>Sidor</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="292"/>
        <source>Create</source>
        <translation>Skapa</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="vanished">Letter</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="vanished">Tabloid</translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="vanished">B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="vanished">B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="vanished">B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="vanished">B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="vanished">B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="vanished">B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="vanished">Uttalande</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="vanished">Verkställande</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="vanished">Folio</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="vanished">Kvartsformat</translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="vanished">Notis</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="vanished">ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="vanished">ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="vanished">ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="vanished">ANSI F</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="122"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>OCR-motor</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="164"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="43"/>
        <source>Languages</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="49"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="194"/>
        <source>Selected</source>
        <translation>Markerat</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="36"/>
        <source>Install languages</source>
        <translation>Installera språk</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="108"/>
        <source>Searchable Text</source>
        <translation>Sökbar text</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Editable Text</source>
        <translation>Redigerbar text</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="138"/>
        <source>Font Family</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="vanished">Redigera all identifierad text manuellt</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="201"/>
        <source>Force manual text editing if confidence level not achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="171"/>
        <source>Minimal confidence level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Linje</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="224"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="258"/>
        <source>Helvetica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="68"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>Vill du verkligen stoppa dokumentidentifieringen?</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="65"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Inga egenskaper.
Inga objekt har valts.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="223"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3778"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4059"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2379"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="288"/>
        <source>Property</source>
        <translation>Egenskap</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="293"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1597"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3153"/>
        <source>Top</source>
        <translation>Överkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2434"/>
        <source>Font Family</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3790"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2479"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4079"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3725"/>
        <source>Fill Color</source>
        <translation>Fyllnadsfärg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2541"/>
        <source>Stroke Color</source>
        <translation>Konturfärg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3578"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3639"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4029"/>
        <source>Opacity</source>
        <translation>Opacitet</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2408"/>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3163"/>
        <source>Width</source>
        <translation>Bredd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2819"/>
        <source>Height</source>
        <translation>Höjd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2431"/>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3934"/>
        <source>Form Field</source>
        <translation>Formulärfält</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3857"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1892"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1943"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Teckensnitt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt teckensnitt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3674"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="546"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sida</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="551"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="556"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Reset form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="566"/>
        <source>Show/Hide fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="571"/>
        <source>Submit a form</source>
        <translation>Skicka ett formulär</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="576"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="478"/>
        <source>Add an Action</source>
        <translation>Lägg till en åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="484"/>
        <source>Trigger</source>
        <translation>Utlösare</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="492"/>
        <source>Mouse Up</source>
        <translation>Mus upp</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="497"/>
        <source>Mouse Down</source>
        <translation>Mus ner</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="502"/>
        <source>Mouse Enter</source>
        <translation>Mus över</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="507"/>
        <source>Mouse Exit</source>
        <translation>Mus bort</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="512"/>
        <source>On Receive Focus</source>
        <translation>Vid fokusering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="517"/>
        <source>On Lose Focus</source>
        <translation>Vid avfokusering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="538"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="590"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="918"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="600"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3341"/>
        <source>Actions</source>
        <translation>Åtgärder</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1677"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2269"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3460"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="905"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="vanished">Upp-etikett</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="695"/>
        <source>Behavior</source>
        <translation>Beteende</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="849"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1821"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1976"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="371"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="854"/>
        <source>Push</source>
        <translation>Tryck</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Outline</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="864"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Invert</source>
        <translation>Invertera</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="vanished">Ner-etikett</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="vanished">RollOver-etikett</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="898"/>
        <source>Item</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="931"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1206"/>
        <source>Export Value</source>
        <translation>Exportera värde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="771"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="973"/>
        <source>Up</source>
        <translation>Upp</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="776"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="957"/>
        <source>Down</source>
        <translation>Ner</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1001"/>
        <source>Sort Items</source>
        <translation>Sortera objekt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="980"/>
        <source>Commit selected value immediately</source>
        <translation>Tillämpa det valda värdet omedelbart</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="994"/>
        <source>Multiple selection</source>
        <translation>Flerval</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="987"/>
        <source>Allow user to enter custom text</source>
        <translation>Tillåt anpassad text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1126"/>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1133"/>
        <source>Scrollable</source>
        <translation>Skrollbar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1140"/>
        <source>Check spelling</source>
        <translation>Kontrollera stavning</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1061"/>
        <source>Limit to</source>
        <translation>Begränsa till</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1075"/>
        <source>chars</source>
        <translation>tecken</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1082"/>
        <source>Split into</source>
        <translation>Dela i</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1054"/>
        <source>Allow Rich Text formatting</source>
        <translation>Tillåt textformatering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Multi-line</source>
        <translation>Flera rader</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <source>cells</source>
        <translation>celler</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1041"/>
        <source>Center</source>
        <translation>Centrera</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1046"/>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>Default Value</source>
        <translation>Standardvärde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Alignment</source>
        <translation>Justering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1219"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1230"/>
        <source>Check</source>
        <translation>Bock</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1235"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="347"/>
        <source>Circle</source>
        <translation>Cirkel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1240"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="349"/>
        <source>Cross</source>
        <translation>Kryss</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1250"/>
        <source>Square</source>
        <translation>Ruta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1255"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="358"/>
        <source>Star</source>
        <translation>Stjärna</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1183"/>
        <source>Checked by Default</source>
        <translation>Markerad som standard</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3768"/>
        <source>Line Thickness</source>
        <translation>Linjetjocklek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1386"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3718"/>
        <source>Border Color</source>
        <translation>Kantfärg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3761"/>
        <source>Line Style</source>
        <translation>Linjestil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3733"/>
        <source>Solid</source>
        <translation>Solid</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1406"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3738"/>
        <source>Dashed</source>
        <translation>Streckad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3753"/>
        <source>Underline</source>
        <translation>Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Highlight</source>
        <translation>Belys</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>OutLine</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Insert</source>
        <translation>Infoga</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1463"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signatur.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Inga tillgängliga alternativ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3360"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3479"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Format category</source>
        <translation>Formatkategori</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1826"/>
        <source>Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1831"/>
        <source>Percentage</source>
        <translation>Procentsats</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1836"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1841"/>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1846"/>
        <source>Special</source>
        <translation>Special</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1851"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2006"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="333"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="337"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1870"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="131"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1875"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="136"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1557"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1885"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1890"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1895"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1572"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1577"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1905"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1910"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1915"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1920"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1929"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1934"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1939"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1944"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Currency Symbol</source>
        <translation>Valutasymbol</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1981"/>
        <source>Dollar ($)</source>
        <translation>Dollar ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1986"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <source>Pound (£)</source>
        <translation>Pund (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1996"/>
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="vanished">Rubel (Руб)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Show parentheses</source>
        <translation>Visa paranteser</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2047"/>
        <source>Decimal Places</source>
        <translation>Decimalplacering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2054"/>
        <source>Separation Style</source>
        <translation>Separeringsstil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>Use red text</source>
        <translation>Använd röd text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Date Options</source>
        <translation>Datumalternativ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>Time Options</source>
        <translation>Tidsalternativ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2150"/>
        <source>Special Options</source>
        <translation>Specialalternativ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Format Script</source>
        <translation>Formatskript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2242"/>
        <source>KeyStroke Script</source>
        <translation>Tangentslagsskript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>Validate</source>
        <translation>Validera</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Validation Script</source>
        <translation>Valideringsskript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2349"/>
        <source>Calculate</source>
        <translation>Beräkna</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2370"/>
        <source>Calculation Script</source>
        <translation>Beräkningsskript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Fill text</source>
        <translation>Fylld text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2504"/>
        <source>Stroke Text</source>
        <translation>Konturtext</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Fill and Stroke</source>
        <translation>Fylld och kontur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Invisible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2554"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3626"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4016"/>
        <source>Line Width</source>
        <translation>Linjetjocklek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Character spacing</source>
        <translation>Teckenavstånd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Word spacing</source>
        <translation>Ordmellanrum</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2597"/>
        <source>Line spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2758"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2768"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2778"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2788"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished">Centrera vertikalt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2885"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2910"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2935"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2960"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2998"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3017"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2901"/>
        <source>Align Top</source>
        <translation type="unfinished">Justera mot överkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Align Right</source>
        <translation type="unfinished">Justera mot högerkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <source>Align Left</source>
        <translation type="unfinished">Justera mot vänsterkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">Centrera horisontellt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2995"/>
        <source>Align Bottom</source>
        <translation type="unfinished">Justera mot underkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <source>Send To Back</source>
        <translation type="unfinished">Placera längst bak</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3033"/>
        <source>Send Backward</source>
        <translation type="unfinished">Skicka bakåt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3052"/>
        <source>Bring Forward</source>
        <translation type="unfinished">Skicka framåt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3071"/>
        <source>Bring To Front</source>
        <translation type="unfinished">Placera längst fram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3143"/>
        <source>Coordinates</source>
        <translation>Koordinater</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3094"/>
        <source>Absolute</source>
        <translation>Absolut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3099"/>
        <source>Relative</source>
        <translation>Relativ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3189"/>
        <source>Geometry</source>
        <translation>Geometri</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3208"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3832"/>
        <source>Font</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3246"/>
        <source>Matrix</source>
        <translation>Matris</translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="vanished">Klippsökväg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3303"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3379"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3553"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3601"/>
        <source>Stroke</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3591"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3613"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3819"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4042"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3693"/>
        <source>Borders and Colors</source>
        <translation>Kantlinjer och färger</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3700"/>
        <source>Thin</source>
        <translation>Tunn</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3705"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3710"/>
        <source>Thick</source>
        <translation>Tjock</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3743"/>
        <source>Beveled</source>
        <translation>Avfasad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3748"/>
        <source>Inset</source>
        <translation>Infälld</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3803"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3867"/>
        <source>ToolTip</source>
        <translation>Knappbeskrivning</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3883"/>
        <source>Orientation</source>
        <translation>Orientering</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3891"/>
        <source>0 Degrees</source>
        <translation>0 grader</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3896"/>
        <source>90 Degrees</source>
        <translation>90 grader</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3901"/>
        <source>180 Degrees</source>
        <translation>180 grader</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3906"/>
        <source>270 Degrees</source>
        <translation>270 grader</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3927"/>
        <source>Read Only</source>
        <translation>Skrivskydd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3942"/>
        <source>Visible</source>
        <translation>Synlig</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3947"/>
        <source>Hidden</source>
        <translation>Dold</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3952"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Synlig men ej utskriftsbar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3957"/>
        <source>Hidden but printable</source>
        <translation>Dold men utskriftsbar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3965"/>
        <source>Required</source>
        <translation>Obligatorisk</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4109"/>
        <source>Locked</source>
        <translation>Låst</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1880"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1887"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1900"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1907"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1955"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Teckenfärg&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt fyllnadsfärg&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1961"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Konturfärg&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt konturfärg&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2454"/>
        <source>Shading</source>
        <translation>Skugga</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="vanished">Bildform</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4052"/>
        <source>Subject</source>
        <translation>Ämne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4089"/>
        <source>Author</source>
        <translation>Författare</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <source>Maintain aspect ratio</source>
        <translation>Bevara proportioner</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code</source>
        <translation>Postnummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code+4</source>
        <translation>Zip Code+4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Phone Number</source>
        <translation>Telefonnummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Social Security Number</source>
        <translation>Personnummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="346"/>
        <source>Check Mark</source>
        <translation>Kontrollmärke</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="348"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="350"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Infoga text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="352"/>
        <source>Key</source>
        <translation>Nyckel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="353"/>
        <source>New Paragraph</source>
        <translation>Nytt stycke</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="354"/>
        <source>Text Note</source>
        <translation>Notis</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="355"/>
        <source>Paragraph</source>
        <translation>Stycke</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="356"/>
        <source>Right Arrow</source>
        <translation>Höger pil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="357"/>
        <source>Right Pointer</source>
        <translation>Höger pekare</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="359"/>
        <source>Up Arrow</source>
        <translation>Pil upp</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="360"/>
        <source>Up Left Arrow</source>
        <translation>Upp vänster pil</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="361"/>
        <source>Graph</source>
        <translation>Diagram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="362"/>
        <source>Paper Clip</source>
        <translation>Gem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="363"/>
        <source>Attachment</source>
        <translation>Bilagor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="364"/>
        <source>Tag</source>
        <translation>Tagg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Rotate</source>
        <translation>Rotera</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3548"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3566"/>
        <source>Fill</source>
        <translation>Fyll</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation type="vanished">Radhöjd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2659"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3398"/>
        <source>Selection change</source>
        <translation>Markeringsändring</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3426"/>
        <source>Do nothing</source>
        <translation>Gör ingenting</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3433"/>
        <source>Execute this script</source>
        <translation>Kör detta skript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2146"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4359"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2151"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4379"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4399"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">Vattenstämpel</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">Bakgrund</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">Sidhuvud och sidfot</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3265"/>
        <source>Clipping Path</source>
        <translation>Klippsökväg</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2855"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2860"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2865"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="702"/>
        <source>Layout</source>
        <translation>Layout</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Label only</source>
        <translation>Endast namnetikett</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Icon only</source>
        <translation>Endast ikon</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="723"/>
        <source>Icon top, label bottom</source>
        <translation>Ikon överst, etikett under</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <source>Label top, icon bottom</source>
        <translation>Etikett överst, ikon under</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Icon left, label right</source>
        <translation>Ikon vänster, etikett höger</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>label left, icon right</source>
        <translation>Etikett höger, ikon vänster</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Label over icon</source>
        <translation>Etikett över ikon</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="758"/>
        <source>Icon and Label</source>
        <translation>Ikon och namnetikett</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>Rollover</source>
        <translation>Rulla över</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="798"/>
        <source>State</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="805"/>
        <source>Choose Icon...</source>
        <translation>Välj ikon...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="828"/>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Label</source>
        <translation>Etikett</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>Knappar med samma namn och värde väljs gemensamt</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Öppna</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alla filer (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="751"/>
        <source>Advanced</source>
        <translation>Avancerad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4102"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2001"/>
        <source>Ruble (₽)</source>
        <translation>Rubel (₽)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3498"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4127"/>
        <source>Always show Object Inspector</source>
        <translation>Visa alltid objektgranskaren</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Textblock</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="175"/>
        <source>Object Inspector</source>
        <translation type="unfinished">Objektgranskare</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1501"/>
        <source>QRCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1506"/>
        <source>DataMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1517"/>
        <source>Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>ECC Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>X Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1590"/>
        <source>X/Y Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Include field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1637"/>
        <source>Pick...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1689"/>
        <source>Encode using Tab Delmited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1694"/>
        <source>Encode using XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1699"/>
        <source>JavaScript</source>
        <translation type="unfinished">JavaScript</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>Objektträdvy</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="285"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="317"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="373"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="obsolete">Geometri</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="vanished">Visa</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="32"/>
        <source>Expand All</source>
        <translation>Expandera alla</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="33"/>
        <source>Collapse All</source>
        <translation>Komprimera alla</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="92"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="135"/>
        <source>All</source>
        <translation>Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="108"/>
        <source>Paths</source>
        <translation>Sökvägar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Shadings</source>
        <translation>Skuggningar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>Containers</source>
        <translation>Behållare</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Text Fields</source>
        <translation>Textfält</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>List Boxes</source>
        <translation>Listrutor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Combo Boxes</source>
        <translation>Kombirutor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Check Boxes</source>
        <translation>Kryssrutor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Radio Buttons</source>
        <translation>Alternativknappar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="166"/>
        <source>Buttons</source>
        <translation>Knappar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="171"/>
        <source>Links</source>
        <translation>Länkar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="176"/>
        <source>Signatures</source>
        <translation>Signaturer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>Visa</translation>
    </message>
    <message>
        <source>Object</source>
        <translation type="obsolete">Objekt</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="270"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="338"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="269"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
</context>
<context>
    <name>OptimizeScannedPagesDlg</name>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="14"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished">Sidintervall</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished">Aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished">Sidor</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="95"/>
        <source>Apply Adaptive Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="107"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">Färg- och gråskalebilder</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="127"/>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="173"/>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="132"/>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="153"/>
        <source>Black and White Images</source>
        <translation type="unfinished">Svartvita bilder</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="178"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished">CCITT Grupp 4</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="183"/>
        <source>JBIG2</source>
        <translation type="unfinished">JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="200"/>
        <source>Small Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="229"/>
        <source>High Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="242"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="248"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="255"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation>Verktygsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation>Alla verktyg:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation>Aktuella verktyg i verktygsfält:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation>Verktygsfält:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation>Lägg till verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation>Ta bort verktygsfält</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation>Återställ alla</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation>Max antal verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation>Minsta anatal verktyg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="174"/>
        <source>Please, name new toolbar</source>
        <translation>Namnge nytt verktygsfält</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Kommentarer</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Skrivmaskin</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Anteckning</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Redigera</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ångra</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Upprepa</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Klipp ut</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiera</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Klistra in</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Arkiv</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Spara</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Skriv ut</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Sök</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Signatur</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Alternativknapp</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Listruta</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Textfält</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Kombinationsruta</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Kryssruta</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">Knapp</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objekt</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Penna</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ellips</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rektangel</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Linje</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Infoga text</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Sekretessredigering</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Markera för sekretessredigering</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Redigera text</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Handverktyg</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Visa</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Föregående vy</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Nästa vy</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="obsolete">Zooma</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zooma ut</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Zooma in</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Anpassa sidan</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Primär</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Spara som...</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">E-postleverans</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="obsolete">Justera mot vänsterkant</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="obsolete">Justera mot högerkant</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="obsolete">Justera mot överkant</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="obsolete">Justera mot underkant</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="obsolete">Centrera horisontellt</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation type="obsolete">Centrera vertikalt</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation type="obsolete">Skicka bakåt</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation type="obsolete">Skicka framåt</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Stödlinjer</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Föregående sida</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Nästa sida</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="obsolete">Egentlig storlek</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">Rotera 90 grader moturs</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">Rotera 90 grader medurs</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation type="obsolete">Redigera dokument</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation type="obsolete">Redigera bilder</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation type="obsolete">Redigera vektorbilder</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="obsolete">Redigera formulär</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="obsolete">Markera text</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="obsolete">Infoga tomma sidor</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="obsolete">Ta bort sidor</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="obsolete">Beskär sidor</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation type="obsolete">Sidlayout</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation type="obsolete">Rotera sidor</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="obsolete">Extrahera sidor...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="obsolete">Infoga sidor...</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="obsolete">Dokumentåtgärder</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation type="obsolete">JavaScript</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">Sidegenskaper</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="obsolete">OCR</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">Sidhuvud och sidfot</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="obsolete">Vattenstämpel</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">Bakgrund</translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="obsolete">Dokument</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="525"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="557"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Vill du verkligen återställa alla verktygsfält, till standardinställning?</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="obsolete">Bifoga en fil som kommentar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="196"/>
        <source>ToolBar with this name already exist.</source>
        <translation>Det finns redan ett verktygsfält med det namnet.</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="obsolete">Teckensnittet innehåller inte dessa tecken.
Försök välja ett annat teckensnitt.</translation>
    </message>
</context>
<context>
    <name>PageCounterWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Sidlayout</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="167"/>
        <source>Scale contents with size change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="203"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">Bevara proportioner</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="247"/>
        <source>Contents Size</source>
        <translation>Innehållsstorlek</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="259"/>
        <source>Left margin</source>
        <translation>Vänster marginal</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Top margin</source>
        <translation>Övre marginal</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="293"/>
        <source>Right margin</source>
        <translation>Höger marginal</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="310"/>
        <source>Bottom margin</source>
        <translation>Undre marginal</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="73"/>
        <location filename="../../src/PageLayoutDialog.ui" line="99"/>
        <source>Page Size</source>
        <translation>Sidstorlek</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">Bredd</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">Höjd</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="63"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Jämna sidor</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Udda sidor</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="86"/>
        <location filename="../../src/PageLayoutDialog.ui" line="154"/>
        <location filename="../../src/PageLayoutDialog.ui" line="174"/>
        <location filename="../../src/PageLayoutDialog.ui" line="190"/>
        <location filename="../../src/PageLayoutDialog.ui" line="266"/>
        <location filename="../../src/PageLayoutDialog.ui" line="283"/>
        <location filename="../../src/PageLayoutDialog.ui" line="300"/>
        <location filename="../../src/PageLayoutDialog.ui" line="317"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="331"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="336"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="341"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Top</source>
        <translation>Överkant</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="137"/>
        <source>Bottom</source>
        <translation>Underkant</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="147"/>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="127"/>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="vanished">Från</translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="vanished">av:</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="106"/>
        <source>Orientation</source>
        <translation>Orientering</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="62"/>
        <source>Portrait</source>
        <translation>Stående</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="119"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="63"/>
        <source>Landscape</source>
        <translation>Liggande</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>Sidegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation>Flikordning</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation>Använd radordning</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation>Använd kolumnordning</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation>Använd dokumentstruktur</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation>Ospecificerad</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation>Åtgärder</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation>Lägg till åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation>Utlösare</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation>Åtgärd</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sida</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation>Skicka ett formulär</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation>Öppna sida</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation>Stäng sida</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="51"/>
        <source>Current Page</source>
        <translation>Aktuell sida</translation>
    </message>
</context>
<context>
    <name>PageRangeWidget</name>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="55"/>
        <source>Page Range</source>
        <translation type="unfinished">Sidintervall</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="61"/>
        <source>Current page view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="117"/>
        <source>Pages</source>
        <translation type="unfinished">Sidor</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="78"/>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="127"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="86"/>
        <source>All pages in range</source>
        <translation type="unfinished">Alla sidor i intervallet</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="91"/>
        <source>Even pages</source>
        <translation type="unfinished">Jämna sidor</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="96"/>
        <source>Odd pages</source>
        <translation type="unfinished">Udda sidor</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Page Range input is incorrect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation>Utskriftsinställningar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation>Papper</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation>Bredd:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation>Höjd:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation>Sidstorlek:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation>Marginal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation>Sidfot</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation>Sidhuvud</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation>Vänster marginal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation>Höger marginal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation>Upplösning</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation>Papperskälla</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation>Punkter</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation>Tum</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation>Millimeter</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="320"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="339"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="355"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Denna fil är åtkomstskyddad. Ange ett dokumentlösenord.</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Ange lösenord</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>Klistra in på flera sidor</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Sidintervall</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation>Sidor</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation>Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation>Utom aktuell</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation>Placera initialer</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation>Hur vill du skapa dina initialer?</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation>Skriv mina initialer</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation>Rita mina initialer</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation>Välj signaturbild</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation>Ange dina initialer:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation>Ändra initialernas stil</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation>Granska initialer:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation>Rita initialer:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation>Bredd</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation>Bläddra och välj en bild på din signatur</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="77"/>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="105"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Open Image</source>
        <translation>Öppna bild</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Bildfiler (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>of</source>
        <translation>av</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Teckensnittet innehåller inte dessa tecken.
Försök välja ett annat teckensnitt.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Utskriftsgranskning</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="621"/>
        <source>Printer</source>
        <translation>Skrivare</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="634"/>
        <source>Properties</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="778"/>
        <location filename="../../src/printdialog/printdialog.ui" line="860"/>
        <source>Center</source>
        <translation>Centrera</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="577"/>
        <source>Print as Grayscale</source>
        <translation>Skriv ut i gråskala</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="vanished">Proportioner</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="707"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignorera proportioner</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="712"/>
        <source>Keep aspect ratio</source>
        <translation>Bevara proportioner</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="717"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Bevara proportioner genom expansion</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="342"/>
        <source>Orientation</source>
        <translation>Orientering</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="307"/>
        <source>Portrait</source>
        <translation>Stående</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="312"/>
        <source>Landscape</source>
        <translation>Liggande</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="437"/>
        <source>Number of copies</source>
        <translation>Antal kopior</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="464"/>
        <source>Collate</source>
        <translation>Sortera</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="vanished">Upplösning</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="180"/>
        <source>Page</source>
        <translation>Sidan</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>of:</source>
        <translation>av:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1332"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1708"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1719"/>
        <source>of </source>
        <translation>av </translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="vanished">1200</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="vanished">DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="725"/>
        <source>Actual Size</source>
        <translation>Egentlig storlek</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation type="vanished">Skriv ut som bild</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="361"/>
        <source>Duplex Printing</source>
        <translation>Duplex-utskrift</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <location filename="../../src/printdialog/printdialog.ui" line="369"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Long side</source>
        <translation>Lång sida</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="302"/>
        <location filename="../../src/printdialog/printdialog.ui" line="374"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Short side</source>
        <translation>Kort sida</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">Alla sidor</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Jämna sidor</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Udda sidor</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="135"/>
        <source>Document and Annotations</source>
        <translation>Dokument och anteckningar</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation type="vanished">Delmängd</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation type="vanished">Alla sidor i intervallet</translation>
    </message>
    <message>
        <source>Print What:</source>
        <translation type="vanished">Skriv ut vad:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Print:</source>
        <translation>Skriv ut vad:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="270"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="272"/>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="751"/>
        <location filename="../../src/printdialog/printdialog.ui" line="880"/>
        <source>Scale</source>
        <translation>Skala</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="732"/>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="765"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Shrink to printable area</source>
        <translation>Krymp till utskrivbar yta</translation>
    </message>
    <message>
        <source>Current view</source>
        <translation type="vanished">Aktuell vy</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="536"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="514"/>
        <source>Poster</source>
        <translation>Affisch</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">Broschyr</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="32"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="63"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save Settings</source>
        <translation>Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save current settings as:</source>
        <translation>Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1583"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="561"/>
        <source>Multiple</source>
        <translation>Flera</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <source>Overlay</source>
        <translation>Övertäckande</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="901"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1106"/>
        <source>Points</source>
        <translation>Punkter</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="906"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1111"/>
        <source>Inches</source>
        <translation>Tum</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="911"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>Millimeters</source>
        <translation>Millimeter</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="867"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="977"/>
        <source>Pages per sheet:</source>
        <translation>Sidor per ark:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="970"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1011"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1016"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1021"/>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1026"/>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1031"/>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1036"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1053"/>
        <source>Page order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1061"/>
        <source>Horizontal</source>
        <translation>Horisontell</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1066"/>
        <source>Horizontal Reversed</source>
        <translation>Omvänd horisontell</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1071"/>
        <source>Vertical</source>
        <translation>Vertikal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1076"/>
        <source>Vertical Reversed</source>
        <translation>Omvänd vertikal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1091"/>
        <source>Additional spacing:</source>
        <translation>Ytterligare avstånd:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1098"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1084"/>
        <source>Center pages in cells</source>
        <translation>Centrera sidor i celler</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="323"/>
        <source>Page Setup</source>
        <translation>Utskriftsformat</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="327"/>
        <source>System Properties</source>
        <translation>Systemegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="581"/>
        <source>Printer cannot be selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="240"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="266"/>
        <source>There was an error printing the document</source>
        <translation>Ett fel inträffade vid utskrift av dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="242"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="268"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="60"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Spara som...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="57"/>
        <source>Insert</source>
        <translation>Infoga</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Location</source>
        <translation>Plats</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="vanished">Sida </translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="179"/>
        <source>Attachment Tab</source>
        <translation>Bilageflik</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Öppna</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="24"/>
        <source>Attachment</source>
        <translation>Mätning</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="175"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source> is already attached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="505"/>
        <source>Replace the file or give it a unique name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="506"/>
        <source>Replace</source>
        <translation type="unfinished">Ersätt</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="507"/>
        <source>Rename</source>
        <translation type="unfinished">Byt namn</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="508"/>
        <source>Cancel</source>
        <translation type="unfinished">Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="779"/>
        <source>You don&apos;t have the permission to save attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="823"/>
        <source>You don&apos;t have the permission to open attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="874"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="938"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="939"/>
        <source>The removed Attachment cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="29"/>
        <source>Add Bookmark</source>
        <translation>Lägg till bokmärke</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">Ta bort bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="31"/>
        <source>Bookmark Properties</source>
        <translation>Bokmärkesegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="32"/>
        <source>Set Destination</source>
        <translation>Ange målplats</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="274"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="275"/>
        <source>The removed bookmark(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="30"/>
        <source>Delete Bookmark(s)</source>
        <translation>Ta bort bokmärke(n)</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="82"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="86"/>
        <source>Close All</source>
        <translation>Stäng alla</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Spara</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Spara som...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="106"/>
        <source>Move to New Window</source>
        <translation>Flytta till nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="227"/>
        <location filename="../../src/document/qdoctab.cpp" line="348"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">Urklipp innehåller ingen data</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="74"/>
        <source>Duplicate tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="78"/>
        <source>Rename tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="90"/>
        <source>Close All Other Tabs</source>
        <translation>Stäng alla andra flikar</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="94"/>
        <source>Close All Tabs to the Right</source>
        <translation>Stäng alla flikar till höger</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1895"/>
        <location filename="../../src/document/qdoctab.cpp" line="1920"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>Urklipp innehåller ingen data</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2214"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2272"/>
        <source>You don&apos;t have permission to modify the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2278"/>
        <source>Save failed</source>
        <translation type="unfinished">Kunde inte spara</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished">Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished">Tillåt öppning av samma dokument i flera flikar</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>option needs to be enabled to allow duplicating tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Rename</source>
        <translation type="unfinished">Byt namn</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Renaming file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Overwrite file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Would you like to overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3757"/>
        <source>Failed to rename file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>E-postleverans</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>Till</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>Ämne</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="17"/>
        <source>Send</source>
        <translation>Skicka</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="vanished">HTTPS-anslutning begärd, men SSL-stöd saknas tills vidare</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Okänt fel</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="vanished">Begäran avbröts</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="vanished">Ingen server att ansluta till</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="vanished">Fel innehållslängd</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="vanished">Servern stängde oväntat anslutningen</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="vanished">Anslutning nekad (eller tidsgränsen överskreds)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="vanished">Värddatorn %1 kunde inte hittas</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="vanished">HTTP-begäran misslyckades</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="vanished">Ogiltigt HTTP-svarshuvud</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="vanished">Okänd autentiseringsmetod</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="vanished">Proxy-autentisering krävs</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="vanished">Autentisering krävs</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="vanished">Ogiltig HTTP brödtext</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="vanished">Fel vid skrivning av svar till enheten</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">Zooma in</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="113"/>
        <source>Zoom to Selection</source>
        <translation>Zooma till markering</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="121"/>
        <source>Clear Selections</source>
        <translation>Ta bort markeringar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Open with Master PDF Editor 3</source>
        <translation type="vanished">Öppna med Master PDF Editor 3</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="16"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>Du får inte använda den här funktionen i gratisversionen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="20"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>Den oregistrerade programversionen infogar en vattenstämpel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>Build</source>
        <translation>Kompilering</translation>
    </message>
    <message>
        <source>Based on</source>
        <translation type="vanished">Baserad på</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <source>32 bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>64 bit</source>
        <translation>64 bit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Enter</source>
        <translation>Mus över</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Exit</source>
        <translation>Mus ut</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Down</source>
        <translation>Mus ner</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Mouse Up</source>
        <translation>Mus upp</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Receive Focus</source>
        <translation>Vid fokusering</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>On Lose Focus</source>
        <translation>Vid avfokusering</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Open</source>
        <translation>Sidöppning</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Close</source>
        <translation>Sidstängning</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Visible</source>
        <translation>Synlig sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Page Invisible</source>
        <translation>Osynlig sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Open Page</source>
        <translation>Öppna sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Close Page</source>
        <translation>Stäng sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>KeyStroke</source>
        <translation>Tangentslag</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="997"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Validate</source>
        <translation>Validera</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Calculate</source>
        <translation>Beräkna</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Close Document</source>
        <translation>Stäng dokument</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Save Document</source>
        <translation>Spara dokument</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Document Saved</source>
        <translation>Dokument sparat</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Print Document</source>
        <translation>Skriv ut dokument</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="65"/>
        <source>Document Printed</source>
        <translation>Dokument utskrivet</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Unknown</source>
        <translation>Okänt</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Goto a Page View</source>
        <translation>Gå till en sida</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Open/execute a File</source>
        <translation>Öppna/Kör en fil</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Thread</source>
        <translation>Tråd</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Open a web link</source>
        <translation>Öppna en webblänk</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Sound</source>
        <translation>Ljud</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Movie</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="98"/>
        <source>Show/Hide fields</source>
        <translation>Visa/Dölj fält</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Submit Form</source>
        <translation>Skicka formulär</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Reset Form</source>
        <translation>Återställ formulär</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Import Data</source>
        <translation>Importera data</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="108"/>
        <source>Run a JavaScript</source>
        <translation>Kör ett JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="112"/>
        <source>Rendition</source>
        <translation>Rendering</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="116"/>
        <source>Goto 3D View</source>
        <translation>Gå till 3D-vy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="25"/>
        <source>Open with</source>
        <translation>Öppna med</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Reset</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Set</source>
        <translation>Tillämpa</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Brightness</source>
        <translation>Ljus</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Approved</source>
        <translation>Godkänt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Confidential</source>
        <translation>Konfidentiellt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Received</source>
        <translation>Mottaget</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Reviewed</source>
        <translation>Granskat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Revised</source>
        <translation>Reviderat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Completed</source>
        <translation>Slutfört</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Draft</source>
        <translation>Utkast</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Emergency</source>
        <translation>Brådskande</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>Expired</source>
        <translation>Utgånget</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Final</source>
        <translation>Slutlig</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Verified</source>
        <translation>Verifierat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Void</source>
        <translation>Ogiltigt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>Accepted</source>
        <translation>Accepterat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="173"/>
        <source>Initial</source>
        <translation>Initialt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="178"/>
        <source>Rejected</source>
        <translation>Avvisat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>SignHere</source>
        <translation>Signera här</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Witness</source>
        <translation>Bevittna</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Dynamic</source>
        <translation>Dynamiska</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation>h:MM tt mmmm dd.yyyy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="216"/>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="221"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="226"/>
        <source>Press Help button to get more info.</source>
        <translation>Tryck på hjälpknappen för mer information.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="231"/>
        <source>Error.</source>
        <translation>Fel.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="236"/>
        <source>Object</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="246"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="251"/>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="256"/>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="261"/>
        <source>Shading</source>
        <translation>Skuggor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="241"/>
        <location filename="../../src/app_config.cpp" line="747"/>
        <source>Objects</source>
        <translation>Objekt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="266"/>
        <source>All Objects</source>
        <translation>Alla Objekt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="271"/>
        <source>Forms</source>
        <translation>Formulär</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="276"/>
        <source>Comments</source>
        <translation>Kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="281"/>
        <source>Container</source>
        <translation>Behållare</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="286"/>
        <source>Sticky Note</source>
        <translation>Anteckning</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="291"/>
        <source>Highlight</source>
        <translation>Belys</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="296"/>
        <source>Underline</source>
        <translation>Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="301"/>
        <source>StrikeOut</source>
        <translation>Genomstruken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="306"/>
        <source>Reply</source>
        <translation>Svara</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-filer (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="426"/>
        <source>Typewriter</source>
        <translation>Skrivmaskin</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="311"/>
        <source>Text Box</source>
        <translation>Textruta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="316"/>
        <source>Formatted Text</source>
        <translation>Formaterad text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="321"/>
        <source>Issued by:</source>
        <translation>Utfärdat av:</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="326"/>
        <source>Expires</source>
        <translation>Utgår</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="331"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="336"/>
        <source>Cancelled</source>
        <translation>Annullerat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="341"/>
        <source>Confirmed</source>
        <translation>Bekräftat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="346"/>
        <source>Not Confirmed</source>
        <translation>Obekräftat</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="351"/>
        <source>Open Object Inspector</source>
        <translation>Öppna objektgranskaren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="356"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="361"/>
        <source>Review History</source>
        <translation>Granskningshistorik</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="366"/>
        <source>Make Current Properties Default</source>
        <translation>Gör aktuella egenskaper till standard</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="371"/>
        <source>Error Loading Image!</source>
        <translation>Kunde inte läsa in bild!</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="376"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>Felaktigt datum-/tidsformat. Infoga datum/tid som matchar formatet: </translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="381"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>Du har förbrukat antalet tillgängliga aktiveringar.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="386"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation>Avaktivera din licens på en annan dator.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="396"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>Din licens har upphört att gälla. Förnya gärna licensen.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="401"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>Det går inte att verifiera din licens! Kontrollera din internetuppkoppling och tryck &quot;Verifiera nu&quot;.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="391"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>Din licens gäller inte för den här versionen. Förnya gärna din licens.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="406"/>
        <source>Print using Windows API</source>
        <translation>Skriv ut med Windows API</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="411"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="416"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>Om OpenSSL inte är installerat, kommer kryptering och signaturfunktionalitet inte att finnas tillgängligt.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="436"/>
        <source>Separator</source>
        <translation>Separator</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="441"/>
        <source>Main</source>
        <translation>Primär</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="446"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="451"/>
        <source>Save As...</source>
        <translation>Spara som...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="461"/>
        <source>Toolbars</source>
        <translation>Vektygsfält</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="466"/>
        <source>Email delivery</source>
        <translation>E-postleverans</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="476"/>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="481"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="486"/>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="491"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="496"/>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="501"/>
        <source>Delete Object(s)</source>
        <translation>Ta bort objekt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="506"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="511"/>
        <source>Redo</source>
        <translation>Upprepa</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="516"/>
        <source>Align Left</source>
        <translation>Justera mot vänsterkant</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="521"/>
        <source>Align Right</source>
        <translation>Justera mot högerkant</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="526"/>
        <source>Align Top</source>
        <translation>Justera mot överkant</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="531"/>
        <source>Align Bottom</source>
        <translation>Justera mot underkant</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="536"/>
        <source>Align Center Horizontal</source>
        <translation>Centrera horisontellt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="541"/>
        <source>Align Center Vertical</source>
        <translation>Centrera vertikalt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="551"/>
        <source>Send To Back</source>
        <translation>Placera längst bak</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="556"/>
        <source>Send Backward</source>
        <translation>Skicka bakåt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="561"/>
        <source>Bring Forward</source>
        <translation>Skicka framåt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="566"/>
        <source>Bring To Front</source>
        <translation>Placera längst fram</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="577"/>
        <source>Grid</source>
        <translation>Stödlinjer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="582"/>
        <source>Snap To Grid</source>
        <translation>Fäst vid stödlinjer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="587"/>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="592"/>
        <source>Previous View</source>
        <translation>Föregående vy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="597"/>
        <source>Next View</source>
        <translation>Nästa vy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="602"/>
        <source>Previous Page</source>
        <translation>Föregående sida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="607"/>
        <source>Next Page</source>
        <translation>Nästa sida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="612"/>
        <source>Zoom Out</source>
        <translation>Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="617"/>
        <source>Actual Size</source>
        <translation>Egentlig storlek</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="622"/>
        <source>Zoom In</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="627"/>
        <location filename="../../src/mainwindow.cpp" line="4147"/>
        <source>Fit Page</source>
        <translation>Anpassa sidan</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="632"/>
        <location filename="../../src/mainwindow.cpp" line="4151"/>
        <source>Fit Width</source>
        <translation>Anpassa bredd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="637"/>
        <source>Facing Pages</source>
        <translation>Motstående sidor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="642"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotera 90 grader moturs</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="647"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotera 90 grader medurs</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="652"/>
        <source>Rotate 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="657"/>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="662"/>
        <source>Edit Document</source>
        <translation>Redigera dokument</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="667"/>
        <source>Edit Text</source>
        <translation>Redigera text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="672"/>
        <source>Edit Images</source>
        <translation>Redigera bilder</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="677"/>
        <source>Edit Vector Images</source>
        <translation>Redigera vektorbilder</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="682"/>
        <source>Edit Forms</source>
        <translation>Redigera formulär</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="692"/>
        <source>Hand Tool</source>
        <translation>Handverktyg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="697"/>
        <source>Select Text</source>
        <translation>Markera text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="702"/>
        <source>Take Snapshot</source>
        <translation>Ta en ögonblicksbild</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="707"/>
        <source>Insert Link</source>
        <translation>Infoga länk</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="712"/>
        <source>Button</source>
        <translation>Knapp</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="717"/>
        <source>Check Box</source>
        <translation>Kryssruta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="722"/>
        <source>Combo Box</source>
        <translation>Kombinationsruta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="727"/>
        <source>Text Field</source>
        <translation>Textfält</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="732"/>
        <source>List Box</source>
        <translation>Listruta</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="737"/>
        <source>Radio Button</source>
        <translation>Alternativknapp</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="742"/>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="752"/>
        <source>Insert Formatted Text</source>
        <translation>Infoga formaterad text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="757"/>
        <source>Insert Text</source>
        <translation>Infoga text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="762"/>
        <source>Insert Image</source>
        <translation>Infoga bild</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="767"/>
        <source>Line</source>
        <translation>Linje</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="772"/>
        <source>Rectangle</source>
        <translation>Rektangel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="777"/>
        <source>Ellipse</source>
        <translation>Ellips</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="782"/>
        <source>Pencil</source>
        <translation>Penna</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="787"/>
        <source>Attach a File as a Comment</source>
        <translation>Bifoga en fil som kommentar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="792"/>
        <source>Redaction</source>
        <translation>Redigering</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="797"/>
        <source>Mark for Redaction</source>
        <translation>Markera för redigering</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="802"/>
        <source>Search And Redact</source>
        <translation>Sök och redigera</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="807"/>
        <source>Apply Redaction</source>
        <translation>Tillämpa redigering</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="812"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="817"/>
        <source>Insert Blank Pages</source>
        <translation>Infoga tomma sidor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="822"/>
        <source>Delete Pages</source>
        <translation>Ta bort sidor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="827"/>
        <source>Crop Pages</source>
        <translation>Beskär sidor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="832"/>
        <source>Page layout</source>
        <translation>Sidlayout</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="837"/>
        <source>Page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="842"/>
        <source>Rotate Pages</source>
        <translation>Rotera sidor</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="847"/>
        <source>Extract Pages...</source>
        <translation>Extrahera sidor...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="852"/>
        <source>Insert Pages...</source>
        <translation>Infoga sidor...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="857"/>
        <source>Cut Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="862"/>
        <source>Copy Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="867"/>
        <source>Paste Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="872"/>
        <source>Document Actions</source>
        <translation>Dokumentåtgärder</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="877"/>
        <source>Document JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="882"/>
        <source>Page Properties</source>
        <translation>Sidegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="887"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="892"/>
        <source>Header and Footer</source>
        <translation>Sidhuvud och sidfot</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="897"/>
        <source>Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="902"/>
        <source>Watermark</source>
        <translation>Vattenstämpel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="907"/>
        <source>Background</source>
        <translation>Bakgrund</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="917"/>
        <source>Page Counter</source>
        <translation>Sidräknare</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="922"/>
        <source>New</source>
        <translation>Nytt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="927"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="992"/>
        <source>Select All</source>
        <translation type="unfinished">Markera alla</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1002"/>
        <source>Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1007"/>
        <source>Show Crop Page Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1012"/>
        <source>Prompt to Scan More Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1017"/>
        <source>Current Page</source>
        <translation type="unfinished">Aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1022"/>
        <source>Autosave on. Document will be saved automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1027"/>
        <source>Images</source>
        <translation type="unfinished">Bilder</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1032"/>
        <source>Vector Images</source>
        <translation type="unfinished">Vektor-bilder</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1037"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1042"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="912"/>
        <location filename="../../src/app_config.cpp" line="932"/>
        <source>Zoom</source>
        <translation>Zooma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="937"/>
        <source>Find</source>
        <translation>Sök</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Kommentar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="962"/>
        <source>Stamp</source>
        <translation>Stämplar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="967"/>
        <source>Comment View</source>
        <translation>Kommentarsvy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="972"/>
        <source>Place Initials</source>
        <translation>Placera initialer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="431"/>
        <source>File</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="947"/>
        <source>Highlight Text</source>
        <translation>Färgmarkera text</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="952"/>
        <source>Draw Comment Tools</source>
        <translation>Rita kommentarverktyg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="957"/>
        <source>Measurement Tools</source>
        <translation>Mätverktyg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="687"/>
        <source>Edit Tools</source>
        <translation>Redigeringsverktyg</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="977"/>
        <source>Continuous Page</source>
        <translation>Kontinuerlig sida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="982"/>
        <source>Single Page</source>
        <translation>Enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="546"/>
        <source>Align Objects</source>
        <translation type="unfinished">Justera objekt</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="571"/>
        <source>Move Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="421"/>
        <source>If NSS is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="987"/>
        <source>No pages selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="471"/>
        <source>System Print...</source>
        <translation type="unfinished">Systemutskrift...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="942"/>
        <source>Label</source>
        <translation type="unfinished">Etikett</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Combine files in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="456"/>
        <source>Save As Image</source>
        <translation type="unfinished">Spara som bild</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="39"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="40"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="41"/>
        <source>Arabic</source>
        <translation type="unfinished">Arabiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="42"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="43"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="44"/>
        <source>Azerbaijani (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="45"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="46"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="47"/>
        <source>Tibetan Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="49"/>
        <source>Bulgarian</source>
        <translation type="unfinished">Bulgariska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="50"/>
        <source>Catalan</source>
        <translation type="unfinished">Katalanska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="51"/>
        <source>Cebuano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="52"/>
        <source>Czech</source>
        <translation type="unfinished">Tjeckiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="53"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="54"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="55"/>
        <source>Cherokee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished">Danska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="58"/>
        <source>German</source>
        <translation type="unfinished">Tyska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="59"/>
        <source>German (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="61"/>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="76"/>
        <source>Greek</source>
        <translation type="unfinished">Grekiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="62"/>
        <source>English</source>
        <translation type="unfinished">Engelska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="63"/>
        <source>English (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="64"/>
        <source>Middle English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="65"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="66"/>
        <source>Estonian</source>
        <translation type="unfinished">Estniska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="67"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="69"/>
        <source>Finnish</source>
        <translation type="unfinished">Finska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="70"/>
        <source>French</source>
        <translation type="unfinished">Franska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="71"/>
        <source>Frankish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="72"/>
        <source>Middle French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="73"/>
        <source>Irish</source>
        <translation type="unfinished">Irländska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="74"/>
        <source>Irish (Uncial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="75"/>
        <source>Galician</source>
        <translation type="unfinished">Galisiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="77"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="78"/>
        <source>Hatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished">Hebreiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="81"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="82"/>
        <source>Hungarian</source>
        <translation type="unfinished">Ungerska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="83"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="84"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="85"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="86"/>
        <source>Italian</source>
        <translation type="unfinished">Italienska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="87"/>
        <source>Old Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="88"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="89"/>
        <source>Japanese</source>
        <translation type="unfinished">Japanska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="90"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="91"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="92"/>
        <source>Old Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="93"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="94"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="95"/>
        <source>Kyrgyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="96"/>
        <source>Korean</source>
        <translation type="unfinished">Koreanska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="97"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="98"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="99"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="100"/>
        <source>Latvian</source>
        <translation type="unfinished">Lettiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="101"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Litauiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="102"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="103"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="104"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="105"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="106"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="107"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="108"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="109"/>
        <source>Dutch</source>
        <translation type="unfinished">Holländska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="110"/>
        <source>Norwegian</source>
        <translation type="unfinished">Norska Bokmål</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="111"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="112"/>
        <source>script and orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="113"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="114"/>
        <source>Polish</source>
        <translation type="unfinished">Polska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="115"/>
        <source>Portuguese</source>
        <translation type="unfinished">Portugisiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="116"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="117"/>
        <source>Romanain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="118"/>
        <source>Russian</source>
        <translation type="unfinished">Ryska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="119"/>
        <source>Russian (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="120"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="121"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="122"/>
        <source>Slovak</source>
        <translation type="unfinished">Slovakiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="123"/>
        <source>Slovak Fractur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="124"/>
        <source>Slovenian</source>
        <translation type="unfinished">Slovenska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="125"/>
        <source>Spanish</source>
        <translation type="unfinished">Spanska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="126"/>
        <source>Old Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="127"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="128"/>
        <source>Serbian</source>
        <translation type="unfinished">Serbiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="129"/>
        <source>Serbian (Latin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="130"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="131"/>
        <source>Swedish</source>
        <translation type="unfinished">Svenska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="132"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="133"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="134"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="135"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="136"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="137"/>
        <source>Thai</source>
        <translation type="unfinished">Thailändska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="138"/>
        <source>Turkish</source>
        <translation type="unfinished">Turkiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="139"/>
        <source>Uyghur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="140"/>
        <source>Urgu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="141"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="142"/>
        <source>Uzbek (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="143"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamesiska</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="144"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qsanelib.cpp" line="389"/>
        <source>Document feeder is out of sheets!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="789"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="984"/>
        <source>Error! Check if the file is valid and exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="988"/>
        <source>Error!</source>
        <translation type="unfinished">Fel!</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="111"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="133"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="142"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/utils/AppSession.cpp" line="64"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3554"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3682"/>
        <source>Error!</source>
        <translation>Fel!</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4325"/>
        <source>There was a problem with your form submission.</source>
        <translation>Det är problem med din formuläröverföring.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4329"/>
        <source>Your form was successfully submitted!</source>
        <translation>Ditt formulär har skickats!</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>of</source>
        <translation type="vanished">av</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Sida</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="40"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="4231"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4235"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4240"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4285"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>PDF-dokumentet försöker skicka formulärdata till en annan plats. Vill du fortsätta?</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="51"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="593"/>
        <source>Open Document</source>
        <translation>Öppna dokument</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="61"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="594"/>
        <source>Blank PDF</source>
        <translation>Tom PDF</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="595"/>
        <source>From Files</source>
        <translation>Från filer</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="597"/>
        <source>From Scanner</source>
        <translation>Från skanner</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="93"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="598"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="99"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="599"/>
        <source>User Guide</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="109"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="602"/>
        <source>Register...</source>
        <translation>Registrering...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="115"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="603"/>
        <source>Buy Online</source>
        <translation>Köp online</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="417"/>
        <source>Create New Document</source>
        <translation>Skapa nytt dokument</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="439"/>
        <source>Recent Files</source>
        <translation>Tidigare filer</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="596"/>
        <source>Empty recent files list</source>
        <translation>Rensa tidigare filer</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="421"/>
        <source>Pinned Files</source>
        <translation>Fästa filer</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="957"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>Du har nått gränsen på 10 fästa filer.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="193"/>
        <source>Pages</source>
        <translation>Sidor</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="vanished">Förstora sidminiatyrer</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="vanished">Förminska sidminiatyrer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="219"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="231"/>
        <source>Attachment</source>
        <translation>Bilagor</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="242"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="277"/>
        <source>Object Inspector</source>
        <translation>Objektgranskare</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="744"/>
        <source>This document contains interactive form fields</source>
        <translation>Detta dokument innehåller interaktiva formulärfält</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="745"/>
        <source>Highlight Fields</source>
        <translation>Belys fält</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="vanished">Detta dokument är åtkomstskyddat. Du har inte behörighet att redigera det här dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="753"/>
        <source>Change</source>
        <translation>Ändra</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="vanished">Ett fel inträffade vid utskrift av dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4254"/>
        <source>Do you want to open?</source>
        <translation>Vill du öppna?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4261"/>
        <source>Don&apos;t show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5068"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Är du säker på att du vill ange platsen för det valda bokmärket till aktuell position?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5161"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">Ta bort sidor</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">Infoga tomma sidor</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">Sidegenskaper</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Rotera 90 grader medurs</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Rotera 90 grader moturs</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="vanished">Fel!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1707"/>
        <source>Error loading font: </source>
        <translation>Fel vid teckensnittsinläsning: </translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="246"/>
        <source>Object TreeView</source>
        <translation>Objektträdvy</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="600"/>
        <source>Layers</source>
        <translation>Lager</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="752"/>
        <source>This document is protectedYou do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="805"/>
        <source>Registration</source>
        <translation>Registrering</translation>
    </message>
    <message>
        <source>Current zoom will also be accounted for.</source>
        <translation type="vanished">Nuvarande zoom kommer också att redovisas.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="263"/>
        <source>Signatures</source>
        <translation>Signaturer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3622"/>
        <source>Document must contain at least one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3629"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3015"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5071"/>
        <source>Set current zoom</source>
        <translation>Ange aktuell zoom</translation>
    </message>
</context>
<context>
    <name>QThumbnailsList</name>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="81"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished">Förstora sidminiatyrer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="84"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished">Förminska sidminiatyrer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="132"/>
        <source>Select All</source>
        <translation type="unfinished">Markera alla</translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="16"/>
        <source>Millimeters (mm)</source>
        <translation>Millimeter (mm)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="17"/>
        <source>Inches (in)</source>
        <translation>Tum (in)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="18"/>
        <source>Points (pt)</source>
        <translation>Punkter (pt)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="19"/>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="20"/>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="21"/>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="59"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="63"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="302"/>
        <location filename="../../src/utils/AppSession.cpp" line="241"/>
        <source>MPE Session file (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="144"/>
        <source>More...</source>
        <translation>Mer...</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="vanished">Användarfärg %1</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>User Color 99</source>
        <translation>Användarfärg 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Black</source>
        <translation>Svart</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>White</source>
        <translation>Vit</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Red</source>
        <translation>Röd</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="356"/>
        <source>Dark red</source>
        <translation>Mörkröd</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Green</source>
        <translation>Grön</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="358"/>
        <source>Dark green</source>
        <translation>Mörkgrön</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="359"/>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="360"/>
        <source>Dark blue</source>
        <translation>Mörkblå</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="361"/>
        <source>Cyan</source>
        <translation>Cyan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="362"/>
        <source>Dark cyan</source>
        <translation>Mörk cyan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="363"/>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="364"/>
        <source>Dark magenta</source>
        <translation>Mörk magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="365"/>
        <source>Yellow</source>
        <translation>Gul</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="366"/>
        <source>Dark yellow</source>
        <translation>Mörkgul</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="367"/>
        <source>Gray</source>
        <translation>Grå</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="368"/>
        <source>Dark gray</source>
        <translation>Mörkgrå</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="369"/>
        <source>Light gray</source>
        <translation>Ljusgrå</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="371"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation>Redaktionell kodredigerare</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation>Koduppsättningar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation>Byt namn</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation>Exportera</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation>Importera</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation>Kodposter</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation>Fyllnadsfärg för censurerat område</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation>Använd överläggstext</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="76"/>
        <source>Code Sets</source>
        <translation>Koduppsättningar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="83"/>
        <source>Code Entries:</source>
        <translation>Kodposter:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="116"/>
        <source>Edit Codes</source>
        <translation>Redigera koder</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="67"/>
        <source>Redaction Code</source>
        <translation>Sekretessredigeringskod</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="133"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="152"/>
        <source>Font</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="201"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="60"/>
        <source>Repeat Overlay Text</source>
        <translation>Upprepa överläggstext</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="140"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="172"/>
        <source>auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="126"/>
        <source>Auto-size text</source>
        <translation>Automatisk textstorlek</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Registreringsinfo</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Efter slutförd order, får du automatiskt
registreringskoden via e-post.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Köp online</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="386"/>
        <source>Registration Code</source>
        <translation>Registreringskod</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="373"/>
        <source>Activate</source>
        <translation>Aktivera</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Offline-aktivering</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="227"/>
        <source>Registered version</source>
        <translation>Registrerad version</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Skicka ID-nyckel och registreringskod till: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;När du har fått din kod, anger du den i fältet för  &amp;quot;Aktiveringskod&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="vanished">Klicka på &quot;Avaktivera&quot; om du vill registrera
licensen på en annan PC.

Registrera sedan om den på nästa PC.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="214"/>
        <source>Deactivate</source>
        <translation>Avaktivera</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="319"/>
        <source>Registration Code:</source>
        <translation>Registreringskod:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="366"/>
        <source>Back</source>
        <translation>Tillbaka</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="422"/>
        <source>Activation Code</source>
        <translation>Aktiveringskod</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Skicka ID-nyckel och registreringskod till: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;När du har fått din kod, anger du den i fältet för  &amp;quot;Aktiveringskod&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="349"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Stäng</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="34"/>
        <source>Thanks for registration.</source>
        <translation>Tack för registreringen.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="35"/>
        <source>License is deactivated.</source>
        <translation>Licensen är avaktiverad.</translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation type="vanished">Du har förbrukat antalet tillgängliga aktiveringar.</translation>
    </message>
    <message>
        <source>Many activations!</source>
        <translation type="vanished">Många aktiveringar!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="37"/>
        <source>Too many activations!</source>
        <translation>Många aktiveringar!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Skicka ID-nyckel och registreringskod till: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;När du har fått din kod, anger du den i fältet för  &amp;quot;Aktiveringskod&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="278"/>
        <source>Purchased On:</source>
        <translation>Inköpt:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="292"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Underhållsplan upphör:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="40"/>
        <source>License is expired!</source>
        <translation>Licensen har upphört att gälla!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="58"/>
        <source>Please, renew your license</source>
        <translation>Förnya gärna licensen</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="470"/>
        <source>Renew</source>
        <translation>Förnya</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="499"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact activations@code-industry.net</source>
        <translation>Avaktivering misslyckades!
Kontrollera internetanslutningen.
Kontakta activations@code-industry.net, om felet upprepas.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="202"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Klicka på &quot;Avaktivera&quot; om du vill registrera
licensen på en annan PC.

Registrera sedan om den på nästa PC.</translation>
    </message>
    <message>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation type="vanished">Avaktivering misslyckades!
Kontrollera internetanslutningen.
Kontakta support@code-industry.net, om felet upprepas.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="320"/>
        <location filename="../../src/regdialog.cpp" line="527"/>
        <source>Activation failed! Check internet connection.</source>
        <translation>Aktivering misslyckades! Kontrollera internetanslutningen.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="291"/>
        <location filename="../../src/regdialog.cpp" line="425"/>
        <source>Incorrect registration code.</source>
        <translation>Felaktig registreringskod.</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Rotera</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Sidor</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exempel: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Aktuell sida</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="28"/>
        <source>Direction</source>
        <translation>Plats</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="35"/>
        <source>Clockwise 90 degrees</source>
        <translation>Medurs 90 grader</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="40"/>
        <source>180 degrees</source>
        <translation>180 grader</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="45"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>Moturs 90 grader</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Jämna sidor</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Udda sidor</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="25"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>Bredd</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>Höjd</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>File Name</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Sidor från</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">till:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Exportera som bild</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="259"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Sidintervall</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>JPEG-kvalitet</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>TIFF-komprimering</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan inte spara i filen:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Filen kanske är skrivskyddad eller används av annat program.</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="vanished">Spara som bild</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="445"/>
        <source>All Files (*)</source>
        <translation>Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>Flersidig</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>Save As TIFF Image</source>
        <translation>Spara som TIFF-bild</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>TIFF-filer (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="269"/>
        <source>Antialiasing</source>
        <translation>Kantutjämning</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="26"/>
        <source>Export</source>
        <translation>Exportera</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="311"/>
        <source>Export:</source>
        <translation>Exportera:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="319"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="324"/>
        <source>Document and Annotations</source>
        <translation>Dokument och anteckningar</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation>Ta bort oanvända element</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation>Bädda in formulärfält</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation>Färg- och gråskalebilder</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation>Komprimering</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation>Förlustfritt</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation>JPEG-kvalitet</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="340"/>
        <source>PDF/A Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation>Svartvita bilder</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation>CCITT Grupp 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Spara optimerad som...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation>Slå samman alla lager</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>Skannar...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScanExeDlg.cpp" line="140"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanImageViewerDialog</name>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="39"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="42"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="45"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">Rotera 90 grader moturs</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="68"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="71"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="74"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">Rotera 90 grader medurs</translation>
    </message>
</context>
<context>
    <name>ScanPreviewDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="44"/>
        <source>Close</source>
        <translation type="unfinished">Stäng</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="51"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="26"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="23"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="18"/>
        <source>Scan</source>
        <translation>Skanna</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="46"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="107"/>
        <source>Output</source>
        <translation>Utdata</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="55"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="199"/>
        <source>Source</source>
        <translation type="unfinished">Källa</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="414"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="61"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="122"/>
        <source>Before current page</source>
        <translation>Före aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="424"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="71"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="132"/>
        <source>After last page</source>
        <translation>Efter sista sidan</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="397"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="78"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="139"/>
        <source>After current page</source>
        <translation>Efter aktuell sida</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="407"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="88"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="149"/>
        <source>Before first page</source>
        <translation>Före första sidan</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="304"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="174"/>
        <source>Append to Current Document </source>
        <translation>Lägg till i aktuellt dokument </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="299"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="181"/>
        <source>Create New Document</source>
        <translation>Skapa nytt dokument</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="450"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>Indata</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="133"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="105"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="241"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="522"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="183"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>Skanner</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="80"/>
        <source>Preview</source>
        <translation>Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="112"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="248"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="90"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="255"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="97"/>
        <source>Skip empty pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="544"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="36"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1069"/>
        <source>Looking for devices. Please wait.</source>
        <translation>Söker efter enhet. Vänta!</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="vanished">Uppdatera</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="vanished">Läge</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="209"/>
        <source>Resolution</source>
        <translation>Upplösning</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="315"/>
        <source>Flatbed</source>
        <translation>Flatbädd</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="322"/>
        <source>Negative Transparency</source>
        <translation>Negativ transparens</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <source>Document Feeder</source>
        <translation>Dokumentmatare</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <source>Positive Transparency</source>
        <translation>Positiv transparens</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="353"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="139"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="197"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="50"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="47"/>
        <source>untitled</source>
        <translation>namnlös</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="501"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1007"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="350"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="381"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="188"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="225"/>
        <source>Save As PDF</source>
        <translation>Spara som PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="503"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1009"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="352"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="383"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="227"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-filer (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="64"/>
        <source>Single Page</source>
        <translation>Enkelsida</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="65"/>
        <source>All Pages From Feeder</source>
        <translation>Alla sidor från mataren</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="462"/>
        <source>Scan:</source>
        <translation>Skanna:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="482"/>
        <source>Page Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1080"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="130"/>
        <source>Open device. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="193"/>
        <source>Size</source>
        <translation type="unfinished">Storlek</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="571"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="27"/>
        <source>Saved Settings</source>
        <translation type="unfinished">Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="39"/>
        <source>Save</source>
        <translation type="unfinished">Spara</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished">Ingen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="70"/>
        <source>Delete</source>
        <translation type="unfinished">Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="219"/>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="225"/>
        <source>After scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="318"/>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save Settings</source>
        <translation type="unfinished">Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="418"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="767"/>
        <source>Scan source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="776"/>
        <source>ADF Duplex Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="784"/>
        <source>ADF Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="792"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="801"/>
        <source>Scan mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="833"/>
        <source>Scan resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="845"/>
        <source>X-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="854"/>
        <source>Y-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="obsolete">Ljus</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="obsolete">Kontrast</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="899"/>
        <source>Page width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="916"/>
        <source>Page height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="938"/>
        <source>Top-left x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="956"/>
        <source>Top-left y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="977"/>
        <source>Bottom-right x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="994"/>
        <source>Bottom-right y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>Skanna fler sidor</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>Skanning slutförd</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation type="vanished">Förhandsgranska</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Rotera 90 grader medurs</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Rotera 90 grader moturs</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="138"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="204"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0 resultat</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Case Sensitive</source>
        <translation>Skiftlägeskänslig</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="92"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="102"/>
        <source> result</source>
        <translation> träff</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="106"/>
        <source> results</source>
        <translation> träffar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="104"/>
        <source> result(s)</source>
        <translation> träff(ar)</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="23"/>
        <source>Include Comments</source>
        <translation>Inkludera kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="27"/>
        <source>Whole Words Only</source>
        <translation>Endast hela ord</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="134"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="183"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="233"/>
        <source>Check All</source>
        <translation>Markera alla</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation>Märk markerade resultat för sekretessredigering</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">Sök och sekretessredigera</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="229"/>
        <source>Uncheck All</source>
        <translation>Avmarkera alla</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="124"/>
        <source>Case Sensitive</source>
        <translation>Skiftlägeskänsligt</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="125"/>
        <source>Include Comments</source>
        <translation>Inkludera kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Whole Words Only</source>
        <translation>Endast hela ord</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation>Certifikatsäkerhet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation>Mottagare</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation>Rättigheter</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation>Innehållskopiering för åtkomst</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation>Ändra dokument</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation>Kommentera</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation>Skriva ut dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Hantera sidor och bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Fylla i befintliga formulär- eller signaturfält</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Print a high resolution version of the document</source>
        <translation>Skriva ut dokumentet med hög upplösning</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Extract the content of the document</source>
        <translation>Extrahera innehållet i dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation>Kryptering</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation>128 bitar AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation>256 bitar AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation>Mottagare</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="35"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="vanished">Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Kräv lösenord för att öppna dokumentet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Åtkomstlösenord</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Bekräfta lösenord</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Rättigheter</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Kommentera</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Ändra dokument</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Innehållskopiering för åtkomst</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Utskrift</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Extrahera dokumentinnehåll</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Skriv ut med hög upplösning</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Fyll i formulär eller signaturfält</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Rättighetslösenord</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="259"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Hantera sidor och bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="104"/>
        <source>Document Open password does not match.</source>
        <translation>Åtkomstlösenorden stämmer inte överens.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="116"/>
        <source>Document Permission password does not match.</source>
        <translation>Rättighetstlösenorden stämmer inte överens.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>Kryptering</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation>Lösenordssäkerhet</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation>40 bit RC4</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation>128 bitar AES</translation>
    </message>
</context>
<context>
    <name>SessionsDialog</name>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished">Nytt</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="32"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="39"/>
        <source>Switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="46"/>
        <source>Import</source>
        <translation type="unfinished">Importera</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="60"/>
        <source>Rename</source>
        <translation type="unfinished">Byt namn</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="67"/>
        <source>Remove</source>
        <translation type="unfinished">Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="74"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="93"/>
        <source>Session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="98"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="103"/>
        <source>Last Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="108"/>
        <source>Document count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="121"/>
        <source>Store paths to documents relative to session file when exporting sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="140"/>
        <source>Managed Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="184"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>Open File</source>
        <translation type="unfinished">Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>MPE session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="273"/>
        <source>Failed to load sessions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="452"/>
        <location filename="../../src/SessionsDialog.cpp" line="457"/>
        <source>New session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>New session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>Please write new session name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation>Ange målplats</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>Använd skrollningslist, mus och zoomverktygför att välja målvy, tryck sedan &quot;Länka&quot;, för att skapa länkmålet.</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation>Länka</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation>Ange aktuell zoom</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Signaturegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="54"/>
        <source>Signature is VALID</source>
        <translation>Signaturen är GILTIG</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Detaljerat</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Signerat av:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="502"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="665"/>
        <source>Reason:</source>
        <translation>Anledning:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="883"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>PLats:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Valideringssammandrag</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Signerarens kontaktinformation:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation>Text för signering</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation>Plats</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation>Anledning</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="331"/>
        <source>Lock document after signing</source>
        <translation>Lås doukumentet efter signering</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="353"/>
        <source>Signature Preview</source>
        <translation>Signaturgranskning</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="72"/>
        <source>I have reviewed this document</source>
        <translation>Jag har granskat detta dokument</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="73"/>
        <source>I am approving this document</source>
        <translation>Jag godkänner detta dokument</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="74"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Jag attesterar äkthet och integritet för detta dokument</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="75"/>
        <source>I agree to specified parts of this document</source>
        <translation>Jag godkänner specificerade delar av detta dokument</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="553"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="557"/>
        <source>M.d.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="562"/>
        <source>M.d.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="567"/>
        <source>M.d.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="572"/>
        <source>M.d.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="577"/>
        <source>MM.dd.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="582"/>
        <source>MM.dd.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="587"/>
        <source>MM.dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="592"/>
        <source>MM.dd.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="597"/>
        <source>MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="602"/>
        <source>MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="607"/>
        <source>d.M.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="612"/>
        <source>d.M.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="617"/>
        <source>dd.MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="622"/>
        <source>dd.MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="627"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="632"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="637"/>
        <source>yy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="642"/>
        <source>yy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="647"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="652"/>
        <source>yyyy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="657"/>
        <source>d-MMMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="662"/>
        <source>d-MMMM HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="667"/>
        <source>d-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="672"/>
        <source>d-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="677"/>
        <source>d-MMMM-yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="682"/>
        <source>d-MMMM-yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="687"/>
        <source>dd-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="692"/>
        <source>dd-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation type="vanished">p12-filer (*.p12)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="918"/>
        <source>A password is required to open certificate:</source>
        <translation>Lösenord krävs för att öppna certifikatet:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="299"/>
        <source>Sign</source>
        <translation>Signera</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="787"/>
        <source>Show Image</source>
        <translation>Visa bild</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="812"/>
        <source>Stretch Image</source>
        <translation>Sträck ut bild</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="822"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="464"/>
        <source>Show Text</source>
        <translation>Visa text</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="476"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Ett fel inträffade under signaturverifieringen!</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Open Image</source>
        <translation>Öppna bild</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="189"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Bildfiler (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Detta dokument har ändrats eller skadats sedan signeringen.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Dokumentet har inte ändrats sedan signeringen.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="53"/>
        <source>Signature is INVALID</source>
        <translation>Signaturen är OGILTIG</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="55"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>Signaturens giltighet är okänd</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="57"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Signerarens identitet är okänd eftersom den inte har inkluderats i din lista över pålitliga identiteter och inget överordnat certifikat är en pålitlig identitet.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="58"/>
        <source>Error during signature verification.</source>
        <translation>Fel vid signaturverifiering.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="59"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Info: Signaturens byte-intervall är ogiltigt</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="60"/>
        <source>I am the author of this document</source>
        <translation>Jag är upphovsman för detta dokument</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="56"/>
        <source>This certificate is not trusted</source>
        <translation>Certifikatet är inte pålitligt</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="vanished">Bläddra...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation>Signera som</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="400"/>
        <source>Appearance Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="441"/>
        <source>Формат  по ГОСТу</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="473"/>
        <source>Date /Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="543"/>
        <source>Date Format</source>
        <translation type="unfinished">Datumformat</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="727"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="733"/>
        <source>Show Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="751"/>
        <source>Rounded Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">Tid</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="483"/>
        <source>Signed By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Custom</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="703"/>
        <source>E-mail</source>
        <translation type="unfinished">E-post</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="713"/>
        <source>Name</source>
        <translation type="unfinished">Namn</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Datum</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="422"/>
        <source>Text</source>
        <translation type="unfinished">Text</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="781"/>
        <source>Image</source>
        <translation type="unfinished">Bild</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation type="vanished">Digitalt signerat av </translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="vanished">E-post</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="280"/>
        <source>Saved Settings</source>
        <translation>Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="308"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="293"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save Settings</source>
        <translation>Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save current settings as:</source>
        <translation>Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1490"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="503"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="332"/>
        <source>Certificate Manager</source>
        <translation>Certifikathanterare</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="331"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Alla filer som stöds (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; Alla filer (*)</translation>
    </message>
    <message>
        <source>Digitally signed by</source>
        <translation type="vanished">Digitalt signerat av</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation>Signaturer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="286"/>
        <source>Unsigned Signature</source>
        <translation>Osignerad signatur</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Location</source>
        <translation>Plats</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="302"/>
        <source>Signed Signature</source>
        <translation>Signerad signatur</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="305"/>
        <source>Signed by:</source>
        <translation>Signerat av:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="306"/>
        <source>Reason:</source>
        <translation>Anledning:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="346"/>
        <source>Click to view this version</source>
        <translation>Klicka för att visa denna version</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Document</source>
        <translation type="unfinished">Dokument</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Utfärdare</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Unikt namn (CN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organisation (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Organisationsenhet (OU)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Serienummer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algoritm</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Ämne</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>E-post</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Validitet</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Inte före</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Inte efter</translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation type="vanished">SHA-1:</translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="vanished">MD5</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Lägg till i pålitliga identiteter</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation>Filnamn</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="vanished">Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="98"/>
        <source>Custom</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation>Hantera stämplar</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>Anpassade stämplar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>Stämplar</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>Redigera stämpel</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>Mall</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulär</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="43"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation>Svara</translation>
    </message>
</context>
<context>
    <name>StickyNoteReply</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>Textredigerare</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="166"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="184"/>
        <source>Add Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="199"/>
        <source>Name</source>
        <translation type="unfinished">Namn</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="224"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="249"/>
        <source>Organization unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="274"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="299"/>
        <source>Email</source>
        <translation type="unfinished">E-post</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="324"/>
        <source>Valid since</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="349"/>
        <source>Valid till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="365"/>
        <source>Date</source>
        <translation type="unfinished">Datum</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="obsolete">Från</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="obsolete">Till</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Teckensnitt&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt teckensnitt&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Teckenfärg&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Byt fyllnadsfärg&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bakgrundsfärg&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ändra bakgrundsfärg&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ThumbnailForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="22"/>
        <source>Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="29"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="42"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="62"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="75"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.cpp" line="39"/>
        <source>Pages</source>
        <translation type="unfinished">Sidor</translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="227"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="233"/>
        <source>Highlight</source>
        <translation type="unfinished">Belys</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="268"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="271"/>
        <source>StrikeOut</source>
        <translation type="unfinished">Genomstruken</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="125"/>
        <source>Underline</source>
        <translation type="unfinished">Stryk under</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="167"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="170"/>
        <source>Copy</source>
        <translation type="unfinished">Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="101"/>
        <source>Delete</source>
        <translation type="unfinished">Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="104"/>
        <source>Open</source>
        <translation type="unfinished">Öppna</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="110"/>
        <source>Red</source>
        <translation type="unfinished">Röd</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="112"/>
        <source>Blue</source>
        <translation type="unfinished">Blå</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="114"/>
        <source>Yellow</source>
        <translation type="unfinished">Gul</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="116"/>
        <source>Green</source>
        <translation type="unfinished">Grön</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="119"/>
        <source>Change</source>
        <translation type="unfinished">Ändra</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <source>New</source>
        <translation type="obsolete">Nytt</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Öppna</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="696"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Sök</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Kommentar</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">Stämplar</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation type="obsolete">Kommentarsvy</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation type="obsolete">Placera initialer</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Primär</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Redigera</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Visa</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objekt</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Kommentarer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="602"/>
        <source>Open a PDF file</source>
        <translation>Öppna en PDF-fil</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete">Visa</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Skrivmaskin</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Anteckning</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ångra</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Upprepa</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Klipp ut</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiera</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Klistra in</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Arkiv</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Spara</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Skriv ut</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Signatur</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Alternativknapp</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Listruta</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Textfält</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Kombinationsruta</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Kryssruta</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">Knapp</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Penna</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ellips</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rektangel</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Linje</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Infoga text</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Sekretessredigering</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Markera för sekretessredigering</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Verktyg</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Redigera text</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Handverktyg</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Föregående vy</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Nästa vy</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zooma ut</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Zooma in</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Anpassa sidan</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>Vattenstämpel</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="648"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="662"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="670"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="231"/>
        <source>Source</source>
        <translation>Källa</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="427"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="244"/>
        <source>File</source>
        <translation>Arkiv</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="417"/>
        <source>Scale</source>
        <translation>Skala</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Antal sidor:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="237"/>
        <source>Page Number</source>
        <translation>Sidnummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="264"/>
        <source>Font</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="270"/>
        <source>Color</source>
        <translation>Färg</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="322"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="299"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="315"/>
        <source>Font Family</source>
        <translation>Teckensnitt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="380"/>
        <source>Browse</source>
        <translation>Bläddra</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="121"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="28"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="45"/>
        <source>of</source>
        <translation type="unfinished">av</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="52"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="127"/>
        <source>Rotation</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="145"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="165"/>
        <source>Opacity</source>
        <translation>Opacitet</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="221"/>
        <source>Scale relative to target page</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="489"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="495"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="630"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="754"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="760"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="791"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="453"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="495"/>
        <source>Vertical distance</source>
        <translation>Vertikalt avstånd</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="529"/>
        <source>from</source>
        <translation>från</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="562"/>
        <source>Top</source>
        <translation>Överkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="468"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="567"/>
        <source>Center</source>
        <translation>Centrera</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="572"/>
        <source>Bottom</source>
        <translation>Underkant</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="488"/>
        <source>Horizontal distance</source>
        <translation>Horisontellt avstånd</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="463"/>
        <source>Left</source>
        <translation>Vänster</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Right</source>
        <translation>Höger</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="580"/>
        <source>Units</source>
        <translation>Enheter</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">punkter</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">tum</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimeter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="80"/>
        <source>Page Range Options...</source>
        <translation>Sidintervall...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save Settings</source>
        <translation>Spara inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save current settings as:</source>
        <translation>Spara aktuella inställningar som:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="302"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Inställningar med detta namn finns redan. Vill du ersätta de gamla inställningarna?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Vill du verkligen ta bort inställningen </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="420"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="436"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="454"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">PDF-filer (*.pdf *.PDF)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="499"/>
        <source>There was an error opening the document !</source>
        <translation>Ett fel inträffade när dokumentet skulle öppnas!</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="629"/>
        <source>Saved Settings</source>
        <translation>Sparade inställningar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="540"/>
        <source>Points</source>
        <translation>punkter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="545"/>
        <source>Inches</source>
        <translation>tum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="550"/>
        <source>Millimeters</source>
        <translation>millimeter</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alla filer som stöds (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="600"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="606"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="613"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSignature</name>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="37"/>
        <source>Digitally signed by</source>
        <translation type="unfinished">Digitalt signerat av</translation>
    </message>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="38"/>
        <source>Email</source>
        <translation type="unfinished">E-post</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Datum</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulär</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation>Lager</translation>
    </message>
</context>
</TS>
