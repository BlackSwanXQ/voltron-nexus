<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="410"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="127"/>
        <source>Registered version.</source>
        <translation>Geregistreerde versie.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="179"/>
        <source>Purchased On:</source>
        <translation>Aangeschaft op:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="187"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Onderhoud verloopt op:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation>Registratie informatie</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation>Licentie overeenkomst</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="126"/>
        <source>Not Registered version.</source>
        <translation>Niet geregistreerde versie.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation>Versie informatie</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation>Opgebouwd met</translation>
    </message>
    <message>
        <source>Legal Notices</source>
        <translation type="vanished">Juridische opmerkingen</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="258"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>Deze software gebruikt, met toestemming, de volgende auteursrechterlijk beschermde software.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="99"/>
        <source>Please, renew your license</source>
        <translation>Vernieuw uw licentie alstublieft</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Third-Party Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>Document acties</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation>Document wordt gesloten</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation>Document wordt bewaard</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation>Document werd opgeslagen</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation>Document zal afgedrukt worden</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>Document werd afgedrukt</translation>
    </message>
</context>
<context>
    <name>AddOpenFilesDialog</name>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="14"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="22"/>
        <source>Open PDF files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="32"/>
        <source>Add Files</source>
        <translation type="unfinished">Bestanden toevoegen</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation>Geavanceerde printinstellingen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation>Afdrukken als afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation>Pagina&apos;s in de wachtrij</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="97"/>
        <source>Сompatible with Laser Engraving</source>
        <translation>Verenigbaar met laser graveren</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="246"/>
        <source>Borders and Colors</source>
        <translation>Randen en Kleuren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="256"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="261"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="266"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="271"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="276"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="281"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="286"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="291"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="296"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="301"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="306"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="314"/>
        <source>Border Color</source>
        <translation>Rand Kleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="321"/>
        <source>Fill Color</source>
        <translation>Vul kleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="329"/>
        <source>Solid</source>
        <translation>Vast</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="334"/>
        <source>Dashed</source>
        <translation>Gestippeld</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="349"/>
        <source>Line Width</source>
        <translation>Lijn breedte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="342"/>
        <source>Line Style</source>
        <translation>Lijnsoort</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>Weergave opties</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>Tonen tijdens printen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>Tonen bij schermweergave</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Positie en grootte van watermerk behouden tijdens printen verschillende pagina afmetingen</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Bestand</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Nieuw</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Openen</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">Recente bestanden</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Help</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">Registratie...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">Controleer nu naar updates</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Help...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="335"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="349"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="357"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="367"/>
        <source>Source</source>
        <translation>Bron</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="405"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="411"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="508"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="514"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="540"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="660"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="449"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Toaal aantal pagina&apos;s:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="383"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="484"/>
        <source>Page Number</source>
        <translation>Pagina nummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="422"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="373"/>
        <source>Scale</source>
        <translation>Schalen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation>Roteren</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="44"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation>Dekking</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation>Relatief schalen ten opzichte van doelpagina</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="140"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="187"/>
        <source>Vertical distance</source>
        <translation>Verticale afstand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="166"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="246"/>
        <source>from</source>
        <translation>van</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="282"/>
        <source>Top</source>
        <translation>Boven</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="265"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="287"/>
        <source>Center</source>
        <translation>Gecentreerd</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="292"/>
        <source>Bottom</source>
        <translation>Beneden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="180"/>
        <source>Horizontal distance</source>
        <translation>Horizontale afstand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="260"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="270"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="173"/>
        <source>Units</source>
        <translation>Eenheden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="506"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="514"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="531"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="538"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="566"/>
        <source>Page Range Options...</source>
        <translation>Paginabereik opties...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save Settings</source>
        <translation>Bewaar instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save current settings as:</source>
        <translation>Bewaar huidige instellingen als:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="241"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Instellingen met deze naam bestaat al. Wilt u het vervangen?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source>Are you sure you want to delete the setting </source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source> ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="337"/>
        <source> pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="371"/>
        <source> mm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="415"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="vanished">Fout tijdens openen document !</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="316"/>
        <source>Saved Settings</source>
        <translation>Opgesalgen instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="228"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="233"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="238"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alle ondersteunde bestanden (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="201"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="207"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatesNumberingOptionsDialog</name>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="32"/>
        <source>Start Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="39"/>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="59"/>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="69"/>
        <source>Number of Digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="14"/>
        <source>Bates Numbering Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source>The value must be between </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source> and </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Bladwijzer eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>instellingen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="115"/>
        <source>Style</source>
        <translation>Stijl</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="129"/>
        <source>Plain</source>
        <translation>Vlak</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="134"/>
        <source>Italic</source>
        <translation>Cursief</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="139"/>
        <source>Bold</source>
        <translation>vet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="144"/>
        <source>Italic &amp; Bold</source>
        <translation>Vet cursief</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="165"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="179"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="292"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="351"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="332"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="185"/>
        <source>Add an Action</source>
        <translation>Voeg Handeling Toe</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="220"/>
        <source>Trigger</source>
        <translation>Trigger</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="204"/>
        <source>Action</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="212"/>
        <source>Mouse Up</source>
        <translation>Muis naar boven</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="228"/>
        <source>Goto a Page View</source>
        <translation>Ga naar een paginaweergave</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="233"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="238"/>
        <source>Open a web link</source>
        <translation>Open een weblink</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="243"/>
        <source>Reset form</source>
        <translation>Formulier herstellen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="248"/>
        <source>Show/Hide fields</source>
        <translation>Toon/Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="253"/>
        <source>Submit a form</source>
        <translation>Verstuur een formulier</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="258"/>
        <source>Run a JavaScript</source>
        <translation>Voer een Java Script uit</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="266"/>
        <source>Add</source>
        <translation>Voeg toe</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Pagina nummer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="86"/>
        <source>Set current position</source>
        <translation>Stel huidige positie in</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="96"/>
        <source>Appearance</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="78"/>
        <source>untitled</source>
        <translation>naamloos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="220"/>
        <source>Do you want to set the current position?</source>
        <translation>Wilt u de huidige positie instellen?</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="222"/>
        <source>Custom</source>
        <translation>Aangepassen</translation>
    </message>
</context>
<context>
    <name>BookmarksForm</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="20"/>
        <source>Bookmarks</source>
        <translation type="unfinished">Bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="38"/>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="69"/>
        <source>Set destanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="100"/>
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="131"/>
        <source>Properties</source>
        <translation type="unfinished">Eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="162"/>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="193"/>
        <source>Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="224"/>
        <source>Delete all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation>Certificaat manager</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation>Uw certificaten</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation>Importeren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation>Vertrouwde Systeem Certificaten</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="44"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Alle ondersteunde bestanden (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="102"/>
        <source>A password is required to open certificate:</source>
        <translation>Een wachtwoord is vereist om certificaat te openen:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="114"/>
        <source>Error!</source>
        <translation>Fout !</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>pfx Files (*.pfx)</source>
        <translation>pfx Bestanden (*.pfx)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>crt Files (*.crt)</source>
        <translation>crt bestanden (*.crt)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="162"/>
        <source>Save File</source>
        <translation>Bestand opslaan</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="171"/>
        <source>Please, specify private key password:</source>
        <translation>Geef privé paswoord sleutel op, alstublieft:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="126"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation>Weet u zeker dat u het certificaat wilt verwijderen?</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation>Maak een nieuw document uit bestanden</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="181"/>
        <source>Add Files</source>
        <translation>Bestanden toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="164"/>
        <source>Add Folder</source>
        <translation>Map toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="211"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="267"/>
        <source>Up</source>
        <translation>Omhoog</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="298"/>
        <source>Down</source>
        <translation>Omlaag</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="237"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="278"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="196"/>
        <source>Page Range</source>
        <translation>Pagina bereik</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="124"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="84"/>
        <source>untitled</source>
        <translation>naamloos</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="126"/>
        <source>Add Headers and Footers to Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>Total pages</source>
        <translation>Totaal aantal pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="198"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="197"/>
        <source>Total Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="488"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="921"/>
        <source>Save As PDF</source>
        <translation>Opslaan als PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="490"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="923"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF bestanden (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1002"/>
        <source>File</source>
        <translation type="unfinished">Bestand</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1003"/>
        <source>has already been added to the list. Please choose a different file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source> is already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1052"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1074"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>are already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Openen</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="600"/>
        <source>Select directory</source>
        <translation>Selecteer map</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="956"/>
        <source>Save failed</source>
        <translation>Opslaan mislukt</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan bestand niet opslaan:</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>
The file may be read-only or used by another application.</source>
        <translatorcomment>Correct</translatorcomment>
        <translation>
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="34"/>
        <source>Output</source>
        <translation>Uitvoer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="101"/>
        <source>Append to Current Document </source>
        <translatorcomment>correct</translatorcomment>
        <translation>Toevoegen aan huidig document </translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="108"/>
        <source>Create New Document</source>
        <translation>Maak een nieuw document</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="43"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="20"/>
        <source>Add files to which Headers and Footers or Bates Numbers should be placed. Bates Numbers will appear in the specified order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="27"/>
        <source>Save and close files after numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="49"/>
        <source>Before current page</source>
        <translation>Voor huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="59"/>
        <source>After last page</source>
        <translation>Na laatste pagina</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="66"/>
        <source>After current page</source>
        <translation>Na huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="76"/>
        <source>Before first page</source>
        <translation>Voor de eerste pagina</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="309"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Alle ondersteunde bestanden (* .pdf * .svg * .svgz * .tif * .tiff * .png * .jpg * .jpeg * .bmp * .ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="137"/>
        <source>Import Bookmarks</source>
        <translation>Importeer Bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Insert Pages</source>
        <translation>Pagina&apos;s invoegen</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="49"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="550"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Alle ondersteunde bestanden (* .pdf * .svg * .svgz * .tif * .tiff * .png * .jpg * .jpeg * .bmp * .ppm) ;; Alle bestanden (*)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="42"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="553"/>
        <source>All Supported Files (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished">Alle ondersteunde bestanden (* .pdf *.PDF * .svg * .svgz * .tif * .tiff * .png * .jpg * .jpeg * .bmp * .ppm) ;; Alle bestanden (*)</translation>
    </message>
</context>
<context>
    <name>DeleteAcrossPagesDialog</name>
    <message>
        <location filename="../../src/DeleteAcrossPagesDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="14"/>
        <source>Delete Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="23"/>
        <source>Do you want to delete all headers, footers and Bates numbers on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="obsolete">Wilt u de kopteksten en voetteksten uit het document verwijderen?</translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="22"/>
        <source>Do you want to delete all watermarks on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="27"/>
        <source>Do you want to delete all backgrounds on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Wil je deze paginas verwijderen? Deze handeling kan niet ongedaan worden gemaakt!</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Verwijder pagina&apos;s</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagina&apos;s van</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">tot:</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="50"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>De verwijderde pagina&apos;s kunnen niet hersteld worden door Ongedaan maken.</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1.6-8.12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Drukknop</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Opacity</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Tekst</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Weergave</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">Color</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Auteur</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">Onderwerp</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">Vergrendeld</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">instellingen</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Huidige pagina</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>Afstand gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>Meting</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>Afstand:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>Hoek:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>Cursor locatie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>Eenheden en markeer instellingen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation>Schaal verhouding:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation>in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation>Aantekening:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="32"/>
        <source>Distance</source>
        <translation>Afstand</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="36"/>
        <source>Perimeter</source>
        <translation>Omtrek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="43"/>
        <source>Area</source>
        <translation>Gebied</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="46"/>
        <source> sq</source>
        <translation> sq</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="222"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="225"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="229"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
</context>
<context>
    <name>DlgChangeFont</name>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="14"/>
        <source>Change Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="39"/>
        <source>Current font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="46"/>
        <source>Change to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="66"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">Verander automatisch het lettertype bij het bewerken van tekst</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="84"/>
        <source>Exact match only</source>
        <translation type="unfinished">Alleen exacte overeenkomst</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="21"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished">Dit lettertype bevat deze tekens niet.
Probeer een ander lettertype te kiezen.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="28"/>
        <source>Change</source>
        <translation type="unfinished">Verandering</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>Plaatsing van het pictogram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>Passend binnen de grenzen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>Wanneer schalen:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>Evenredig</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>Niet evenredig</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>Knop</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>Schalen:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>Altijd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>Nooit</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>Pictogram is te groot</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Gebruik dit dialoogvenster om de manier te wijzigen waarop het pictogram moet worden geschaald om in de knop te passen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>Pictogram is te klein</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>Paginanummer en datumnotatie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>Datumnotatie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>Paginanummer formaat</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>Begin paginanummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="51"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="18"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="20"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="21"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>of</source>
        <translation>van</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="53"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="27"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="29"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="14"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="16"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation>Paginabereik opties</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeeld: 1.6-8.12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Even en oneven pagina&apos;s</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Even pagina&apos;s</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Oneven pagina&apos;s</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Bewerk tekst</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Opslaan als</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Eigenschappen...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Knippen</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Kopiëren</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Verwijderen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="41"/>
        <source>Select All</source>
        <translation>Alles selecteren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Plakken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="48"/>
        <source>Add Sticky Note</source>
        <translation>Opmerking toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="49"/>
        <source>Highlight Text</source>
        <translation>Tekst markeren</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="50"/>
        <source>Strikeout Text</source>
        <translation>Tekst doorstrepen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="51"/>
        <source>Underline Text</source>
        <translation>Onderstrepen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>Add Bookmark</source>
        <translation>Bladwijzer toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2456"/>
        <location filename="../../src/docpage/docpage.cpp" line="2496"/>
        <source>Goto a Page View</source>
        <translation>Ga naar een paginaweergave</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2465"/>
        <source>Open a web link</source>
        <translation>Open een weblink</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2475"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2486"/>
        <source>Run a JavaScript</source>
        <translation>Voer een JavaScript uit</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3975"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="70"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="82"/>
        <source>Set Status</source>
        <translation>Status instellen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1087"/>
        <location filename="../../src/docpage/docpage.cpp" line="1090"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1678"/>
        <source>The selected area has been copied</source>
        <translation>Het geselecteerde gebied is gekopieerd</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">Kopiëren</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Knippen</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Plakken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="131"/>
        <source>Select All</source>
        <translation>Alles selecteren</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="132"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Tekst bewerken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="136"/>
        <source>Signature options</source>
        <translation>Handtekening opties</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="139"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="2622"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Open Image</source>
        <translation>Open afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="140"/>
        <source>Set Fit to Page</source>
        <translation>Passend op pagina instellen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="141"/>
        <source>Save Image to file</source>
        <translation>Bewaar afbeelding als bestand</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Bewaar als...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1940"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG afbeeldingen (*.png);;BMP Images (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1950"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG afbeeldingen (*.png)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="134"/>
        <source>Edit Image</source>
        <translation>Afbeelding bewerken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="143"/>
        <source>Edit Path Nodes</source>
        <translation>Bewerk pad knooppunten</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1656"/>
        <source>Edit the image and press Replace</source>
        <translation>Bewerk de afbeelding en klik op vervangen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1658"/>
        <source>Replace</source>
        <translation>Vervangen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1659"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2593"/>
        <source>Delete Node</source>
        <translation>Verwijder knooppunt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Afbeeldingsbestanden (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="594"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="609"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="137"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="135"/>
        <source>Replace Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1650"/>
        <source>An error occurred when attempting to open external application for editing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Java script editor</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>laten zien</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>Selecteer velden</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>De-selecteer alles</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>Verbergen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>Alles selecteren</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>Methode</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="187"/>
        <source>Show/Hide Fields</source>
        <translation>Toon /Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="221"/>
        <source>Reset Form</source>
        <translation>Herstel formulier</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">instellingen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>Locaal bestand</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation>Gebruik anoniem</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>Gebruikersnaam en wachtwoord nodig</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>Gebruikersnaam</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>Wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="115"/>
        <source>Open File</source>
        <translation>Bestand openen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="117"/>
        <source>All Files (*.*)</source>
        <translation>Alle bestanden (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="191"/>
        <source>Select Field</source>
        <translation>Selecteer veld</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a file:</source>
        <translation>Voer een bestand in:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Ga naar pagina</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation>Paginanummer</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation>Zoom modus</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation>automatisch</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Open a web link</source>
        <translation>Open een web link</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Enter a web site:</source>
        <translation>Open een website:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="171"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="173"/>
        <source>All Files (*.*)</source>
        <translation>Alle bestanden (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="114"/>
        <source>Named Action</source>
        <translation>Benoemde actie</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation>Op pagina passen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation>Op breedte passen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation>Op hoogte passen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation>Zichtbaar passen</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditTabOrderDlg</name>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="14"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="20"/>
        <source>Forms</source>
        <translation type="unfinished">Formulieren</translation>
    </message>
</context>
<context>
    <name>ExportCSVDialog</name>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="20"/>
        <source>Export to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="50"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="78"/>
        <source>Browse</source>
        <translation type="unfinished">Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="88"/>
        <source>Separator</source>
        <translation type="unfinished">Scheidingsteken</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="103"/>
        <source>Semicolon ( ; )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="129"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="146"/>
        <source>Comma ( , )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="153"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="38"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="47"/>
        <source>Export</source>
        <translation type="unfinished">Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="111"/>
        <source>Export to csv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="113"/>
        <source>csv files (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished">
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="77"/>
        <source>Extract pages as a single file</source>
        <translation>Paginas uitpakken als één bestand</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Pagina&apos;s uitpakken</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="141"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="130"/>
        <source>Save As PDF</source>
        <translation>Opslaan als PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="132"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF bestanden (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan niet in het bestand opslaan:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>The file &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>&quot; already exists. Do you wish to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="43"/>
        <source>Export Pages</source>
        <translation>Pagina&apos;s exporteren</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="124"/>
        <source>Export bookmarks</source>
        <translation>Bladwijzers exporteren</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="134"/>
        <source>Delete pages after extracting</source>
        <translation>Pagina&apos;s na uitpakken verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="23"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation>Exporteer naar tekst</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="64"/>
        <source>Extract pages as a single file</source>
        <translation>Paginas uitpakken als één bestand</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="35"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="43"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation>txt bestanden (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan bestand niet opslaan:</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Eigenschappen van het document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Omschrijving</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Onderwerp</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Trefwoord</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Gemaakt door</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>PDF-bron</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Protect</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>Beginweergave</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Images</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>Lettertypen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>Lettertypes gebruikt in dit document</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Documentveiligheid</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Wachtwoord gebruiker</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Wachtwoord eigenaar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>Wachtwoord Versleuteling</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>Geen versleuteling</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>Afdruktoestemming</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>Druk af met hoge resolutie</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Toestemming Extractie Inhoud</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extraheer de inhoud van het document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>Document aanpassen</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Commentaar in het document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Vul een formulier in</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Beheer paginas en bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Open naar pagina:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>van :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Beeld:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation>Aleen pagina</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation>Bladwijzerspaneel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation>Pagina&apos;s paneel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation>Bijlagen paneel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation>Lagen paneel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation>Verandering</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation>Machtigingen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation>Pak de inhoud van het document uit</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation>Inhoud kopiëren voor toegankelijkheid</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="723"/>
        <source>Password</source>
        <translation>Wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="724"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Het document is beveiligd. Voer een wachtwoord in:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="746"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Incorrect wachtwoord. Voer het eigenaarswachtwoord in.</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation>Gebruikersinterface-opties</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation>Verberg werkbalk</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation>Verberg Menu balk</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation>Verberg Venster Controle</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation>Venster opties</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation>Centreer venster op scherm</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation>Toon document titel</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation>Open in volledige schermmodus</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation>Indeling en bestemming</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation>Navigatie Tab:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation>Pagina opmaak:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="248"/>
        <source>Default</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation>Enkele pagina</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation>Eén pagina vooruit</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation>Tweezijdig (bekijken)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Tweezijdig vooruit (bekijken)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation>Tweezijdig omslag</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>Tweezijdig doorlopend voorblad</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation>Huidig Formaat</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation>Op pagina passend</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation>Past in de breedte</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="268"/>
        <source>Fit Height</source>
        <translation>Past in de hoogte</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="273"/>
        <source>Fit Visible</source>
        <translation>Past zichtbaar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation>Open document acties</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation>Voeg Handeling Toe</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation>Ga naar een paginaweergave</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation>Open een web link</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation>Formulier herstellen</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation>Toon/Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation>Verstuur een formulier</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation>Voer een Java Script uit</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translation>Certificaat versleuteling</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Algemeen</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Weergave</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">instellingen</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Acties</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Verwijderen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Sluiten</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stijl</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Color</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Voeg toe</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Vergrendeld</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Naam</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Randen en Kleuren</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Voeg Handeling Toe</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Knopinfo</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Oriëntatie</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Lijnsoort</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Rand Kleur</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Omhoog</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Omlaag</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Eigenschappen</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Tekst</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Formaat wijzigen</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">Invoegen</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bewerken</translation>
    </message>
</context>
<context>
    <name>HeaderAndFooterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="365"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="569"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="593"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="621"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished">Koptekst en voettekst</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="28"/>
        <source>Show Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="166"/>
        <source>Margins</source>
        <translation type="unfinished">Marges</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="257"/>
        <source>Units</source>
        <translation type="unfinished">Eenheden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="291"/>
        <source>Points</source>
        <translation type="unfinished">Punten</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="296"/>
        <source>Inches</source>
        <translation type="unfinished">Inches</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="301"/>
        <source>Millimeters</source>
        <translation type="unfinished">Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="328"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="347"/>
        <source>Delete</source>
        <translation type="unfinished">Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="361"/>
        <source>None</source>
        <translation type="unfinished">Geen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="369"/>
        <source>Save</source>
        <translation type="unfinished">Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="522"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="536"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="553"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="560"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="588"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="150"/>
        <source>Page number and date format</source>
        <translation type="unfinished">Pafinanummer en datumnotatie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="41"/>
        <source>Insert Page Number</source>
        <translation type="unfinished">Invoegen pagina nummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="48"/>
        <source>Insert Date</source>
        <translation type="unfinished">Invoegen datum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="55"/>
        <source>Insert Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="70"/>
        <source>Font</source>
        <translation type="unfinished">Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="76"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="96"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="116"/>
        <source>Font Family</source>
        <translation type="unfinished">Lettertype familie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="178"/>
        <source>Top</source>
        <translation type="unfinished">Boven</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="188"/>
        <source>Right</source>
        <translation type="unfinished">Rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="198"/>
        <source>Left</source>
        <translation type="unfinished">Links</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="247"/>
        <source>Bottom</source>
        <translation type="unfinished">Beneden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Use Page Range of the currently edited Pagemark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="408"/>
        <source>Right Footer Text</source>
        <translation type="unfinished">Voettekst rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="469"/>
        <source>Center Header Text</source>
        <translation type="unfinished">Koptekst in het midden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="439"/>
        <source>Left Footer Text</source>
        <translation type="unfinished">Voettekst links</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="476"/>
        <source>Right Header Text</source>
        <translation type="unfinished">Koptekst rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="432"/>
        <source>Center Footer Text</source>
        <translation type="unfinished">Voettekst in het midden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="425"/>
        <source>Left Header Text</source>
        <translation type="unfinished">Koptekst links</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation type="vanished">Koptekst en voettekst</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="vanished">Topmarge</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="vanished">Marge rechts</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="vanished">Ondergrens marge</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="vanished">Marge links</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Lettertype</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Kleur</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Grootte</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="vanished">Lettertype familie</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Instellingen</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Verwijderen</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Geen</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Opslaan</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation type="vanished">Voettekst rechts</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation type="vanished">Koptekst in het midden</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation type="vanished">Voettekst links</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation type="vanished">Koptekst rechts</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation type="vanished">Voettekst in het midden</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation type="vanished">Koptekst links</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation type="vanished">Invoegen datum</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation type="vanished">Invoegen pagina nummer</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation type="vanished">Pafinanummer en datumnotatie</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="vanished">Pagina bereik opties...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="vanished">instellingen opslaan</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="vanished">Huidige instellingen opslaan als:</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="vanished">Instellingen met deze naam bestaat al. Wilt u de oude instellingen vervagen?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="vanished">Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="vanished"> ?</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="vanished">Eenheden</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation type="vanished">Opgeslagen instellingen</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="vanished">Marges</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="vanished">Punten</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="vanished">Inches</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="vanished">Millimeters</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Alle paginas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="obsolete">Bestand Name</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Bladeren</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">Paginas</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation>Formulier</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>Installeer talen</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>Talen</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="165"/>
        <source>Install</source>
        <translation>Installeer</translation>
    </message>
</context>
<context>
    <name>InteractiveCPDFReader</name>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="39"/>
        <source>Словарь в форме хранящейся в памяти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="52"/>
        <source>Команда(или help для их описания) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="88"/>
        <source>Вводимые ключи</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="101"/>
        <source>Черновик для записей</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="130"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="146"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="162"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="178"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="194"/>
        <source>5</source>
        <translation type="unfinished">5</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="207"/>
        <source>Скопировать текущий 
словарь в черновик</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>JavaScript Console</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>Uitvoeren</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>Opruimen</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>Blijft op de top</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation>Functie naam</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Java Script Editor</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Functie naam</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="126"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation>%1, ...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="205"/>
        <source>Press shortcut</source>
        <translation>Klik op de sneltoets</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>Toetsenbord sneltoetsen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation>Alles herstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation>Snelkoppeling</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation>Herstel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation>Commando</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacApplication</name>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="465"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zoom uit</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="470"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="478"/>
        <source>Zoom In</source>
        <translation type="unfinished">Inzoomen</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Vorige pagina</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Volgende pagina</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>Formulieren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>Talen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="542"/>
        <source>Highlight color</source>
        <translation>Markeer kleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="562"/>
        <source>Required field highlight color</source>
        <translation>Markeer vereiste velden</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3370"/>
        <source>Please choose the interface language</source>
        <translation>Kies u voorkeurs interface taal</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3442"/>
        <source>Check for Updates Automatically</source>
        <translation>Controleer automatisch op Master PDF Editor updates</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3461"/>
        <source>Weekly</source>
        <translation>Elke week</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3466"/>
        <source>Monthly</source>
        <translation>Elke maand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3456"/>
        <source>Never</source>
        <translation>Nooit</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="894"/>
        <source>Options</source>
        <translation>instellingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1236"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2044"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2272"/>
        <source>Smooth text and images</source>
        <translation>Soepele tekst en afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1324"/>
        <source>Time before a move or resize starts:</source>
        <translation>Tijd voordat een verplaatsing of verandering begint:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1317"/>
        <source>Select item by hovering the mouse</source>
        <translation>Selecteer item door de muis te bewegen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Built-in</source>
        <translation>Ingebouwd</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="522"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3390"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Het is vereist om het programma opnieuw te starten zodat de wijzigingen van kracht worden.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Update</source>
        <translation>Update</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="vanished">Arabisch</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="vanished">Bulgaars</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="vanished">Catalaans</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="vanished">Eenvoudig Chinees</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="vanished">Chinese-Traditioneel</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="vanished">Tsjechisch</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="vanished">Deens</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="vanished">Nederlands</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">Engels</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="vanished">Estlands</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="vanished">Fins</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="vanished">Frans</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="vanished">Galicisch</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="vanished">Duits</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="vanished">Grieks</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="vanished">Hebreeuws</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="vanished">Hongaars</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="vanished">Iers</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="vanished">Italiaans</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished">Japans</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="vanished">Koreaans</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="vanished">Lets</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="vanished">Litouws</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="vanished">Noors</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="vanished">Noorse Nynorsk</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished">Pools</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="vanished">Portugees</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="vanished">Portugees-Braziliaans</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="vanished">Roemeens</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">Russisch</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="vanished">Servisch</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="vanished">Slowaaks</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="vanished">Sloveens</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="vanished">Spaans</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="vanished">Zweeds</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="vanished">Thais</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="vanished">Turks</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="vanished">Oekraïens</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="vanished">Valenciaans</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Vietnamees</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="203"/>
        <source>Saving Documents</source>
        <translation>Documenten opslaan</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Create backup file</source>
        <translation>Maak backup bestand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Kies doelmap voor &quot;Opslaan als&quot; documenten</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Last used folder</source>
        <translation>Laatst gebruikte map</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Original documents folder</source>
        <translation>Originele documentenmap</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1144"/>
        <source>Default font</source>
        <translation>Standaard lettertype</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2855"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2900"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1530"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1847"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1162"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1854"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2512"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="vanished">Armeens</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>History</source>
        <translation>Geschiedenis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="151"/>
        <source>Restore last session when application start</source>
        <translation>Herstel laatste sessie bij programma herstart</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="158"/>
        <source>Restore last view settings when reopening</source>
        <translation>Herstel de laatste weergave-instellingen bij heropening</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1593"/>
        <source>Enable JavaScript</source>
        <translation>Schakel Javascript in</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="598"/>
        <source> Always hide document message bar </source>
        <translation> Verberg altijd de documentberichtenbalk </translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2109"/>
        <source>Default Layout and Zoom</source>
        <translation>Standaard opmaak en zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2224"/>
        <source>Default page layout</source>
        <translation>Standaard pagina opmaak</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2122"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2232"/>
        <source>Automatic</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2204"/>
        <source>Single Page</source>
        <translation>Enkele pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2209"/>
        <source>Facing Pages</source>
        <translation>Tegenoverliggende pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2255"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2127"/>
        <source>Actual Size</source>
        <translation>Huidige Formaat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="984"/>
        <source>Show warning when opening links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <source>Convert static XFA into normal PDF when opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1224"/>
        <source>Page scrolling options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <source>Configure scroll value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1297"/>
        <source>Enable scroll without delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1137"/>
        <source>Create Pencil lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1979"/>
        <source>Create Pencil and Brush lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2132"/>
        <source>Fit Page</source>
        <translation>Pagina passend maken</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2137"/>
        <source>Fit Width</source>
        <translation>Pas de breedte aan</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2142"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2147"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2152"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2157"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2162"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2167"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2172"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2177"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2182"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2187"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="747"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2401"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2288"/>
        <source>Bitmap Images</source>
        <translation>Bitmap afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2295"/>
        <source>Vector Images</source>
        <translation>Vector afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2383"/>
        <source>Replace Document Colors</source>
        <translation>Vervang document kleuren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2408"/>
        <source>Page Background</source>
        <translation>Pagina achtergrond</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation>Tonen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2425"/>
        <source>Theme</source>
        <translation>Thema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="464"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="479"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="2041"/>
        <source>Select directory</source>
        <translation>Selecteer map</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1061"/>
        <source>Automatically change font when editing text</source>
        <translation>Verander automatisch het lettertype bij het bewerken van tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2318"/>
        <source>Resolution</source>
        <translation>Resolutie</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2334"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2324"/>
        <source>System PPI</source>
        <translation>Systeem PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>Icons in menus</source>
        <translation>Pictogrammen in Menu&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Open documenten als nieuwe tabbladen in hetzelfde venster (opnieuw opstarten vereist)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="342"/>
        <source>Enable scroll wheel zooming</source>
        <translation>Schakel het zoomen met het scrollwiel in</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1663"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2098"/>
        <source>Pop-up Opacity</source>
        <translation>Pop-up Dekking</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1564"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1820"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2075"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1687"/>
        <source>Sticky Note</source>
        <translation>Notitie</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1803"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1557"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1835"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1946"/>
        <source>Opacity</source>
        <translation>Dekking</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Highlight Text</source>
        <translation>Markeer tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1697"/>
        <source>Strikeout Text</source>
        <translation>Tekst doorhalen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1702"/>
        <source>Underline Text</source>
        <translation>Onderstrepen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1537"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1928"/>
        <source>Line Width</source>
        <translation>Lijn Breedte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="656"/>
        <source>Appearance</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="727"/>
        <source>Check Mark</source>
        <translation>Vinkje</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="728"/>
        <source>Circle</source>
        <translation>Circel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="838"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <source>Cross</source>
        <translation>Kruis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Tekst invoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="733"/>
        <source>Key</source>
        <translation>Sleutel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="734"/>
        <source>New Paragraph</source>
        <translation>Nieuwe Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="735"/>
        <source>Text Note</source>
        <translation>Tekst notitie</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="736"/>
        <source>Paragraph</source>
        <translation>Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="737"/>
        <source>Right Arrow</source>
        <translation>Pijl rechts</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="738"/>
        <source>Right Pointer</source>
        <translation>Aanwijzer rechts</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="853"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="739"/>
        <source>Star</source>
        <translation>Ster</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="740"/>
        <source>Up Arrow</source>
        <translation>Pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="741"/>
        <source>Up Left Arrow</source>
        <translation>Linker pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="742"/>
        <source>Graph</source>
        <translation>Diagram</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="743"/>
        <source>Paper Clip</source>
        <translation>Paper Clip</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="744"/>
        <source>Attachment</source>
        <translation>Bijlagen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="745"/>
        <source>Tag</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation>javaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1605"/>
        <source>Show errors and  messages in console</source>
        <translation>Toon fouten en berichten in de console</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="606"/>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="248"/>
        <source>Autosave interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="299"/>
        <source>Autosave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="175"/>
        <source>Show Quick actions on text and comments selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Lock file from opening by other instances of Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Enable logging to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="398"/>
        <source>Log files directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Edit Box</source>
        <translation>Tekst veld</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="616"/>
        <source>Check box</source>
        <translation>Selectievakje</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <source>Radio button</source>
        <translation>Radio knop</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Combo box</source>
        <translation>Keuzelijst met invoervak</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>List box</source>
        <translation>Keuzelijst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Button</source>
        <translation>Knop</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="641"/>
        <source>Signature</source>
        <translation>Handtekening</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="662"/>
        <source>Borders and Colors</source>
        <translation>Randen en Kleuren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="669"/>
        <source>Thin</source>
        <translation>Dun</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="674"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="679"/>
        <source>Thick</source>
        <translation>Dik</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="687"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Border Color</source>
        <translation>Rand Kleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="694"/>
        <source>Fill Color</source>
        <translation>Opvul kleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="702"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="929"/>
        <source>Solid</source>
        <translation>Effen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="934"/>
        <source>Dashed</source>
        <translation>Gestippeld</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="712"/>
        <source>Beveled</source>
        <translation>Schuin</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="717"/>
        <source>Inset</source>
        <translation>Inzet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="722"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="939"/>
        <source>Underline</source>
        <translation>Onderstreept</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="921"/>
        <source>Line Style</source>
        <translation>Lijn stijl</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="737"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="900"/>
        <source>Line Thickness</source>
        <translation>Lijn dikte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Maximum CPU usage for OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3471"/>
        <source>Once in 3 months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="263"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2527"/>
        <source>Auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="801"/>
        <source>Font</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="947"/>
        <source>Highlight</source>
        <translation>Hoogepunt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="958"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="963"/>
        <source>Invert</source>
        <translation>Omkeren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="968"/>
        <source>OutLine</source>
        <translation>Omtrek</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Insert</source>
        <translation>Invoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>Style</source>
        <translation>Stijl</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="828"/>
        <source>Check</source>
        <translation>Controleren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="843"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="848"/>
        <source>Square</source>
        <translation>Vierkant</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation>Raster</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1384"/>
        <source>Units</source>
        <translation>Eenheden</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1411"/>
        <source>Width between lines</source>
        <translation>Breedte tussen lijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1444"/>
        <source>Height between lines</source>
        <translation>Hoogte tussen lijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Left offset</source>
        <translation>Offset Links</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1437"/>
        <source>Top offset</source>
        <translation>Offset Top</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1451"/>
        <source>Subdivision</source>
        <translation>Onderverdeling</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1707"/>
        <source>Measurements</source>
        <translation>Afmetingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1712"/>
        <source>Drawing</source>
        <translation>Tekening</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1098"/>
        <source>Selected text color</source>
        <translation>Geselecteerde tekstkleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>Default</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2431"/>
        <source>Application Style</source>
        <translation>Applicatie stijl</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2610"/>
        <source>Use default program</source>
        <translation>Gebruik standaard programma</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>evolution</source>
        <translation>evolution</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2634"/>
        <source>kmail</source>
        <translation>kmail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2639"/>
        <source>thunderbird</source>
        <translation>thunderbird</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2647"/>
        <source>Use SMTP</source>
        <translation>Gebruik SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2670"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2758"/>
        <source>Email address</source>
        <translation>Email adres</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Secure connections</source>
        <translation>Beveiligde verbindingen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2726"/>
        <source>NONE</source>
        <translation>GEEN</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2736"/>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2718"/>
        <source>SMTP server</source>
        <translation>SMTP server</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>User</source>
        <translation>Gebruiker</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2744"/>
        <source>SMTP port</source>
        <translation>SMTP-poort</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2691"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3101"/>
        <source>Password</source>
        <translation>Wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2950"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>Standaard pad naar tesseract ocr-gegevensbestanden</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2923"/>
        <source>Additional tesseract ocr config file</source>
        <translation>Aanvullend tesseract ocr configuratiebestand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2943"/>
        <source>Install languages</source>
        <translation>Installeer talen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="501"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1929"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1949"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1969"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1391"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1484"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1520"/>
        <source>pt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation>Netwerk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1615"/>
        <source>Enable safe reading mode</source>
        <translation>Schakel de modus veilig lezen in</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2980"/>
        <source>Direct internet connection</source>
        <translation>Directe internetverbinding</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2990"/>
        <source>Manual proxy configuration</source>
        <translation>Handmatige proxy configuratie</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3006"/>
        <source>HTTP Proxy</source>
        <translation>HTTP Proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3013"/>
        <source>SOCKS 5 Proxy</source>
        <translation>SOCKS 5 Proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3023"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3033"/>
        <source>Port</source>
        <translation>Poort</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2679"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3076"/>
        <source>Authentication</source>
        <translation>Authenticatie</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3091"/>
        <source>User name</source>
        <translation>Gebruikersnaam</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2519"/>
        <source>Icon set</source>
        <translation>Pictogrammen set</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation>Toetsenbord</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="349"/>
        <source>Show Start page</source>
        <translation>Toon Startpagina</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1419"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1424"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1429"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="450"/>
        <source>Load all objects separately</source>
        <translation>Laad alle objecten afzonderlijk</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1353"/>
        <source>Always show Object Inspector</source>
        <translation>Laat Object Inspecteur altijd zien</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2262"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Verbied bestanden om de modus Volledig scherm bij openen te activeren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1717"/>
        <source>Typewriter</source>
        <translation>Schrijfmachine</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>Light</source>
        <translation>Licht</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>Dark</source>
        <translation>Donker</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <source>Exact match only</source>
        <translation>Alleen exacte overeenkomst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation>Certificaat</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1360"/>
        <source>Save last editing Tool</source>
        <translation>Sla de laatste bewerkingsgereedschap op</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3228"/>
        <source>Default paths for system certificates</source>
        <translation>Standaard pad voor systeem certificaten</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3176"/>
        <source>Certificate Manager</source>
        <translation>Certificaat manager</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="810"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>In Windows bevinden alle certificaten zich in de systeemopslag.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="421"/>
        <source>Alternative method for PDF render</source>
        <translation>Alternatieve methode voor PDF weergave</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="473"/>
        <source>Memory/Speed</source>
        <translation>Geheugen/Snelheid</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="480"/>
        <source>Minimize memory usage</source>
        <translation>Minimum geheugengebruik</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="485"/>
        <source>Maximal render speed</source>
        <translation>Maximale snelheidsweergave</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="829"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1139"/>
        <source>System Theme</source>
        <translation>Systeem thema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3238"/>
        <source>Database for Certificate Manager</source>
        <translation>Database voor certificaat manager</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3298"/>
        <source>Password:</source>
        <translation>Wachtwoord:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3254"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3271"/>
        <source>Copy</source>
        <translation>Kopiëren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3305"/>
        <source>Path for DB:</source>
        <translation>Pad voor DB:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation>Opstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="815"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>In macOS, alle certificaten bevinden zich in de systeemopslag.</translation>
    </message>
    <message>
        <source>Farsi</source>
        <translation type="vanished">Farsi</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation>Sta openen van hetzelfde document toe in meerdere tabbladen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="998"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1004"/>
        <source>Add full path to filename in export file</source>
        <translation>Voeg het volledige pad toe aan de bestandsnaam in het exportbestand</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="991"/>
        <source>Recreate pdf forms when opening</source>
        <translation>Maak PDF-formulieren opnieuw bij het openen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="830"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1143"/>
        <source>Light Theme</source>
        <translation>Licht thema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="831"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1147"/>
        <source>Dark Theme</source>
        <translation>Donker thema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation>Taakbalken</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2499"/>
        <source>Standard</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2504"/>
        <source>Office Pro</source>
        <translation>Office Pro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1367"/>
        <source>Edit Text Elements as Blocks</source>
        <translation>Bewerk tekstelementen als blokken</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2041"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2489"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2532"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2537"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Save recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2217"/>
        <source>Navigation Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Page Only</source>
        <translation type="unfinished">Aleen pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished">Bladwijzerspaneel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2247"/>
        <source>Pages Panel</source>
        <translation type="unfinished">Pagina&apos;s paneel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3334"/>
        <source>Strong verification of signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="255"/>
        <source>PDF Specification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Algemeen</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulieren</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Talen</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Markeer kleur</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Markeer vereiste velden:</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Kies u voorkeurs interface taal:</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Controleer automatisch op Master PDF Editor updates:</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Elke week</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Elke maand</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nooit</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Instellingen</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Bladeren</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stijl</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Verwijder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="139"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Open</source>
        <translation>Openen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="159"/>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <source>New</source>
        <translation>Nieuw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Save As...</source>
        <translation>Opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="896"/>
        <source>Print</source>
        <translation>Afdrukken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2432"/>
        <source>Recent Files</source>
        <translation>Recente bestanden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="743"/>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Exit</source>
        <translation>Afsluiten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Cut</source>
        <translation>Knippen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Copy</source>
        <translation>Kopiëren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="938"/>
        <source>Paste</source>
        <translation>Plakken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Select All</source>
        <translation>Alles selecteren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>First Page</source>
        <translation>Eerste pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Previous Page</source>
        <translation>Vorige pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Next Page</source>
        <translation>Volgende pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Last Page</source>
        <translation>Laatste pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="207"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="604"/>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <source>Zoom In</source>
        <translation>Inzoomen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Zoom Out</source>
        <translation>Zoom uit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Actual Size</source>
        <translation>Huidig Formaat</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="291"/>
        <source>Toolbars</source>
        <translation>Taakbalken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <source>Statusbar</source>
        <translation>Toon statusbalk</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="289"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <source>Tools</source>
        <translation>Gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>Hand Tool</source>
        <translation>Handaanwijzer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Register...</source>
        <translation>Registratie...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Controleer nu naar updates</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">Exporteer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <location filename="../../src/mainwindow.ui" line="771"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Vergroot pagina markeringen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Reduce Page Thumbnails</source>
        <translation>verklein pagina markeringen</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Voeg pagina&apos;s toe van PDF</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Pak pagina&apos;s uit.naar PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Highlight Fields</source>
        <translation>Markeer alle velden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <location filename="../../src/mainwindow.cpp" line="5944"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1127"/>
        <source>Properties</source>
        <translation>Eigenschappen</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Alle paginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Huidige pagina</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Vlak</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Cursief</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">vet</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Vet cursief</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2003"/>
        <source>Bookmarks</source>
        <translation>Bladwijzers</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Invoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1161"/>
        <source>Highlight Text</source>
        <translation>Vet gedrukt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <source>Underline Text</source>
        <translation>Onderstrepen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1169"/>
        <source>Strikeout Text</source>
        <translation>Streep door</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2011"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="71"/>
        <source>Attachment</source>
        <translation>Bijlagen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>Check box</source>
        <translation>Selectievakje</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1278"/>
        <source>Radio button</source>
        <translation>Radio knop</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <location filename="../../src/mainwindow.ui" line="1302"/>
        <source>Button</source>
        <translation>Push Button</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>List box</source>
        <translation>Keuzelijst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1286"/>
        <source>Combo box</source>
        <translation>Keuzelijst met invoervak</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Edit Box</source>
        <translation>Tekst veld</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2802"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Wilt u de wijzigingen opslaan in %s voordat u het sluit?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="279"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="58"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Help...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2619"/>
        <source>Cannot open file :
</source>
        <translation>Kon bestand niet openen; bestand niet gevonden:
</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="203"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <source>View</source>
        <translation>Beeld</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">Er zijn geen nieuwe updates beschikbaar!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Edit Document</source>
        <translation>Bewerk het document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1242"/>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="426"/>
        <location filename="../../src/mainwindow.ui" line="1386"/>
        <source>Comments</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>Add Sticky Note</source>
        <translation>Opmerking</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Opmerking</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <location filename="../../src/mainwindow.cpp" line="5976"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="590"/>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="709"/>
        <source>There was an error opening the document !</source>
        <translation>Er is een fout opgetreden bij het openen van het document!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1075"/>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <source>Page layout</source>
        <translation>Pagina Opmaak</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Voeg pagina toe</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Voeg pagina toe</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Verwijder pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1995"/>
        <source>Pages</source>
        <translation>Paginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Undo</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Redo</source>
        <translation>Opnieuw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="880"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Create a new blank PDF</source>
        <translation>Maak een nieuwe lege PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="505"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="732"/>
        <location filename="../../src/mainwindow.ui" line="735"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1191"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <source>Send to Back</source>
        <translation>Naar achteren sturen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_mac_tool_bars.cpp" line="20"/>
        <source>Main</source>
        <translation>Hoofd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Images</source>
        <translation>Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1325"/>
        <source>Home page</source>
        <translation>Home page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="635"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Contents</source>
        <translation>Inhoud</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="796"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Select Text</source>
        <translation>Selecteer tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2618"/>
        <source>Open failed</source>
        <translation>Openen mislukt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="232"/>
        <source>Empty recent files list</source>
        <translation>Lijst met recente bestanden leegmaken</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation type="vanished">Export voltooid</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1081"/>
        <location filename="../../src/mainwindow.cpp" line="1212"/>
        <location filename="../../src/mainwindow.cpp" line="3025"/>
        <location filename="../../src/mainwindow.cpp" line="4331"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <location filename="../../src/mainwindow.cpp" line="4569"/>
        <source>Save failed</source>
        <translation>Opslaan mislukt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan niet opslaan in het bestand:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6062"/>
        <location filename="../../src/mainwindow.cpp" line="6064"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Eigenschappen van het document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>Find</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Find Next</source>
        <translation>Zoek volgende</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="57"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Nieuwe verscie beschikbaar !
Wilt u Nu downloaden?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>Close Without Saving</source>
        <translation>Sluiten zonder opslaan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2813"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <location filename="../../src/mainwindow.ui" line="1089"/>
        <source>Rotate Pages</source>
        <translation>Roteer pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Move Pages</source>
        <translation>Verplaats pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1930"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Edit Text</source>
        <translation>Bewerk tekst</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">Omschrijving</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Object Inspector</source>
        <translation>Object Inspector</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1117"/>
        <location filename="../../src/mainwindow.cpp" line="7130"/>
        <location filename="../../src/mainwindow.cpp" line="7192"/>
        <location filename="../../src/mainwindow.cpp" line="7341"/>
        <source>untitled</source>
        <translation>zonder titel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>Align Objects</source>
        <translation>Objecten uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1210"/>
        <location filename="../../src/mainwindow.ui" line="1213"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <location filename="../../src/mainwindow.ui" line="1705"/>
        <source>Line</source>
        <translation>Lijn</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1218"/>
        <location filename="../../src/mainwindow.ui" line="1221"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <location filename="../../src/mainwindow.ui" line="1727"/>
        <source>Rectangle</source>
        <translation>Rechthoek</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1226"/>
        <location filename="../../src/mainwindow.ui" line="1229"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Ellipse</source>
        <translation>Ovaal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Left</source>
        <translation>Links uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>Align Right</source>
        <translation>Rechts uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1048"/>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Align Top</source>
        <translation>Top uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Align Bottom</source>
        <translation>Onderkant uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1307"/>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Signature</source>
        <translation>Handtekening</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <location filename="../../src/mainwindow.ui" line="966"/>
        <source>Set Fit to Page</source>
        <translation>Passend binnen de pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3066"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Er is een fout opgetreden tijdens de handtekeningverificatie!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Forms</source>
        <translation>Formulieren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="510"/>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>End</source>
        <translation>Eind</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>Reset Forms</source>
        <translation>Herstel formulieren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Fit Page</source>
        <translation>Op de pagina passen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Fit Width</source>
        <translation>In de breedte passen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="757"/>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Facing Pages</source>
        <translation>Tegenoverliggende pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Delete Pages</source>
        <translation>Pagina&apos;s verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Edit Forms</source>
        <translation>Formulier bewerken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <source>Bring to Front</source>
        <translation>Breng naar voren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1097"/>
        <location filename="../../src/mainwindow.ui" line="1100"/>
        <source>Extract Pages...</source>
        <translation>Pagina&apos;s uitpakken...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1108"/>
        <location filename="../../src/mainwindow.ui" line="1111"/>
        <source>Insert Pages...</source>
        <translation>Pagina&apos;s invoegen...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <location filename="../../src/mainwindow.ui" line="1237"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <location filename="../../src/mainwindow.ui" line="1749"/>
        <source>Pencil</source>
        <translation>Penseel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1159"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF Bestanden (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Open a PDF file</source>
        <translation>Open een PDF bestand</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1262"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="vanished">Open Object Inspector</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation>Pagina&apos;s bijsnijden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">Vorige/Volgende</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">Bewerk hulpmiddelen</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">Pagina:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1906"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="649"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1056"/>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <source>Insert Blank Pages</source>
        <translation>Lege pagina&apos;s invoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1410"/>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1418"/>
        <location filename="../../src/mainwindow.ui" line="1421"/>
        <location filename="../../src/mainwindow.ui" line="1424"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7139"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7201"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-bestanden (* .fdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <source>Export Form Data...</source>
        <translation>Formuliergegevens exporteren ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1434"/>
        <source>Import Form Data...</source>
        <translation>Formuliergegevens importeren ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1439"/>
        <source>Export Comments Data...</source>
        <translation>Commentaargegevens exporteren ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1444"/>
        <source>Import Comments Data...</source>
        <translation>Commentaargegevens importeren ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="544"/>
        <source>Select text for copying and pasting</source>
        <translation>Selecteer tekst voor kopïeren en plakken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="167"/>
        <source>Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="245"/>
        <source>Navigation Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Save the document</source>
        <translation>Document opslaan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="710"/>
        <source>Save the document with a new name</source>
        <translation>Document opslaan met een nieuwe naam</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>Print the document</source>
        <translation>Print document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="793"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Selecteer en bewerk tekst, afbeeldingen, annotaties, formuliervelden ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="810"/>
        <source>Select text for editing</source>
        <translation>Selecteer tekst voor bewerken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Verwijder de momenteel geselecteerde object (en)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="916"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Knip de geselecteerde object (en) en plaats deze op het klembord</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="930"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Kopieer de geselecteerde object (en) en plaats deze op het klembord</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Paste from the Clipboard</source>
        <translation>Plak van het klembord</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <source>Undo the last action</source>
        <translation>Maak de laatste actie ongedaan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Redo the previously undone action.</source>
        <translation>Voer de eerder ongedaan gemaakte actie opnieuw uit.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Send to Back selected object.</source>
        <translation>Stuur geselecteerde object naar achteren.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Bring to Front selected object.</source>
        <translation>Stuur geselecteerde object naar voren.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Open window with document properties</source>
        <translation>Open venster met documenteigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <source>Click the page to add a note at that position</source>
        <translation>Klik op de pagina om een notitie op die positie toe te voegen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Insert new text to current page</source>
        <translation>Voeg nieuwe tekst toe aan de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>Insert new image to current page</source>
        <translation>Voeg een nieuwe afbeeldding toe aan de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>Insert new link to current page</source>
        <translation>Voeg een nieuwe link toe aan de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1449"/>
        <source>Save Optimized As...</source>
        <translation>Geoptimaliseerd opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5939"/>
        <source>Font type</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5941"/>
        <source>Font Embedded</source>
        <translation>Lettertype ingesloten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5950"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5959"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5967"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5972"/>
        <location filename="../../src/mainwindow.cpp" line="6196"/>
        <source>Width</source>
        <translation>BreedteBreedte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5973"/>
        <location filename="../../src/mainwindow.cpp" line="6197"/>
        <source>Height</source>
        <translation>Hoogte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5974"/>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5980"/>
        <source>Path</source>
        <translation>Pad</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5984"/>
        <source>Shading</source>
        <translation>Schaduw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="1946"/>
        <source>Objects</source>
        <translation>Objecten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6224"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6005"/>
        <location filename="../../src/mainwindow.cpp" line="6211"/>
        <source>Selected</source>
        <translation>Geselecteerd</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1463"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1620"/>
        <location filename="../../src/mainwindow.cpp" line="1647"/>
        <source>Can&apos;t find :</source>
        <translation>Kan het niet vinden:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5943"/>
        <source>Font Not Embedded</source>
        <translation>Lettertype niet ingesloten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="624"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1476"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1481"/>
        <source>Document Actions</source>
        <translation>Document acties</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Replace Document Colors</source>
        <translation>Vervang document kleuren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Paste to Multiple Pages</source>
        <translation>Plak naar meerdere pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2069"/>
        <location filename="../../src/mainwindow.ui" line="2072"/>
        <source>Paste at Copy Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2075"/>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Shift+V</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation type="vanished">Uw geïnstalleerde versie van Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>JavaScript Console</source>
        <translation>JavaScript Console</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>Page Properties</source>
        <translation>Pagina eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1521"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF-editor kan geen kop- en voetteksten in het document vinden.</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="vanished">Wilt u de kopteksten en voetteksten uit het document verwijderen?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="376"/>
        <source>Watermark</source>
        <translation>Watermerk</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="430"/>
        <source>Measurements</source>
        <translation>Afmetingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <location filename="../../src/mainwindow.cpp" line="3180"/>
        <source>Drawing</source>
        <translation>Tekenen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Ctrl+Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1537"/>
        <source>Menu Bar</source>
        <translation>Menubalk</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1540"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>Show Cover Page During Facing</source>
        <translation>Voorblad tonen tijdens weergave</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Full Screen</source>
        <translation>Volledig scherm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1559"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1590"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Align Center Horizontal</source>
        <translation>Lijn het midden horizontaal uit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Vertical</source>
        <translation>Lijn het midden verticaal uit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <source>Find Previous</source>
        <translation>Vind vorige</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1619"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <location filename="../../src/mainwindow.ui" line="1644"/>
        <source>Grid</source>
        <translation>Raster</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1647"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Snap to Grid</source>
        <translation>Klik op raster</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1661"/>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <location filename="../../src/mainwindow.ui" line="1672"/>
        <source>Distance Tool</source>
        <translation>Afstand gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <location filename="../../src/mainwindow.ui" line="1683"/>
        <source>Perimeter Tool</source>
        <translation>Perimeter gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <location filename="../../src/mainwindow.ui" line="1694"/>
        <source>Area Tool</source>
        <translation>Gebied gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <location filename="../../src/mainwindow.ui" line="1716"/>
        <source>Arrow</source>
        <translation>Pijl</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <location filename="../../src/mainwindow.ui" line="1760"/>
        <source>Attach a File as a Comment</source>
        <translation>Bijlage toevoegen als opmerking</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1987"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2027"/>
        <source>Signatures</source>
        <translation type="unfinished">Handtekeningen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2035"/>
        <source>Layers</source>
        <translation type="unfinished">Lagen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2043"/>
        <source>Object TreeView</source>
        <translation type="unfinished">Boomstructuur object</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2051"/>
        <source>Document Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2056"/>
        <source>Organize Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2064"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished">Bewerk tekstelementen als blokken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2080"/>
        <source>Pages to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2088"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2096"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2101"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2104"/>
        <source>Manage Header And Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2109"/>
        <source>Add To Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2114"/>
        <source>Open session from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2119"/>
        <source>Save session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2124"/>
        <source>Managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2129"/>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2134"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2139"/>
        <source>Clear recent sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2144"/>
        <source>Save session to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2149"/>
        <source>Current Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2154"/>
        <source>Save session to managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2159"/>
        <source>Save and close current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2164"/>
        <source>Delete across pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3606"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor kan geen watermerken vinden in het document.</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="vanished">Wilt u de watermerken uit het document verwijderen?</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="vanished">Master PDF Editor kan geen achtergrond in het document vinden.</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="vanished">Wilt u de achtergrond uit het document verwijderen?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Blank PDF</source>
        <translation>Leeg PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <source>From Scanner</source>
        <translation>Van Scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <location filename="../../src/mainwindow.ui" line="1771"/>
        <source>Create a new document from scanner</source>
        <translation>Maak een nieuw document van scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <source>From Files</source>
        <translation>Van bestanden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <location filename="../../src/mainwindow.ui" line="1782"/>
        <source>Create a new document from files</source>
        <translation>Maak een nieuw document van bestanden</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">Stempel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <location filename="../../src/mainwindow.ui" line="1801"/>
        <source>Brush</source>
        <translation>Borstel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="367"/>
        <source>Header and Footer</source>
        <translation>Kop en Voet</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>Check Box</source>
        <translation>Selectievakje</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Radio Button</source>
        <translation>Radio knop</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Combo Box</source>
        <translation>Keuzelijst met invoervak</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <source>List Box</source>
        <translation>Keuzelijst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Text Field</source>
        <translation>Tekst veld</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1820"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5938"/>
        <source>Characters</source>
        <translation>Karakters</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="215"/>
        <source>Page Display</source>
        <translation>Pagina weergave</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Go To</source>
        <translation>Ga naar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="237"/>
        <location filename="../../src/mainwindow.ui" line="2019"/>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1721"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Het is vereist om het programma opnieuw te starten zodat de wijzigingen van kracht worden.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1633"/>
        <source>Send file via email</source>
        <translation>Verzend bestand via e-mail</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Callout</source>
        <translation>Roepen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1835"/>
        <source>Formatted Text</source>
        <translation>Geformatteerde tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Typewriter</source>
        <translation>Schrijfmachine</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <location filename="../../src/mainwindow.ui" line="1877"/>
        <source>Redaction</source>
        <translation>Opstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <source>Alt+7</source>
        <translation>Alt+7</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <source>Check for Updates</source>
        <translation>Controleer op updates</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Mark for Redaction</source>
        <translation>Markeren voor opstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1851"/>
        <source>Apply Redactions</source>
        <translation>Opstellen toepassen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1856"/>
        <source>Redaction Properties</source>
        <translation>Opstel eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1864"/>
        <source>Show Redaction ToolBar</source>
        <translation>Toon opstel werkbalk</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1869"/>
        <source>Search and Redact</source>
        <translation>Zoeken en redigeer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1882"/>
        <source>Certificate Manager</source>
        <translation>Certificaat manager</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1887"/>
        <source>Send Backward</source>
        <translation>Terug sturen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1892"/>
        <source>Bring Forward</source>
        <translation>Vooruit sturen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1900"/>
        <source>Edit Vector Images</source>
        <translation>Bewerk Vector afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1911"/>
        <source>Next View</source>
        <translation>Volgende beeld</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1916"/>
        <source>Previous View</source>
        <translation>Vorige beeld</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1924"/>
        <source>Edit Images</source>
        <translation>Bewerk afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1935"/>
        <location filename="../../src/mainwindow.cpp" line="3307"/>
        <source>Show Comments List</source>
        <translation>toon lijst met commentaren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="462"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation>U hebt geen toegang tot dit gecodeerde document.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="464"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>Het is gecodeerd met een certificaat afwezig in uw systeem.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="477"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1043"/>
        <source>File is opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1045"/>
        <source>Use Save As... to save your work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2897"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3147"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="100"/>
        <source>All Reviewers</source>
        <translation>Alle recensenten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3285"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="80"/>
        <source>Hide All Comments</source>
        <translation>Verberg alle commentaren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3290"/>
        <source>Show All Comments</source>
        <translation>Toon alle commentaren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3592"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3627"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3634"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5319"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>Master PDF-editor kan in het document geen opsteller vinden!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6199"/>
        <source>Format</source>
        <translation type="unfinished">Formaat</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6900"/>
        <source>Failed to restore last open session:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7437"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7438"/>
        <source>Document doesn&apos;t contain any tables with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="79"/>
        <source>Comment View</source>
        <translation>Commentaar bekijken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="93"/>
        <source>Show by Type</source>
        <translation>Weergeven op type</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3171"/>
        <source>All Types</source>
        <translation>Alle typen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3176"/>
        <source>Notes</source>
        <translation>Notities</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3184"/>
        <source>Text Editing Markups</source>
        <translation>Tekstmarkeringen bewerken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3188"/>
        <source>Stamps</source>
        <translation>Stempels</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3192"/>
        <source>Attachments</source>
        <translation>Bijlagen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="97"/>
        <source>Show by Reviewer</source>
        <translation>Weergeven door recensent</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="107"/>
        <source>Show by Status</source>
        <translation>Weergeven op status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3217"/>
        <source>All Status</source>
        <translation>Alle status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3222"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Toon</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="45"/>
        <source>You already have the latest version!</source>
        <translation>U heeft al de laatste versie!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>Alle ondersteunde bestanden (* .pdf * .xps * .PDF * .XPS * .tif * .tiff * .fdf) ;; PDF-bestanden (* .pdf * .PDF) ;; FDF-bestanden (* .fdf * .FDF) ;; XPS-bestanden (* .xps * .XPS) ;; TIFF-bestanden (* .tif * .tiff) ;; Alle bestanden (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3303"/>
        <source>Hide Comments List</source>
        <translation>Verberg lijst met commentaren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>File is locked by another Master PDF Editor instance, it will be opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="433"/>
        <source>You will be able to save your work, but only to another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="vanished">pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="616"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="635"/>
        <source>Place Initials</source>
        <translation>Initialen plaatsen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="617"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="636"/>
        <source>Create New Initials</source>
        <translation>creër nieuwe initialen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="619"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="638"/>
        <source>Open Containing Folder</source>
        <translation>Open bevattende map</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open Bestand&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF of XPS bestand&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Handgereedschap&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Gebruik het handje om pagina&apos;s te verplaatsen, koppelingen te openen en tekst te selecteren.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Selecteer Tekst&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecteer tekst voor kopiëren en plakken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Opslaan&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sla het document op&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Opslaan als...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sla het document op met een nieuwe naam&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>System Print...</source>
        <translation>Systeem afdrukken ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head /&gt; &lt;body&gt; &lt;p&gt; &lt;span style = &quot;font-weight: 600;&quot;&gt; Systeemafdrukdialoog &lt;/ span&gt; &lt;/ p&gt; &lt;p&gt; Afdrukken via systeemdialoog ... &lt;/ p &gt; &lt;/ body&gt; &lt;/ html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head /&gt; &lt;body&gt; &lt;p&gt; &lt;span style = &quot;font-weight: 600;&quot;&gt; Document bewerken &lt;/ span&gt; &lt;/ p&gt; &lt;p&gt; Tekst, afbeeldingen, annotaties en formuliervelden selecteren en bewerken. .. &lt;/ p&gt; &lt;/ body&gt; &lt;/ html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bewerk Tekstt Objecten&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecteer tekst voor bewerken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Verwijder object(en)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Verwijder de huidige geselecteerde objecten)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bewerk Formulieren&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecteer formulier voor bewerken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nieuw&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Maak een nieuwe lege PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Afdrukken&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Document afdrukken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="913"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Knippen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Knip de selectieobject (en) en plaats deze op het klembord&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopiëren&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopieer de selectieobject (en) en plaats deze op het klembord&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Plakken&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Plak van het klembord&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ongedaan maken&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Laatste actie ongedaan maken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Herhalen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Voer de eerder ongedaan gemaakte actie opnieuw uit.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1130"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Eigenschappen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open venster met documenteigenschappen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tekst invoegen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Voeg nieuwe tekst toe aan de huidige pagina&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Afbeelding invoegen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Voeg een nieuwe afbeelding toe aan de huidige pagina&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Link invoegen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Voeg een nieuwe link in naar de huidige pagina&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bewerk Vector afbeeldingen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecteer vector Afbeeldingen voor bewerken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Afbeeldingen bewerken&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecteer bitmap afbeeldingen voor bewerken&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="149"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Pages to Images</source>
        <translation>Pagina&apos;s naar Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Pages to Text</source>
        <translation>Pagina&apos;s naar Tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1951"/>
        <source>Extract all Images</source>
        <translation>Alle afbeeldingen uitpakken</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1434"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG IAfbeeldingen (*.png);;BMP Afbeeldingen (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1956"/>
        <source>Reload</source>
        <translation>Vernieuwen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1964"/>
        <source>Take a Snapshot</source>
        <translation>Maak een schermopname</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="249"/>
        <source>Red</source>
        <translation>Rood</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="254"/>
        <source>Blue</source>
        <translation>Blauw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="259"/>
        <source>Yellow</source>
        <translation>Geel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="264"/>
        <source>Green</source>
        <translation>Groen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Default</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="63"/>
        <source>What&apos;s new</source>
        <translation>Wat is nieuw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="551"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>Het bestand dat u probeert te openen, bevat opmerkingen of formuliergegevens die veronderstelt worden te worden geplaatst op</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>This document cannot be found.</source>
        <translation>Dit document kan niet worden gevonden.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>Wilt u bladeren en proberen dit document te vinden?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1672"/>
        <source>Saved Settings</source>
        <translation>Opgeslagen instellingen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="26"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation>Kan niet verbinden! Controleer of u verbinding heeft met internet en controleer opnieuw op updates.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1969"/>
        <source>Toolbar Settings</source>
        <translation>Werkbalk instellingen</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">E-mailbezorging</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Tekst invoegen</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Notitie</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="vanished">Enkele pagina</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1977"/>
        <source>Continuous</source>
        <translation>Doorgaan</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Tekst blok</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <source>Insert Initials</source>
        <translation>Plaats initialen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5159"/>
        <location filename="../../src/mainwindow.cpp" line="5181"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Weet u zeker dat u alle werkbalken wilt resetten naar de standaardinstellingen?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="302"/>
        <source>Reset toolbars</source>
        <translation>Werkbalken opnieuw instellen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Minimum tools</source>
        <translation type="unfinished">minimum gereedschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="61"/>
        <source>New Paragraph</source>
        <translation type="unfinished">Nieuwe Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="114"/>
        <source>Delete All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="116"/>
        <source>Delete All Visible Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="299"/>
        <source>Maximum tools</source>
        <translation type="unfinished">Maiximum gereedschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="82"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="250"/>
        <location filename="../../src/mainwindow_update.cpp" line="357"/>
        <source>Error</source>
        <translation type="unfinished">Fout</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="252"/>
        <location filename="../../src/mainwindow_update.cpp" line="359"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished">Activatie mislukt! Controleer uw internet verbinding.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="297"/>
        <source>License is expired!</source>
        <translation type="unfinished">Licentie is verlopen!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="71"/>
        <location filename="../../src/mainwindow_update.cpp" line="300"/>
        <location filename="../../src/mainwindow_update.cpp" line="504"/>
        <source>Renew</source>
        <translation type="unfinished">Vernieuw</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="68"/>
        <source>WARNING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="338"/>
        <source>Too many activations!</source>
        <translation type="unfinished">Te veel activaties!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="394"/>
        <source>Server connection lost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="445"/>
        <source>Failed to connect to License server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="516"/>
        <source>Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <source>Label</source>
        <translation type="unfinished">Label</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6222"/>
        <source>Rotate</source>
        <translation type="unfinished">Roteren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="54"/>
        <source>Check Mark</source>
        <translation type="unfinished">Vinkje</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="55"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="56"/>
        <source>Comment</source>
        <translation type="unfinished">Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="57"/>
        <source>Cross</source>
        <translation type="unfinished">Kruis</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="60"/>
        <source>Key</source>
        <translation type="unfinished">Sleutel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="62"/>
        <source>Text Note</source>
        <translation type="unfinished">Tekst notitie</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="63"/>
        <source>Paragraph</source>
        <translation type="unfinished">Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Right Arrow</source>
        <translation type="unfinished">Pijl rechts</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="65"/>
        <source>Right Pointer</source>
        <translation type="unfinished">Aanwijzer rechts</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="66"/>
        <source>Star</source>
        <translation type="unfinished">Ster</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="67"/>
        <source>Up Arrow</source>
        <translation type="unfinished">Pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="68"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">Linker pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="69"/>
        <source>Graph</source>
        <translation type="unfinished">Diagram</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="70"/>
        <source>Paper Clip</source>
        <translation type="unfinished">Paper Clip</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="72"/>
        <source>Tag</source>
        <translation type="unfinished">Label</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1982"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="62"/>
        <source>Failed opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="67"/>
        <source>File is already opened and opening same file in multiple tabs option is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="72"/>
        <source>File does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="319"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="323"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>Current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="376"/>
        <source>Error loading session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="20"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zoom uit</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="27"/>
        <source>Close</source>
        <translation type="unfinished">Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="34"/>
        <source>Edit</source>
        <translation type="unfinished">Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="41"/>
        <source>Remove</source>
        <translation type="unfinished">Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="48"/>
        <source>Zoom In</source>
        <translation type="unfinished">Inzoomen</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="65"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="72"/>
        <source>Zoom Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="79"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="14"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="82"/>
        <source>Manage Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="113"/>
        <source>All</source>
        <translation type="unfinished">Alles</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="117"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="510"/>
        <source>Header and Footer</source>
        <translation type="unfinished">Kop en Voet</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="119"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="513"/>
        <source>Bates Numbering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="263"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="516"/>
        <source>Type</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="517"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="518"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="519"/>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Left</source>
        <translation type="unfinished">Links</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Right</source>
        <translation type="unfinished">Rechts</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="525"/>
        <source>Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="635"/>
        <source>Remove Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="639"/>
        <source>Do you want to remove selected Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="643"/>
        <source>Do you want to remove selected headers/footers from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="657"/>
        <source>Remove all Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="658"/>
        <source>Do you want to remove all headers, footers and Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>Tekst herkenning</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>Origineel</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="25"/>
        <source>Not Text</source>
        <translation>Geen tekst</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Verplaats pagina&apos;s</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagina&apos;s van</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">tot:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="43"/>
        <source>Destination</source>
        <translation>Bestemming</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="55"/>
        <source>To:</source>
        <translation>Naar:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="65"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>First</source>
        <translation>Eerste</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="121"/>
        <source>Last</source>
        <translation>Laatste</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Huidige pagina</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Pagina grootte</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="49"/>
        <source>Width</source>
        <translation>Breedte</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="86"/>
        <source>Height</source>
        <translation>Hoogte</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="vanished">A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="vanished">A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="vanished">A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="vanished">A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="vanished">A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="vanished">A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="vanished">A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="vanished">A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="vanished">A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="vanished">A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="vanished">A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="vanished">Aangepast paginaformaat</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>Portrait</source>
        <translation>Portret</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>Landscape</source>
        <translation>Landschap</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="151"/>
        <source>Contents Size</source>
        <translation>Inhoudsmaat</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>Left margin</source>
        <translation>Linker marge</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="203"/>
        <source>Top margin</source>
        <translation>Top marge</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="183"/>
        <source>Right margin</source>
        <translation>Rechter marge</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Bottom margin</source>
        <translation>Onderste marge</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="246"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="252"/>
        <source>Before current page</source>
        <translation>Voor de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="269"/>
        <source>After current page</source>
        <translation>Na de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="276"/>
        <source>After last page</source>
        <translation>Na de laatste pagina</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="262"/>
        <source>Before first page</source>
        <translation>Voor de eerste pagina</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="286"/>
        <source>Number of pages</source>
        <translation>Aantal pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="312"/>
        <source>Page(s)</source>
        <translation>Pagina(s)</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="292"/>
        <source>Create</source>
        <translation>Maak</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="vanished">Brief</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="vanished">Tabloid</translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="vanished">B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="vanished">B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="vanished">B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="vanished">B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="vanished">B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="vanished">B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="vanished">Uitspraak</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="vanished">Uitvoerend</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="vanished">Folio</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="vanished">Quarto</translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="vanished">Notitie</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="vanished">ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="vanished">ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="vanished">ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="vanished">ANSI F</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="122"/>
        <source>Units</source>
        <translation>Eenheden</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>OCR-engine</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1.6-8.12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="164"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="43"/>
        <source>Languages</source>
        <translation>Talen</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="49"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="194"/>
        <source>Selected</source>
        <translation>Geselecteerd</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="36"/>
        <source>Install languages</source>
        <translation>Installeer talen</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="108"/>
        <source>Searchable Text</source>
        <translation>Doorzoekbare tekst</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Editable Text</source>
        <translation>Bewerkbare tekst</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="138"/>
        <source>Font Family</source>
        <translation>Lettertype familie</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="vanished">Bewerk alle herkende tekst handmatig</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">automatisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="201"/>
        <source>Force manual text editing if confidence level not achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="171"/>
        <source>Minimal confidence level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Lijn</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="224"/>
        <source>Advanced</source>
        <translation type="unfinished">Geavanceerd</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="258"/>
        <source>Helvetica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="68"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>Weet u zeker dat u de documentherkenning wilt stoppen?</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="65"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Geen eigenschappen
Er zijn geen objectselecties.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="223"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3778"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4059"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2379"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="288"/>
        <source>Property</source>
        <translation>Eigendom</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="293"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1597"/>
        <source>Value</source>
        <translation>Waarde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3153"/>
        <source>Top</source>
        <translation>Boven</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2434"/>
        <source>Font Family</source>
        <translation>Lettertype familie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3790"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2479"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4079"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3725"/>
        <source>Fill Color</source>
        <translation>Opvulkleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2541"/>
        <source>Stroke Color</source>
        <translation>Lijnkleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3578"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3639"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4029"/>
        <source>Opacity</source>
        <translation>Dekking</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2408"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3163"/>
        <source>Width</source>
        <translation>Breedte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2819"/>
        <source>Height</source>
        <translation>Hoogte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2431"/>
        <source>Path</source>
        <translation>Pad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3934"/>
        <source>Form Field</source>
        <translation>Tekst veld</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3857"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">vet</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Cursief</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1892"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1943"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lettertype familie&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Wijzig Lettertype familie&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3674"/>
        <source>Remove</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="546"/>
        <source>Goto a Page View</source>
        <translation>Ga naar pagina weergave</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="551"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="556"/>
        <source>Open a web link</source>
        <translation>Open een weblink</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Reset form</source>
        <translation>Formulier herstellen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="566"/>
        <source>Show/Hide fields</source>
        <translation>Toon/Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="571"/>
        <source>Submit a form</source>
        <translation>Verstuur een formulier</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="576"/>
        <source>Run a JavaScript</source>
        <translation>Voer een Java Script uit</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="478"/>
        <source>Add an Action</source>
        <translation>Voeg Handeling Toe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="484"/>
        <source>Trigger</source>
        <translation>Trigger</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="492"/>
        <source>Mouse Up</source>
        <translation>Muis naar boven</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="497"/>
        <source>Mouse Down</source>
        <translation>Muis naar beneden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="502"/>
        <source>Mouse Enter</source>
        <translation>Mouse Enter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="507"/>
        <source>Mouse Exit</source>
        <translation>Muis uitgang</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="512"/>
        <source>On Receive Focus</source>
        <translation>Focus ontvangen aan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="517"/>
        <source>On Lose Focus</source>
        <translation>Focus verliezen aan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="538"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="590"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="918"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="600"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3341"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1677"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2269"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3460"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="905"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="695"/>
        <source>Behavior</source>
        <translation>Gedrag</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="849"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1821"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1976"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="371"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="854"/>
        <source>Push</source>
        <translation>Drukken</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Outline</source>
        <translation>Omtrek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="864"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Invert</source>
        <translation>Omkeren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="898"/>
        <source>Item</source>
        <translation>Item</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="931"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1206"/>
        <source>Export Value</source>
        <translation>Exporteer waarde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="771"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="973"/>
        <source>Up</source>
        <translation>Omhoog</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="776"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="957"/>
        <source>Down</source>
        <translation>Omlaag</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1001"/>
        <source>Sort Items</source>
        <translation>Sorteer items</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="980"/>
        <source>Commit selected value immediately</source>
        <translation>Onmiddelijk vastleggen van de geselecteerde waarde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="994"/>
        <source>Multiple selection</source>
        <translation>Meerdere selectie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="987"/>
        <source>Allow user to enter custom text</source>
        <translation>Sta de gebruiker toe om aangepaste tekst in te voeren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1126"/>
        <source>Password</source>
        <translation>Wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1133"/>
        <source>Scrollable</source>
        <translation>Scrollable</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1140"/>
        <source>Check spelling</source>
        <translation>Controleer spelling</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1061"/>
        <source>Limit to</source>
        <translation>Limiet tot</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1075"/>
        <source>chars</source>
        <translation>karakter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1082"/>
        <source>Split into</source>
        <translation>Delen in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1054"/>
        <source>Allow Rich Text formatting</source>
        <translation>Opmaak in RTF-indeling toestaan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Multi-line</source>
        <translation>meerdere lijnen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <source>cells</source>
        <translation>Cellen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1041"/>
        <source>Center</source>
        <translation>Centreren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1046"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>Default Value</source>
        <translation>Standaard waarde</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Alignment</source>
        <translation>Uitlijning</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1219"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <source>Style</source>
        <translation>Stijl</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1230"/>
        <source>Check</source>
        <translation>Controleer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1235"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="347"/>
        <source>Circle</source>
        <translation>Cirkel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1240"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="349"/>
        <source>Cross</source>
        <translation>Kruis</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1250"/>
        <source>Square</source>
        <translation>Vierkant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1255"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="358"/>
        <source>Star</source>
        <translation>Ster</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1183"/>
        <source>Checked by Default</source>
        <translation>Standaard gecontroleerd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3768"/>
        <source>Line Thickness</source>
        <translation>Lijn dikte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1386"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3718"/>
        <source>Border Color</source>
        <translation>Rand Kleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3761"/>
        <source>Line Style</source>
        <translation>Lijn stijl</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3733"/>
        <source>Solid</source>
        <translation>Effen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1406"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3738"/>
        <source>Dashed</source>
        <translation>Gestippeld</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3753"/>
        <source>Underline</source>
        <translation>Onderstrepen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Highlight</source>
        <translation>Markeren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>OutLine</source>
        <translation>Omtrek</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Insert</source>
        <translation>Invoegen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1463"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;! DOCTYPE HTML PUBLIC &quot;- // W3C // DTD HTML 4.0 // EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt; &lt;head&gt; &lt;meta name = &quot;qrichtext&quot; content = &quot;1&quot; /&gt; &lt;style type = &quot;text / css&quot;&gt;
p, li {white-space: pre-wrap; }
&lt;/ style&gt; &lt;/ head&gt; &lt;body style = &quot;font-family: &apos;Sans Serif&apos;; font-size: 9pt; font-weight: 400; font-style: normal;&quot;&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-insent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-size: 10pt;&quot;&gt; Signature. &lt;/ span&gt; &lt;/ p&gt;
&lt;p style = &quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-block-insent: 0; text-indent: 0px;&quot;&gt; &lt;span style = &quot;font-size: 10pt;&quot;&gt; Geen beschikbare opties &lt;/ span&gt; &lt;/ p&gt; &lt;/ body&gt; &lt;/ html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3360"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3479"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Format category</source>
        <translation>Formaat categorie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1826"/>
        <source>Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1831"/>
        <source>Percentage</source>
        <translation>Percentage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1836"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1841"/>
        <source>Time</source>
        <translation>Tijd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1846"/>
        <source>Special</source>
        <translation>Speciaal</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1851"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2006"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="333"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="337"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1870"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="131"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1875"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="136"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1557"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1885"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1890"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1895"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1572"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1577"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1905"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1910"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1915"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1920"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1929"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1934"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1939"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1944"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Currency Symbol</source>
        <translation>Huidige symbool</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1981"/>
        <source>Dollar ($)</source>
        <translation>Dollar ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1986"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <source>Pound (£)</source>
        <translation>Pond (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1996"/>
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Show parentheses</source>
        <translation>Haakjes tonen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2047"/>
        <source>Decimal Places</source>
        <translation>Decimale plaatsen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2054"/>
        <source>Separation Style</source>
        <translation>Scheidingsstijl</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>Use red text</source>
        <translation>Gebruik rode tekst</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Date Options</source>
        <translation>Datum opties</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>Time Options</source>
        <translation>Tijd opties</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2150"/>
        <source>Special Options</source>
        <translation>Speciale opties</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Format Script</source>
        <translation>Format Script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2242"/>
        <source>KeyStroke Script</source>
        <translation>KeyStroke Script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>Validate</source>
        <translation>Valideren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Validation Script</source>
        <translation>Valideer Script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2349"/>
        <source>Calculate</source>
        <translation>Calculeren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2370"/>
        <source>Calculation Script</source>
        <translation>Calculeer Script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Fill text</source>
        <translation>Vul tekst</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2504"/>
        <source>Stroke Text</source>
        <translation>Tekst doorstrepen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Fill and Stroke</source>
        <translation>Vul en Lijn</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Invisible</source>
        <translation>Onzichtbaar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2554"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3626"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4016"/>
        <source>Line Width</source>
        <translation>Lijn breedte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Character spacing</source>
        <translation>Tekenafstand</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Word spacing</source>
        <translation>Woord afstand</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2597"/>
        <source>Line spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2758"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2768"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2778"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2788"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished">Lijn het midden verticaal uit</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2885"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2910"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2935"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2960"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2998"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3017"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2901"/>
        <source>Align Top</source>
        <translation type="unfinished">Top uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Align Right</source>
        <translation type="unfinished">Rechts uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <source>Align Left</source>
        <translation type="unfinished">Links uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">Lijn het midden horizontaal uit</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2995"/>
        <source>Align Bottom</source>
        <translation type="unfinished">Onderkant uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <source>Send To Back</source>
        <translation type="unfinished">Stuur naar achteren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3033"/>
        <source>Send Backward</source>
        <translation type="unfinished">Terug sturen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3052"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3071"/>
        <source>Bring To Front</source>
        <translation type="unfinished">Naar voren brengen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3143"/>
        <source>Coordinates</source>
        <translation>Coördinaten</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3094"/>
        <source>Absolute</source>
        <translation>Absoluut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3099"/>
        <source>Relative</source>
        <translation>Relatief</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3189"/>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3208"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3832"/>
        <source>Font</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3246"/>
        <source>Matrix</source>
        <translation>Matrix</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>General</source>
        <translation>Algemeen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3303"/>
        <source>Appearance</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3379"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3553"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3601"/>
        <source>Stroke</source>
        <translation>Doorstrepen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3591"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3613"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3819"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4042"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3693"/>
        <source>Borders and Colors</source>
        <translation>Randen en Kleuren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3700"/>
        <source>Thin</source>
        <translation>Dun</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3705"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3710"/>
        <source>Thick</source>
        <translation>Dik</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3743"/>
        <source>Beveled</source>
        <translation>Schuin</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3748"/>
        <source>Inset</source>
        <translation>Invoegen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3803"/>
        <source>Auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3867"/>
        <source>ToolTip</source>
        <translation>Knopinfo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3883"/>
        <source>Orientation</source>
        <translation>Oriëntatie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3891"/>
        <source>0 Degrees</source>
        <translation>0 graden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3896"/>
        <source>90 Degrees</source>
        <translation>90 Graden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3901"/>
        <source>180 Degrees</source>
        <translation>180 Graden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3906"/>
        <source>270 Degrees</source>
        <translation>270 Graden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3927"/>
        <source>Read Only</source>
        <translation>Alleen Lezen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3942"/>
        <source>Visible</source>
        <translation>Zichtbaar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3947"/>
        <source>Hidden</source>
        <translation>Verborgen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3952"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Zichtbaar maar wordt niet afgedrukt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3957"/>
        <source>Hidden but printable</source>
        <translation>Verborgen maar afdrukbaar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3965"/>
        <source>Required</source>
        <translation>Verplicht</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4109"/>
        <source>Locked</source>
        <translation>Vergrendeld</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1880"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1887"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1900"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1907"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1955"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1961"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2454"/>
        <source>Shading</source>
        <translation>Schaduw</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4052"/>
        <source>Subject</source>
        <translation>Onderwerp</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4089"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <source>Maintain aspect ratio</source>
        <translation>Behoud de beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code</source>
        <translation>Postcode</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code+4</source>
        <translation>Postcode+4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Phone Number</source>
        <translation>Telefoon nummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Social Security Number</source>
        <translation>Burgerservicenummer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="346"/>
        <source>Check Mark</source>
        <translation>Vinkje</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="348"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="350"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Tekst invoegen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="352"/>
        <source>Key</source>
        <translation>Sleutel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="353"/>
        <source>New Paragraph</source>
        <translation>Nieuwe Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="354"/>
        <source>Text Note</source>
        <translation>Tekst notitie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="355"/>
        <source>Paragraph</source>
        <translation>Paragraaf</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="356"/>
        <source>Right Arrow</source>
        <translation>Pijl rechts</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="357"/>
        <source>Right Pointer</source>
        <translation>Aanwijzer rechts</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="359"/>
        <source>Up Arrow</source>
        <translation>Pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="360"/>
        <source>Up Left Arrow</source>
        <translation>Linker pijl omhoog</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="361"/>
        <source>Graph</source>
        <translation>Diagram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="362"/>
        <source>Paper Clip</source>
        <translation>Paper Clip</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="363"/>
        <source>Attachment</source>
        <translation>Bijlage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="364"/>
        <source>Tag</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Rotate</source>
        <translation>Roteren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3548"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3566"/>
        <source>Fill</source>
        <translation>Vullen</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation type="vanished">Lijn hoogte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2659"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3398"/>
        <source>Selection change</source>
        <translation>Verander Selectie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3426"/>
        <source>Do nothing</source>
        <translation>Niets doen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3433"/>
        <source>Execute this script</source>
        <translation>Dit script uitvoeren</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Units</source>
        <translation>Eenheden</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2146"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4359"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2151"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4379"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4399"/>
        <source> mm</source>
        <translatorcomment> mm</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">Watermerk</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">Achtergrond</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">Kop en Voet</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3265"/>
        <source>Clipping Path</source>
        <translation>Uitknippad</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2855"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2860"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2865"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="702"/>
        <source>Layout</source>
        <translation>Opmaak</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Label only</source>
        <translation>Alleen label</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Icon only</source>
        <translation>Alleen pictogram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="723"/>
        <source>Icon top, label bottom</source>
        <translation>Pictogram boven, label onderaan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <source>Label top, icon bottom</source>
        <translation>Label bovenaan, pictogram onderaan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Icon left, label right</source>
        <translation>Pictogram links, label rechts</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>label left, icon right</source>
        <translation>label inks, pictogram rechts</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Label over icon</source>
        <translation>Label over pictogram</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="758"/>
        <source>Icon and Label</source>
        <translation>Pictogram en Label</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>Rollover</source>
        <translation>Omrollen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="798"/>
        <source>State</source>
        <translation>Staat</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="805"/>
        <source>Choose Icon...</source>
        <translation>Kies pictogram...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="828"/>
        <source>Clear</source>
        <translation>Opruimen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>Knoppen met dezelfde naam en waarden zijn geselecteerd in unison</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Openen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alle bestanden (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="751"/>
        <source>Advanced</source>
        <translation>Geavanceerd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4102"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2001"/>
        <source>Ruble (₽)</source>
        <translation>Roebel (₽)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3498"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4127"/>
        <source>Always show Object Inspector</source>
        <translation>Laat Object Inspecteur altijd zien</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Tekst blok</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="175"/>
        <source>Object Inspector</source>
        <translation type="unfinished">Object Inspector</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1501"/>
        <source>QRCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1506"/>
        <source>DataMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1517"/>
        <source>Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>ECC Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>X Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1590"/>
        <source>X/Y Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Include field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1637"/>
        <source>Pick...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1689"/>
        <source>Encode using Tab Delmited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1694"/>
        <source>Encode using XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1699"/>
        <source>JavaScript</source>
        <translation type="unfinished">javaScript</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>Boomstructuur object</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="285"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="317"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="373"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Alle paginas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Beeld</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="32"/>
        <source>Expand All</source>
        <translation>Alles uitvouwen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="33"/>
        <source>Collapse All</source>
        <translation>Alles inklappen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="92"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="135"/>
        <source>All</source>
        <translation>Alles</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Images</source>
        <translation>Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="108"/>
        <source>Paths</source>
        <translation>Paden</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Shadings</source>
        <translation>Schaduwen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>Containers</source>
        <translation>Containers</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Text Fields</source>
        <translation>Tekst velden</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>List Boxes</source>
        <translation>Keuzelijsten</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Combo Boxes</source>
        <translation>Keuzelijst met invoervakken</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Check Boxes</source>
        <translation>Selectievakjes</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Radio Buttons</source>
        <translation>Radio knoppen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="166"/>
        <source>Buttons</source>
        <translation>Knoppen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="171"/>
        <source>Links</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="176"/>
        <source>Signatures</source>
        <translation>Handtekeningen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>Laten zien</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="270"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="338"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="269"/>
        <source>Comment</source>
        <translation>Commentaar</translation>
    </message>
</context>
<context>
    <name>OptimizeScannedPagesDlg</name>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="14"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished">Huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="95"/>
        <source>Apply Adaptive Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="107"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">Kleur- en grijswaarden Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="127"/>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="173"/>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="132"/>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="153"/>
        <source>Black and White Images</source>
        <translation type="unfinished">Zwart en Wit afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="178"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished">CCITT Groep 4CCITT</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="183"/>
        <source>JBIG2</source>
        <translation type="unfinished">JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="200"/>
        <source>Small Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="229"/>
        <source>High Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="242"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="248"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="255"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation>werkbalken</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation>Alle gereedschappen:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation>Gereedschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation>Huidige werkbalk gereedschappen:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation>Werkbalken:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation>Werkbalk toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation>Werkbalk verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation>Alles herstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation>Maiximum gereedschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation>minimum gereedschappen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="174"/>
        <source>Please, name new toolbar</source>
        <translation>Geef de nieuwe werkbalk een naam</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Commentaar</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Schrijfmachine</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Notitie</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bewerken</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ongedaan maken</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Opnieuw</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Knippen</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiëren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Plakken</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Bestand</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Opslaan</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Afdrukken</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Zoeken</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulieren</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Handtekening</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Radio knop</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Keuzelijst</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Tekst veld</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Keuzelijst met invoervak</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Selectievakje</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objecten</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Penseel</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ovaal</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rechthoek</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Lijn</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Tekst invoegen</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Opstellen</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Markeren voor opstellen</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Bewerk tekst</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Handaanwijzer</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Beeld</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vorige beeld</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Volgende beeld</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="obsolete">Zoom</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zoom uit</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Inzoomen</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Hoofd</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">E-mailbezorging</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="obsolete">Links uitlijnen</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="obsolete">Rechts uitlijnen</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="obsolete">Top uitlijnen</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="obsolete">Onderkant uitlijnen</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="obsolete">Lijn het midden horizontaal uit</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation type="obsolete">Lijn het midden verticaal uit</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation type="obsolete">Terug sturen</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation type="obsolete">Vooruit sturen</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Raster</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Vorige pagina</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Volgende pagina</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="obsolete">Tegenoverliggende pagina&apos;s</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation type="obsolete">Bewerk het document</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation type="obsolete">Bewerk afbeeldingen</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation type="obsolete">Bewerk Vector afbeeldingen</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="obsolete">Formulier bewerken</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="obsolete">Selecteer tekst</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="obsolete">Lege pagina&apos;s invoegen</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="obsolete">Pagina&apos;s bijsnijden</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation type="obsolete">Pagina Opmaak</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation type="obsolete">Roteer pagina&apos;s</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="obsolete">Pagina&apos;s uitpakken...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="obsolete">Pagina&apos;s invoegen...</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="obsolete">Document acties</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation type="obsolete">Document JavaScript</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">Pagina eigenschappen</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="obsolete">OCR</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">Kop en Voet</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="obsolete">Watermerk</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">Achtergrond</translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="obsolete">Document</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="525"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="557"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Weet u zeker dat u alle werkbalken wilt resetten naar de standaardinstellingen?</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="obsolete">Bijlage toevoegen als opmerking</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="196"/>
        <source>ToolBar with this name already exist.</source>
        <translation>Er bestaat al een werkbalk met deze naam.</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="obsolete">Dit lettertype bevat deze tekens niet.
Probeer een ander lettertype te kiezen.</translation>
    </message>
</context>
<context>
    <name>PageCounterWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulier</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Pagina Opmaak</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="167"/>
        <source>Scale contents with size change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="203"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">Behoud de beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="247"/>
        <source>Contents Size</source>
        <translation>Inhoudsmaat</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="259"/>
        <source>Left margin</source>
        <translation>Linker marge</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Top margin</source>
        <translation>Top marge</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="293"/>
        <source>Right margin</source>
        <translation>Rechter marge</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="310"/>
        <source>Bottom margin</source>
        <translation>Ondergrens marge</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="73"/>
        <location filename="../../src/PageLayoutDialog.ui" line="99"/>
        <source>Page Size</source>
        <translation>Pagina grootte</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">Breedte</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="obsolete">Hoogte</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">tot:</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="63"/>
        <source>Units</source>
        <translation>Eenheden</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Even en oneven pagina&apos;s</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Even pagina&apos;s</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Oneven pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="86"/>
        <location filename="../../src/PageLayoutDialog.ui" line="154"/>
        <location filename="../../src/PageLayoutDialog.ui" line="174"/>
        <location filename="../../src/PageLayoutDialog.ui" line="190"/>
        <location filename="../../src/PageLayoutDialog.ui" line="266"/>
        <location filename="../../src/PageLayoutDialog.ui" line="283"/>
        <location filename="../../src/PageLayoutDialog.ui" line="300"/>
        <location filename="../../src/PageLayoutDialog.ui" line="317"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="331"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="336"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="341"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Top</source>
        <translation>Boven</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="137"/>
        <source>Bottom</source>
        <translation>Beneden</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="147"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="127"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="vanished">Van</translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="vanished">van :</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="106"/>
        <source>Orientation</source>
        <translation>Oriëntatie</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="62"/>
        <source>Portrait</source>
        <translation>Portret</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="119"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="63"/>
        <source>Landscape</source>
        <translation>Landschap</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>Pagina eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation>Tabblad volgorde</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation>Gebruik rijvolgorde</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation>Gebruik kolomvolgorde</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation>Gebruik document structuur</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation>Niet gespecificeerd</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation>Acties</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation>Voeg Handeling Toe</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation>Trigger</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation>Actie</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation>Ga naar een paginaweergave</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation>Open een weblink</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation>Formulier herstellen</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation>Toon/Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation>Verstuur een formulier</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation>Voer een Java Script uit</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation>Open pagina</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation>Pagina sluiten</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="51"/>
        <source>Current Page</source>
        <translation>Huidige pagina</translation>
    </message>
</context>
<context>
    <name>PageRangeWidget</name>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="55"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="61"/>
        <source>Current page view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="117"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="78"/>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="127"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="86"/>
        <source>All pages in range</source>
        <translation type="unfinished">Alle pagina&apos;s in bereik</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="91"/>
        <source>Even pages</source>
        <translation type="unfinished">Even pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="96"/>
        <source>Odd pages</source>
        <translation type="unfinished">Oneven pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Page Range input is incorrect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation>Printer instellingen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation>Papier</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation>Breedte:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation>Hoogte:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation>Pagina grootte:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation>Marges</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation>Onderste marge</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation>Top marge</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation>Linker marge</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation>Rechter marge</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation>Resolutie</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation>Papier Bron</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="320"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="339"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="355"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Wachtwoord:</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Dit bestand wordt door een wachtwoord beschermd. Voer het wachtwoord in</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Geef wachtwoord op</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>Plak naar meerdere pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Pagina bereik</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation>Pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Voorbeeld: 1.6-8.12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation>Alle pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation>Behalve de huidige</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation>Initialen plaatsen</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation>Hoe wil je je initialen maken?</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation>Type mijn initialen</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation>Teken mijn intialen</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation>Selecteer handtekening afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation>Voer je initialen in:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>Style</source>
        <translation>Stijl</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation>Lettertype familie</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation>Verander initialen stijl</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation>Beoordeel initialen:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation>Teken initialen:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation>Breedte</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation>Blader en selecteer een afbeelding met uw handtekening</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="77"/>
        <source>Clear</source>
        <translation>Opruimen</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="105"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Open Image</source>
        <translation>Open afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Afbeeldingsbestanden (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>of</source>
        <translation>vna</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Dit lettertype bevat deze tekens niet.
Probeer een ander lettertype te kiezen.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="621"/>
        <source>Printer</source>
        <translation>Printer</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="634"/>
        <source>Properties</source>
        <translation>Eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="778"/>
        <location filename="../../src/printdialog/printdialog.ui" line="860"/>
        <source>Center</source>
        <translation>Centreren</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="577"/>
        <source>Print as Grayscale</source>
        <translation>Uitprinten in grijstinten</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="vanished">Beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="707"/>
        <source>Ignore aspect ratio</source>
        <translation>Negeer de beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="712"/>
        <source>Keep aspect ratio</source>
        <translation>Behoud de beeldverhouding</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="717"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Houd de beeldverhouding bij door uit te vouwen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="342"/>
        <source>Orientation</source>
        <translation>Oriëntatie</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="307"/>
        <source>Portrait</source>
        <translation>Portret</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="312"/>
        <source>Landscape</source>
        <translation>Landschap</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Alle paginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation>Afdrukken</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="180"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>of:</source>
        <translation>van :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1332"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1708"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1719"/>
        <source>of </source>
        <translation>van </translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="725"/>
        <source>Actual Size</source>
        <translation>Huidige Formaat</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="361"/>
        <source>Duplex Printing</source>
        <translation>Dubbelzijdig afdrukken</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <location filename="../../src/printdialog/printdialog.ui" line="369"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Long side</source>
        <translation>Lange zijde</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="302"/>
        <location filename="../../src/printdialog/printdialog.ui" line="374"/>
        <source>Auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Short side</source>
        <translation>Korte zijde</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Even pagina&apos;s</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Oneven pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="135"/>
        <source>Document and Annotations</source>
        <translation>Document en annotaties</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">Alles</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation type="vanished">Deelverzameling</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation type="vanished">Alle pagina&apos;s in bereik</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Print:</source>
        <translation>Afdrukken:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="437"/>
        <source>Number of copies</source>
        <translation>Aantal kopieën</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="464"/>
        <source>Collate</source>
        <translation>Vergelijken</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="270"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="272"/>
        <source>Advanced</source>
        <translation>Geavanceerd</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="751"/>
        <location filename="../../src/printdialog/printdialog.ui" line="880"/>
        <source>Scale</source>
        <translation>Schalen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="732"/>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="765"/>
        <source>Fit Page</source>
        <translation>Op pagina passen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Shrink to printable area</source>
        <translation>Verkleinen tot afdrukbaar gebied</translation>
    </message>
    <message>
        <source>Current view</source>
        <translation type="vanished">Huidige weergave</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="536"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="514"/>
        <source>Poster</source>
        <translation>Poster</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">Boekje</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>Opgeslagen instellingen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="32"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="63"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save Settings</source>
        <translation>Instellingen opslaan</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save current settings as:</source>
        <translation>Bewaar huidige instellingen als:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1583"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Instellingen met deze naam bestaan al. Wilt u de oude instellingen vervangen?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="561"/>
        <source>Multiple</source>
        <translation>Meerdere</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <source>Overlay</source>
        <translation>Overlappen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="901"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1106"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="906"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1111"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="911"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="867"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="977"/>
        <source>Pages per sheet:</source>
        <translation>Pagina&apos;s per vel:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="970"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1011"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1016"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1021"/>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1026"/>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1031"/>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1036"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1053"/>
        <source>Page order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1061"/>
        <source>Horizontal</source>
        <translation>Horizontaal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1066"/>
        <source>Horizontal Reversed</source>
        <translation>Horizontaal omgekeerd</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1071"/>
        <source>Vertical</source>
        <translation>Verticaal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1076"/>
        <source>Vertical Reversed</source>
        <translation>Verticaal omgekeerd</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1091"/>
        <source>Additional spacing:</source>
        <translation>Extra afstand:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1098"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1084"/>
        <source>Center pages in cells</source>
        <translation>Centreer pagina&apos;s in cellen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="323"/>
        <source>Page Setup</source>
        <translation>Pagina instellingen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="327"/>
        <source>System Properties</source>
        <translation>Systeem Eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="581"/>
        <source>Printer cannot be selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="240"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="266"/>
        <source>There was an error printing the document</source>
        <translation>Er is een foutopgetreden tijdens het printen</translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="242"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="268"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Size</source>
        <translation>Formaat wijzigen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Description</source>
        <translation>Omschrijving</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="60"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source> is already attached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="505"/>
        <source>Replace the file or give it a unique name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="506"/>
        <source>Replace</source>
        <translation type="unfinished">Vervangen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="507"/>
        <source>Rename</source>
        <translation type="unfinished">Naam wijzigen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="508"/>
        <source>Cancel</source>
        <translation type="unfinished">Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="779"/>
        <source>You don&apos;t have the permission to save attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="823"/>
        <source>You don&apos;t have the permission to open attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="938"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="939"/>
        <source>The removed Attachment cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="57"/>
        <source>Insert</source>
        <translation>Invoegen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Location</source>
        <translation>Locatie</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="179"/>
        <source>Attachment Tab</source>
        <translation>Bijlagen paneel</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Openen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="24"/>
        <source>Attachment</source>
        <translation>Bijlage</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="175"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="874"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="29"/>
        <source>Add Bookmark</source>
        <translation>Bladwijzer toevoegen</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">Wis bladwijzer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="31"/>
        <source>Bookmark Properties</source>
        <translation>Bladwijzer eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="32"/>
        <source>Set Destination</source>
        <translation>Bestemming instellen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="274"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="275"/>
        <source>The removed bookmark(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="30"/>
        <source>Delete Bookmark(s)</source>
        <translation>Wis bladwijzer(s)</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="82"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="86"/>
        <source>Close All</source>
        <translation>Alles sluiten</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Opslaan</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="106"/>
        <source>Move to New Window</source>
        <translation>Verplaats naar nieuw venster</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="227"/>
        <location filename="../../src/document/qdoctab.cpp" line="348"/>
        <source>untitled</source>
        <translation>zonder titel</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">Het kleombord bevat geen gegevens</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="74"/>
        <source>Duplicate tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="78"/>
        <source>Rename tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="90"/>
        <source>Close All Other Tabs</source>
        <translation>Sluit alle andere tabbladen</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="94"/>
        <source>Close All Tabs to the Right</source>
        <translation>Sluit alle tabs naar rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1895"/>
        <location filename="../../src/document/qdoctab.cpp" line="1920"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>Het klembord bevat geen gegevens</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2214"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2272"/>
        <source>You don&apos;t have permission to modify the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2278"/>
        <source>Save failed</source>
        <translation type="unfinished">Opslaan mislukt</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished">
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished">Sta openen van hetzelfde document toe in meerdere tabbladen</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>option needs to be enabled to allow duplicating tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Rename</source>
        <translation type="unfinished">Naam wijzigen</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Renaming file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Overwrite file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Would you like to overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3757"/>
        <source>Failed to rename file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>E-mailbezorging</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>Aan</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>Onderwerp</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="17"/>
        <source>Send</source>
        <translation>Verzenden</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Bestand</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bewerken</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ongedaan maken</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Opnieuw</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiëren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Plakken</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">vet</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Cursief</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ongedaan maken</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Opnieuw</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiëren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Plakken</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">vet</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Cursief</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">Inzoomen</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">Zoom uit</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="113"/>
        <source>Zoom to Selection</source>
        <translation>Zoom naar selectie</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Op pagina passend</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="121"/>
        <source>Clear Selections</source>
        <translation>Verwijder selecties</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="16"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>Het is niet toegestaan om deze functie in de gratis versie te gebruiken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="20"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>De niet-geregistreerde versie zal een watermerk invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>Build</source>
        <translation>Gebouwd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <source>32 bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>64 bit</source>
        <translation>64 bit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Enter</source>
        <translation>Muis Enter</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Exit</source>
        <translation>Muis uitgang</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Down</source>
        <translation>Muis naar beneden</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Mouse Up</source>
        <translation>Muis naar boven</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Receive Focus</source>
        <translation>Focus ontvangen aan</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>On Lose Focus</source>
        <translation>Focus verliezen aan</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Open</source>
        <translation>Pagina openen</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Close</source>
        <translation>Pagina sluiten</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Visible</source>
        <translation>Pagina zichtbaar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Page Invisible</source>
        <translation>Pagina onzichtbaar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Open Page</source>
        <translation>Open pagina</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Close Page</source>
        <translation>Pagina sluiten</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>KeyStroke</source>
        <translation>KeyStroke</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="997"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Validate</source>
        <translation>Valideren</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Calculate</source>
        <translation>Calculeren</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Close Document</source>
        <translation>Document sluiten</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Save Document</source>
        <translation>Document opslaan</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Document Saved</source>
        <translation>Document is opgeslagen</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Print Document</source>
        <translation>Document afdrukken</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="65"/>
        <source>Document Printed</source>
        <translation>Document is afgedrukt</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Unknown</source>
        <translation>Onbekend</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Goto a Page View</source>
        <translation>Ga naar een paginaweergave</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Open/execute a File</source>
        <translation>Open / voer een bestand uit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Thread</source>
        <translation>Draad</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Open a web link</source>
        <translation>Open een weblink</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Sound</source>
        <translation>Geluid</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Movie</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="98"/>
        <source>Show/Hide fields</source>
        <translation>Toon/Verberg velden</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Submit Form</source>
        <translation>Formulier verzenden</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Reset Form</source>
        <translation>Herstel formulier</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Import Data</source>
        <translation>Importeer gegevens</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="108"/>
        <source>Run a JavaScript</source>
        <translation>Voer een JavaScript uit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="112"/>
        <source>Rendition</source>
        <translation>Vertolking</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="116"/>
        <source>Goto 3D View</source>
        <translation>Ga naar 3D weergave</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="25"/>
        <source>Open with</source>
        <translation>Open met</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Reset</source>
        <translation>Herstel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Set</source>
        <translation>Reeks</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Brightness</source>
        <translation>Helderheid</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Contrast</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Approved</source>
        <translation>Aangenomen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Confidential</source>
        <translation>Vertrouwelijk</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Received</source>
        <translation>Ontvangen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Reviewed</source>
        <translation>Beoordeeld</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Revised</source>
        <translation>Herzien</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Completed</source>
        <translation>Voltooid</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Draft</source>
        <translation>Consept</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Emergency</source>
        <translation>Noodgeval</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>Expired</source>
        <translation>Verlopen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Final</source>
        <translation>Laatste</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Verified</source>
        <translation>Geverifieerd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Void</source>
        <translation>Leegte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>Accepted</source>
        <translation>Geaccepteerd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="173"/>
        <source>Initial</source>
        <translation>Initiaal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="178"/>
        <source>Rejected</source>
        <translation>Verworpen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>SignHere</source>
        <translation>Teken hier</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Witness</source>
        <translation>Getuige</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Dynamic</source>
        <translation>Dynamisch</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Standard</source>
        <translation>Standaard</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation>h:MM tt mmmm dd.yyyy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="216"/>
        <source>Icon</source>
        <translation>Pictogram</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="221"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="226"/>
        <source>Press Help button to get more info.</source>
        <translation>Druk op Help voor meer info.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="231"/>
        <source>Error.</source>
        <translation>Fout.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="236"/>
        <source>Object</source>
        <translation>Object</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="246"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="251"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="256"/>
        <source>Path</source>
        <translation>Pad</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="261"/>
        <source>Shading</source>
        <translation>Schaduw</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="241"/>
        <location filename="../../src/app_config.cpp" line="747"/>
        <source>Objects</source>
        <translation>Objecten</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="266"/>
        <source>All Objects</source>
        <translation>Alle objecten</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="271"/>
        <source>Forms</source>
        <translation>Formulieren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="276"/>
        <source>Comments</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="281"/>
        <source>Container</source>
        <translation>Container</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="286"/>
        <source>Sticky Note</source>
        <translation>Notitie</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="291"/>
        <source>Highlight</source>
        <translation>Markeren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="296"/>
        <source>Underline</source>
        <translation>Onderstrepen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="301"/>
        <source>StrikeOut</source>
        <translation>Doorstrepen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="306"/>
        <source>Reply</source>
        <translation>Antwoord</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-bestanden (* .fdf)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="426"/>
        <source>Typewriter</source>
        <translation>Schrijfmachine</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="311"/>
        <source>Text Box</source>
        <translation>Tekstvak</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="316"/>
        <source>Formatted Text</source>
        <translation>Geformatteerde tekst</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="321"/>
        <source>Issued by:</source>
        <translation>Uitgegeven door:</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="326"/>
        <source>Expires</source>
        <translation>Verlopen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="331"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="336"/>
        <source>Cancelled</source>
        <translation>Geannuleerd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="341"/>
        <source>Confirmed</source>
        <translation>Bevestigd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="346"/>
        <source>Not Confirmed</source>
        <translation>Niet bevestigd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="351"/>
        <source>Open Object Inspector</source>
        <translation>Open Object Inspector</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="356"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="361"/>
        <source>Review History</source>
        <translation>Geschiedenis bekijken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="366"/>
        <source>Make Current Properties Default</source>
        <translation>Maak huidige instellingen standaard</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="371"/>
        <source>Error Loading Image!</source>
        <translation>Fout Afbeelding laden!</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="376"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>Onjuist formaat voor datum / tijd. Voer, alstublieft de juiste datum/tijd in: </translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="381"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>U hebt het aantal beschikbare activeringen overschreden.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="386"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation>Deactiveer uw licentie voor gebruik op een andere pc.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="396"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>Uw licentie is verlopen, vernieuw uw licentie alstublieft.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="401"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>Onmogelijk om uw licentie te verifiëren! Controleer uw internetverbinding en druk op Nu verifiëren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="391"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>Uw licentie staat het gebruik van deze versie niet toe. Vernieuw alstublieft uw licentie.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="406"/>
        <source>Print using Windows API</source>
        <translation>Afdrukken met Windows API</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="411"/>
        <source>Do not show this message again</source>
        <translation>Laat dit bericht niet meer zien</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="416"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>Als OpenSSL niet is geïnstalleerd, zijn encryptie- en handtekeningfunctionaliteit niet beschikbaar.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="436"/>
        <source>Separator</source>
        <translation>Scheidingsteken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="441"/>
        <source>Main</source>
        <translation>Hoofd</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="446"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="451"/>
        <source>Save As...</source>
        <translation>Opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="461"/>
        <source>Toolbars</source>
        <translation>Taakbalken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="466"/>
        <source>Email delivery</source>
        <translation>E-mailbezorging</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="476"/>
        <source>Print</source>
        <translation>Afdrukken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="481"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="486"/>
        <source>Cut</source>
        <translation>Knippen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="491"/>
        <source>Copy</source>
        <translation>Kopiëren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="496"/>
        <source>Paste</source>
        <translation>Plakken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="501"/>
        <source>Delete Object(s)</source>
        <translation>Verwijder Objet(s)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="506"/>
        <source>Undo</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="511"/>
        <source>Redo</source>
        <translation>Opnieuw</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="516"/>
        <source>Align Left</source>
        <translation>Links uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="521"/>
        <source>Align Right</source>
        <translation>Rechts uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="526"/>
        <source>Align Top</source>
        <translation>Top uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="531"/>
        <source>Align Bottom</source>
        <translation>Onderkant uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="536"/>
        <source>Align Center Horizontal</source>
        <translation>Lijn het midden horizontaal uit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="541"/>
        <source>Align Center Vertical</source>
        <translation>Lijn het midden verticaal uit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="551"/>
        <source>Send To Back</source>
        <translation>Stuur naar achteren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="556"/>
        <source>Send Backward</source>
        <translation>Terug sturen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="561"/>
        <source>Bring Forward</source>
        <translation>Naar voren brengen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="566"/>
        <source>Bring To Front</source>
        <translation>Naar voren brengen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="577"/>
        <source>Grid</source>
        <translation>Raster</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="582"/>
        <source>Snap To Grid</source>
        <translation>Uitlijnen op raster</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="587"/>
        <source>View</source>
        <translation>Beeld</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="592"/>
        <source>Previous View</source>
        <translation>Vorige beeld</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="597"/>
        <source>Next View</source>
        <translation>Volgende beeld</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="602"/>
        <source>Previous Page</source>
        <translation>Vorige pagina</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="607"/>
        <source>Next Page</source>
        <translation>Volgende pagina</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="612"/>
        <source>Zoom Out</source>
        <translation>Zoom uit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="617"/>
        <source>Actual Size</source>
        <translation>daadwerkelijke grootte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="622"/>
        <source>Zoom In</source>
        <translation>Inzoomen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="627"/>
        <location filename="../../src/mainwindow.cpp" line="4147"/>
        <source>Fit Page</source>
        <translation>Op de pagina passen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="632"/>
        <location filename="../../src/mainwindow.cpp" line="4151"/>
        <source>Fit Width</source>
        <translation>In de breedte passen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="637"/>
        <source>Facing Pages</source>
        <translation>Tegenoverliggende pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="642"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="647"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="652"/>
        <source>Rotate 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="657"/>
        <source>Tools</source>
        <translation>Gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="662"/>
        <source>Edit Document</source>
        <translation>Bewerk het document</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="667"/>
        <source>Edit Text</source>
        <translation>Bewerk tekst</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="672"/>
        <source>Edit Images</source>
        <translation>Bewerk afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="677"/>
        <source>Edit Vector Images</source>
        <translation>Bewerk Vector afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="682"/>
        <source>Edit Forms</source>
        <translation>Formulier bewerken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="692"/>
        <source>Hand Tool</source>
        <translation>Handaanwijzer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="697"/>
        <source>Select Text</source>
        <translation>Selecteer tekst</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="702"/>
        <source>Take Snapshot</source>
        <translation>Maak snapshot</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="707"/>
        <source>Insert Link</source>
        <translation>Link invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="712"/>
        <source>Button</source>
        <translation>Knop</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="717"/>
        <source>Check Box</source>
        <translation>Selectievakje</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="722"/>
        <source>Combo Box</source>
        <translation>Keuzelijst met invoervak</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="727"/>
        <source>Text Field</source>
        <translation>Tekst veld</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="732"/>
        <source>List Box</source>
        <translation>Keuzelijst</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="737"/>
        <source>Radio Button</source>
        <translation>Radio knop</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="742"/>
        <source>Signature</source>
        <translation>Handtekening</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="752"/>
        <source>Insert Formatted Text</source>
        <translation>Opgemaakte tekst invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="757"/>
        <source>Insert Text</source>
        <translation>Tekst invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="762"/>
        <source>Insert Image</source>
        <translation>Afbeelding invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="767"/>
        <source>Line</source>
        <translation>Lijn</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="772"/>
        <source>Rectangle</source>
        <translation>Rechthoek</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="777"/>
        <source>Ellipse</source>
        <translation>Ovaal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="782"/>
        <source>Pencil</source>
        <translation>Penseel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="787"/>
        <source>Attach a File as a Comment</source>
        <translation>Bijlage toevoegen als opmerking</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="792"/>
        <source>Redaction</source>
        <translation>Opstellen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="797"/>
        <source>Mark for Redaction</source>
        <translation>Markeren voor opstellen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="802"/>
        <source>Search And Redact</source>
        <translation>Zoeken en redigeren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="807"/>
        <source>Apply Redaction</source>
        <translation>redactie toepassen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="812"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="817"/>
        <source>Insert Blank Pages</source>
        <translation>Lege pagina&apos;s invoegen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="822"/>
        <source>Delete Pages</source>
        <translation>Verwijder Pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="827"/>
        <source>Crop Pages</source>
        <translation>Pagina&apos;s bijsnijden</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="832"/>
        <source>Page layout</source>
        <translation>Pagina Opmaak</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="837"/>
        <source>Page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="842"/>
        <source>Rotate Pages</source>
        <translation>Roteer pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="847"/>
        <source>Extract Pages...</source>
        <translation>Pagina&apos;s uitpakken...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="852"/>
        <source>Insert Pages...</source>
        <translation>Pagina&apos;s invoegen...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="857"/>
        <source>Cut Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="862"/>
        <source>Copy Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="867"/>
        <source>Paste Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="872"/>
        <source>Document Actions</source>
        <translation>Document acties</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="877"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="882"/>
        <source>Page Properties</source>
        <translation>Pagina eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="887"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="892"/>
        <source>Header and Footer</source>
        <translation>Kop en Voet</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="897"/>
        <source>Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="902"/>
        <source>Watermark</source>
        <translation>Watermerk</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="907"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="917"/>
        <source>Page Counter</source>
        <translation>Paginateller</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="922"/>
        <source>New</source>
        <translation>Nieuw</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="927"/>
        <source>Open</source>
        <translation>Openen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="992"/>
        <source>Select All</source>
        <translation type="unfinished">Alles selecteren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1002"/>
        <source>Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1007"/>
        <source>Show Crop Page Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1012"/>
        <source>Prompt to Scan More Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1017"/>
        <source>Current Page</source>
        <translation type="unfinished">Huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1022"/>
        <source>Autosave on. Document will be saved automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1027"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1032"/>
        <source>Vector Images</source>
        <translation type="unfinished">Vector afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1037"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1042"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="912"/>
        <location filename="../../src/app_config.cpp" line="932"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="937"/>
        <source>Find</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="962"/>
        <source>Stamp</source>
        <translation>Stempel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="967"/>
        <source>Comment View</source>
        <translation>Commentaar bekijken</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="972"/>
        <source>Place Initials</source>
        <translation>Initialen plaatsen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="431"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="947"/>
        <source>Highlight Text</source>
        <translation>Tesktst markeren</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="952"/>
        <source>Draw Comment Tools</source>
        <translation>Hulpmiddel Ontwerp Gereedschap</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="957"/>
        <source>Measurement Tools</source>
        <translation>Meetinstrumenten</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="687"/>
        <source>Edit Tools</source>
        <translation>Bewerk hulpmiddelen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="977"/>
        <source>Continuous Page</source>
        <translation>Doorlopende pagina</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="982"/>
        <source>Single Page</source>
        <translation>Enkele pagina</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="546"/>
        <source>Align Objects</source>
        <translation type="unfinished">Objecten uitlijnen</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="571"/>
        <source>Move Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="421"/>
        <source>If NSS is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="987"/>
        <source>No pages selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="471"/>
        <source>System Print...</source>
        <translation type="unfinished">Systeem afdrukken ...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="942"/>
        <source>Label</source>
        <translation type="unfinished">Label</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Combine files in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="456"/>
        <source>Save As Image</source>
        <translation type="unfinished">Bewaar als Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="39"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="40"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="41"/>
        <source>Arabic</source>
        <translation type="unfinished">Arabisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="42"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="43"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="44"/>
        <source>Azerbaijani (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="45"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="46"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="47"/>
        <source>Tibetan Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="49"/>
        <source>Bulgarian</source>
        <translation type="unfinished">Bulgaars</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="50"/>
        <source>Catalan</source>
        <translation type="unfinished">Catalaans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="51"/>
        <source>Cebuano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="52"/>
        <source>Czech</source>
        <translation type="unfinished">Tsjechisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="53"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="54"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="55"/>
        <source>Cherokee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished">Deens</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="58"/>
        <source>German</source>
        <translation type="unfinished">Duits</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="59"/>
        <source>German (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="61"/>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="76"/>
        <source>Greek</source>
        <translation type="unfinished">Grieks</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="62"/>
        <source>English</source>
        <translation type="unfinished">Engels</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="63"/>
        <source>English (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="64"/>
        <source>Middle English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="65"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="66"/>
        <source>Estonian</source>
        <translation type="unfinished">Estlands</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="67"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="69"/>
        <source>Finnish</source>
        <translation type="unfinished">Fins</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="70"/>
        <source>French</source>
        <translation type="unfinished">Frans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="71"/>
        <source>Frankish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="72"/>
        <source>Middle French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="73"/>
        <source>Irish</source>
        <translation type="unfinished">Iers</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="74"/>
        <source>Irish (Uncial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="75"/>
        <source>Galician</source>
        <translation type="unfinished">Galicisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="77"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="78"/>
        <source>Hatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished">Hebreeuws</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="81"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="82"/>
        <source>Hungarian</source>
        <translation type="unfinished">Hongaars</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="83"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="84"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="85"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="86"/>
        <source>Italian</source>
        <translation type="unfinished">Italiaans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="87"/>
        <source>Old Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="88"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="89"/>
        <source>Japanese</source>
        <translation type="unfinished">Japans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="90"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="91"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="92"/>
        <source>Old Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="93"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="94"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="95"/>
        <source>Kyrgyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="96"/>
        <source>Korean</source>
        <translation type="unfinished">Koreaans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="97"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="98"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="99"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="100"/>
        <source>Latvian</source>
        <translation type="unfinished">Lets</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="101"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Litouws</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="102"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="103"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="104"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="105"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="106"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="107"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="108"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="109"/>
        <source>Dutch</source>
        <translation type="unfinished">Nederlands</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="110"/>
        <source>Norwegian</source>
        <translation type="unfinished">Noors</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="111"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="112"/>
        <source>script and orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="113"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="114"/>
        <source>Polish</source>
        <translation type="unfinished">Pools</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="115"/>
        <source>Portuguese</source>
        <translation type="unfinished">Portugees</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="116"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="117"/>
        <source>Romanain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="118"/>
        <source>Russian</source>
        <translation type="unfinished">Russisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="119"/>
        <source>Russian (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="120"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="121"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="122"/>
        <source>Slovak</source>
        <translation type="unfinished">Slowaaks</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="123"/>
        <source>Slovak Fractur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="124"/>
        <source>Slovenian</source>
        <translation type="unfinished">Sloveens</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="125"/>
        <source>Spanish</source>
        <translation type="unfinished">Spaans</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="126"/>
        <source>Old Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="127"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="128"/>
        <source>Serbian</source>
        <translation type="unfinished">Servisch</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="129"/>
        <source>Serbian (Latin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="130"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="131"/>
        <source>Swedish</source>
        <translation type="unfinished">Zweeds</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="132"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="133"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="134"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="135"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="136"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="137"/>
        <source>Thai</source>
        <translation type="unfinished">Thais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="138"/>
        <source>Turkish</source>
        <translation type="unfinished">Turks</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="139"/>
        <source>Uyghur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="140"/>
        <source>Urgu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="141"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="142"/>
        <source>Uzbek (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="143"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamees</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="144"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qsanelib.cpp" line="389"/>
        <source>Document feeder is out of sheets!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="789"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="984"/>
        <source>Error! Check if the file is valid and exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="988"/>
        <source>Error!</source>
        <translation type="unfinished">Fout !</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="111"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="133"/>
        <source> in</source>
        <translation type="unfinished"> in</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="142"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/utils/AppSession.cpp" line="64"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3554"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3682"/>
        <source>Error!</source>
        <translation>Fout !</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4325"/>
        <source>There was a problem with your form submission.</source>
        <translation>Er is een probleem met uw formulierinzending.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4329"/>
        <source>Your form was successfully submitted!</source>
        <translation>Uw formulier is succesvol ingediend!</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>of</source>
        <translation type="vanished">van</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Pagina</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="40"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="4231"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4235"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4240"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4285"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>Met PDF-documentactie wordt geprobeerd formuliergegevens naar een andere locatie te verzenden. Doorgaan?</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="51"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="593"/>
        <source>Open Document</source>
        <translation>Open document</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="61"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="594"/>
        <source>Blank PDF</source>
        <translation>Blanco PDF</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="595"/>
        <source>From Files</source>
        <translation>Van bestanden</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="597"/>
        <source>From Scanner</source>
        <translation>Van Scanner</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="93"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="598"/>
        <source>Settings</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="99"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="599"/>
        <source>User Guide</source>
        <translation>Gebruikershandleiding</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="109"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="602"/>
        <source>Register...</source>
        <translation>Registreren...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="115"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="603"/>
        <source>Buy Online</source>
        <translation>Koop online</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="417"/>
        <source>Create New Document</source>
        <translation>Maak een nieuw document</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="439"/>
        <source>Recent Files</source>
        <translation>Recente bestanden</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="596"/>
        <source>Empty recent files list</source>
        <translation>Lijst met recente bestanden leegmaken</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="421"/>
        <source>Pinned Files</source>
        <translation>Vastgezette bestanden</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="957"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>U heeft de limiet van 10 vastgezette bestanden bereikt.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="193"/>
        <source>Pages</source>
        <translation>Pagina&apos;s</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="vanished">Vergroot pagina markeringen</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="vanished">verklein pagina markeringen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="219"/>
        <source>Bookmarks</source>
        <translation>Bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="231"/>
        <source>Attachment</source>
        <translation>Bijlage</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="242"/>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="277"/>
        <source>Object Inspector</source>
        <translation>Object Inspector</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="744"/>
        <source>This document contains interactive form fields</source>
        <translation>Dit document bevat interactieve formulier velden</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="745"/>
        <source>Highlight Fields</source>
        <translation>Markeer alle velden</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="vanished">Dit document is beveiligd. U heeft geen toestemming om het te bewerken</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="753"/>
        <source>Change</source>
        <translation>Verandering</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="vanished">Er is een foutopgetreden tijdens het printen</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Voeg pagina toe</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4254"/>
        <source>Do you want to open?</source>
        <translation>Wilt u het openen?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4261"/>
        <source>Don&apos;t show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5068"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Weet u zeker dat u de bestemming van de geselecteerde bladwijzer wilt instellen op de huidige locatie?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5161"/>
        <source>untitled</source>
        <translation>naamloos</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">Verwijder pagina&apos;s</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">Lege pagina&apos;s invoegen</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">Pagina eigenschappen</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="vanished">Fout !</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1707"/>
        <source>Error loading font: </source>
        <translation>Fout bij laden van lettertype:: </translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="246"/>
        <source>Object TreeView</source>
        <translation>Boomstructuur object</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="600"/>
        <source>Layers</source>
        <translation>Lagen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="752"/>
        <source>This document is protectedYou do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="805"/>
        <source>Registration</source>
        <translation>Registratie</translation>
    </message>
    <message>
        <source>Current zoom will also be accounted for.</source>
        <translation type="vanished">De huidige zoomlens zal ook worden verantwoord.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="263"/>
        <source>Signatures</source>
        <translation>Handtekeningen</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3622"/>
        <source>Document must contain at least one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3629"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3015"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5071"/>
        <source>Set current zoom</source>
        <translation>Stel de huidige zoomlens in</translation>
    </message>
</context>
<context>
    <name>QThumbnailsList</name>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="81"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished">Vergroot pagina markeringen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="84"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished">verklein pagina markeringen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="132"/>
        <source>Select All</source>
        <translation type="unfinished">Alles selecteren</translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="16"/>
        <source>Millimeters (mm)</source>
        <translation>Millimeters (mm)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="17"/>
        <source>Inches (in)</source>
        <translation>Inches (in)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="18"/>
        <source>Points (pt)</source>
        <translation>Punten (pt)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="19"/>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="20"/>
        <source>Didot (DD)</source>
        <translatorcomment>Didot (DD)</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="21"/>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="59"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="63"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="302"/>
        <location filename="../../src/utils/AppSession.cpp" line="241"/>
        <source>MPE Session file (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="144"/>
        <source>More...</source>
        <translation>Meer...</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>User Color 99</source>
        <translation>Gebruik kleur 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Black</source>
        <translation>Zwart</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>White</source>
        <translation>Wit</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Red</source>
        <translation>Rood</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="356"/>
        <source>Dark red</source>
        <translation>Donker rood</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Green</source>
        <translation>Groen</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="358"/>
        <source>Dark green</source>
        <translation>Donker groen</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="359"/>
        <source>Blue</source>
        <translation>Blauw</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="360"/>
        <source>Dark blue</source>
        <translation>Donker blauw</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="361"/>
        <source>Cyan</source>
        <translation>Cyaan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="362"/>
        <source>Dark cyan</source>
        <translation>Donker cyaan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="363"/>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="364"/>
        <source>Dark magenta</source>
        <translation>Donker magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="365"/>
        <source>Yellow</source>
        <translation>Geel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="366"/>
        <source>Dark yellow</source>
        <translation>Donker geel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="367"/>
        <source>Gray</source>
        <translation>Grijs</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="368"/>
        <source>Dark gray</source>
        <translation>Donker grijs</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="369"/>
        <source>Light gray</source>
        <translation>Licht grijs</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="371"/>
        <source>Transparent</source>
        <translation>Transparant</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation>Redaction Code Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation>Codesets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation>Naam wijzigen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation>Importeren</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation>Code ingangen</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation>Bewerk kleuren opvul gebied</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation>Gebruik overlay tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="76"/>
        <source>Code Sets</source>
        <translation>Codesets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="83"/>
        <source>Code Entries:</source>
        <translation>Code ingangen:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="116"/>
        <source>Edit Codes</source>
        <translation>Bewerk codes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="67"/>
        <source>Redaction Code</source>
        <translation>Code opstellen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="133"/>
        <source>Color</source>
        <translation>KleurColor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="152"/>
        <source>Font</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="201"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="60"/>
        <source>Repeat Overlay Text</source>
        <translation>Herhaal overlay tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="140"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="172"/>
        <source>auto</source>
        <translation>automatisch</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="126"/>
        <source>Auto-size text</source>
        <translation>Automatische grootte tekst</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Registratie informatie</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Nadat uw order is voltooid, 
ontvangt u automatisch 
uw registratiecode via e-mail.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Koop online</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="386"/>
        <source>Registration Code</source>
        <translation>Registratie code</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="373"/>
        <source>Activate</source>
        <translation>Activeren</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Offline Activatie</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="227"/>
        <source>Registered version</source>
        <translation>Geregistreerde versie</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt; &lt;head /&gt; &lt;body&gt; &lt;p&gt; Stuur de ID-sleutel en de registratiecode naar: &lt;/ p&gt; &lt;p&gt; &lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt; &lt;span style = &quot;tekst-decoratie: onderstrepen; kleur: # 007af4;&quot;&gt; activations@code-industry.net &lt;/ span&gt; &lt;/a&gt; &lt;/ p&gt; &lt;p&gt; Zodra u uw code hebt ontvangen, voert u deze in &amp; quot; Activeringscode &amp; quot; veld &lt;/ p&gt; &lt;p&gt; &lt;br/&gt; &lt;/ p&gt; &lt;/ body&gt; &lt;/ html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="214"/>
        <source>Deactivate</source>
        <translation>De-activeren</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="319"/>
        <source>Registration Code:</source>
        <translation>Registratie code:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="366"/>
        <source>Back</source>
        <translation>Terug</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="422"/>
        <source>Activation Code</source>
        <translation>Activatie Code</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="349"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="34"/>
        <source>Thanks for registration.</source>
        <translation>Dank u voor Registratie.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="35"/>
        <source>License is deactivated.</source>
        <translation>Licentie is ge-deactiveerd.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="37"/>
        <source>Too many activations!</source>
        <translation>Te veel activaties!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="499"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact activations@code-industry.net</source>
        <translation>Deactivation mislukt!
Controleer uw internet verbinding.
Als de foutmelding zich herhaald, contact activations@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head /&gt; &lt;body&gt; &lt;p&gt; Stuur de ID-sleutel en de registratiecode naar: &lt;/ p&gt; &lt;p&gt; &lt;a href=&quot;mailto: support@code-industry.net&quot;&gt; &lt;span style = &quot;tekst-decoratie: onderstrepen; kleur: # 007af4;&quot;&gt; support@code-industry.net &lt;/ span&gt; &lt;/a&gt; &lt;/ p&gt; &lt;p&gt; Zodra u uw code hebt ontvangen, voert u deze in &amp; quot; Activeringscode &amp; quot; veld &lt;/ p&gt; &lt;p&gt; &lt;br/&gt; &lt;/ p&gt; &lt;/ body&gt; &lt;/ html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="278"/>
        <source>Purchased On:</source>
        <translation>Aangeschaft op:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="292"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Onderhoud verloopt op:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="40"/>
        <source>License is expired!</source>
        <translation>Licentie is verlopen!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="58"/>
        <source>Please, renew your license</source>
        <translation>Vernieuw uw licentie alstublieft</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="470"/>
        <source>Renew</source>
        <translation>Vernieuw</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="202"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Als u die licentie op een andere pc wilt registreren, klikt u op de knop &quot;Deactiveren&quot;. 

Registreer het dan waar u wilt.</translation>
    </message>
    <message>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation type="vanished">Deactivation mislukt!
Controleer uw internet verbinding.
Als de foutmelding zich herhaald, contact support@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="320"/>
        <location filename="../../src/regdialog.cpp" line="527"/>
        <source>Activation failed! Check internet connection.</source>
        <translation>Activatie mislukt! Controleer uw internet verbinding.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="291"/>
        <location filename="../../src/regdialog.cpp" line="425"/>
        <source>Incorrect registration code.</source>
        <translation>Onjuiste registratie code.</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Roteren</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pagina&apos;s</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Voorbeeld: 1.6-8.12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Huidige pagina</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">tot:</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="28"/>
        <source>Direction</source>
        <translation>Richting</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="35"/>
        <source>Clockwise 90 degrees</source>
        <translation>Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="40"/>
        <source>180 degrees</source>
        <translation>180 Graden</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="45"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Even en oneven pagina&apos;s</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Even pagina&apos;s</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Oneven pagina&apos;s</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="25"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>Breedte</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>Hoogte</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>Formaat</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>File Name</source>
        <translation>Bestand Name</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pagina&apos;s van</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">tot:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Exporteer als afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="259"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Pagina bereik</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Alle pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation>MBP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>JPEG kwaliteit</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translatorcomment>Does not excist for the Netherlands</translatorcomment>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translatorcomment>Does not excist for the Netherlands</translatorcomment>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>TIFF Compressie</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Kan bestand niet opslaan:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Het bestand kan alleen-lezen zijn of door een andere toepassing worden gebruikt.</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="vanished">Bewaar als Afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="445"/>
        <source>All Files (*)</source>
        <translation>Alle bestanden (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>Meerdere pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>Save As TIFF Image</source>
        <translation>Bewaar als TIFF afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>TIFF Bestanden (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>Transparant</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="269"/>
        <source>Antialiasing</source>
        <translation>Antialiasing</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="26"/>
        <source>Export</source>
        <translation>Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="311"/>
        <source>Export:</source>
        <translation>Exporteren:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="319"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="324"/>
        <source>Document and Annotations</source>
        <translation>Document en annotaties</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation>Verwijder niet gebruikte elementen</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation>Formuliervelden vervlakken</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation>Kleur- en grijswaarden Afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation>Compressie</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation>Zonder verlies</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation>JPEG kwaliteit</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="340"/>
        <source>PDF/A Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation>Zwart en Wit afbeeldingen</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation>CCITT Groep 4CCITT</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Geoptimaliseerd opslaan als...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation>Voeg alle lagen samen</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>Scanning...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScanExeDlg.cpp" line="140"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanImageViewerDialog</name>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="39"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="42"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="45"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">Draai 90 graden tegen de klok in</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="68"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="71"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="74"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">Draai 90 graden met de klok mee</translation>
    </message>
</context>
<context>
    <name>ScanPreviewDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="44"/>
        <source>Close</source>
        <translation type="unfinished">Sluiten</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="51"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="26"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="23"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="18"/>
        <source>Scan</source>
        <translation>Scan</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="46"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="107"/>
        <source>Output</source>
        <translation>Uitvoer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="55"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="199"/>
        <source>Source</source>
        <translation type="unfinished">Bron</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="414"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="61"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="122"/>
        <source>Before current page</source>
        <translation>Voor huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="424"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="71"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="132"/>
        <source>After last page</source>
        <translation>Na de laatste pagina</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="397"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="78"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="139"/>
        <source>After current page</source>
        <translation>Na de huidige pagina</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="407"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="88"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="149"/>
        <source>Before first page</source>
        <translation>Voor de eerste pagina</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="304"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="174"/>
        <source>Append to Current Document </source>
        <translation>Toevoegen aan huidig document </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="299"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="181"/>
        <source>Create New Document</source>
        <translation>Maak een nieuw document</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="450"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>Invoer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="133"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="105"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="241"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="522"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="183"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>Scanner</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="80"/>
        <source>Preview</source>
        <translation>Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="112"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="248"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="90"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="255"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="97"/>
        <source>Skip empty pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="544"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="36"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1069"/>
        <source>Looking for devices. Please wait.</source>
        <translation>Op zoek naar apparaten.Even geduld aub.</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="vanished">Herladen</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="vanished">Modus</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="209"/>
        <source>Resolution</source>
        <translation>Resolutie</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="315"/>
        <source>Flatbed</source>
        <translation>Flatbed</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="322"/>
        <source>Negative Transparency</source>
        <translation>Negatieve transparantie</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <source>Document Feeder</source>
        <translation>Documentinvoer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <source>Positive Transparency</source>
        <translation>Positieve transparantie</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="353"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="139"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="197"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="50"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="47"/>
        <source>untitled</source>
        <translation>naamloos</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="501"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1007"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="350"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="381"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="188"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="225"/>
        <source>Save As PDF</source>
        <translation>Bewaar als PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="503"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1009"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="352"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="383"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="227"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF bestanden (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="64"/>
        <source>Single Page</source>
        <translation>Enkele pagina</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="65"/>
        <source>All Pages From Feeder</source>
        <translation>Alle ingevoerde pagina&apos;s</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="462"/>
        <source>Scan:</source>
        <translation>Scan:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="482"/>
        <source>Page Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1080"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="130"/>
        <source>Open device. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="193"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="571"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="27"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="39"/>
        <source>Save</source>
        <translation type="unfinished">Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished">Geen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="70"/>
        <source>Delete</source>
        <translation type="unfinished">Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="219"/>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="225"/>
        <source>After scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="318"/>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="418"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="767"/>
        <source>Scan source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="776"/>
        <source>ADF Duplex Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="784"/>
        <source>ADF Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="792"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="801"/>
        <source>Scan mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="833"/>
        <source>Scan resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="845"/>
        <source>X-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="854"/>
        <source>Y-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="obsolete">Helderheid</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="obsolete">Contrast</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="899"/>
        <source>Page width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="916"/>
        <source>Page height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="938"/>
        <source>Top-left x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="956"/>
        <source>Top-left y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="977"/>
        <source>Bottom-right x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="994"/>
        <source>Bottom-right y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>Meer pagina&apos;s scannen</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>Scannen voltooid</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation type="vanished">Voorvertoning</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Draai 90 graden met de klok mee</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Draai 90 graden tegen de klok in</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="138"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="204"/>
        <source>Search</source>
        <translation>Zoeken</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0 resulaten</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Case Sensitive</source>
        <translation>Hoofdletter gevoelig</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="92"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="102"/>
        <source> result</source>
        <translation> resultaat</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="106"/>
        <source> results</source>
        <translation> resultaten</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="104"/>
        <source> result(s)</source>
        <translation> resultaten</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="23"/>
        <source>Include Comments</source>
        <translation>opmerkingen toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="27"/>
        <source>Whole Words Only</source>
        <translation>Aleen hele woorden</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="134"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="183"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="233"/>
        <source>Check All</source>
        <translation>Selecteer alles</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation>Markeer geslecteerde resultaten voor herziening</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">Zoek en redigeer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="229"/>
        <source>Uncheck All</source>
        <translation>De-selecteer alles</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="124"/>
        <source>Case Sensitive</source>
        <translation>Hoofdletter gevoelig</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="125"/>
        <source>Include Comments</source>
        <translation>opmerkingen toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Whole Words Only</source>
        <translation>Aleen hele woorden</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation>Certificaat beveiliging</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation>Ontvanger</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation>Machtigingen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation>Inhoud kopiëren voor toegankelijkheid</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation>Document aanpassen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation>Document wordt geprint</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Beheer pagina&apos;s en bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Vul een bestand formulier in of handtekening veld in</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Print a high resolution version of the document</source>
        <translation>Druk af met hoge resolutie</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Extract the content of the document</source>
        <translation>Inhoud van het document uitpakken</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation>Versleuteling</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation>Ontvangers</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="35"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Een wachtwoord is vereist om het document te openen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Open document met wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Bevestig wachtwoord</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Machtigingen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Document aanpassen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Inhoud kopiëren voor toegankelijkheid</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Document wordt geprint</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Pak de inhoud van het document uit</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Druk af met hoge resolutie</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Vul een bestand formulier in of handtekening veld in</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Wachtwoord toestemmingen</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="259"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Beheer pagina&apos;s en bladwijzers</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="104"/>
        <source>Document Open password does not match.</source>
        <translation>Wachtwoord om document te openen komt niet overeen.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="116"/>
        <source>Document Permission password does not match.</source>
        <translation>Document toestemmingen en wachtwoord komen niet overeen.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>Versleuteling</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation>128 bit RC4</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation>Wachtwoord beveiliging</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation>128 bit RC4 {40 ?}</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
</context>
<context>
    <name>SessionsDialog</name>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished">Nieuw</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="32"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="39"/>
        <source>Switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="46"/>
        <source>Import</source>
        <translation type="unfinished">Importeren</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished">Exporteren</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="60"/>
        <source>Rename</source>
        <translation type="unfinished">Naam wijzigen</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="67"/>
        <source>Remove</source>
        <translation type="unfinished">Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="74"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="93"/>
        <source>Session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="98"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="103"/>
        <source>Last Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="108"/>
        <source>Document count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="121"/>
        <source>Store paths to documents relative to session file when exporting sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="140"/>
        <source>Managed Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="184"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>MPE session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="273"/>
        <source>Failed to load sessions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="452"/>
        <location filename="../../src/SessionsDialog.cpp" line="457"/>
        <source>New session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>New session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>Please write new session name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation>Bestemming instellen</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>Gebruik de schuifbalken-, muis- en zoomhulpmiddelen om de doelweergave te selecteren en druk vervolgens op Koppeling instellen om de een link te maken</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation>Stel Link in</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation>Stel de huidige zoomlens in</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Handtekening eigenschappen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="54"/>
        <source>Signature is VALID</source>
        <translation>Handtekening is GELDIG</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Details</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Ondertekend door:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="502"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="665"/>
        <source>Reason:</source>
        <translation>Reden:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="883"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Locatie:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Validatie samenvatting</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Contactgegevens voor ondertekenaar:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation>Tekst voor ondertekening</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation>Locatie</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation>Reden</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="331"/>
        <source>Lock document after signing</source>
        <translation>Na ondertekening document vergrendelen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="353"/>
        <source>Signature Preview</source>
        <translation>Voorvertoning handtekening</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="72"/>
        <source>I have reviewed this document</source>
        <translation>Ik heb dit document beoordeeld</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="73"/>
        <source>I am approving this document</source>
        <translation>Ik ga akkoord met dit document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="74"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Ik bevestig de nauwkeurigheid en integriteit van dit document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="75"/>
        <source>I agree to specified parts of this document</source>
        <translation>Ik ga akkoord met specifieke delen van dit document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="553"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="557"/>
        <source>M.d.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="562"/>
        <source>M.d.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="567"/>
        <source>M.d.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="572"/>
        <source>M.d.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="577"/>
        <source>MM.dd.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="582"/>
        <source>MM.dd.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="587"/>
        <source>MM.dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="592"/>
        <source>MM.dd.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="597"/>
        <source>MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="602"/>
        <source>MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="607"/>
        <source>d.M.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="612"/>
        <source>d.M.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="617"/>
        <source>dd.MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="622"/>
        <source>dd.MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="627"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="632"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="637"/>
        <source>yy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="642"/>
        <source>yy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="647"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="652"/>
        <source>yyyy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="657"/>
        <source>d-MMMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="662"/>
        <source>d-MMMM HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="667"/>
        <source>d-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="672"/>
        <source>d-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="677"/>
        <source>d-MMMM-yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="682"/>
        <source>d-MMMM-yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="687"/>
        <source>dd-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="692"/>
        <source>dd-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="331"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="299"/>
        <source>Sign</source>
        <translation>Ondertekenen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="787"/>
        <source>Show Image</source>
        <translation>Toon afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="812"/>
        <source>Stretch Image</source>
        <translation>Afbeelding uitrekken</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="822"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="464"/>
        <source>Show Text</source>
        <translation>Toon tekst</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="476"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Er heeft zich een fout voorgedaan tijdens de handtekening verificatie!</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Open Image</source>
        <translation>Open afbeelding</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="189"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Afbeeldingsbestanden (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Het document is gewijzigd of beschadigd sinds de handtekeningen werden toegepast.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Document is niet gewijzigd sinds de handtekeningen zijn toegepast.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="53"/>
        <source>Signature is INVALID</source>
        <translation>Handtekening is NIET GELDIG</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="55"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>Handtekening geldigheid is ONBEKEND</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="57"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>De identiteit van de ondertekenaar is onbekend omdat deze niet is opgenomen in uw lijst met vertrouwde identiteiten en geen van de bovenliggende certificaten vertrouwensidentiteiten zijn.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="58"/>
        <source>Error during signature verification.</source>
        <translation>Er is een fout opgetreden tijdens de handtekeningverificatie.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="59"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Details: het bereik van de handtekeningbyte is ongeldig</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="60"/>
        <source>I am the author of this document</source>
        <translation>Ik ben de auteur van dit document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="56"/>
        <source>This certificate is not trusted</source>
        <translation>Dit certificaat is niet vertrouwd</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation>Onderteken als</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="400"/>
        <source>Appearance Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="441"/>
        <source>Формат  по ГОСТу</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="473"/>
        <source>Date /Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="543"/>
        <source>Date Format</source>
        <translation type="unfinished">Datumnotatie</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="727"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="733"/>
        <source>Show Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="751"/>
        <source>Rounded Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">Tijd</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="483"/>
        <source>Signed By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="703"/>
        <source>E-mail</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="713"/>
        <source>Name</source>
        <translation type="unfinished">Naam</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Datum</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="422"/>
        <source>Text</source>
        <translation type="unfinished">Tekst</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="781"/>
        <source>Image</source>
        <translation type="unfinished">Afbeelding</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation type="vanished">Digitaal ondertekend door </translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="vanished">Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="280"/>
        <source>Saved Settings</source>
        <translation>Opgeslagen instellingen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="308"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="293"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save Settings</source>
        <translation>instellingen opslaan</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save current settings as:</source>
        <translation>Bewaar huidige instellingen als:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1490"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Instellingen met deze naam bestaat al. Wilt u de oude instellingen vervangen?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="503"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="332"/>
        <source>Certificate Manager</source>
        <translation>Certificaat manager</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Alle nondersteunde formaten (*.p12 *.pfx);; p12 Bestanden (*.p12);; pfx Bestanden (*.pfx);; Alle bestanden (*)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="918"/>
        <source>A password is required to open certificate:</source>
        <translation>Een wachtwoord is vereist om certificaat te openen:</translation>
    </message>
    <message>
        <source>Digitally signed by</source>
        <translation type="vanished">Digitaal ondertekend door</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation>Handtekeningen</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="286"/>
        <source>Unsigned Signature</source>
        <translation>Niet-ondertekende handtekening</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Location</source>
        <translation>Locatie</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="302"/>
        <source>Signed Signature</source>
        <translation>Ondertekende handtekening</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="305"/>
        <source>Signed by:</source>
        <translation>Ondertekend door:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="306"/>
        <source>Reason:</source>
        <translation>Reden:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="346"/>
        <source>Click to view this version</source>
        <translation>Klik om deze versie te bekijken</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Document</source>
        <translation type="unfinished">Document</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Uitgever</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Gemeenschappelijke naam (GN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organisatie (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Organisatie Eenheid (OE)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Serienummer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algortime</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Onderwerp</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Geldig</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Niet voor</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Niet na</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Toevoegen aan Vertrouwde Certificaten</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation>Bestandsnaam</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="98"/>
        <source>Custom</source>
        <translation>Aangepast</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation>Beheer zegels</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>Aangepaste zegels</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>Toevoegen</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>Zegel</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>Zegel bewerken</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>Naam</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>Sjabloon</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="43"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation>Antwoord</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Lettertype:</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Tekengrootte:</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Tekst Kleur:</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>Tekst Bewerker</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="166"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="184"/>
        <source>Add Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="199"/>
        <source>Name</source>
        <translation type="unfinished">Naam</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="224"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="249"/>
        <source>Organization unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="274"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="299"/>
        <source>Email</source>
        <translation type="unfinished">Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="324"/>
        <source>Valid since</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="349"/>
        <source>Valid till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="365"/>
        <source>Date</source>
        <translation type="unfinished">Datum</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="obsolete">Van</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="obsolete">Aan</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>It&apos;s not common to change HTML Code</translatorcomment>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>It&apos;s not common to change HTML Code</translatorcomment>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>It&apos;s not common to change HTML Code</translatorcomment>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ThumbnailForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulier</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="22"/>
        <source>Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="29"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="42"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="62"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="75"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.cpp" line="39"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="227"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="233"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="268"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="271"/>
        <source>StrikeOut</source>
        <translation type="unfinished">Doorstrepen</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="125"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="167"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="170"/>
        <source>Copy</source>
        <translation type="unfinished">Kopiëren</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="101"/>
        <source>Delete</source>
        <translation type="unfinished">Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="104"/>
        <source>Open</source>
        <translation type="unfinished">Openen</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="110"/>
        <source>Red</source>
        <translation type="unfinished">Rood</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="112"/>
        <source>Blue</source>
        <translation type="unfinished">Blauw</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="114"/>
        <source>Yellow</source>
        <translation type="unfinished">Geel</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="116"/>
        <source>Green</source>
        <translation type="unfinished">Groen</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="119"/>
        <source>Change</source>
        <translation type="unfinished">Verandering</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <source>New</source>
        <translation type="obsolete">Nieuw</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Openen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="696"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Zoeken</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Commentaar</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">Stempel</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation type="obsolete">Commentaar bekijken</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation type="obsolete">Initialen plaatsen</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Hoofd</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bewerken</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Beeld</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objecten</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Commentaar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="602"/>
        <source>Open a PDF file</source>
        <translation>Open een PDF bestand</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Schrijfmachine</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Notitie</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Ongedaan maken</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Opnieuw</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Knippen</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopiëren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Plakken</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Bestand</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Opslaan</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Afdrukken</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulieren</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Handtekening</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Radio knop</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Keuzelijst</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Tekst veld</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Keuzelijst met invoervak</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Selectievakje</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Penseel</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ovaal</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rechthoek</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Lijn</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Tekst invoegen</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Opstellen</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Markeren voor opstellen</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Gereedschap</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Bewerk tekst</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Handaanwijzer</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vorige beeld</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Volgende beeld</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zoom uit</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Inzoomen</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>Watermerk</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="648"/>
        <source>Delete</source>
        <translation>Verwijderen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="662"/>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="670"/>
        <source>Save</source>
        <translation>Opslaan</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="231"/>
        <source>Source</source>
        <translation>Bron</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="427"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="244"/>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="417"/>
        <source>Scale</source>
        <translation>Schalen</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Toaal aantal pagina&apos;s:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="237"/>
        <source>Page Number</source>
        <translation>Pagina nummer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="264"/>
        <source>Font</source>
        <translation>Lettertype</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="270"/>
        <source>Color</source>
        <translation>Kleur</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="322"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="315"/>
        <source>Font Family</source>
        <translation>Lettertype familie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="380"/>
        <source>Browse</source>
        <translation>Bladeren</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="121"/>
        <source>Appearance</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Voorvertoning</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="28"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="45"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="52"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="127"/>
        <source>Rotation</source>
        <translation>Roteren</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="145"/>
        <source>Options</source>
        <translation>Instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="165"/>
        <source>Opacity</source>
        <translation>Dekking</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="221"/>
        <source>Scale relative to target page</source>
        <translation>Relatief schalen ten opzichte van doelpagina</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="489"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="495"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="630"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="754"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="760"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="791"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="453"/>
        <source>Position</source>
        <translation>Positie</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="495"/>
        <source>Vertical distance</source>
        <translation>Verticale afstand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="529"/>
        <source>from</source>
        <translation>van</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="562"/>
        <source>Top</source>
        <translation>Boven</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="468"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="567"/>
        <source>Center</source>
        <translation>Centreren</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="572"/>
        <source>Bottom</source>
        <translation>Beneden</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="488"/>
        <source>Horizontal distance</source>
        <translation>Horizontale afstand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="463"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="580"/>
        <source>Units</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="80"/>
        <source>Page Range Options...</source>
        <translation>Paginabereik opties...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save Settings</source>
        <translation>instellingen opslaan</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save current settings as:</source>
        <translation>Bewaar huidige instellingen als:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="302"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Instellingen met deze naam bestaat al. Wilt u de oude instellingen vervangen?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Bent u er zeker van de instellingen te verwijderen </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="420"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="436"/>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="454"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>Open File</source>
        <translation>Open bestand</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="499"/>
        <source>There was an error opening the document !</source>
        <translation>Fout tijdens openen document !</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="299"/>
        <source>auto</source>
        <translation>automatisch</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="629"/>
        <source>Saved Settings</source>
        <translation>Opgeslagen instellingen</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="540"/>
        <source>Points</source>
        <translation>Punten</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="545"/>
        <source>Inches</source>
        <translation>Inches</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="550"/>
        <source>Millimeters</source>
        <translation>Millimeters</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Alle ondersteunde bestanden (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="600"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="606"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="613"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSignature</name>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="37"/>
        <source>Digitally signed by</source>
        <translation type="unfinished">Digitaal ondertekend door</translation>
    </message>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="38"/>
        <source>Email</source>
        <translation type="unfinished">Email</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Datum</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation>Lagen</translation>
    </message>
</context>
</TS>
