<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>製品情報</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="410"/>
        <source>Ok</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="127"/>
        <source>Registered version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="179"/>
        <source>Purchased On:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="187"/>
        <source>Maintenance Plan Expires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation type="unfinished">登録情報</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="126"/>
        <source>Not Registered version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="258"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="99"/>
        <source>Please, renew your license</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Third-Party Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation type="unfinished">文書のアクション</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation type="unfinished">動作</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddOpenFilesDialog</name>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="14"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="22"/>
        <source>Open PDF files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>File Name</source>
        <translation type="unfinished">ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="32"/>
        <source>Add Files</source>
        <translation type="unfinished">ファイルを追加</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="97"/>
        <source>Сompatible with Laser Engraving</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation type="unfinished">書式</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="246"/>
        <source>Borders and Colors</source>
        <translation type="unfinished">線の種類および色</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="256"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="261"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="266"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="271"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="276"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="281"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="286"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="291"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="296"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="301"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="306"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="314"/>
        <source>Border Color</source>
        <translation type="unfinished">線の色：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="321"/>
        <source>Fill Color</source>
        <translation type="unfinished">塗りつぶし：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="329"/>
        <source>Solid</source>
        <translation type="unfinished">実線</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="334"/>
        <source>Dashed</source>
        <translation type="unfinished">破線</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="obsolete">線幅：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="349"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="342"/>
        <source>Line Style</source>
        <translation type="unfinished">線の種類：</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">ファイル</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">PDFの作成</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">開く</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">最近使用したファイル</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">ヘルプ</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="obsolete">オンラインマニュアル</translation>
    </message>
    <message>
        <source>Home page</source>
        <translation type="obsolete">ホームページ</translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="obsolete">提案を投稿...</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">登録情報</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">アップデートの確認</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">ヘルプ...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation type="unfinished">背景</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="335"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="349"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="357"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="367"/>
        <source>Source</source>
        <translation type="unfinished">ソース</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="405"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="411"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="508"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="514"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="540"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="660"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="449"/>
        <source>File</source>
        <translation type="unfinished">ファイル</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="obsolete">ページ総数 ：</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="383"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="484"/>
        <source>Page Number</source>
        <translation type="unfinished">ページ番号</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="422"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="373"/>
        <source>Scale</source>
        <translation type="unfinished">縮尺</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation type="unfinished">外観</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation type="unfinished">回転</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="44"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation type="unfinished">不透明度</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished">ターゲットページに対する相対的縮尺</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="140"/>
        <source>Position</source>
        <translation type="unfinished">位置</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="187"/>
        <source>Vertical distance</source>
        <translation type="unfinished">垂直距離</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="166"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="246"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="282"/>
        <source>Top</source>
        <translation type="unfinished">上</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="265"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="287"/>
        <source>Center</source>
        <translation type="unfinished">中央</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="292"/>
        <source>Bottom</source>
        <translation type="unfinished">底</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="180"/>
        <source>Horizontal distance</source>
        <translation type="unfinished">水平距離</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="260"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="270"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="173"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="506"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="514"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="531"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="538"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="566"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">ページ範囲のオプション...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="241"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="337"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="371"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="415"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="obsolete">文書を開く途中でエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="316"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="228"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="233"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="238"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="201"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="207"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatesNumberingOptionsDialog</name>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="32"/>
        <source>Start Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="39"/>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="59"/>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="69"/>
        <source>Number of Digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="14"/>
        <source>Bates Numbering Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source>The value must be between </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source> and </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>ブックマークのプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>オプション</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>テキスト</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="115"/>
        <source>Style</source>
        <translation>スタイル</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="129"/>
        <source>Plain</source>
        <translation>通常書体</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="134"/>
        <source>Italic</source>
        <translation>イタリック</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="139"/>
        <source>Bold</source>
        <translation>太字</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="144"/>
        <source>Italic &amp; Bold</source>
        <translation>太字斜体</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="165"/>
        <source>Color</source>
        <translation>色</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="179"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="292"/>
        <source>Actions</source>
        <translation>動作</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="351"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="332"/>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="185"/>
        <source>Add an Action</source>
        <translation>アクションを追加</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="220"/>
        <source>Trigger</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="204"/>
        <source>Action</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="212"/>
        <source>Mouse Up</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="228"/>
        <source>Goto a Page View</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="233"/>
        <source>Open/execute a File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="238"/>
        <source>Open a web link</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="243"/>
        <source>Reset form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="248"/>
        <source>Show/Hide fields</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="253"/>
        <source>Submit a form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="258"/>
        <source>Run a JavaScript</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="266"/>
        <source>Add</source>
        <translation>追加</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation type="unfinished">ページ番号</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="86"/>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="96"/>
        <source>Appearance</source>
        <translation type="unfinished">外観</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="78"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="220"/>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="222"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
</context>
<context>
    <name>BookmarksForm</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="20"/>
        <source>Bookmarks</source>
        <translation type="unfinished">ブックマーク</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="38"/>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="69"/>
        <source>Set destanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="100"/>
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="131"/>
        <source>Properties</source>
        <translation type="unfinished">文書のプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="162"/>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="193"/>
        <source>Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="224"/>
        <source>Delete all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="44"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="102"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished">証明書を開くにはパスワードが必要です：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="114"/>
        <source>Error!</source>
        <translation type="unfinished">エラー！</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>pfx Files (*.pfx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>crt Files (*.crt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="162"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="171"/>
        <source>Please, specify private key password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="126"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation type="unfinished">既存PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="181"/>
        <source>Add Files</source>
        <translation type="unfinished">ファイルを追加</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="164"/>
        <source>Add Folder</source>
        <translation type="unfinished">フォルダを追加</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="211"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="267"/>
        <source>Up</source>
        <translation type="unfinished">上へ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="298"/>
        <source>Down</source>
        <translation type="unfinished">下へ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="237"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="278"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="196"/>
        <source>Page Range</source>
        <translation type="unfinished">ページ範囲</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>File Name</source>
        <translation type="unfinished">ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="124"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="84"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="126"/>
        <source>Add Headers and Footers to Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>Total pages</source>
        <translation type="unfinished">ページ総数</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="198"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="197"/>
        <source>Total Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="488"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="921"/>
        <source>Save As PDF</source>
        <translation type="unfinished">PDFを保存</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="490"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="923"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished">PDFファイル (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1002"/>
        <source>File</source>
        <translation type="unfinished">ファイル</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1003"/>
        <source>has already been added to the list. Please choose a different file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source> is already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1052"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1074"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>are already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">開く</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="obsolete">全ての形式 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="600"/>
        <source>Select directory</source>
        <translation type="unfinished">ディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="956"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="34"/>
        <source>Output</source>
        <translation type="unfinished">出力</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="101"/>
        <source>Append to Current Document </source>
        <translation type="unfinished">現在の文書に追加</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="108"/>
        <source>Create New Document</source>
        <translation type="unfinished">新規文書を作成</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="43"/>
        <source>Position</source>
        <translation type="unfinished">位置</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="20"/>
        <source>Add files to which Headers and Footers or Bates Numbers should be placed. Bates Numbers will appear in the specified order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="27"/>
        <source>Save and close files after numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="49"/>
        <source>Before current page</source>
        <translation type="unfinished">現在のページの前</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="59"/>
        <source>After last page</source>
        <translation type="unfinished">最終ページの後</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="66"/>
        <source>After current page</source>
        <translation type="unfinished">現在のページの後</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="76"/>
        <source>Before first page</source>
        <translation type="unfinished">第1ページの前</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="137"/>
        <source>Import Bookmarks</source>
        <translation type="unfinished">ブックマークをインポート</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="309"/>
        <source>Show</source>
        <translation type="unfinished">表示</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Insert Pages</source>
        <translation type="unfinished">複数ページを挿入</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="550"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="42"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="49"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="553"/>
        <source>All Supported Files (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteAcrossPagesDialog</name>
    <message>
        <location filename="../../src/DeleteAcrossPagesDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="14"/>
        <source>Delete Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="23"/>
        <source>Do you want to delete all headers, footers and Bates numbers on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="22"/>
        <source>Do you want to delete all watermarks on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="27"/>
        <source>Do you want to delete all backgrounds on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>ページを削除</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">現在のページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">-：</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="50"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Form Fields</source>
        <translation type="obsolete">フォーム部品</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">プッシュボタン</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">不透明度</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">テキスト</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">外観</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">色</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">基本</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="vanished">作成者：</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="vanished">タイトル：</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">ロック</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">オプション</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Rotate Pages</source>
        <translation type="vanished">ページを回転</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">-：</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">現在のページ</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation type="unfinished">距離測定ツール</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation type="unfinished">測定</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="32"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="36"/>
        <source>Perimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="43"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="46"/>
        <source> sq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="222"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="225"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="229"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgChangeFont</name>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="14"/>
        <source>Change Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="39"/>
        <source>Current font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="46"/>
        <source>Change to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="66"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">テキスト編集時にフォントを自動的に変更</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="84"/>
        <source>Exact match only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="21"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="28"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation type="unfinished">プッシュボタン</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation type="unfinished">Never</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="51"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="18"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="20"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="21"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="53"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="27"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="29"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="14"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="16"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">偶数/奇数ページ</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="obsolete">偶数ページ</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="obsolete">奇数ページ</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">テキストの修正</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">名前をつけて保存</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">文書のプロパティ...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">切り取り</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">コピー</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="vanished">背面へ移動</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">前面へ移動</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">削除</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">元に戻す</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="41"/>
        <source>Select All</source>
        <translation>すべて選択</translation>
    </message>
    <message>
        <source>UnSelect</source>
        <translation type="vanished">選択を解除</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">貼り付け</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="48"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished">付箋を追加</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="49"/>
        <source>Highlight Text</source>
        <translation type="unfinished">テキストを強調表示</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="50"/>
        <source>Strikeout Text</source>
        <translation type="unfinished">テキストに取消線</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="51"/>
        <source>Underline Text</source>
        <translation type="unfinished">テキストに下線</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>Add Bookmark</source>
        <translation type="unfinished">ブックマークを追加</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2456"/>
        <location filename="../../src/docpage/docpage.cpp" line="2496"/>
        <source>Goto a Page View</source>
        <translation type="unfinished">ページビューに移る</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2465"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2475"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2486"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished">JavaScript を実行する</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3975"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="70"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="82"/>
        <source>Set Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1087"/>
        <location filename="../../src/docpage/docpage.cpp" line="1090"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1678"/>
        <source>The selected area has been copied</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">コピー</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">切り取り</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">貼り付け</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="131"/>
        <source>Select All</source>
        <translation>すべて選択</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="132"/>
        <source>Options</source>
        <translation>オプション</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">テキストの修正</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="136"/>
        <source>Signature options</source>
        <translation type="unfinished">署名</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">元に戻す</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="139"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="2622"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Open Image</source>
        <translation>ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="141"/>
        <source>Save Image to file</source>
        <translation type="unfinished">名前をつけて保存</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1659"/>
        <source>Cancel</source>
        <translation type="unfinished">キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="594"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="609"/>
        <source>Image</source>
        <translation type="unfinished">画像</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="134"/>
        <source>Edit Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="140"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="143"/>
        <source>Edit Path Nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1656"/>
        <source>Edit the image and press Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1658"/>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1940"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1950"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2593"/>
        <source>Delete Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="137"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="135"/>
        <source>Replace Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1650"/>
        <source>An error occurred when attempting to open external application for editing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Document</name>
    <message>
        <source>Do you want to open?</source>
        <translation type="obsolete">開きますか？</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>アクション</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">ページへ移動</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">自動</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">上</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">左</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">ページ番号</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">拡大 (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">ファイルを開く/実行</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">ファイルを編集</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>表示</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>フィールドを選択</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>全選択を解除</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>隠す</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>すべてを選択</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>書式</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="187"/>
        <source>Show/Hide Fields</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="221"/>
        <source>Reset Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">オプション</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">ページ全体</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>参照...</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation type="unfinished">ユーザ名</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation type="unfinished">パスワード</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="115"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="117"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished">全ての形式 (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="191"/>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>参照...</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation type="unfinished">ページへ移動</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation type="unfinished">ページ番号</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation type="unfinished">拡大 (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="171"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="173"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished">全ての形式 (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="114"/>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation type="unfinished">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditTabOrderDlg</name>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="14"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="20"/>
        <source>Forms</source>
        <translation type="unfinished">フォーム</translation>
    </message>
</context>
<context>
    <name>ExportCSVDialog</name>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="20"/>
        <source>Export to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="50"/>
        <source>File Name</source>
        <translation type="unfinished">ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="78"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="88"/>
        <source>Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="103"/>
        <source>Semicolon ( ; )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="129"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="146"/>
        <source>Comma ( , )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="153"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="38"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="47"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="111"/>
        <source>Export to csv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="113"/>
        <source>csv files (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="77"/>
        <source>Extract pages as a single file</source>
        <translation>ページをファイルとして抽出</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>参照...</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>複数ページを抽出</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="141"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">現在のページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">-：</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="130"/>
        <source>Save As PDF</source>
        <translation>PDFとして保存</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="132"/>
        <source>PDF Files (*.pdf)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>Can&apos;t save to the file:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>The file &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>&quot; already exists. Do you wish to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="43"/>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="124"/>
        <source>Export bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="134"/>
        <source>Delete pages after extracting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="23"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished">ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="64"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished">ページをファイルとして抽出</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="35"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="43"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>文書のプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>文書情報</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>タイトル：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>タイトル：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>作成者：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>キーワード：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>アプリケーション：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>PDF変換：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>セキュリティ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>初期表示</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">画像として出力</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>フォント</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>使用フォント</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">ドキュメントのセキュリティ</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">ユーザーパスワード：</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">所有者パスワード：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>パスワード暗号化</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>暗号化されていません</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>印刷を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>高解像度での印刷を許可する</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Content Extraction Permission</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extract the contents of the document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>文書内容の変更を許可する</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">コメントやフォームフィールドの変更を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>フォームフィールドへの入力を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation>ページとブックマークの管理を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Open to page：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>Older From：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>情報</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">表示：</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation type="unfinished">許可</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished">文書の内容を抽出する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished">アクセシビリティのための内容の抽出を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation type="unfinished">コメントの追加・編集を許可する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="723"/>
        <source>Password</source>
        <translation type="unfinished">パスワード</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="724"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="746"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="248"/>
        <source>Default</source>
        <translation type="unfinished">標準</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation type="unfinished">単ページ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation type="unfinished">ズーム</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation type="unfinished">実サイズ</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation type="unfinished">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="268"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="273"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation type="unfinished">動作</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation type="unfinished">アクションを追加</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation type="unfinished">ページビューに移る</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation type="unfinished">フォームをリセットする</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished">フィールドを表示する/隠す</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation type="unfinished">フォームを送信する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished">JavaScript を実行する</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">システム</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">外観</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">オプション</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">動作</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">削除</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">閉じる</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">スタイル</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">色</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">追加</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">ロック</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">名前</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">線の種類および色</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">アクションを追加</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">ツールチップ</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">標定</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">線の種類：</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">線幅：</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">塗りつぶし：</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">線の色：</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">上へ</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">下へ</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="vanished">文書のプロパティ</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="vanished">基本</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="vanished">可視</translation>
    </message>
    <message>
        <source>Printable</source>
        <translation type="vanished">印刷対象</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="vanished">読み取り専用</translation>
    </message>
    <message>
        <source>Required</source>
        <translation type="vanished">必須</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="vanished">細</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="vanished">中</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="vanished">太</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">テキスト</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">サイズ</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">フォント</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="vanished">自動</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">左</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="vanished">中央</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="vanished">右</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation type="vanished">初期値</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">パスワード</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">挿入</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="vanished">編集</translation>
    </message>
</context>
<context>
    <name>HeaderAndFooterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="365"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="569"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="593"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="621"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="166"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="257"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="291"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="296"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="301"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">左余白</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">右余白</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="obsolete">上余白</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="obsolete">下余白</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="328"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="347"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="361"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="369"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="522"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="536"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="553"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="560"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="588"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">ページ範囲のオプション...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="150"/>
        <source>Page number and date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="28"/>
        <source>Show Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="41"/>
        <source>Insert Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="48"/>
        <source>Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="55"/>
        <source>Insert Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="70"/>
        <source>Font</source>
        <translation type="unfinished">フォント</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="76"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="96"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="116"/>
        <source>Font Family</source>
        <translation type="unfinished">フォントファミリー</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="178"/>
        <source>Top</source>
        <translation type="unfinished">上</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="188"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="198"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="247"/>
        <source>Bottom</source>
        <translation type="unfinished">底</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Use Page Range of the currently edited Pagemark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="408"/>
        <source>Right Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="469"/>
        <source>Center Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="439"/>
        <source>Left Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="476"/>
        <source>Right Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="432"/>
        <source>Center Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="425"/>
        <source>Left Header Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Top margin</source>
        <translation type="obsolete">上余白</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">右余白</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="obsolete">下余白</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">左余白</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="obsolete">フォント</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">色</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">サイズ</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="obsolete">フォントファミリー</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">削除</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">なし</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="obsolete">ページ範囲のオプション...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="obsolete">設定を保存</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="obsolete">設定を保存：</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="obsolete">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="obsolete">設定を削除しますか</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="obsolete">単位</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation type="obsolete">保存済み設定</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">ポイント</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="obsolete">インチ</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="obsolete">ミリメートル</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="vanished">複数ページを挿入</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">全てのページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">-：</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="vanished">ファイル名</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="vanished">参照...</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="vanished">位置</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="vanished">現在のページの前</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="vanished">現在のページの後</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="vanished">最終ページの後</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="vanished">第1ページの前</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">ファイルを開く</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">ページ総数 ：</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="obsolete">ページ前</translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="obsolete">ページ後</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="obsolete">ブックマークをインポート</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="obsolete">パスワード</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="obsolete">ファイルが保護されています。 文書を開くパスワードを入力してください。</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation type="obsolete">読み取りエラー： PDF は保護されています。</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished">フォーム</translation>
    </message>
</context>
<context>
    <name>InspectorObjectDialog</name>
    <message>
        <source>Enlarge selected text</source>
        <translation type="obsolete">選択されたテキストを拡大</translation>
    </message>
    <message>
        <source>Reduce selected text</source>
        <translation type="obsolete">選択されたテキストを縮小</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation type="unfinished">インストール言語</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation type="unfinished">言語</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="165"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InteractiveCPDFReader</name>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="39"/>
        <source>Словарь в форме хранящейся в памяти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="52"/>
        <source>Команда(или help для их описания) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="88"/>
        <source>Вводимые ключи</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="101"/>
        <source>Черновик для записей</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="130"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="146"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="162"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="178"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="194"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="207"/>
        <source>Скопировать текущий 
словарь в черновик</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation type="unfinished">JavaScriptコンソール</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation type="unfinished">閉じる</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="126"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="205"/>
        <source>Press shortcut</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacApplication</name>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="465"/>
        <source>Zoom Out</source>
        <translation type="unfinished">ズームアウト</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="470"/>
        <source>Actual Size</source>
        <translation type="unfinished">実サイズ</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="478"/>
        <source>Zoom In</source>
        <translation type="unfinished">ズームイン</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">前のページへ</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">次のページへ</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation>システム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>言語</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="542"/>
        <source>Highlight color</source>
        <translation>[可視]が有効にされた部品の強調色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="562"/>
        <source>Required field highlight color</source>
        <translation>[必須]が有効にされた部品の強調色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3442"/>
        <source>Check for Updates Automatically</source>
        <translation>自動で Master PDF Editor のアップデートを確認：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3461"/>
        <source>Weekly</source>
        <translation>毎週</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3466"/>
        <source>Monthly</source>
        <translation>毎月</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3456"/>
        <source>Never</source>
        <translation>Never</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="894"/>
        <source>Options</source>
        <translation>オプション</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1236"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2044"/>
        <source> ms</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2272"/>
        <source>Smooth text and images</source>
        <translation>テキストと画像を滑らかに表示する</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1324"/>
        <source>Time before a move or resize starts:</source>
        <translation>移動またはリサイズを開始するまでの時間</translation>
    </message>
    <message>
        <source>Open saved file with the default viewer after saving</source>
        <translation type="vanished">保存後、標準のビューワで開く</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1317"/>
        <source>Select item by hovering the mouse</source>
        <translation>マウスポインタ直下のドキュメントを強調表示する</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Built-in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3370"/>
        <source>Please choose the interface language</source>
        <translation>操作に用いる言語を選択して下さい。</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="522"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3390"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>変更を反映するには、プログラムを再起動する必要があります。</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode.</source>
        <translation type="vanished">PDFをPDF/Aモードで保存する</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="203"/>
        <source>Saving Documents</source>
        <translation type="unfinished">文書を保存中</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Create backup file</source>
        <translation type="unfinished">バックアップファイルを作成</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Last used folder</source>
        <translation type="unfinished">最後に使われたフォルダ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Original documents folder</source>
        <translation type="unfinished">ドキュメント フォルダ</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">参照...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1144"/>
        <source>Default font</source>
        <translation type="unfinished">標準フォント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation type="unfinished">編集中</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2855"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2900"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1530"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1847"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1162"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1854"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2512"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>History</source>
        <translation type="unfinished">履歴</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="151"/>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="158"/>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1593"/>
        <source>Enable JavaScript</source>
        <translation type="unfinished">JavaScript を有効にする</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="598"/>
        <source> Always hide document message bar </source>
        <translation type="unfinished">メッセージバーを常時隠す</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2109"/>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished">標準レイアウトとズーム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2224"/>
        <source>Default page layout</source>
        <translation type="unfinished">標準ページレイアウト</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2122"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2232"/>
        <source>Automatic</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2204"/>
        <source>Single Page</source>
        <translation type="unfinished">単ページ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2209"/>
        <source>Facing Pages</source>
        <translation type="unfinished">見開き表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2255"/>
        <source>Zoom</source>
        <translation type="unfinished">ズーム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2127"/>
        <source>Actual Size</source>
        <translation type="unfinished">実サイズ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="984"/>
        <source>Show warning when opening links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <source>Convert static XFA into normal PDF when opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1224"/>
        <source>Page scrolling options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <source>Configure scroll value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1297"/>
        <source>Enable scroll without delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1137"/>
        <source>Create Pencil lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1979"/>
        <source>Create Pencil and Brush lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2132"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2137"/>
        <source>Fit Width</source>
        <translation type="unfinished">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2142"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2147"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2152"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2157"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2162"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2167"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2172"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2177"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2182"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2187"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="747"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2401"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2288"/>
        <source>Bitmap Images</source>
        <translation type="unfinished">ビットマップ画像</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2295"/>
        <source>Vector Images</source>
        <translation type="unfinished">ベクトル画像</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2383"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished">白黒反転表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2408"/>
        <source>Page Background</source>
        <translation type="unfinished">背景</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation type="unfinished">ディスプレイ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished">設定</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="obsolete">オブジェクトインスペクターを常時表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2425"/>
        <source>Theme</source>
        <translation type="unfinished">テーマ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="464"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="479"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="2041"/>
        <source>Select directory</source>
        <translation type="unfinished">ディレクトリを選択</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1061"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">テキスト編集時にフォントを自動的に変更</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2318"/>
        <source>Resolution</source>
        <translation type="unfinished">解像度</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2334"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2324"/>
        <source>System PPI</source>
        <translation type="unfinished">システム PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>Icons in menus</source>
        <translation type="unfinished">メニューアイコン</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation type="unfinished">環境設定の「同じウィンドウの新しいタブとして文書を開く (再起動が必要)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="342"/>
        <source>Enable scroll wheel zooming</source>
        <translation>スクロールホイールでズーム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1663"/>
        <source>Author</source>
        <translation type="unfinished">作成者：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2098"/>
        <source>Pop-up Opacity</source>
        <translation type="unfinished">ポップアップ不透明度</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1564"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1820"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2075"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1687"/>
        <source>Sticky Note</source>
        <translation type="unfinished">付箋</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1803"/>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1557"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1835"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1946"/>
        <source>Opacity</source>
        <translation type="unfinished">不透明度</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Highlight Text</source>
        <translation type="unfinished">テキストを強調表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1697"/>
        <source>Strikeout Text</source>
        <translation type="unfinished">テキストに取消線</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1702"/>
        <source>Underline Text</source>
        <translation type="unfinished">テキストに下線</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1537"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1928"/>
        <source>Line Width</source>
        <translation type="unfinished">線幅</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="656"/>
        <source>Appearance</source>
        <translation type="unfinished">外観</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="727"/>
        <source>Check Mark</source>
        <translation type="unfinished">チェックマーク</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="728"/>
        <source>Circle</source>
        <translation type="unfinished">円</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <source>Comment</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="838"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <source>Cross</source>
        <translation type="unfinished">交差</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <source>Help</source>
        <translation type="unfinished">ヘルプ</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">テキストを挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="733"/>
        <source>Key</source>
        <translation type="unfinished">キー</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="734"/>
        <source>New Paragraph</source>
        <translation type="unfinished">新規段落</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="735"/>
        <source>Text Note</source>
        <translation type="unfinished">テキストノート</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="736"/>
        <source>Paragraph</source>
        <translation type="unfinished">段落</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="737"/>
        <source>Right Arrow</source>
        <translation type="unfinished">右矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="738"/>
        <source>Right Pointer</source>
        <translation type="unfinished">右ポインタ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="853"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="739"/>
        <source>Star</source>
        <translation type="unfinished">星</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="740"/>
        <source>Up Arrow</source>
        <translation type="unfinished">上矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="741"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">左上矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="742"/>
        <source>Graph</source>
        <translation type="unfinished">グラフ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="743"/>
        <source>Paper Clip</source>
        <translation type="unfinished">ペーパークリップ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="744"/>
        <source>Attachment</source>
        <translation type="unfinished">添付ファイル</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="745"/>
        <source>Tag</source>
        <translation type="unfinished">タグ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1605"/>
        <source>Show errors and  messages in console</source>
        <translation type="unfinished">コンソールにエラーとメッセージを表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="606"/>
        <source>Link</source>
        <translation type="unfinished">リンク</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="248"/>
        <source>Autosave interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="299"/>
        <source>Autosave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="175"/>
        <source>Show Quick actions on text and comments selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Lock file from opening by other instances of Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Enable logging to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="398"/>
        <source>Log files directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Edit Box</source>
        <translation type="unfinished">テキスト領域</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="616"/>
        <source>Check box</source>
        <translation type="unfinished">チェックボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <source>Radio button</source>
        <translation type="unfinished">ラジオボタン</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Combo box</source>
        <translation type="unfinished">コンボボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>List box</source>
        <translation type="unfinished">リストボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Button</source>
        <translation type="unfinished">プッシュボタン</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="641"/>
        <source>Signature</source>
        <translation type="unfinished">署名</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="662"/>
        <source>Borders and Colors</source>
        <translation type="unfinished">線の種類および色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="669"/>
        <source>Thin</source>
        <translation type="unfinished">細</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="674"/>
        <source>Medium</source>
        <translation type="unfinished">中</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="679"/>
        <source>Thick</source>
        <translation type="unfinished">太</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="687"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Border Color</source>
        <translation type="unfinished">線の色：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="694"/>
        <source>Fill Color</source>
        <translation type="unfinished">塗りつぶし：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="702"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="929"/>
        <source>Solid</source>
        <translation type="unfinished">実線</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="934"/>
        <source>Dashed</source>
        <translation type="unfinished">破線</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="712"/>
        <source>Beveled</source>
        <translation type="unfinished">面取り</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="717"/>
        <source>Inset</source>
        <translation type="unfinished">インセット</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="722"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="939"/>
        <source>Underline</source>
        <translation type="unfinished">下線</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="921"/>
        <source>Line Style</source>
        <translation type="unfinished">線の種類：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="737"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="900"/>
        <source>Line Thickness</source>
        <translation type="unfinished">線幅：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Maximum CPU usage for OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3471"/>
        <source>Once in 3 months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="263"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2527"/>
        <source>Auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="801"/>
        <source>Font</source>
        <translation type="unfinished">フォント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="947"/>
        <source>Highlight</source>
        <translation type="unfinished">強調</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="958"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="963"/>
        <source>Invert</source>
        <translation type="unfinished">反転</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="968"/>
        <source>OutLine</source>
        <translation type="unfinished">アウトライン</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Insert</source>
        <translation type="unfinished">挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>Style</source>
        <translation type="unfinished">スタイル</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="828"/>
        <source>Check</source>
        <translation type="unfinished">チェック</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="843"/>
        <source>Diamond</source>
        <translation type="unfinished">ダイヤモンド</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="848"/>
        <source>Square</source>
        <translation type="unfinished">四角</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation type="unfinished">グリッド</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1384"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1411"/>
        <source>Width between lines</source>
        <translation type="unfinished">線間の幅</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1444"/>
        <source>Height between lines</source>
        <translation type="unfinished">線間の高さ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Left offset</source>
        <translation type="unfinished">左オフセット</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1437"/>
        <source>Top offset</source>
        <translation type="unfinished">上オフセット</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1451"/>
        <source>Subdivision</source>
        <translation type="unfinished">細分</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1707"/>
        <source>Measurements</source>
        <translation type="unfinished">計測</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1712"/>
        <source>Drawing</source>
        <translation type="unfinished">描画</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1098"/>
        <source>Selected text color</source>
        <translation type="unfinished">選択されたテキスト色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>Default</source>
        <translation type="unfinished">標準</translation>
    </message>
    <message>
        <source>Fusion</source>
        <translation type="obsolete">融合</translation>
    </message>
    <message>
        <source>Plastique</source>
        <translation type="obsolete">プラスティーク</translation>
    </message>
    <message>
        <source>CleanLooks</source>
        <translation type="obsolete">クリーンルックス</translation>
    </message>
    <message>
        <source>Motif</source>
        <translation type="obsolete">モチーフ</translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="obsolete">ダークスタイル</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2431"/>
        <source>Application Style</source>
        <translation type="unfinished">アプリケーションスタイル</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2610"/>
        <source>Use default program</source>
        <translation type="unfinished">標準プログラムを使用</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>evolution</source>
        <translation type="unfinished">エボリューション</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2634"/>
        <source>kmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2639"/>
        <source>thunderbird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2647"/>
        <source>Use SMTP</source>
        <translation type="unfinished">SMTP を使用</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2670"/>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2758"/>
        <source>Email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Secure connections</source>
        <translation type="unfinished">セキュア</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2726"/>
        <source>NONE</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2736"/>
        <source>STARTTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2718"/>
        <source>SMTP server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>User</source>
        <translation type="unfinished">ユーザ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2744"/>
        <source>SMTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2691"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3101"/>
        <source>Password</source>
        <translation type="unfinished">パスワード</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2950"/>
        <source>Default path to tesseract ocr data files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2923"/>
        <source>Additional tesseract ocr config file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2943"/>
        <source>Install languages</source>
        <translation type="unfinished">インストール言語</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="501"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1929"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1949"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1969"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1391"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1484"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1520"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation type="unfinished">ネットワーク</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1615"/>
        <source>Enable safe reading mode</source>
        <translation type="unfinished">セーフ読み込みモードを有効にする</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2980"/>
        <source>Direct internet connection</source>
        <translation type="unfinished">ダイレクトインターネット接続</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2990"/>
        <source>Manual proxy configuration</source>
        <translation type="unfinished">マニュアル proxy 設定</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3006"/>
        <source>HTTP Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3013"/>
        <source>SOCKS 5 Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3023"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3033"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2679"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3076"/>
        <source>Authentication</source>
        <translation type="unfinished">認証</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3091"/>
        <source>User name</source>
        <translation type="unfinished">ユーザ名</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2519"/>
        <source>Icon set</source>
        <translation type="unfinished">アイコンセット</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation type="unfinished">キーボード</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="349"/>
        <source>Show Start page</source>
        <translation>スタートページを表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1419"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1424"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1429"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="450"/>
        <source>Load all objects separately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1353"/>
        <source>Always show Object Inspector</source>
        <translation>オブジェクトインスペクターを常時表示</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2262"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1717"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <source>Exact match only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1360"/>
        <source>Save last editing Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3228"/>
        <source>Default paths for system certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3176"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="810"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation type="unfinished">基本</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="421"/>
        <source>Alternative method for PDF render</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="473"/>
        <source>Memory/Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="480"/>
        <source>Minimize memory usage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="485"/>
        <source>Maximal render speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="829"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1139"/>
        <source>System Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3238"/>
        <source>Database for Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3298"/>
        <source>Password:</source>
        <translation type="unfinished">パスワード：</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3254"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3271"/>
        <source>Copy</source>
        <translation type="unfinished">コピー</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3305"/>
        <source>Path for DB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="815"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="998"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1004"/>
        <source>Add full path to filename in export file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="991"/>
        <source>Recreate pdf forms when opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="830"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1143"/>
        <source>Light Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="831"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1147"/>
        <source>Dark Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation type="unfinished">ツールバー</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2499"/>
        <source>Standard</source>
        <translation type="unfinished">標準</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2504"/>
        <source>Office Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1367"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2041"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2489"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2532"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2537"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Save recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2217"/>
        <source>Navigation Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2247"/>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3334"/>
        <source>Strong verification of signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="255"/>
        <source>PDF Specification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">システム</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">言語</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">[可視]が有効にされた部品の強調色</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">[必須]が有効にされた部品の強調色</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">自動で Master PDF Editor のアップデートを確認：</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">毎週</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">毎月</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Never</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation type="obsolete">移動またはリサイズを開始するまでの時間</translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation type="obsolete">テキストと画像を滑らかに表示する</translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation type="obsolete">マウスポインタ直下のドキュメントを強調表示する</translation>
    </message>
    <message>
        <source>Open saved file with the default viewer after saving</source>
        <translation type="obsolete">保存後、標準のビューワで開く</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">操作に用いる言語を選択して下さい。</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="obsolete">変更を反映するには、プログラムを再起動する必要があります。</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="obsolete">更新</translation>
    </message>
    <message>
        <source>Save PDF file in PDF/A mode.</source>
        <translation type="obsolete">PDFをPDF/Aモードで保存する</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">参照...</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">スタイル</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">削除</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="139"/>
        <source>File</source>
        <translation>ファイル</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Open</source>
        <translation>PDFを新規作成</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="159"/>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <source>New</source>
        <translation>PDFを開く</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Save</source>
        <translation>上書き保存</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Save As...</source>
        <translation>名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="896"/>
        <source>Print</source>
        <translation>印刷</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2432"/>
        <source>Recent Files</source>
        <translation>最近使用したファイル</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="743"/>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Exit</source>
        <translation>終了</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Cut</source>
        <translation>切り取り</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Copy</source>
        <translation>コピー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="938"/>
        <source>Paste</source>
        <translation>貼り付け</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Select All</source>
        <translation>すべて選択</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>First Page</source>
        <translation>最初のページへ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Previous Page</source>
        <translation>前のページへ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Next Page</source>
        <translation>次のページへ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Last Page</source>
        <translation>最後のページへ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="207"/>
        <source>Zoom</source>
        <translation>ズーム</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="604"/>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <source>Zoom In</source>
        <translation>ズームイン</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Zoom Out</source>
        <translation>ズームアウト</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Actual Size</source>
        <translation>実サイズ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="291"/>
        <source>Toolbars</source>
        <translation>ツールバー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <source>Statusbar</source>
        <translation>ステータスバーを表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="289"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <source>Tools</source>
        <translation>ツール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>Hand Tool</source>
        <translation>手のひらツール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Register...</source>
        <translation>登録情報</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">アップデートの確認</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <location filename="../../src/mainwindow.ui" line="771"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>サムネイルを拡大</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Reduce Page Thumbnails</source>
        <translation>サムネイルを縮小</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">外部PDFからページを挿入...</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">ページをPDFとして抽出...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Highlight Fields</source>
        <translation>全ての部品を強調</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <location filename="../../src/mainwindow.cpp" line="5944"/>
        <source>Text</source>
        <translation>テキスト</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1127"/>
        <source>Properties</source>
        <translation>文書のプロパティ</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">通常書体</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">イタリック</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">太字</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">太字斜体</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2003"/>
        <source>Bookmarks</source>
        <translation>ブックマーク</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1161"/>
        <source>Highlight Text</source>
        <translation>テキストを強調表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <source>Underline Text</source>
        <translation>テキストに下線</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1169"/>
        <source>Strikeout Text</source>
        <translation>テキストに取消線</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2011"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="71"/>
        <source>Attachment</source>
        <translation>添付ファイル</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>Check box</source>
        <translation>チェックボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1278"/>
        <source>Radio button</source>
        <translation>ラジオボタン</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <location filename="../../src/mainwindow.ui" line="1302"/>
        <source>Button</source>
        <translation>プッシュボタン</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>List box</source>
        <translation>リストボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1286"/>
        <source>Combo box</source>
        <translation>コンボボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Edit Box</source>
        <translation>テキスト領域</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>Document</source>
        <translation>文書</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2802"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>閉じる前に%sへの変更を保存しますか？</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="279"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="58"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">ヘルプ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2619"/>
        <source>Cannot open file :
</source>
        <translation>ファイルが開けません。ファイルが見つかりませんでした。</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="203"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <source>View</source>
        <translation>表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">利用可能な更新はありません。</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Edit Document</source>
        <translation>ドキュメント編集</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1242"/>
        <source>Link</source>
        <translation>リンク</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="426"/>
        <location filename="../../src/mainwindow.ui" line="1386"/>
        <source>Comments</source>
        <translation>コメント</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>Add Sticky Note</source>
        <translation>付箋を追加</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">付箋を追加</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <location filename="../../src/mainwindow.cpp" line="5976"/>
        <source>Image</source>
        <translation>画像</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="590"/>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="709"/>
        <source>There was an error opening the document !</source>
        <translation>文書を開く途中でエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1075"/>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <source>Page layout</source>
        <translation>ページ設定</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">空白ページを挿入</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">空白ページを挿入</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">ページを削除</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1995"/>
        <source>Pages</source>
        <translation>ページ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Undo</source>
        <translation>元に戻す</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Redo</source>
        <translation>先へ進む</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="880"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Create a new blank PDF</source>
        <translation>空白PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="505"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="732"/>
        <location filename="../../src/mainwindow.ui" line="735"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1191"/>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <source>Send to Back</source>
        <translation>背面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">前面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_mac_tool_bars.cpp" line="20"/>
        <source>Main</source>
        <translation>メイン</translation>
    </message>
    <message>
        <source>Font attributes</source>
        <translation type="obsolete">フォント設定</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Images</source>
        <translation>画像として出力</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1325"/>
        <source>Home page</source>
        <translation>ホームページ</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="vanished">本製品について...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Ctrl++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="635"/>
        <source>Ctrl+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="796"/>
        <source>Alt+1</source>
        <translation></translation>
    </message>
    <message>
        <source>Suggestions...</source>
        <translation type="vanished">提案を投稿...</translation>
    </message>
    <message>
        <source>Suggestions</source>
        <translation type="vanished">提案を投稿</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Select Text</source>
        <translation>テキスト選択</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Alt+3</source>
        <translation></translation>
    </message>
    <message>
        <source>Form Fields</source>
        <translation type="vanished">フォーム部品</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>HTML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2618"/>
        <source>Open failed</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="232"/>
        <source>Empty recent files list</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1081"/>
        <location filename="../../src/mainwindow.cpp" line="1212"/>
        <location filename="../../src/mainwindow.cpp" line="3025"/>
        <location filename="../../src/mainwindow.cpp" line="4331"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <location filename="../../src/mainwindow.cpp" line="4569"/>
        <source>Save failed</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>Can&apos;t save to the file:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6062"/>
        <location filename="../../src/mainwindow.cpp" line="6064"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>Open File</source>
        <translation></translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="vanished">全ての形式 (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</translation>
    </message>
    <message>
        <source>Enlarge selected text</source>
        <translation type="obsolete">選択されたテキストを拡大</translation>
    </message>
    <message>
        <source>Reduce selected text</source>
        <translation type="obsolete">選択されたテキストを縮小</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">文書のプロパティ</translation>
    </message>
    <message>
        <source>Font Attributes</source>
        <translation type="obsolete">フォント設定</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Contents</source>
        <translation>オンラインマニュアル</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>Find</source>
        <translation>検索</translation>
    </message>
    <message>
        <source>Find Next (F3)</source>
        <translation type="vanished">次を検索 (F3)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Find Next</source>
        <translation>次を検索</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="57"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>新しいバージョンを利用可能です！
今すぐダウンロードしますか？</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation type="obsolete">破棄</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2813"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>Close Without Saving</source>
        <translation>破棄</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Ctrl+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <location filename="../../src/mainwindow.ui" line="1089"/>
        <source>Rotate Pages</source>
        <translation>ページを回転</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Move Pages</source>
        <translation>ページを移動</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1930"/>
        <source>Alt+4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Edit Text</source>
        <translation>テキストの修正</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="vanished">文書情報</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="237"/>
        <location filename="../../src/mainwindow.ui" line="2019"/>
        <source>Search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Object Inspector</source>
        <translation>オブジェクト インスペクタ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1117"/>
        <location filename="../../src/mainwindow.cpp" line="7130"/>
        <location filename="../../src/mainwindow.cpp" line="7192"/>
        <location filename="../../src/mainwindow.cpp" line="7341"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>Align Objects</source>
        <translation type="unfinished">配置</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1210"/>
        <location filename="../../src/mainwindow.ui" line="1213"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <location filename="../../src/mainwindow.ui" line="1705"/>
        <source>Line</source>
        <translation>直線</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1218"/>
        <location filename="../../src/mainwindow.ui" line="1221"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <location filename="../../src/mainwindow.ui" line="1727"/>
        <source>Rectangle</source>
        <translation>四角形</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1226"/>
        <location filename="../../src/mainwindow.ui" line="1229"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Ellipse</source>
        <translation>楕円</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">印刷プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Left</source>
        <translation type="unfinished">左寄せ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>Align Right</source>
        <translation type="unfinished">右へ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1048"/>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Align Top</source>
        <translation type="unfinished">上詰め</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Align Bottom</source>
        <translation type="unfinished">下詰め</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1307"/>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Signature</source>
        <translation type="unfinished">署名</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation type="obsolete">開きますか？</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <location filename="../../src/mainwindow.ui" line="966"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3066"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished">署名検証中にエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Forms</source>
        <translation type="unfinished">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="510"/>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <source>About</source>
        <translation>本製品について...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Home</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>End</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>Reset Forms</source>
        <translation type="unfinished">フォームを初期化</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Fit Width</source>
        <translation type="unfinished">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="757"/>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Facing Pages</source>
        <translation type="unfinished">見開き表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Delete Pages</source>
        <translation>ページを削除</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Edit Forms</source>
        <translation type="unfinished">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <source>Bring to Front</source>
        <translation>前面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a Blank Pages</source>
        <translation type="vanished">空白ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1097"/>
        <location filename="../../src/mainwindow.ui" line="1100"/>
        <source>Extract Pages...</source>
        <translation>複数ページを抽出</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1108"/>
        <location filename="../../src/mainwindow.ui" line="1111"/>
        <source>Insert Pages...</source>
        <translation>複数ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <location filename="../../src/mainwindow.ui" line="1237"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <location filename="../../src/mainwindow.ui" line="1749"/>
        <source>Pencil</source>
        <translation>鉛筆</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1159"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>PgUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>PgDown</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1262"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="vanished">オブジェクト インスペクタ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation type="unfinished">ページをクロップ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1906"/>
        <source>Alt+5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="649"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>Ctrl+Shift+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Ctrl+F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1056"/>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <source>Insert Blank Pages</source>
        <translation>空白ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <source>Alt+2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1410"/>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">時計回り</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1418"/>
        <location filename="../../src/mainwindow.ui" line="1421"/>
        <location filename="../../src/mainwindow.ui" line="1424"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">反時計回り</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7139"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7201"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <source>Export Form Data...</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1434"/>
        <source>Import Form Data...</source>
        <translation type="unfinished">インポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1439"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1444"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished">インポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="544"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="167"/>
        <source>Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="245"/>
        <source>Navigation Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="710"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="793"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="810"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="916"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="930"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1449"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished">最適化して保存</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5939"/>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5941"/>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5950"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5959"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5967"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5972"/>
        <location filename="../../src/mainwindow.cpp" line="6196"/>
        <source>Width</source>
        <translation type="unfinished">幅</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5973"/>
        <location filename="../../src/mainwindow.cpp" line="6197"/>
        <source>Height</source>
        <translation type="unfinished">高さ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5974"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5980"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5984"/>
        <source>Shading</source>
        <translation type="unfinished">シェーディング</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="1946"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6224"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6005"/>
        <location filename="../../src/mainwindow.cpp" line="6211"/>
        <source>Selected</source>
        <translation type="unfinished">選択</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1463"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1620"/>
        <location filename="../../src/mainwindow.cpp" line="1647"/>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5943"/>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="624"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1476"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1481"/>
        <source>Document Actions</source>
        <translation type="unfinished">文書のアクション</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished">白黒反転表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Paste to Multiple Pages</source>
        <translation type="unfinished">複数ページに貼り付ける</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2069"/>
        <location filename="../../src/mainwindow.ui" line="2072"/>
        <source>Paste at Copy Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2075"/>
        <source>Ctrl+Shift+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>JavaScript Console</source>
        <translation type="unfinished">JavaScriptコンソール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>Page Properties</source>
        <translation type="unfinished">ページのプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1521"/>
        <source>Ctrl+Shift+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="376"/>
        <source>Watermark</source>
        <translation type="unfinished">透かし</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Background</source>
        <translation type="unfinished">背景</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="430"/>
        <source>Measurements</source>
        <translation type="unfinished">計測</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <location filename="../../src/mainwindow.cpp" line="3180"/>
        <source>Drawing</source>
        <translation type="unfinished">描画</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Ctrl+Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1537"/>
        <source>Menu Bar</source>
        <translation type="unfinished">メニューバー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1540"/>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>Show Cover Page During Facing</source>
        <translation type="unfinished">見開き時に表紙を単独表示する</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Full Screen</source>
        <translation type="unfinished">全画面表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1559"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1590"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">水平距離</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <source>Find Previous</source>
        <translation type="unfinished">前を検索</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1619"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <location filename="../../src/mainwindow.ui" line="1644"/>
        <source>Grid</source>
        <translation type="unfinished">グリッド</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1647"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Snap to Grid</source>
        <translation type="unfinished">移動をグリッド単位に制限する</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1661"/>
        <source>Ctrl+Shift+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <location filename="../../src/mainwindow.ui" line="1672"/>
        <source>Distance Tool</source>
        <translation type="unfinished">距離測定ツール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <location filename="../../src/mainwindow.ui" line="1683"/>
        <source>Perimeter Tool</source>
        <translation type="unfinished">外周測定ツール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <location filename="../../src/mainwindow.ui" line="1694"/>
        <source>Area Tool</source>
        <translation type="unfinished">面積測定ツール</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <location filename="../../src/mainwindow.ui" line="1716"/>
        <source>Arrow</source>
        <translation type="unfinished">矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <location filename="../../src/mainwindow.ui" line="1760"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished">ファイルをコメントとして添付する</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1987"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2027"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2035"/>
        <source>Layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2043"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2051"/>
        <source>Document Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2056"/>
        <source>Organize Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2064"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2080"/>
        <source>Pages to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2088"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2096"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2101"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2104"/>
        <source>Manage Header And Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2109"/>
        <source>Add To Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2114"/>
        <source>Open session from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2119"/>
        <source>Save session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2124"/>
        <source>Managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2129"/>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2134"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2139"/>
        <source>Clear recent sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2144"/>
        <source>Save session to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2149"/>
        <source>Current Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2154"/>
        <source>Save session to managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2159"/>
        <source>Save and close current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2164"/>
        <source>Delete across pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3606"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Blank PDF</source>
        <translation type="unfinished">空白PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <source>From Scanner</source>
        <translation type="unfinished">スキャナ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <location filename="../../src/mainwindow.ui" line="1771"/>
        <source>Create a new document from scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <source>From Files</source>
        <translation type="unfinished">既存PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <location filename="../../src/mainwindow.ui" line="1782"/>
        <source>Create a new document from files</source>
        <translation type="unfinished">既存PDF</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">スタンプ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <location filename="../../src/mainwindow.ui" line="1801"/>
        <source>Brush</source>
        <translation type="unfinished">ブラシ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="367"/>
        <source>Header and Footer</source>
        <translation type="unfinished">ヘッダーとフッター</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>Check Box</source>
        <translation type="unfinished">チェックボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Radio Button</source>
        <translation type="unfinished">ラジオボタン</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Combo Box</source>
        <translation type="unfinished">コンボボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <source>List Box</source>
        <translation type="unfinished">リストボックス</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Text Field</source>
        <translation type="unfinished">テキストフィールド</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Menu</source>
        <translation type="unfinished">メニューバー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1820"/>
        <source>F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5938"/>
        <source>Characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="215"/>
        <source>Page Display</source>
        <translation type="unfinished">ページレイアウト</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Go To</source>
        <translation type="unfinished">移動</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1721"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>変更を反映するには、プログラムを再起動する必要があります。</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1633"/>
        <source>Send file via email</source>
        <translation type="unfinished">Email でファイルを送信</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Callout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1835"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Default</source>
        <translation type="unfinished">標準</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <location filename="../../src/mainwindow.ui" line="1877"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Alt+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <source>Alt+7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <source>Check for Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Mark for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1851"/>
        <source>Apply Redactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1856"/>
        <source>Redaction Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1864"/>
        <source>Show Redaction ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1869"/>
        <source>Search and Redact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1882"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1887"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1892"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1900"/>
        <source>Edit Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1911"/>
        <source>Next View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1916"/>
        <source>Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1924"/>
        <source>Edit Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1935"/>
        <location filename="../../src/mainwindow.cpp" line="3307"/>
        <source>Show Comments List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="462"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="464"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="477"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1043"/>
        <source>File is opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1045"/>
        <source>Use Save As... to save your work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2897"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3147"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="100"/>
        <source>All Reviewers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3285"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="80"/>
        <source>Hide All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3290"/>
        <source>Show All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3592"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3627"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3634"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5319"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6199"/>
        <source>Format</source>
        <translation type="unfinished">書式</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6900"/>
        <source>Failed to restore last open session:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7437"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7438"/>
        <source>Document doesn&apos;t contain any tables with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="79"/>
        <source>Comment View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="93"/>
        <source>Show by Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3171"/>
        <source>All Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3176"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3184"/>
        <source>Text Editing Markups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3188"/>
        <source>Stamps</source>
        <translation type="unfinished">スタンプ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3192"/>
        <source>Attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="97"/>
        <source>Show by Reviewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="107"/>
        <source>Show by Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3217"/>
        <source>All Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3222"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete">表示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="45"/>
        <source>You already have the latest version!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3303"/>
        <source>Hide Comments List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>File is locked by another Master PDF Editor instance, it will be opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="433"/>
        <source>You will be able to save your work, but only to another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="616"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="635"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="617"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="636"/>
        <source>Create New Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="619"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="638"/>
        <source>Open Containing Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>System Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="913"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1130"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="149"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Pages to Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Pages to Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1951"/>
        <source>Extract all Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1434"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1956"/>
        <source>Reload</source>
        <translation type="unfinished">リロード</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1964"/>
        <source>Take a Snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="249"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="254"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="259"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="264"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="63"/>
        <source>What&apos;s new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="551"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>This document cannot be found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1672"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="26"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1969"/>
        <source>Toolbar Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Email 配信</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="obsolete">背面へ移動</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">テキストを挿入</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">付箋</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="obsolete">単ページ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1977"/>
        <source>Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <source>Insert Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5159"/>
        <location filename="../../src/mainwindow.cpp" line="5181"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="302"/>
        <source>Reset toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Minimum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="61"/>
        <source>New Paragraph</source>
        <translation type="unfinished">新規段落</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="114"/>
        <source>Delete All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="116"/>
        <source>Delete All Visible Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="299"/>
        <source>Maximum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="82"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="250"/>
        <location filename="../../src/mainwindow_update.cpp" line="357"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="252"/>
        <location filename="../../src/mainwindow_update.cpp" line="359"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="297"/>
        <source>License is expired!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="71"/>
        <location filename="../../src/mainwindow_update.cpp" line="300"/>
        <location filename="../../src/mainwindow_update.cpp" line="504"/>
        <source>Renew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="68"/>
        <source>WARNING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="338"/>
        <source>Too many activations!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="394"/>
        <source>Server connection lost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="445"/>
        <source>Failed to connect to License server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="516"/>
        <source>Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6222"/>
        <source>Rotate</source>
        <translation type="unfinished">回転</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="54"/>
        <source>Check Mark</source>
        <translation type="unfinished">チェックマーク</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="55"/>
        <source>Circle</source>
        <translation type="unfinished">円</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="56"/>
        <source>Comment</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="57"/>
        <source>Cross</source>
        <translation type="unfinished">交差</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="60"/>
        <source>Key</source>
        <translation type="unfinished">キー</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="62"/>
        <source>Text Note</source>
        <translation type="unfinished">テキストノート</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="63"/>
        <source>Paragraph</source>
        <translation type="unfinished">段落</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Right Arrow</source>
        <translation type="unfinished">右矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="65"/>
        <source>Right Pointer</source>
        <translation type="unfinished">右ポインタ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="66"/>
        <source>Star</source>
        <translation type="unfinished">星</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="67"/>
        <source>Up Arrow</source>
        <translation type="unfinished">上矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="68"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">左上矢印</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="69"/>
        <source>Graph</source>
        <translation type="unfinished">グラフ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="70"/>
        <source>Paper Clip</source>
        <translation type="unfinished">ペーパークリップ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="72"/>
        <source>Tag</source>
        <translation type="unfinished">タグ</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1982"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="62"/>
        <source>Failed opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="67"/>
        <source>File is already opened and opening same file in multiple tabs option is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="72"/>
        <source>File does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="319"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="323"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>Current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="376"/>
        <source>Error loading session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="20"/>
        <source>Zoom Out</source>
        <translation type="unfinished">ズームアウト</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="27"/>
        <source>Close</source>
        <translation type="unfinished">閉じる</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="34"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="41"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="48"/>
        <source>Zoom In</source>
        <translation type="unfinished">ズームイン</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="65"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="72"/>
        <source>Zoom Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="79"/>
        <source>Show</source>
        <translation type="unfinished">表示</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="14"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="82"/>
        <source>Manage Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="113"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="117"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="510"/>
        <source>Header and Footer</source>
        <translation type="unfinished">ヘッダーとフッター</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="119"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="513"/>
        <source>Bates Numbering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="263"/>
        <source>All Pages</source>
        <translation type="unfinished">全てのページ</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="516"/>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="517"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="518"/>
        <source>Page Range</source>
        <translation type="unfinished">ページ範囲</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="519"/>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Center</source>
        <translation type="unfinished">中央</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="525"/>
        <source>Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="635"/>
        <source>Remove Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="639"/>
        <source>Do you want to remove selected Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="643"/>
        <source>Do you want to remove selected headers/footers from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="657"/>
        <source>Remove all Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="658"/>
        <source>Do you want to remove all headers, footers and Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation type="unfinished">認証されたテキスト</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation type="unfinished">オリジナル</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="25"/>
        <source>Not Text</source>
        <translation type="unfinished">テキストではない</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation type="unfinished">ページを移動</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">-：</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="43"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="55"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="65"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>First</source>
        <translation type="unfinished">最初</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="121"/>
        <source>Last</source>
        <translation type="unfinished">最後</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Move Pages</source>
        <translation type="vanished">ページを移動</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">-：</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">ページ指定</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>ページサイズ</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="49"/>
        <source>Width</source>
        <translation>幅</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="86"/>
        <source>Height</source>
        <translation>高さ</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="vanished">カスタムサイズ</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>Portrait</source>
        <translation>縦</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>Landscape</source>
        <translation>横</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="151"/>
        <source>Contents Size</source>
        <translation>余白</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>Left margin</source>
        <translation>左余白</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="203"/>
        <source>Top margin</source>
        <translation>上余白</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="183"/>
        <source>Right margin</source>
        <translation>右余白</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Bottom margin</source>
        <translation>下余白</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="246"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="252"/>
        <source>Before current page</source>
        <translation>現在のページの前</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="269"/>
        <source>After current page</source>
        <translation>現在のページの後</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="276"/>
        <source>After last page</source>
        <translation>最終ページの後</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="262"/>
        <source>Before first page</source>
        <translation>第1ページの前</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="286"/>
        <source>Number of pages</source>
        <translation>ページ数</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="312"/>
        <source>Page(s)</source>
        <translation>ページ(s)</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="292"/>
        <source>Create</source>
        <translation>作成</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="122"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation type="unfinished">OCR エンジン</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="164"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="43"/>
        <source>Languages</source>
        <translation type="unfinished">言語</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="49"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="194"/>
        <source>Selected</source>
        <translation type="unfinished">選択</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="36"/>
        <source>Install languages</source>
        <translation type="unfinished">インストール言語</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="108"/>
        <source>Searchable Text</source>
        <translation type="unfinished">検索可能なテキスト</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Editable Text</source>
        <translation type="unfinished">編集可能なテキスト</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="138"/>
        <source>Font Family</source>
        <translation type="unfinished">フォントファミリー</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="obsolete">認識されたすべてのテキストを手動で編集</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="obsolete">自動</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="201"/>
        <source>Force manual text editing if confidence level not achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="171"/>
        <source>Minimal confidence level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">直線</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="224"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="258"/>
        <source>Helvetica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation type="unfinished">キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="68"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation type="unfinished">文書認識を停止しますか？</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="65"/>
        <source>No Properties
There is no object selections.</source>
        <translation>属性はありません。オブジェクトが選択されていません。</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="223"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3778"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4059"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2379"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="288"/>
        <source>Property</source>
        <translation type="unfinished">プロパティ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="293"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1597"/>
        <source>Value</source>
        <translation type="unfinished">値</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3153"/>
        <source>Top</source>
        <translation type="unfinished">上</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2434"/>
        <source>Font Family</source>
        <translation type="unfinished">フォントファミリー</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3790"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2479"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4079"/>
        <source>Type</source>
        <translation type="unfinished">タイプ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3725"/>
        <source>Fill Color</source>
        <translation>塗りつぶし：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2541"/>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3578"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3639"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4029"/>
        <source>Opacity</source>
        <translation type="unfinished">不透明度</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2408"/>
        <source>Image</source>
        <translation type="unfinished">画像</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3163"/>
        <source>Width</source>
        <translation type="unfinished">幅</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2819"/>
        <source>Height</source>
        <translation type="unfinished">高さ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2431"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3934"/>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3857"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">太字</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">イタリック</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1892"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1943"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3674"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="546"/>
        <source>Goto a Page View</source>
        <translation type="unfinished">ページビューに移る</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="551"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="556"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Reset form</source>
        <translation type="unfinished">フォームをリセットする</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="566"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished">フィールドを表示する/隠す</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="571"/>
        <source>Submit a form</source>
        <translation type="unfinished">フォームを送信する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="576"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished">JavaScript を実行する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="478"/>
        <source>Add an Action</source>
        <translation type="unfinished">アクションを追加</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="484"/>
        <source>Trigger</source>
        <translation type="unfinished">トリガー</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="492"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="497"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="502"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="507"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="512"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="517"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="538"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="590"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="918"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="600"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3341"/>
        <source>Actions</source>
        <translation type="unfinished">動作</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1677"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2269"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3460"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="905"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="695"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="849"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1821"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1976"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="371"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="854"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="864"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Invert</source>
        <translation type="unfinished">反転</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="898"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="931"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1206"/>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="771"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="973"/>
        <source>Up</source>
        <translation type="unfinished">上へ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="776"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="957"/>
        <source>Down</source>
        <translation type="unfinished">下へ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1001"/>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="980"/>
        <source>Commit selected value immediately</source>
        <translation type="unfinished">選択した値を確定する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="994"/>
        <source>Multiple selection</source>
        <translation type="unfinished">複数選択</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="987"/>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished">カスタムテキストの入力を許可</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1126"/>
        <source>Password</source>
        <translation type="unfinished">パスワード</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1133"/>
        <source>Scrollable</source>
        <translation type="unfinished">スクロール可能</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1140"/>
        <source>Check spelling</source>
        <translation type="unfinished">スペルチェック</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1061"/>
        <source>Limit to</source>
        <translation type="unfinished">制限する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1075"/>
        <source>chars</source>
        <translation type="unfinished">文字</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1082"/>
        <source>Split into</source>
        <translation type="unfinished">分割する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1054"/>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished">リッチテキスト形式を許可する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Multi-line</source>
        <translation type="unfinished">マルチライン</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <source>cells</source>
        <translation type="unfinished">セル</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1041"/>
        <source>Center</source>
        <translation type="unfinished">中央</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1046"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>Default Value</source>
        <translation type="unfinished">初期値</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Alignment</source>
        <translation type="unfinished">アラインメント</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1219"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <source>Style</source>
        <translation type="unfinished">スタイル</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1230"/>
        <source>Check</source>
        <translation type="unfinished">チェック</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1235"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="347"/>
        <source>Circle</source>
        <translation type="unfinished">円</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1240"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="349"/>
        <source>Cross</source>
        <translation type="unfinished">交差</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Diamond</source>
        <translation type="unfinished">ダイヤモンド</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1250"/>
        <source>Square</source>
        <translation type="unfinished">四角</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1255"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="358"/>
        <source>Star</source>
        <translation type="unfinished">星</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1183"/>
        <source>Checked by Default</source>
        <translation type="unfinished">標準でチェック済み</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3768"/>
        <source>Line Thickness</source>
        <translation>線幅：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1386"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3718"/>
        <source>Border Color</source>
        <translation>線の色：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3761"/>
        <source>Line Style</source>
        <translation>線の種類：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3733"/>
        <source>Solid</source>
        <translation type="unfinished">実線</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1406"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3738"/>
        <source>Dashed</source>
        <translation type="unfinished">破線</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3753"/>
        <source>Underline</source>
        <translation type="unfinished">下線</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Highlight</source>
        <translation type="unfinished">ハイライト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>OutLine</source>
        <translation type="unfinished">アウトライン</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Insert</source>
        <translation type="unfinished">挿入</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1463"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3360"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3479"/>
        <source>Format</source>
        <translation type="unfinished">書式</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Format category</source>
        <translation type="unfinished">書式カテゴリ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1826"/>
        <source>Number</source>
        <translation type="unfinished">番号</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1831"/>
        <source>Percentage</source>
        <translation type="unfinished">パーセント</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1836"/>
        <source>Date</source>
        <translation type="unfinished">年月日</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1841"/>
        <source>Time</source>
        <translation type="unfinished">時間</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1846"/>
        <source>Special</source>
        <translation type="unfinished">特別</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1851"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2006"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="333"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="337"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1870"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="131"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1875"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="136"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1557"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1885"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1890"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1895"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1572"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1577"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1905"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1910"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1915"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1920"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1929"/>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1934"/>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1939"/>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1944"/>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Currency Symbol</source>
        <translation type="unfinished">通貨記号</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1981"/>
        <source>Dollar ($)</source>
        <translation type="unfinished">ドル ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1986"/>
        <source>Euro (€)</source>
        <translation type="unfinished">ユーロ (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <source>Pound (£)</source>
        <translation type="unfinished">ポンド (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1996"/>
        <source>Yen (¥)</source>
        <translation type="unfinished">円 (¥)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Show parentheses</source>
        <translation type="unfinished">括弧を表示する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2047"/>
        <source>Decimal Places</source>
        <translation type="unfinished">少数単位</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2054"/>
        <source>Separation Style</source>
        <translation type="unfinished">分割スタイル</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>Use red text</source>
        <translation type="unfinished">赤字を使用</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Date Options</source>
        <translation type="unfinished">年月日オプション</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>Time Options</source>
        <translation type="unfinished">時間オプション</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2150"/>
        <source>Special Options</source>
        <translation type="unfinished">特別オプション</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Format Script</source>
        <translation type="unfinished">書式スクリプト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2242"/>
        <source>KeyStroke Script</source>
        <translation type="unfinished">キーストロークスクリプト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>Validate</source>
        <translation type="unfinished">検証</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Validation Script</source>
        <translation type="unfinished">検証スクリプト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2349"/>
        <source>Calculate</source>
        <translation type="unfinished">計算する</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2370"/>
        <source>Calculation Script</source>
        <translation type="unfinished">計算スクリプト</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Fill text</source>
        <translation type="unfinished">テキストを塗りつぶす</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2504"/>
        <source>Stroke Text</source>
        <translation type="unfinished">テキストを打ち込む</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Fill and Stroke</source>
        <translation type="unfinished">塗りつぶしと打ち込み</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Invisible</source>
        <translation type="unfinished">目に見えない</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2554"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3626"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4016"/>
        <source>Line Width</source>
        <translation type="unfinished">線の幅</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Character spacing</source>
        <translation type="unfinished">テキスト間隔</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Word spacing</source>
        <translation type="unfinished">単語の間隔</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2597"/>
        <source>Line spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2758"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2768"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2778"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2788"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2885"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2910"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2935"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2960"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2998"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3017"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2901"/>
        <source>Align Top</source>
        <translation type="unfinished">上詰め</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Align Right</source>
        <translation type="unfinished">右へ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <source>Align Left</source>
        <translation type="unfinished">左寄せ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">水平距離</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2995"/>
        <source>Align Bottom</source>
        <translation type="unfinished">下詰め</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <source>Send To Back</source>
        <translation type="unfinished">背面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3033"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3052"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3071"/>
        <source>Bring To Front</source>
        <translation type="unfinished">前面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3143"/>
        <source>Coordinates</source>
        <translation type="unfinished">座標</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3094"/>
        <source>Absolute</source>
        <translation type="unfinished">絶対</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3099"/>
        <source>Relative</source>
        <translation type="unfinished">相対</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3189"/>
        <source>Geometry</source>
        <translation type="unfinished">幾何</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3208"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3832"/>
        <source>Font</source>
        <translation type="unfinished">フォント</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3246"/>
        <source>Matrix</source>
        <translation type="unfinished">マトリクス</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>General</source>
        <translation type="unfinished">基本</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3303"/>
        <source>Appearance</source>
        <translation type="unfinished">外観</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3379"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3553"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3601"/>
        <source>Stroke</source>
        <translation type="unfinished">ストローク</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3591"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3613"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3819"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4042"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3693"/>
        <source>Borders and Colors</source>
        <translation type="unfinished">線の種類および色</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3700"/>
        <source>Thin</source>
        <translation type="unfinished">細</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3705"/>
        <source>Medium</source>
        <translation type="unfinished">中</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3710"/>
        <source>Thick</source>
        <translation type="unfinished">太</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3743"/>
        <source>Beveled</source>
        <translation type="unfinished">面取りした</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3748"/>
        <source>Inset</source>
        <translation type="unfinished">インセット</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3803"/>
        <source>Auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3867"/>
        <source>ToolTip</source>
        <translation type="unfinished">ツールチップ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3883"/>
        <source>Orientation</source>
        <translation>標定</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3891"/>
        <source>0 Degrees</source>
        <translation type="unfinished">0 度</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3896"/>
        <source>90 Degrees</source>
        <translation type="unfinished">90 度</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3901"/>
        <source>180 Degrees</source>
        <translation type="unfinished">180 度</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3906"/>
        <source>270 Degrees</source>
        <translation type="unfinished">270 度</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3927"/>
        <source>Read Only</source>
        <translation type="unfinished">読み取り専用</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3942"/>
        <source>Visible</source>
        <translation type="unfinished">可視</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3947"/>
        <source>Hidden</source>
        <translation type="unfinished">隠れた</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3952"/>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3957"/>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3965"/>
        <source>Required</source>
        <translation type="unfinished">必須</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4109"/>
        <source>Locked</source>
        <translation type="unfinished">ロック</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1880"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1887"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1900"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1907"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1955"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1961"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2454"/>
        <source>Shading</source>
        <translation type="unfinished">シェーディング</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="obsolete">画像フォーム</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4052"/>
        <source>Subject</source>
        <translation type="unfinished">タイトル：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4089"/>
        <source>Author</source>
        <translation type="unfinished">作成者：</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">アスペクト比を維持</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code</source>
        <translation type="unfinished">郵便番号</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code+4</source>
        <translation type="unfinished">郵便番号+4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Phone Number</source>
        <translation type="unfinished">電話番号</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Social Security Number</source>
        <translation type="unfinished">社会保障番号</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="346"/>
        <source>Check Mark</source>
        <translation type="unfinished">チェックマーク</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="348"/>
        <source>Comment</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="350"/>
        <source>Help</source>
        <translation type="unfinished">ヘルプ</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">テキストを挿入</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="352"/>
        <source>Key</source>
        <translation type="unfinished">キー</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="353"/>
        <source>New Paragraph</source>
        <translation type="unfinished">新規段落</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="354"/>
        <source>Text Note</source>
        <translation type="unfinished">テキストノート</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="355"/>
        <source>Paragraph</source>
        <translation type="unfinished">段落</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="356"/>
        <source>Right Arrow</source>
        <translation type="unfinished">右矢印</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="357"/>
        <source>Right Pointer</source>
        <translation type="unfinished">右ポインタ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="359"/>
        <source>Up Arrow</source>
        <translation type="unfinished">上矢印</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="360"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">左上矢印</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="361"/>
        <source>Graph</source>
        <translation type="unfinished">グラフ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="362"/>
        <source>Paper Clip</source>
        <translation type="unfinished">ペーパークリップ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="363"/>
        <source>Attachment</source>
        <translation type="unfinished">添付ファイル</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="364"/>
        <source>Tag</source>
        <translation type="unfinished">タグ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Rotate</source>
        <translation type="unfinished">回転</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3548"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3566"/>
        <source>Fill</source>
        <translation type="unfinished">塗りつぶし</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation type="obsolete">線の高さ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2659"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3398"/>
        <source>Selection change</source>
        <translation type="unfinished">選択の変更</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3426"/>
        <source>Do nothing</source>
        <translation type="unfinished">何もしない</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3433"/>
        <source>Execute this script</source>
        <translation type="unfinished">スクリプトを実行</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2146"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4359"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2151"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4379"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4399"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="obsolete">透かし</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">背景</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">ヘッダーとフッター</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3265"/>
        <source>Clipping Path</source>
        <translation type="unfinished">クリッピングパス</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2855"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2860"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2865"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="702"/>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Label only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Icon only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="723"/>
        <source>Icon top, label bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <source>Label top, icon bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Icon left, label right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>label left, icon right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Label over icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="758"/>
        <source>Icon and Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>Rollover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="798"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="805"/>
        <source>Choose Icon...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="828"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished">全ての形式 (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="751"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4102"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2001"/>
        <source>Ruble (₽)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3498"/>
        <source>Settings</source>
        <translation type="unfinished">設定</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4127"/>
        <source>Always show Object Inspector</source>
        <translation type="unfinished">オブジェクトインスペクターを常時表示</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="175"/>
        <source>Object Inspector</source>
        <translation type="unfinished">オブジェクト インスペクタ</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1501"/>
        <source>QRCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1506"/>
        <source>DataMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1517"/>
        <source>Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>ECC Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>X Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1590"/>
        <source>X/Y Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Include field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1637"/>
        <source>Pick...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1689"/>
        <source>Encode using Tab Delmited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1694"/>
        <source>Encode using XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1699"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="285"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="317"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="373"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="obsolete">幾何</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">表示</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="32"/>
        <source>Expand All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="33"/>
        <source>Collapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="92"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="135"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Images</source>
        <translation type="unfinished">画像として出力</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="108"/>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Shadings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>Containers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Text Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>List Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Combo Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Check Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Radio Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="166"/>
        <source>Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="171"/>
        <source>Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="176"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation type="unfinished">表示</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="270"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="338"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="269"/>
        <source>Comment</source>
        <translation type="unfinished">コメント</translation>
    </message>
</context>
<context>
    <name>OptimizeScannedPagesDlg</name>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="14"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished">ページ範囲</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished">現在のページ</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished">全てのページ</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="95"/>
        <source>Apply Adaptive Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="107"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">カラー画像とグレースケール画像</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="127"/>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="173"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="132"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="153"/>
        <source>Black and White Images</source>
        <translation type="unfinished">白黒画像</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="178"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="183"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="200"/>
        <source>Small Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="229"/>
        <source>High Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="242"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="248"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="255"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation type="unfinished">ツール</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="174"/>
        <source>Please, name new toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">コメント</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">付箋</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">編集</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">元に戻す</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">先へ進む</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="obsolete">前面へ移動</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">切り取り</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">コピー</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">貼り付け</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="obsolete">背面へ移動</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">ファイル</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">印刷</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">検索</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">署名</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">ラジオボタン</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">リストボックス</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">テキストフィールド</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">コンボボックス</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">チェックボックス</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">プッシュボタン</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">鉛筆</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">楕円</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">四角形</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">直線</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">テキストを挿入</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">テキストの修正</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">手のひらツール</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">表示</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="obsolete">ズーム</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">ズームアウト</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">ズームイン</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">ページ全体</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">幅に合わせる</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">メイン</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">名前をつけて保存</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Email 配信</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="obsolete">左寄せ</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="obsolete">右へ</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="obsolete">上詰め</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="obsolete">下詰め</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="obsolete">水平距離</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">グリッド</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">前のページへ</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">次のページへ</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="obsolete">実サイズ</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation type="obsolete">見開き表示</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">反時計回り</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">時計回り</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation type="obsolete">ドキュメント編集</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="obsolete">テキスト選択</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="obsolete">空白ページを挿入</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="obsolete">ページを削除</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="obsolete">ページをクロップ</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation type="obsolete">ページ設定</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation type="obsolete">ページを回転</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="obsolete">複数ページを抽出</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="obsolete">複数ページを挿入</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="obsolete">文書のアクション</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">ページのプロパティ</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">ヘッダーとフッター</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="obsolete">透かし</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">背景</translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="obsolete">文書</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="525"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="557"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="obsolete">ファイルをコメントとして添付する</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="196"/>
        <source>ToolBar with this name already exist.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageCounterWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>ページ設定</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="167"/>
        <source>Scale contents with size change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="203"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">アスペクト比を維持</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="247"/>
        <source>Contents Size</source>
        <translation>余白</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="259"/>
        <source>Left margin</source>
        <translation>左余白</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Top margin</source>
        <translation>上余白</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="293"/>
        <source>Right margin</source>
        <translation>右余白</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="310"/>
        <source>Bottom margin</source>
        <translation>下余白</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="73"/>
        <location filename="../../src/PageLayoutDialog.ui" line="99"/>
        <source>Page Size</source>
        <translation>ページサイズ</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">幅</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">高さ</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">現在のページ</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">全てのページ</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">-：</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="63"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">偶数/奇数ページ</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="obsolete">偶数ページ</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="obsolete">奇数ページ</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="86"/>
        <location filename="../../src/PageLayoutDialog.ui" line="154"/>
        <location filename="../../src/PageLayoutDialog.ui" line="174"/>
        <location filename="../../src/PageLayoutDialog.ui" line="190"/>
        <location filename="../../src/PageLayoutDialog.ui" line="266"/>
        <location filename="../../src/PageLayoutDialog.ui" line="283"/>
        <location filename="../../src/PageLayoutDialog.ui" line="300"/>
        <location filename="../../src/PageLayoutDialog.ui" line="317"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="331"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="336"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="341"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Top</source>
        <translation type="unfinished">上</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="137"/>
        <source>Bottom</source>
        <translation type="unfinished">底</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="147"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="127"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="106"/>
        <source>Orientation</source>
        <translation type="unfinished">標定</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="62"/>
        <source>Portrait</source>
        <translation type="unfinished">縦</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="119"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="63"/>
        <source>Landscape</source>
        <translation type="unfinished">横</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation type="unfinished">ページのプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation type="unfinished">タブオーダー</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation type="unfinished">行の順を使う</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation type="unfinished">列の順を使う</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation type="unfinished">文書構造を使う</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation type="unfinished">未指定</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation type="unfinished">動作</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation type="unfinished">アクションを追加</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation type="unfinished">トリガー</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation type="unfinished">ページビューに移る</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation type="unfinished">フォームをリセットする</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished">フィールドを表示する/隠す</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation type="unfinished">フォームを送信する</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished">JavaScript を実行する</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation type="unfinished">ページを開く</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation type="unfinished">ページを閉じる</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="51"/>
        <source>Current Page</source>
        <translation type="unfinished">現在のページ</translation>
    </message>
</context>
<context>
    <name>PageRangeWidget</name>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="55"/>
        <source>Page Range</source>
        <translation type="unfinished">ページ範囲</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="61"/>
        <source>Current page view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="68"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="117"/>
        <source>Pages</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="78"/>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="127"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="86"/>
        <source>All pages in range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="91"/>
        <source>Even pages</source>
        <translation type="unfinished">偶数ページ</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="96"/>
        <source>Odd pages</source>
        <translation type="unfinished">奇数ページ</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Page Range input is incorrect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation type="unfinished">解像度</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="320"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="339"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="355"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>パスワード：</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>ファイルが保護されています。 文書を開くパスワードを入力してください。</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>パスワードを入力</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation type="unfinished">複数ページに貼り付ける</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation type="unfinished">ページ範囲</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>Style</source>
        <translation type="unfinished">スタイル</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation type="unfinished">フォントファミリー</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation type="unfinished">幅</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="77"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="105"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Open Image</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">印刷プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="634"/>
        <source>Properties</source>
        <translation type="unfinished">文書のプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="778"/>
        <location filename="../../src/printdialog/printdialog.ui" line="860"/>
        <source>Center</source>
        <translation type="unfinished">中央</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="342"/>
        <source>Orientation</source>
        <translation>標定</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="307"/>
        <source>Portrait</source>
        <translation type="unfinished">縦</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="312"/>
        <source>Landscape</source>
        <translation type="unfinished">横</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">ページ指定</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">-：</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation type="unfinished">印刷</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="obsolete">解像度</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="180"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="725"/>
        <source>Actual Size</source>
        <translation type="unfinished">実サイズ</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="obsolete">自動</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <location filename="../../src/printdialog/printdialog.ui" line="369"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="302"/>
        <location filename="../../src/printdialog/printdialog.ui" line="374"/>
        <source>Auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">偶数/奇数ページ</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="obsolete">偶数ページ</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="obsolete">奇数ページ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Document</source>
        <translation type="unfinished">文書</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="751"/>
        <location filename="../../src/printdialog/printdialog.ui" line="880"/>
        <source>Scale</source>
        <translation type="unfinished">縮尺</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="765"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="536"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="20"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="63"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1583"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="577"/>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="707"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="712"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="717"/>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Shrink to printable area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="732"/>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="361"/>
        <source>Duplex Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Long side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Short side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="514"/>
        <source>Poster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="437"/>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="464"/>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="621"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="32"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Print:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="135"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1332"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1708"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1719"/>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="270"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="272"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="561"/>
        <source>Multiple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <source>Overlay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="901"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1106"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="906"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1111"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="911"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="867"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="977"/>
        <source>Pages per sheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="970"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1011"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1016"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1021"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1026"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1031"/>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1036"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1053"/>
        <source>Page order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1061"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1066"/>
        <source>Horizontal Reversed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1071"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1076"/>
        <source>Vertical Reversed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1091"/>
        <source>Additional spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1098"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1084"/>
        <source>Center pages in cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="323"/>
        <source>Page Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="327"/>
        <source>System Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="581"/>
        <source>Printer cannot be selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="240"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="266"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="242"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="268"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="60"/>
        <source>Delete</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source> is already attached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="505"/>
        <source>Replace the file or give it a unique name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="506"/>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="507"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="508"/>
        <source>Cancel</source>
        <translation type="unfinished">キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="779"/>
        <source>You don&apos;t have the permission to save attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="823"/>
        <source>You don&apos;t have the permission to open attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="938"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="939"/>
        <source>The removed Attachment cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="57"/>
        <source>Insert</source>
        <translation>挿入</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="179"/>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="24"/>
        <source>Attachment</source>
        <translation type="unfinished">添付ファイル</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="obsolete">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="175"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="874"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="29"/>
        <source>Add Bookmark</source>
        <translation>ブックマークを追加</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">ブックマークの削除</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="31"/>
        <source>Bookmark Properties</source>
        <translation>ブックマークのプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="32"/>
        <source>Set Destination</source>
        <translation type="unfinished">目的地を設定</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="274"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="275"/>
        <source>The removed bookmark(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="30"/>
        <source>Delete Bookmark(s)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="82"/>
        <source>Close</source>
        <translation type="unfinished">閉じる</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="86"/>
        <source>Close All</source>
        <translation type="unfinished">全て閉じる</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="106"/>
        <source>Move to New Window</source>
        <translation type="unfinished">新しいウィンドウへ移る</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="227"/>
        <location filename="../../src/document/qdoctab.cpp" line="348"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="90"/>
        <source>Close All Other Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="74"/>
        <source>Duplicate tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="78"/>
        <source>Rename tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="94"/>
        <source>Close All Tabs to the Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1895"/>
        <location filename="../../src/document/qdoctab.cpp" line="1920"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2214"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2272"/>
        <source>You don&apos;t have permission to modify the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2278"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>option needs to be enabled to allow duplicating tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Renaming file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Overwrite file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Would you like to overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3757"/>
        <source>Failed to rename file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation type="unfinished">Email 配信</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation type="unfinished">タイトル：</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="17"/>
        <source>Send</source>
        <translation type="unfinished">送信</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">ファイル</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">編集</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">元に戻す</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">先へ進む</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">コピー</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">貼り付け</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">太字</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">イタリック</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">左</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">右</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">元に戻す</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">先へ進む</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">コピー</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">貼り付け</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">太字</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">イタリック</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">左</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">右</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">ズームイン</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">ズームアウト</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="113"/>
        <source>Zoom to Selection</source>
        <translation type="unfinished">選択範囲をズーム</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="121"/>
        <source>Clear Selections</source>
        <translation type="unfinished">選択をクリア</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="16"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation type="unfinished">無償版ではこの機能を使用できません</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="20"/>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished">未登録版は透かしを挿入します</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <source>32 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>64 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Open Page</source>
        <translation type="unfinished">ページを開く</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Close Page</source>
        <translation type="unfinished">ページを閉じる</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="997"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Format</source>
        <translation type="unfinished">書式</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Validate</source>
        <translation type="unfinished">検証</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Calculate</source>
        <translation type="unfinished">計算する</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Goto a Page View</source>
        <translation type="unfinished">ページビューに移る</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Open/execute a File</source>
        <translation type="unfinished">ファイルを開く/実行</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Open a web link</source>
        <translation type="unfinished">ウェブリンクを開く</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="98"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished">フィールドを表示する/隠す</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="108"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished">JavaScript を実行する</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="25"/>
        <source>Open with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Confidential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Reviewed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Revised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>Accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="173"/>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="178"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>SignHere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Witness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Dynamic</source>
        <translation type="unfinished">ダイナミック</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Standard</source>
        <translation type="unfinished">標準</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="216"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="221"/>
        <source>Info</source>
        <translation type="unfinished">情報</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="226"/>
        <source>Press Help button to get more info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="231"/>
        <source>Error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="236"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="246"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="251"/>
        <source>Image</source>
        <translation type="unfinished">画像</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="256"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="261"/>
        <source>Shading</source>
        <translation type="unfinished">シェーディング</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="241"/>
        <location filename="../../src/app_config.cpp" line="747"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="266"/>
        <source>All Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="271"/>
        <source>Forms</source>
        <translation type="unfinished">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="276"/>
        <source>Comments</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="281"/>
        <source>Container</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="286"/>
        <source>Sticky Note</source>
        <translation type="unfinished">付箋</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="291"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="296"/>
        <source>Underline</source>
        <translation type="unfinished">下線</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="301"/>
        <source>StrikeOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="306"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="426"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="311"/>
        <source>Text Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="316"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="321"/>
        <source>Issued by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="326"/>
        <source>Expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="331"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="336"/>
        <source>Cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="341"/>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="346"/>
        <source>Not Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="351"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished">オブジェクト インスペクタ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="356"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="361"/>
        <source>Review History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="366"/>
        <source>Make Current Properties Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="371"/>
        <source>Error Loading Image!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="376"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="381"/>
        <source>You have exceeded the number of available activations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="386"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="396"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="401"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="391"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="406"/>
        <source>Print using Windows API</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="411"/>
        <source>Do not show this message again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="416"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Page Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>KeyStroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Close Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Save Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Document Saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="65"/>
        <source>Document Printed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Submit Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Import Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="112"/>
        <source>Rendition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="116"/>
        <source>Goto 3D View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="436"/>
        <source>Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="441"/>
        <source>Main</source>
        <translation type="unfinished">メイン</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="446"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="451"/>
        <source>Save As...</source>
        <translation type="unfinished">名前をつけて保存</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="461"/>
        <source>Toolbars</source>
        <translation type="unfinished">ツールバー</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="466"/>
        <source>Email delivery</source>
        <translation type="unfinished">Email 配信</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="476"/>
        <source>Print</source>
        <translation type="unfinished">印刷</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="481"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="486"/>
        <source>Cut</source>
        <translation type="unfinished">切り取り</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="491"/>
        <source>Copy</source>
        <translation type="unfinished">コピー</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="496"/>
        <source>Paste</source>
        <translation type="unfinished">貼り付け</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="501"/>
        <source>Delete Object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="506"/>
        <source>Undo</source>
        <translation type="unfinished">元に戻す</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="511"/>
        <source>Redo</source>
        <translation type="unfinished">先へ進む</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="516"/>
        <source>Align Left</source>
        <translation type="unfinished">左寄せ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="521"/>
        <source>Align Right</source>
        <translation type="unfinished">右へ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="526"/>
        <source>Align Top</source>
        <translation type="unfinished">上詰め</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="531"/>
        <source>Align Bottom</source>
        <translation type="unfinished">下詰め</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="536"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">水平距離</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="541"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="551"/>
        <source>Send To Back</source>
        <translation type="unfinished">背面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="556"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="561"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="566"/>
        <source>Bring To Front</source>
        <translation type="unfinished">前面へ移動</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="577"/>
        <source>Grid</source>
        <translation type="unfinished">グリッド</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="582"/>
        <source>Snap To Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="587"/>
        <source>View</source>
        <translation type="unfinished">表示</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="592"/>
        <source>Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="597"/>
        <source>Next View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="602"/>
        <source>Previous Page</source>
        <translation type="unfinished">前のページへ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="607"/>
        <source>Next Page</source>
        <translation type="unfinished">次のページへ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="612"/>
        <source>Zoom Out</source>
        <translation type="unfinished">ズームアウト</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="617"/>
        <source>Actual Size</source>
        <translation type="unfinished">実サイズ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="622"/>
        <source>Zoom In</source>
        <translation type="unfinished">ズームイン</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="627"/>
        <location filename="../../src/mainwindow.cpp" line="4147"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページ全体</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="632"/>
        <location filename="../../src/mainwindow.cpp" line="4151"/>
        <source>Fit Width</source>
        <translation type="unfinished">幅に合わせる</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="637"/>
        <source>Facing Pages</source>
        <translation type="unfinished">見開き表示</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="642"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">反時計回り</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="647"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">時計回り</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="652"/>
        <source>Rotate 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="657"/>
        <source>Tools</source>
        <translation type="unfinished">ツール</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="662"/>
        <source>Edit Document</source>
        <translation type="unfinished">ドキュメント編集</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="667"/>
        <source>Edit Text</source>
        <translation type="unfinished">テキストの修正</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="672"/>
        <source>Edit Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="677"/>
        <source>Edit Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="682"/>
        <source>Edit Forms</source>
        <translation type="unfinished">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="692"/>
        <source>Hand Tool</source>
        <translation type="unfinished">手のひらツール</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="697"/>
        <source>Select Text</source>
        <translation type="unfinished">テキスト選択</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="702"/>
        <source>Take Snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="707"/>
        <source>Insert Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="712"/>
        <source>Button</source>
        <translation type="unfinished">プッシュボタン</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="717"/>
        <source>Check Box</source>
        <translation type="unfinished">チェックボックス</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="722"/>
        <source>Combo Box</source>
        <translation type="unfinished">コンボボックス</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="727"/>
        <source>Text Field</source>
        <translation type="unfinished">テキストフィールド</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="732"/>
        <source>List Box</source>
        <translation type="unfinished">リストボックス</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="737"/>
        <source>Radio Button</source>
        <translation type="unfinished">ラジオボタン</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="742"/>
        <source>Signature</source>
        <translation type="unfinished">署名</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="752"/>
        <source>Insert Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="757"/>
        <source>Insert Text</source>
        <translation type="unfinished">テキストを挿入</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="762"/>
        <source>Insert Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="767"/>
        <source>Line</source>
        <translation type="unfinished">直線</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="772"/>
        <source>Rectangle</source>
        <translation type="unfinished">四角形</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="777"/>
        <source>Ellipse</source>
        <translation type="unfinished">楕円</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="782"/>
        <source>Pencil</source>
        <translation type="unfinished">鉛筆</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="787"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished">ファイルをコメントとして添付する</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="792"/>
        <source>Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="797"/>
        <source>Mark for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="802"/>
        <source>Search And Redact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="807"/>
        <source>Apply Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="812"/>
        <source>Document</source>
        <translation type="unfinished">文書</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="817"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished">空白ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="822"/>
        <source>Delete Pages</source>
        <translation type="unfinished">ページを削除</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="827"/>
        <source>Crop Pages</source>
        <translation type="unfinished">ページをクロップ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="832"/>
        <source>Page layout</source>
        <translation type="unfinished">ページ設定</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="837"/>
        <source>Page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="842"/>
        <source>Rotate Pages</source>
        <translation type="unfinished">ページを回転</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="847"/>
        <source>Extract Pages...</source>
        <translation type="unfinished">複数ページを抽出</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="852"/>
        <source>Insert Pages...</source>
        <translation type="unfinished">複数ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="857"/>
        <source>Cut Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="862"/>
        <source>Copy Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="867"/>
        <source>Paste Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="872"/>
        <source>Document Actions</source>
        <translation type="unfinished">文書のアクション</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="877"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="882"/>
        <source>Page Properties</source>
        <translation type="unfinished">ページのプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="887"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="892"/>
        <source>Header and Footer</source>
        <translation type="unfinished">ヘッダーとフッター</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="897"/>
        <source>Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="902"/>
        <source>Watermark</source>
        <translation type="unfinished">透かし</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="907"/>
        <source>Background</source>
        <translation type="unfinished">背景</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="917"/>
        <source>Page Counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="922"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="927"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="992"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1002"/>
        <source>Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1007"/>
        <source>Show Crop Page Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1012"/>
        <source>Prompt to Scan More Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1017"/>
        <source>Current Page</source>
        <translation type="unfinished">現在のページ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1022"/>
        <source>Autosave on. Document will be saved automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1027"/>
        <source>Images</source>
        <translation type="unfinished">画像として出力</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1032"/>
        <source>Vector Images</source>
        <translation type="unfinished">ベクトル画像</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1037"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1042"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="912"/>
        <location filename="../../src/app_config.cpp" line="932"/>
        <source>Zoom</source>
        <translation type="unfinished">ズーム</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="937"/>
        <source>Find</source>
        <translation type="unfinished">検索</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">コメント</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="962"/>
        <source>Stamp</source>
        <translation type="unfinished">スタンプ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="967"/>
        <source>Comment View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="972"/>
        <source>Place Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="431"/>
        <source>File</source>
        <translation type="unfinished">ファイル</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="947"/>
        <source>Highlight Text</source>
        <translation type="unfinished">テキストを強調表示</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="952"/>
        <source>Draw Comment Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="957"/>
        <source>Measurement Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="687"/>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="977"/>
        <source>Continuous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="982"/>
        <source>Single Page</source>
        <translation type="unfinished">単ページ</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="546"/>
        <source>Align Objects</source>
        <translation type="unfinished">配置</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="571"/>
        <source>Move Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="421"/>
        <source>If NSS is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="987"/>
        <source>No pages selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="471"/>
        <source>System Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="942"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Combine files in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="456"/>
        <source>Save As Image</source>
        <translation type="unfinished">画像として保存</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="39"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="40"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="41"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="42"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="43"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="44"/>
        <source>Azerbaijani (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="45"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="46"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="47"/>
        <source>Tibetan Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="49"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="50"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="51"/>
        <source>Cebuano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="52"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="53"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="54"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="55"/>
        <source>Cherokee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="58"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="59"/>
        <source>German (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="61"/>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="76"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="62"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="63"/>
        <source>English (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="64"/>
        <source>Middle English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="65"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="66"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="67"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="69"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="70"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="71"/>
        <source>Frankish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="72"/>
        <source>Middle French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="73"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="74"/>
        <source>Irish (Uncial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="75"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="77"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="78"/>
        <source>Hatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="81"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="82"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="83"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="84"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="85"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="86"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="87"/>
        <source>Old Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="88"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="89"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="90"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="91"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="92"/>
        <source>Old Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="93"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="94"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="95"/>
        <source>Kyrgyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="96"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="97"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="98"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="99"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="100"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="101"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="102"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="103"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="104"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="105"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="106"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="107"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="108"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="109"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="110"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="111"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="112"/>
        <source>script and orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="113"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="114"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="115"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="116"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="117"/>
        <source>Romanain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="118"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="119"/>
        <source>Russian (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="120"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="121"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="122"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="123"/>
        <source>Slovak Fractur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="124"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="125"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="126"/>
        <source>Old Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="127"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="128"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="129"/>
        <source>Serbian (Latin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="130"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="131"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="132"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="133"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="134"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="135"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="136"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="137"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="138"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="139"/>
        <source>Uyghur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="140"/>
        <source>Urgu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="141"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="142"/>
        <source>Uzbek (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="143"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="144"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qsanelib.cpp" line="389"/>
        <source>Document feeder is out of sheets!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="789"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="984"/>
        <source>Error! Check if the file is valid and exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="988"/>
        <source>Error!</source>
        <translation type="unfinished">エラー！</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="111"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="133"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="142"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/AppSession.cpp" line="64"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3554"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3682"/>
        <source>Error!</source>
        <translation type="unfinished">エラー！</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4325"/>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished">フォームの提出に問題がありました。</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4329"/>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished">&gt;フォームが正常に提出されました！</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="40"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="4231"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4235"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4240"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4285"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="51"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="593"/>
        <source>Open Document</source>
        <translation type="unfinished">文書を開く</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="61"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="594"/>
        <source>Blank PDF</source>
        <translation type="unfinished">空白PDF</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="595"/>
        <source>From Files</source>
        <translation type="unfinished">既存PDF</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="597"/>
        <source>From Scanner</source>
        <translation type="unfinished">スキャナ</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="93"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="598"/>
        <source>Settings</source>
        <translation type="unfinished">設定</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="99"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="599"/>
        <source>User Guide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="109"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="602"/>
        <source>Register...</source>
        <translation type="unfinished">登録情報</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="115"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="603"/>
        <source>Buy Online</source>
        <translation type="unfinished">オンラインで購入</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="417"/>
        <source>Create New Document</source>
        <translation type="unfinished">新規文書を作成</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="439"/>
        <source>Recent Files</source>
        <translation type="unfinished">最近使用したファイル</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="596"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="421"/>
        <source>Pinned Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="957"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="193"/>
        <source>Pages</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="obsolete">サムネイルを拡大</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="obsolete">サムネイルを縮小</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="219"/>
        <source>Bookmarks</source>
        <translation type="unfinished">ブックマーク</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="231"/>
        <source>Attachment</source>
        <translation type="unfinished">添付ファイル</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="242"/>
        <source>Search</source>
        <translation type="unfinished">検索</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="277"/>
        <source>Object Inspector</source>
        <translation type="unfinished">オブジェクト インスペクタ</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="744"/>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="745"/>
        <source>Highlight Fields</source>
        <translation type="unfinished">全ての部品を強調</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="753"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">空白ページを挿入</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4254"/>
        <source>Do you want to open?</source>
        <translation type="unfinished">開きますか？</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4261"/>
        <source>Don&apos;t show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5068"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5161"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="obsolete">ページを削除</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">空白ページを挿入</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">ページのプロパティ</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">時計回り</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">反時計回り</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="obsolete">エラー！</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1707"/>
        <source>Error loading font: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="246"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="600"/>
        <source>Layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="752"/>
        <source>This document is protectedYou do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="805"/>
        <source>Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="263"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3622"/>
        <source>Document must contain at least one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3629"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5071"/>
        <source>Set current zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3015"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QThumbnailsList</name>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="81"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished">サムネイルを拡大</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="84"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished">サムネイルを縮小</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="132"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="16"/>
        <source>Millimeters (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="17"/>
        <source>Inches (in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="18"/>
        <source>Points (pt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="19"/>
        <source>Pica (P̸)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="20"/>
        <source>Didot (DD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="21"/>
        <source>Cicero (CC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="59"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="63"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="302"/>
        <location filename="../../src/utils/AppSession.cpp" line="241"/>
        <source>MPE Session file (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="144"/>
        <source>More...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>User Color 99</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Black</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>White</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Red</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="356"/>
        <source>Dark red</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Green</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="358"/>
        <source>Dark green</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="359"/>
        <source>Blue</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="360"/>
        <source>Dark blue</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="361"/>
        <source>Cyan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="362"/>
        <source>Dark cyan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="363"/>
        <source>Magenta</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="364"/>
        <source>Dark magenta</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="365"/>
        <source>Yellow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="366"/>
        <source>Dark yellow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="367"/>
        <source>Gray</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="368"/>
        <source>Dark gray</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="369"/>
        <source>Light gray</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="371"/>
        <source>Transparent</source>
        <translation type="unfinished">透明</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="76"/>
        <source>Code Sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="83"/>
        <source>Code Entries:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="116"/>
        <source>Edit Codes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="67"/>
        <source>Redaction Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="133"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="152"/>
        <source>Font</source>
        <translation type="unfinished">フォント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="201"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="60"/>
        <source>Repeat Overlay Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="140"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="172"/>
        <source>auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="126"/>
        <source>Auto-size text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>登録情報</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>注文が完了しましたら、自動的に電子
メールで登録コードが通知されます。</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>オンラインで購入</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="386"/>
        <source>Registration Code</source>
        <translation>登録</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="373"/>
        <source>Activate</source>
        <translation>アクティベート</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>オフラインでアクティベート</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="227"/>
        <source>Registered version</source>
        <translation>登録バージョン</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="vanished">登録済みライセンスを別のPCに移すには［無効化］をクリックしてください。

その後、別のPCに登録してください。</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="214"/>
        <source>Deactivate</source>
        <translation>アクティベートを無効化</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="366"/>
        <source>Back</source>
        <translation>戻る</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="422"/>
        <source>Activation Code</source>
        <translation>アクティベーションコード</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">閉じる</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="202"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>登録済みライセンスを別のPCに移すには［無効化］をクリックしてください。

その後、別のPCに登録してください。</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="278"/>
        <source>Purchased On:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="292"/>
        <source>Maintenance Plan Expires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="319"/>
        <source>Registration Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="349"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="34"/>
        <source>Thanks for registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="35"/>
        <source>License is deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="37"/>
        <source>Too many activations!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="40"/>
        <source>License is expired!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="58"/>
        <source>Please, renew your license</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="291"/>
        <location filename="../../src/regdialog.cpp" line="425"/>
        <source>Incorrect registration code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="470"/>
        <source>Renew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="499"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact activations@code-industry.net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="320"/>
        <location filename="../../src/regdialog.cpp" line="527"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation type="unfinished">回転</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">ページ範囲</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="obsolete">ページ</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="obsolete">サンプル： 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">現在のページ</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">-：</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="28"/>
        <source>Direction</source>
        <translation type="unfinished">方向</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="35"/>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished">時計回り 90°</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="40"/>
        <source>180 degrees</source>
        <translation type="unfinished">180°</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="45"/>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished">反時計回り 270°</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">偶数/奇数ページ</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="obsolete">偶数ページ</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="obsolete">奇数ページ</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">全てのページ</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="25"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>幅</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>高さ</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>書式</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>File Name</source>
        <translation>ファイル名</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">ページ指定</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">-：</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>画像として出力</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="259"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">ページ範囲</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">全てのページ</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">保存</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>Can&apos;t save to the file:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation></translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="vanished">画像として保存</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="445"/>
        <source>All Files (*)</source>
        <translation>全ての形式 (*)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation type="unfinished">複数ページ</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>Save As TIFF Image</source>
        <translation type="unfinished">TIFF形式で保存</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished">TIFF形式 (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation type="unfinished">透明</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="269"/>
        <source>Antialiasing</source>
        <translation type="unfinished">アンチエイリアス</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="26"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="311"/>
        <source>Export:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="319"/>
        <source>Document</source>
        <translation type="unfinished">文書</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="324"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation type="unfinished">不使用エレメントを除去</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation type="unfinished">フォームフィールドを展開</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">カラー画像とグレースケール画像</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation type="unfinished">圧縮</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation type="unfinished">ロスレス</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation type="unfinished">JPEG 品質</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="340"/>
        <source>PDF/A Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation type="unfinished">白黒画像</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished">最適化して保存</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation type="unfinished">スキャン中...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation type="unfinished">キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScanExeDlg.cpp" line="140"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanImageViewerDialog</name>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="39"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="42"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="45"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">反時計回り</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="68"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="71"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="74"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">時計回り</translation>
    </message>
</context>
<context>
    <name>ScanPreviewDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="44"/>
        <source>Close</source>
        <translation type="unfinished">閉じる</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="51"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="26"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="23"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="18"/>
        <source>Scan</source>
        <translation type="unfinished">スキャン</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="46"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="107"/>
        <source>Output</source>
        <translation type="unfinished">出力</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="55"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Position</source>
        <translation type="unfinished">位置</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="199"/>
        <source>Source</source>
        <translation type="unfinished">ソース</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="414"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="61"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="122"/>
        <source>Before current page</source>
        <translation type="unfinished">現在のページの前</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="424"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="71"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="132"/>
        <source>After last page</source>
        <translation type="unfinished">最終ページの後</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="397"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="78"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="139"/>
        <source>After current page</source>
        <translation type="unfinished">現在のページの後</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="407"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="88"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="149"/>
        <source>Before first page</source>
        <translation type="unfinished">第1ページの前</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="304"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="174"/>
        <source>Append to Current Document </source>
        <translation type="unfinished">現在の文書に追加</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="299"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="181"/>
        <source>Create New Document</source>
        <translation type="unfinished">新規文書を作成</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="450"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation type="unfinished">入力</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="462"/>
        <source>Scan:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="133"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="105"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="241"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="522"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="183"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation type="unfinished">スキャナー</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="80"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="112"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="248"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="90"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="255"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="97"/>
        <source>Skip empty pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="544"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="36"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1069"/>
        <source>Looking for devices. Please wait.</source>
        <translation type="unfinished">デバイスを探索中。お待ち下さい。</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="obsolete">リロード</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="obsolete">モード</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="209"/>
        <source>Resolution</source>
        <translation type="unfinished">解像度</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="315"/>
        <source>Flatbed</source>
        <translation type="unfinished">フラットベッド</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="322"/>
        <source>Negative Transparency</source>
        <translation type="unfinished">ネガ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <source>Document Feeder</source>
        <translation type="unfinished">ドキュメントフィーダ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <source>Positive Transparency</source>
        <translation type="unfinished">ポジ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="353"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="139"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="197"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="50"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="47"/>
        <source>untitled</source>
        <translation type="unfinished">名称なし</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="501"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1007"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="350"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="381"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="188"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="225"/>
        <source>Save As PDF</source>
        <translation type="unfinished">PDF として保存</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="503"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1009"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="352"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="383"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="227"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished">PDF ファイル (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="64"/>
        <source>Single Page</source>
        <translation type="unfinished">単ページ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="482"/>
        <source>Page Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1080"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="130"/>
        <source>Open device. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="193"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="571"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="27"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="39"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="70"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="219"/>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="225"/>
        <source>After scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="318"/>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="65"/>
        <source>All Pages From Feeder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="418"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="767"/>
        <source>Scan source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="776"/>
        <source>ADF Duplex Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="784"/>
        <source>ADF Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="792"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="801"/>
        <source>Scan mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="833"/>
        <source>Scan resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="845"/>
        <source>X-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="854"/>
        <source>Y-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="899"/>
        <source>Page width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="916"/>
        <source>Page height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="938"/>
        <source>Top-left x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="956"/>
        <source>Top-left y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="977"/>
        <source>Bottom-right x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="994"/>
        <source>Bottom-right y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation type="obsolete">プレビュー</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="obsolete">時計回り</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="obsolete">反時計回り</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="138"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="204"/>
        <source>Search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0  結果</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Case Sensitive</source>
        <translation>大文字と小文字を区別</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="92"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="102"/>
        <source> result</source>
        <translation> 結果</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="106"/>
        <source> results</source>
        <translation> 結果</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="104"/>
        <source> result(s)</source>
        <translation> 結果</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="23"/>
        <source>Include Comments</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="27"/>
        <source>Whole Words Only</source>
        <translation type="unfinished">全ての単語のみ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="134"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="183"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="233"/>
        <source>Check All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="229"/>
        <source>Uncheck All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="124"/>
        <source>Case Sensitive</source>
        <translation type="unfinished">大文字と小文字を区別</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="125"/>
        <source>Include Comments</source>
        <translation type="unfinished">コメント</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Whole Words Only</source>
        <translation type="unfinished">全ての単語のみ</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation type="unfinished">許可</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished">アクセシビリティのための内容の抽出を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation type="unfinished">文書内容の変更を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation type="unfinished">コメントの追加・編集を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation type="unfinished">印刷を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished">フォームフィールドへの入力を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished">高解像度での印刷を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished">文書の内容を抽出する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="35"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="obsolete">セキュリティ PDF</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation type="unfinished">文書を開くパスワードが要求された</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation type="unfinished">文書を開くパスワード</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation type="unfinished">パスワードを確認</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation type="unfinished">許可</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation type="unfinished">コメントの追加・編集を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation type="unfinished">文書内容の変更を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished">アクセシビリティのための内容の抽出を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation type="unfinished">印刷を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished">文書の内容を抽出する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished">高解像度での印刷を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished">フォームフィールドへの入力を許可する</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation type="unfinished">許可パスワード</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="259"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished">ページの管理とブックマーク</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="104"/>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="116"/>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SessionsDialog</name>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="32"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="39"/>
        <source>Switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="46"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished">エクスポート</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="60"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="67"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="74"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="93"/>
        <source>Session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="98"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="103"/>
        <source>Last Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="108"/>
        <source>Document count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="121"/>
        <source>Store paths to documents relative to session file when exporting sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="140"/>
        <source>Managed Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="184"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>MPE session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="273"/>
        <source>Failed to load sessions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="452"/>
        <location filename="../../src/SessionsDialog.cpp" line="457"/>
        <source>New session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>New session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>Please write new session name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation type="unfinished">目的地を設定</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished">キャンセル</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation type="unfinished">署名のプロパティ</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="54"/>
        <source>Signature is VALID</source>
        <translation type="unfinished">署名は有効です</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation type="unfinished">詳細</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>Info</source>
        <translation type="unfinished">情報</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="353"/>
        <source>Signature Preview</source>
        <translation type="unfinished">署名のプレビュー</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="331"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="918"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished">証明書を開くにはパスワードが必要です：</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="299"/>
        <source>Sign</source>
        <translation type="unfinished">署名する</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="787"/>
        <source>Show Image</source>
        <translation type="unfinished">画像を表示する</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="812"/>
        <source>Stretch Image</source>
        <translation type="unfinished">画像を伸長する</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="464"/>
        <source>Show Text</source>
        <translation type="unfinished">テキストを表示する</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="476"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished">署名検証中にエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Open Image</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="53"/>
        <source>Signature is INVALID</source>
        <translation type="unfinished">署名は無効です</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="55"/>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished">署名の有効性は不明です</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="58"/>
        <source>Error during signature verification.</source>
        <translation type="unfinished">署名の検証中にエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="280"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="308"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="293"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1490"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="503"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="502"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="665"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="883"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="400"/>
        <source>Appearance Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="441"/>
        <source>Формат  по ГОСТу</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="473"/>
        <source>Date /Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="543"/>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="727"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="733"/>
        <source>Show Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="751"/>
        <source>Rounded Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">時間</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="483"/>
        <source>Signed By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="703"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="713"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">年月日</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="822"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="422"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="781"/>
        <source>Image</source>
        <translation type="unfinished">画像</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="331"/>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="56"/>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="57"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="59"/>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="60"/>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="72"/>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="73"/>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="74"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="75"/>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="553"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="557"/>
        <source>M.d.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="562"/>
        <source>M.d.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="567"/>
        <source>M.d.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="572"/>
        <source>M.d.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="577"/>
        <source>MM.dd.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="582"/>
        <source>MM.dd.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="587"/>
        <source>MM.dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="592"/>
        <source>MM.dd.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="597"/>
        <source>MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="602"/>
        <source>MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="607"/>
        <source>d.M.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="612"/>
        <source>d.M.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="617"/>
        <source>dd.MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="622"/>
        <source>dd.MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="627"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="632"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="637"/>
        <source>yy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="642"/>
        <source>yy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="647"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="652"/>
        <source>yyyy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="657"/>
        <source>d-MMMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="662"/>
        <source>d-MMMM HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="667"/>
        <source>d-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="672"/>
        <source>d-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="677"/>
        <source>d-MMMM-yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="682"/>
        <source>d-MMMM-yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="687"/>
        <source>dd-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="692"/>
        <source>dd-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="189"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="332"/>
        <source>Certificate Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="286"/>
        <source>Unsigned Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <source>Page</source>
        <translation type="unfinished">ページ</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="302"/>
        <source>Signed Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="305"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="306"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="346"/>
        <source>Click to view this version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Document</source>
        <translation type="unfinished">文書</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation type="unfinished">情報</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation type="unfinished">発行者</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation type="unfinished">一般名 (CN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation type="unfinished">組織 (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished">組織単位 (OU)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation type="unfinished">シリアル番号</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation type="unfinished">アルゴリズム</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>タイトル：</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation type="unfinished">有効性</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished">信頼できる IDに追加</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation type="unfinished">データ</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation type="unfinished">ファイル名</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="98"/>
        <source>Custom</source>
        <translation type="unfinished">カスタム</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation type="unfinished">カスタムスタンプ</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation type="unfinished">追加</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation type="unfinished">編集</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation type="unfinished">スタンプ</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation type="unfinished">スタンプを編集</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation type="unfinished">テンプレート</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="vanished">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="43"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteReply</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">フォント名 </translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">フォントサイズ</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">文字色</translation>
    </message>
    <message>
        <source>Text Settings</source>
        <translation type="obsolete">テキスト設定</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="166"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="184"/>
        <source>Add Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="199"/>
        <source>Name</source>
        <translation type="unfinished">名前</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="224"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="249"/>
        <source>Organization unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="274"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="299"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="324"/>
        <source>Valid since</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="349"/>
        <source>Valid till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="365"/>
        <source>Date</source>
        <translation type="unfinished">年月日</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ThumbnailForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="22"/>
        <source>Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="29"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="42"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="62"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="75"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.cpp" line="39"/>
        <source>Pages</source>
        <translation type="unfinished">ページ</translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="227"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="233"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="268"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="271"/>
        <source>StrikeOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="125"/>
        <source>Underline</source>
        <translation type="unfinished">下線</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="167"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="170"/>
        <source>Copy</source>
        <translation type="unfinished">コピー</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="101"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="104"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="110"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="112"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="114"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="116"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="119"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="696"/>
        <source>Zoom</source>
        <translation type="unfinished">ズーム</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">検索</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">コメント</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">スタンプ</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">メイン</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">編集</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">表示</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">コメント</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="602"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete">表示</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">付箋</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">元に戻す</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">先へ進む</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="obsolete">前面へ移動</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">切り取り</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">コピー</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">貼り付け</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="obsolete">背面へ移動</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">ファイル</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">印刷</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">署名</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">ラジオボタン</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">リストボックス</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">テキストフィールド</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">コンボボックス</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">チェックボックス</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="obsolete">プッシュボタン</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">鉛筆</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">楕円</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">四角形</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">直線</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">テキストを挿入</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">ツール</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">テキストの修正</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">手のひらツール</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">ズームアウト</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">ズームイン</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">ページ全体</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">幅に合わせる</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation type="unfinished">透かし</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">設定</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="648"/>
        <source>Delete</source>
        <translation type="unfinished">削除</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="662"/>
        <source>None</source>
        <translation type="unfinished">なし</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="670"/>
        <source>Save</source>
        <translation type="unfinished">保存</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="231"/>
        <source>Source</source>
        <translation type="unfinished">ソース</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="427"/>
        <source>Text</source>
        <translation type="unfinished">テキスト</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="244"/>
        <source>File</source>
        <translation type="unfinished">ファイル</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="417"/>
        <source>Scale</source>
        <translation type="unfinished">縮尺</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="obsolete">ページ総数：</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="237"/>
        <source>Page Number</source>
        <translation type="unfinished">ページ番号</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="264"/>
        <source>Font</source>
        <translation type="unfinished">フォント</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="270"/>
        <source>Color</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="322"/>
        <source>Size</source>
        <translation type="unfinished">サイズ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="315"/>
        <source>Font Family</source>
        <translation type="unfinished">フォントファミリー</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="380"/>
        <source>Browse</source>
        <translation type="unfinished">参照...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="121"/>
        <source>Appearance</source>
        <translation type="unfinished">外観</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">プレビュー</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="28"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="45"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="52"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="127"/>
        <source>Rotation</source>
        <translation type="unfinished">回転</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="145"/>
        <source>Options</source>
        <translation type="unfinished">オプション</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="165"/>
        <source>Opacity</source>
        <translation type="unfinished">不透明度</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="221"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished">ターゲットページに対する相対的縮尺</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="489"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="495"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="630"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="754"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="760"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="791"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="453"/>
        <source>Position</source>
        <translation type="unfinished">位置</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="495"/>
        <source>Vertical distance</source>
        <translation type="unfinished">垂直距離</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="529"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="562"/>
        <source>Top</source>
        <translation type="unfinished">上</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="468"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="567"/>
        <source>Center</source>
        <translation type="unfinished">中央</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="572"/>
        <source>Bottom</source>
        <translation type="unfinished">底</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="488"/>
        <source>Horizontal distance</source>
        <translation type="unfinished">水平距離</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="463"/>
        <source>Left</source>
        <translation type="unfinished">左</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Right</source>
        <translation type="unfinished">右</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="580"/>
        <source>Units</source>
        <translation type="unfinished">単位</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="80"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">ページ範囲のオプション...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save Settings</source>
        <translation type="unfinished">設定を保存</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">設定を保存：</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="302"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished">設定名が存在します。上書きしますか？</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">設定を削除しますか</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="420"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="436"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="454"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>Open File</source>
        <translation type="unfinished">ファイルを開く</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="499"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished">文書を開く途中でエラーが発生しました</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="299"/>
        <source>auto</source>
        <translation type="unfinished">自動</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="629"/>
        <source>Saved Settings</source>
        <translation type="unfinished">保存済み設定</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="540"/>
        <source>Points</source>
        <translation type="unfinished">ポイント</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="545"/>
        <source>Inches</source>
        <translation type="unfinished">インチ</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="550"/>
        <source>Millimeters</source>
        <translation type="unfinished">ミリメートル</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="600"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="606"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="613"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSignature</name>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="37"/>
        <source>Digitally signed by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="38"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">年月日</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">フォーム</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
