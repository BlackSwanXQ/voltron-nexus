<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv_SE">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Spara alla</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Ja till &amp;alla</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;ej till alla</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Försök igen</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorera</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Förkasta</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Verkställ</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Återställ standardvärden</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Klipp &amp;ut</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Stega uppåt</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Stega &amp;nedåt</translation>
    </message>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Markera alla</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Ångra</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Gör om</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Klipp &amp;ut</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiera</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Kopiera &amp;länkplats</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Klistra &amp;in</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Markera alla</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>Hu&amp;e:</source>
    </message>
    <message>
        <source>&amp;Sat:</source>
    </message>
    <message>
        <source>&amp;Val:</source>
    </message>
    <message>
        <source>&amp;Red:</source>
    </message>
    <message>
        <source>&amp;Green:</source>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
    </message>
    <message>
        <source>&amp;HTML:</source>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
    </message>
    <message>
        <source>Select Color</source>
    </message>
    <message>
        <source>&amp;Basic colors</source>
    </message>
    <message>
        <source>&amp;Custom colors</source>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
    </message>
</context>
</TS>
