<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_ru">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Сохранить все</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Да</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Да для &amp;всех</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>Н&amp;ет для всех</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Прервать</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Повторить</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Пропустить</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Отклонить</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Сбросить</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>По умолчанию</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Отменить действие</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Повторить действие</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Вырезать</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Копировать</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>В&amp;ставить</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Выделить всё</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Отменить действие</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Повторить действие</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Вырезать</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Копировать</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Скопировать &amp;адрес ссылки</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>В&amp;ставить</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Выделить всё</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Выделить всё</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>Шаг вв&amp;ерх</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Шаг вн&amp;из</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>Hu&amp;e:</source>
        <translation>&amp;Тон:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Нас:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Ярк:</translation>
    </message>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Красный:</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Зелёный:</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>С&amp;иний:</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>&amp;Альфа-канал:</translation>
    </message>
    <message>
        <source>&amp;HTML:</source>
        <translation>&amp;HTML:</translation>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
        <translation>Курсор в %1, %2
Нажмите ESC для отмены</translation>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
        <translation>&amp;Взять цвет с экрана</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Выбор цвета</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>&amp;Основные цвета</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Пользовательские цвета</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Добавить к пользовательским цветам</translation>
    </message>
</context>
</TS>
