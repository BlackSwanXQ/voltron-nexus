<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="410"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="127"/>
        <source>Registered version.</source>
        <translation>Version enregistrée.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="179"/>
        <source>Purchased On:</source>
        <translation>Achetée le :</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="187"/>
        <source>Maintenance Plan Expires:</source>
        <translation>La licence expire le :</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation>Info d&apos;Enregistrement</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation>Agrément de licence</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="126"/>
        <source>Not Registered version.</source>
        <translation>Version non enregistrée.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation>Info de Version</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation>Créé avec</translation>
    </message>
    <message>
        <source>Legal Notices</source>
        <translation type="vanished">Notices légales</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="258"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>Ce logiciel utilise, avec autorisation, les logiciels sous copyright suivants.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="99"/>
        <source>Please, renew your license</source>
        <translation>Merci de la renouveler</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Third-Party Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>Actions de document</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation>Script Java</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation>Le document sera fermé</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation>Le document sera sauvegardé</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation>Le document a été enregistré</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation>Le document sera imprimé</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>Le document a été imprimé</translation>
    </message>
</context>
<context>
    <name>AddOpenFilesDialog</name>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="14"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="22"/>
        <source>Open PDF files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>Size</source>
        <translation type="unfinished">Dimension</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="32"/>
        <source>Add Files</source>
        <translation type="unfinished">Ajouter des fichiers</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation>Fonction d&apos;Impression Avancée</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation>Imprimer en tant qu&apos;image</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translation>File d&apos;attente dans les pages du sous-ensemble</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="97"/>
        <source>Сompatible with Laser Engraving</source>
        <translation>Compatible avec la gravure laser</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="246"/>
        <source>Borders and Colors</source>
        <translation>Bordures et Couleurs</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="256"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="261"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="266"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="271"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="276"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="281"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="286"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="291"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="296"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="301"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="306"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="314"/>
        <source>Border Color</source>
        <translation>Couleur de Bordure</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="321"/>
        <source>Fill Color</source>
        <translation>Couleur de Remplissage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="329"/>
        <source>Solid</source>
        <translation>Solide</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="334"/>
        <source>Dashed</source>
        <translation>Pointillés</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="obsolete">Épaisseur de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="349"/>
        <source>Line Width</source>
        <translation>Largeur de la Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="342"/>
        <source>Line Style</source>
        <translation>Style de Ligne</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>Options d&apos;apparence</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>Afficher lors de l&apos;impression</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>Afficher lors de l&apos;affichage sur l&apos;écran</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Garder la position et la taille du texte du filigrane constants lors de l&apos;impression sur différentes tailles de page</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="vanished">Fichier</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="vanished">Nouveau</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Ouvrir</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="vanished">Fichiers récents</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Aide</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="vanished">Contenu</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="vanished">Enregistrement...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">Rechercher des mises à jour</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation type="vanished">Vider la liste des fichiers récents</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="vanished">Aide...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>Arrière-plan</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="335"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="349"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="357"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="367"/>
        <source>Source</source>
        <translation>La source</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="405"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="411"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="508"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="514"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="540"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="660"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="449"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total des pages :</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="383"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="484"/>
        <source>Page Number</source>
        <translation>Numéro de Page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="422"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="373"/>
        <source>Scale</source>
        <translation>Échelle</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="44"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation>Opacité</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation>Échelle par rapport à la page cible</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="140"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="187"/>
        <source>Vertical distance</source>
        <translation>Distance verticale</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="506"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="514"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="531"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="538"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="166"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="246"/>
        <source>from</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="282"/>
        <source>Top</source>
        <translation>Haut</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="265"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="287"/>
        <source>Center</source>
        <translation>Centrer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="292"/>
        <source>Bottom</source>
        <translation>Bas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="180"/>
        <source>Horizontal distance</source>
        <translation>Distance horizontale</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="260"/>
        <source>Left</source>
        <translation>Gauche</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="270"/>
        <source>Right</source>
        <translation>Droite</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="173"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">points</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="566"/>
        <source>Page Range Options...</source>
        <translation>Options de plage de pages...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save Settings</source>
        <translation>Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save current settings as:</source>
        <translation>Enregistrer les paramètres actuels comme:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="241"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Ętes-vous sûr de vouloir supprimer le paramètre ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source> ?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="337"/>
        <source> pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="371"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="415"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Fichiers PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="vanished">Une erreur s&apos;est produite à l&apos;ouverture du document !</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="316"/>
        <source>Saved Settings</source>
        <translation>Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="228"/>
        <source>Points</source>
        <translation>Points</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="233"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="238"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Tous les fichiers pris en charge (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="201"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="207"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatesNumberingOptionsDialog</name>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="32"/>
        <source>Start Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="39"/>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="59"/>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="69"/>
        <source>Number of Digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="14"/>
        <source>Bates Numbering Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source>The value must be between </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source> and </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Propriétés du Signet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="115"/>
        <source>Style</source>
        <translation>Style</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="129"/>
        <source>Plain</source>
        <translation>Uni</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="134"/>
        <source>Italic</source>
        <translation>Italique</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="139"/>
        <source>Bold</source>
        <translation>Gras</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="144"/>
        <source>Italic &amp; Bold</source>
        <translation>Gras &amp; Italique</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="165"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="179"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="292"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="351"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="332"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="185"/>
        <source>Add an Action</source>
        <translation>Ajouter une Action</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="220"/>
        <source>Trigger</source>
        <translation>Déclencher</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="204"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="212"/>
        <source>Mouse Up</source>
        <translation>Souris vers le haut</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="228"/>
        <source>Goto a Page View</source>
        <translation>Aller à une vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="233"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un fichier</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="238"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="243"/>
        <source>Reset form</source>
        <translation>Réinitialiser un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="248"/>
        <source>Show/Hide fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="253"/>
        <source>Submit a form</source>
        <translation>Soumettre un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="258"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="266"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Numéro de Page</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="86"/>
        <source>Set current position</source>
        <translation>Régler la position courante</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="96"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="78"/>
        <source>untitled</source>
        <translation>sans titre</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="220"/>
        <source>Do you want to set the current position?</source>
        <translation>Voulez-vous régler la position courante ?</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="222"/>
        <source>Custom</source>
        <translation>Personnel</translation>
    </message>
</context>
<context>
    <name>BookmarksForm</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="20"/>
        <source>Bookmarks</source>
        <translation type="unfinished">Signets</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="38"/>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="69"/>
        <source>Set destanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="100"/>
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="131"/>
        <source>Properties</source>
        <translation type="unfinished">Propriétés</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="162"/>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="193"/>
        <source>Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="224"/>
        <source>Delete all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation>Gestionnaire de Certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation>Vos certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation>Certificats de confiance approuvés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="44"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>Open File</source>
        <translation>Ouvrir un fichier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Tous les fichiers supportés (*.p12 *.pfx *.cer *.crt *.pem);; Fichiers p12 (*.p12);; Fichiers pfx (*.pfx);; Tous les Fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="102"/>
        <source>A password is required to open certificate:</source>
        <translation>Un mot de passe est demandé pour ouvrir le certificat :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="114"/>
        <source>Error!</source>
        <translation>Erreur !</translation>
    </message>
    <message>
        <source>Are you sure you want to delete ceritficate?</source>
        <translation type="vanished">Etes vous certain de supprimer le certificat ?</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>pfx Files (*.pfx)</source>
        <translation>Fichiers pfx (*.pfx)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>crt Files (*.crt)</source>
        <translation>Fichiers crt (*.crt)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="162"/>
        <source>Save File</source>
        <translation>Sauvegarder le fichier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="171"/>
        <source>Please, specify private key password:</source>
        <translation>SVP, préciser le mot de passe privé :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="126"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation>Etes vous certain de supprimer le certificat ?</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation>Créer un document à partir de fichiers</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="181"/>
        <source>Add Files</source>
        <translation>Ajouter des fichiers</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="164"/>
        <source>Add Folder</source>
        <translation>Ajouter le dossier</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="211"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="267"/>
        <source>Up</source>
        <translation>Monter</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="298"/>
        <source>Down</source>
        <translation>Descendre</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="237"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="278"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="196"/>
        <source>Page Range</source>
        <translation>Plage de Page</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>File Name</source>
        <translation>Nom du Fichier</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="124"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="84"/>
        <source>untitled</source>
        <translation>sans titre</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="126"/>
        <source>Add Headers and Footers to Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>Total pages</source>
        <translation>Total des pages</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="198"/>
        <source>Size</source>
        <translation type="unfinished">Dimension</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="197"/>
        <source>Total Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="488"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="921"/>
        <source>Save As PDF</source>
        <translation>Sauvegarder comme PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="490"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="923"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Fichiers PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1002"/>
        <source>File</source>
        <translation type="unfinished">Fichier</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1003"/>
        <source>has already been added to the list. Please choose a different file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source> is already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1052"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1074"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>are already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Ouvrir</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Tous les fichiers (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="600"/>
        <source>Select directory</source>
        <translation>Répertoire sélectionné</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="956"/>
        <source>Save failed</source>
        <translation>La Sauvegarde a échoué</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossible d&apos;enregistrer vers le fichier :</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="34"/>
        <source>Output</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="101"/>
        <source>Append to Current Document </source>
        <translation>Ajouter au document actuel</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="108"/>
        <source>Create New Document</source>
        <translation>Créer un nouveau document</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="43"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="20"/>
        <source>Add files to which Headers and Footers or Bates Numbers should be placed. Bates Numbers will appear in the specified order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="27"/>
        <source>Save and close files after numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="49"/>
        <source>Before current page</source>
        <translation>Avant la page courante</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="59"/>
        <source>After last page</source>
        <translation>Après la dernière Page</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="66"/>
        <source>After current page</source>
        <translation>Après la page courante</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="76"/>
        <source>Before first page</source>
        <translation>Avant la première Page</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="309"/>
        <source>Show</source>
        <translation type="unfinished">Montrer</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Tous les fichiers pris en charge (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="137"/>
        <source>Import Bookmarks</source>
        <translation>Importer les Signets</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Insert Pages</source>
        <translation>Insérer les Pages</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Ok</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="550"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Tous les fichiers pris en charge (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Tous les fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="42"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="49"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="553"/>
        <source>All Supported Files (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Tous les fichiers pris en charge (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Tous les fichiers (*)</translation>
    </message>
</context>
<context>
    <name>DeleteAcrossPagesDialog</name>
    <message>
        <location filename="../../src/DeleteAcrossPagesDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="14"/>
        <source>Delete Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="23"/>
        <source>Do you want to delete all headers, footers and Bates numbers on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="obsolete">Supprimer les en-têtes et les pieds de page du document ?</translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="22"/>
        <source>Do you want to delete all watermarks on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="27"/>
        <source>Do you want to delete all backgrounds on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Voulez-vous supprimer ces pages ?  Cette opération nest pas réversible.</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Supprimer les Pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page courante</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="50"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Les pages supprimées ne peuvent pas être récupérées avec l&apos;action annuler.</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Bouton de validation</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Opacité</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texte</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Apparence</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">Couleur</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Auteur</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">Sujet</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">Vérrouillé</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Paramètres</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Rotate Pages</source>
        <translation type="vanished">Rotation de Pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Sélectionner la plage de page</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">à:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Pages sélectionnées</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Page courante</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>Outil Distance</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>Mesure</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>Distance :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>Angle :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>Emplacement du curseur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>Unités et paramètres de marquage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation>Ratio d&apos;échelle :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation>po</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation>Annotation :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="32"/>
        <source>Distance</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="36"/>
        <source>Perimeter</source>
        <translation>Périmètre</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="43"/>
        <source>Area</source>
        <translation>Zone</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="46"/>
        <source> sq</source>
        <translation> sq</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="222"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="225"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="229"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
</context>
<context>
    <name>DlgChangeFont</name>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="14"/>
        <source>Change Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="39"/>
        <source>Current font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="46"/>
        <source>Change to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="66"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">Changer automatiquement la police lors de l&apos;édition du texte</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="84"/>
        <source>Exact match only</source>
        <translation type="unfinished">Correspondance exacte seulement</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="21"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished">Cette police ne contient pas ces caractères.
Choisir une autre police.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="28"/>
        <source>Change</source>
        <translation type="unfinished">Changer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Famille de Polices&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la  Famille de Polices&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>Placement d&apos;icônes</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>Ajuster aux limites</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>Quand mettre à l&apos;échelle :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>Proportionnellement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>Non proportionnellement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>Bouton</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>Échelle :</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>Toujours</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>L&apos;icône est trop grande</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Utiliser cette boîte de dialogue pour modifier la façon dont l&apos;icône est mise à l&apos;échelle pour s&apos;adapter au bouton</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>L&apos;icône est trop petite</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>Numéro de page et format de la date</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>Format de date</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>Format de numéro de page</translation>
    </message>
    <message>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="14"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="16"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>Numéro de la page de démarrage</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="51"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="18"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="20"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="21"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>of</source>
        <translation>de </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="53"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="27"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="29"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation>Options de plage de pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Pages paires et impaires</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Pages paires</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Pages impaires</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Éditer texte</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Enregistrer l&apos;image sous</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Propriétés de l&apos;objet...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Couper</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copier</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="obsolete">Placer Devant</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Supprimer</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annuler</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="41"/>
        <source>Select All</source>
        <translation>Tout sélectionner</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Coller</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Enregistrer sous...</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation type="obsolete">Ajuster à la page</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="48"/>
        <source>Add Sticky Note</source>
        <translation>Ajouter Note</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="49"/>
        <source>Highlight Text</source>
        <translation>Surligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="50"/>
        <source>Strikeout Text</source>
        <translation>Barrer le Texte</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="51"/>
        <source>Underline Text</source>
        <translation>Souligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>Add Bookmark</source>
        <translation>Ajouter un Signet</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2456"/>
        <location filename="../../src/docpage/docpage.cpp" line="2496"/>
        <source>Goto a Page View</source>
        <translation>Aller à une vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2465"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2475"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un fichier</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2486"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3975"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="70"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="82"/>
        <source>Set Status</source>
        <translation>Définir le statut</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1087"/>
        <location filename="../../src/docpage/docpage.cpp" line="1090"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1678"/>
        <source>The selected area has been copied</source>
        <translation>La zone sélectionnée a été copiée</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copier</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Couper</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Coller</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="131"/>
        <source>Select All</source>
        <translation>Tout Sélectionner</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="132"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Éditer texte</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="136"/>
        <source>Signature options</source>
        <translation>Options de Signature</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Annuler</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="139"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="2622"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Open Image</source>
        <translation>Ouvrir une Image</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Fichiers Images (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="vanished">Erreur au chargement de l&apos;image !</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="140"/>
        <source>Set Fit to Page</source>
        <translation>Ajuster à la Page</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="141"/>
        <source>Save Image to file</source>
        <translation>Enregistrer l&apos;image sous</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1940"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Images PNG (*.png);;Images BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1950"/>
        <source>PNG Images (*.png)</source>
        <translation>Images PNG (*.png)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Fichiers Images (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>ERROR Loading Image !</source>
        <translation type="vanished">Erreur au chargement de l&apos;image !</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="134"/>
        <source>Edit Image</source>
        <translation>Editer l&apos;Image</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="143"/>
        <source>Edit Path Nodes</source>
        <translation>Editer les Nœuds du Chemin</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1656"/>
        <source>Edit the image and press Replace</source>
        <translation>Editer l&apos;image et appuyer sur Remplacer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1658"/>
        <source>Replace</source>
        <translation>Remplacer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1659"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2593"/>
        <source>Delete Node</source>
        <translation>Supprimer le Noeud</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Fichiers Image (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Tous les fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="594"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="609"/>
        <source>Image</source>
        <translation>Image</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="137"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="135"/>
        <source>Replace Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1650"/>
        <source>An error occurred when attempting to open external application for editing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Editeur de script Java</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">Aller à la Page</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">Haut</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Gauche</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">Page Nombre</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">Zoom (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Ouvrir/Exécuter un Fichier</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">Editer un fichier</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>Montrer</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>Sélectionner les Champs</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>Tout Déselectionner</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>Cacher</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>Tout Sélectionner</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>Méthode</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="187"/>
        <source>Show/Hide Fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="221"/>
        <source>Reset Form</source>
        <translation>Réinitialiser le Formulaire</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="vanished">Entrer un fichier :</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="vanished">Entrer un site internet :</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="vanished">Mode Zoom</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Habitude</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Zoom d&apos;origine</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajuster la Page</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">Ajuster la Largeur</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">Ajuster V</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">Ajuster R</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">Ajuster B</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">Ajuster BH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">Ajuster BV</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>Fichier local</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation>Utiliser de façon anonyme</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>Nécessite le nom d&apos;utilisateur et le mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>Nom d&apos;utilisateur</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="115"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="117"/>
        <source>All Files (*.*)</source>
        <translation>Tous les Fichiers (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="191"/>
        <source>Select Field</source>
        <translation>Sélectionner le Champ</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a file:</source>
        <translation>Entrer un fichier :</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Aller à la Page</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation>Numéro de Page</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation>Mode Zoom</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">Ajuster V</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">Ajuster R</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">Ajuster B</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">Ajuster BH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">Ajuster BV</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Enter a web site:</source>
        <translation>Entrer un site internet :</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="171"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="173"/>
        <source>All Files (*.*)</source>
        <translation>Tous les Fichiers (*.*)</translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="vanished">XYZ</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="vanished">Ajuster</translation>
    </message>
    <message>
        <source>FitH</source>
        <translation type="vanished">Ajuster H</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="114"/>
        <source>Named Action</source>
        <translation>Action Nommée</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation>Personnel</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation>Ajuster la Largeur</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation>Ajuster la Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation>Ajuster la partie Visible</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditTabOrderDlg</name>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="14"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="20"/>
        <source>Forms</source>
        <translation type="unfinished">Formulaires</translation>
    </message>
</context>
<context>
    <name>ExportCSVDialog</name>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="20"/>
        <source>Export to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="50"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="78"/>
        <source>Browse</source>
        <translation type="unfinished">Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="88"/>
        <source>Separator</source>
        <translation type="unfinished">Séparateur</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="103"/>
        <source>Semicolon ( ; )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="129"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="146"/>
        <source>Comma ( , )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="153"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="38"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="47"/>
        <source>Export</source>
        <translation type="unfinished">Exporter</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="111"/>
        <source>Export to csv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="113"/>
        <source>csv files (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished">
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="77"/>
        <source>Extract pages as a single file</source>
        <translation>Extraire des pages comme fichier unique</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Extraire les Pages</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nom du Fichier</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="141"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page Courante</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">Ok</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="130"/>
        <source>Save As PDF</source>
        <translation>Sauvegarder comme PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="132"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Fichiers PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossible d&apos;enregistrer vers le fichier :</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>The file &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>&quot; already exists. Do you wish to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="43"/>
        <source>Export Pages</source>
        <translation>Exporter les Pages</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="vanished">Exporter les Pages </translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="vanished">Exporter les Signets</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="124"/>
        <source>Export bookmarks</source>
        <translation>Exporter les Signets</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="134"/>
        <source>Delete pages after extracting</source>
        <translation>Supprimer les pages après extraction</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="23"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation>Exporter en texte</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nom du Fichier</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page Courante</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les pages</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="64"/>
        <source>Extract pages as a single file</source>
        <translation>Extraire des pages comme fichier unique</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="35"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="43"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation>Fichiers txt (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossible d&apos;enregistrer vers le fichier :</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Propriétés du Document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Info du Document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Titre</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Mots-clés</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Créateur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Produit par</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Protéger</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>Vue initiale</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Images</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>Polices</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>Polices utilisées dans ce document</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Protection</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Mot de passe Utilisateur</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Votre Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>Cryptage du mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>Pas de Cryptage</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>Imprimer le document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimer le document en haute résolution</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Extraire le texte et les graphiques</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extraction avancée du texte et des graphiques</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>Modifier le document</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Modifier les annotations ou les champs de formulaires</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Remplir un formulaire ou les zones de signature</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Gérer les Pages et les Signets</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Ouvrir à la Page :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>de :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Information du PDF</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Mode Page :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation>Page Seulement</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation>Panneau des Signets</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation>Panneau des Pages</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation>Panneau des Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation>Panneaux des Couches</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="vanished">Plein Ecran</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation>Changer</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation>Permissions</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translation>Extraire le contenu du document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation>Contenu copié pour accessibilité</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation>Commenter</translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="vanished">Lancer un script Java pour le Document ouvert</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="723"/>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="724"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Le document est protégé. SVP, entrer le mot de passe pour ôter la protection :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="746"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Mot de passe faux. SVP, entrer votre mot de passe.</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation>Options d&apos;interface utilisateur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation>Masquer la barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation>Masquer la barre de menu</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation>Cacher les contrôles de fenêtre</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation>Options de fenêtres</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation>Fenêtre centrale sur l&apos;écran</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation>Afficher le titre du document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation>Ouvrir en mode plein écran</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation>Disposition et destination</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation>Onglet Navigation :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation>Format de la Page :</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="248"/>
        <source>Default</source>
        <translation>Par défaut</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation>Page Seule</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation>Page Seule (continu)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation>Pages côte à côte</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Pages côte à côte (continu)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation>Pages côte à côte (Page de Couverture)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>En continu (Page de Couverture)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translation>Taille actuelle</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation>Ajuster la Largeur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="268"/>
        <source>Fit Height</source>
        <translation>Ajuster la Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="273"/>
        <source>Fit Visible</source>
        <translation>Ajuster la partie Visible</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translation>Ouvrir Actions du Document</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation>Ajouter une Action</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation>Aller à la Vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un fichier</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation>Réinitialiser un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translation>Soumettre un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translatorcomment>Cryptage du Certificat</translatorcomment>
        <translation>Certificate Encryption</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Général</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Apparence</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Actions</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Supprimer</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Fermer</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Style</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Couleur</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Ajouter</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Verrouillé</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nom</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Bordures et Couleurs</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation type="vanished">Ajouter une Action</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Info-bulle</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientation</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Style de Ligne</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Épaisseur de Ligne</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Couleur de Remplissage</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Couleur de Bordure</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Monter</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Descendre</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Propriétés</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texte</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Dimension</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">Gauche</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">Droite</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">Insertion</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Edition</translation>
    </message>
</context>
<context>
    <name>HeaderAndFooterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save Settings</source>
        <translation>Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save current settings as:</source>
        <translation>Enregistrer les paramètres actuels comme:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="365"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Ętes-vous sûr de vouloir supprimer le paramètre</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="569"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="593"/>
        <source> in</source>
        <translation type="unfinished"> po</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="621"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished">En-tête et pied de page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="166"/>
        <source>Margins</source>
        <translation type="unfinished">Marges</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="257"/>
        <source>Units</source>
        <translation type="unfinished">Unités</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="291"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="296"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="301"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">Bord à gauche</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">Bord à droite</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="obsolete">Bord en haut</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="obsolete">Bord en bas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="328"/>
        <source>Saved Settings</source>
        <translation type="unfinished">Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="347"/>
        <source>Delete</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="361"/>
        <source>None</source>
        <translation type="unfinished">Aucun</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="369"/>
        <source>Save</source>
        <translation type="unfinished">Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="522"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="536"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="553"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="560"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="588"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">Options de plage de pages...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="150"/>
        <source>Page number and date format</source>
        <translation type="unfinished">Numéro de page et format de la date</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="28"/>
        <source>Show Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="41"/>
        <source>Insert Page Number</source>
        <translation type="unfinished">Insérer un numéro de page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="48"/>
        <source>Insert Date</source>
        <translation type="unfinished">Insérer la Date</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="55"/>
        <source>Insert Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="70"/>
        <source>Font</source>
        <translation type="unfinished">Police</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="76"/>
        <source>Color</source>
        <translation type="unfinished">Couleur</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="96"/>
        <source>Size</source>
        <translation type="unfinished">Dimension</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="116"/>
        <source>Font Family</source>
        <translation type="unfinished">Famille de Polices</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="178"/>
        <source>Top</source>
        <translation type="unfinished">Haut</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="188"/>
        <source>Right</source>
        <translation type="unfinished">Droite</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="198"/>
        <source>Left</source>
        <translation type="unfinished">Gauche</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="247"/>
        <source>Bottom</source>
        <translation type="unfinished">Bas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Use Page Range of the currently edited Pagemark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="408"/>
        <source>Right Footer Text</source>
        <translation type="unfinished">Texte de droite du pied de page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="469"/>
        <source>Center Header Text</source>
        <translation type="unfinished">Texte du centre de l&apos;en-tête</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="439"/>
        <source>Left Footer Text</source>
        <translation type="unfinished">Texte de gauche du pied de page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="476"/>
        <source>Right Header Text</source>
        <translation type="unfinished">Texte de droite de l&apos;en-tête</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="432"/>
        <source>Center Footer Text</source>
        <translation type="unfinished">Texte du centre du pied de page</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="425"/>
        <source>Left Header Text</source>
        <translation type="unfinished">Texte de gauche de l&apos;entête</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation type="vanished">En-tête et pied de page</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="vanished">Bord en haut</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="vanished">Bord à droite</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="vanished">Bord en bas</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="vanished">Bord à gauche</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Police</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Couleur</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Dimension</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="vanished">Famille de Polices</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Supprimer</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Aucun</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Enregistrer</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation type="vanished">Texte de droite du pied de page</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation type="vanished">Texte du centre de l&apos;en-tête</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation type="vanished">Texte de gauche du pied de page</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation type="vanished">Texte de droite de l&apos;en-tête</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation type="vanished">Texte du centre du pied de page</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation type="vanished">Texte de gauche de l&apos;entête</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation type="vanished">Insérer la Date</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation type="vanished">Insérer un numéro de page</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation type="vanished">Numéro de page et format de la date</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="vanished">Options de plage de pages...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="vanished">Enregistrer les paramètres</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="vanished">Enregistrer les paramètres actuels comme :</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="vanished">Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="vanished">Ętes-vous sûr de vouloir supprimer le paramètre?</translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="vanished"> ?</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="vanished">Marges</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="vanished">Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">points</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> po</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation type="vanished">Paramètres enregistrés</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="vanished">Marges</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="vanished">Points</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="vanished">millimètres</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="vanished">Insérer les Pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de page</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Pages sélectionnées</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">à:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="vanished">Nom du fichier</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="vanished">Parcourir</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="vanished">Position</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="vanished">Après la dernière Page</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="vanished">Avant la première Page</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">Ok</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Ouvrir le Fichier</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="vanished">Fichiers PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total des pages :</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation type="vanished">Erreur de lecture : ce PDF est protégé.</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="vanished">Avant la page</translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="vanished">Après la page</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="vanished">Importer les Signets</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">Mot de passe</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="vanished">Le fichier est protégé. SVP, entrer le mot de passe pour l&apos;ouvrir :</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation type="vanished">Erreur de lecture : ce PDF est protégé.</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>Installer Langues</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>Langues</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="165"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
</context>
<context>
    <name>InteractiveCPDFReader</name>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="39"/>
        <source>Словарь в форме хранящейся в памяти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="52"/>
        <source>Команда(или help для их описания) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="88"/>
        <source>Вводимые ключи</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="101"/>
        <source>Черновик для записей</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="130"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="146"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="162"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="178"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="194"/>
        <source>5</source>
        <translation type="unfinished">5</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="207"/>
        <source>Скопировать текущий 
словарь в черновик</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>Console JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>Courir</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>Clair</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>Rester en haut</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation>Nom de la fonction</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Editeur de scripts Java</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Nom de la fonction</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>Script Java</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="126"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation>%1, ...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="205"/>
        <source>Press shortcut</source>
        <translation>Appuyer sur le raccourci</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>Raccourcis clavier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation>Réinitialiser tout</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation>Raccourci</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation>Réinitialiser</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation>Commander</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacApplication</name>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="465"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zoom Arrière</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="470"/>
        <source>Actual Size</source>
        <translation type="unfinished">Taille actuelle</translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="478"/>
        <source>Zoom In</source>
        <translation type="unfinished">Zoom Avant</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Page précédente</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Page suivante</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation type="unfinished">Système</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>Formulaires</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>Langues</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="542"/>
        <source>Highlight color</source>
        <translation>Couleur de surlignage</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="562"/>
        <source>Required field highlight color</source>
        <translation>Couleur de surlignage du champs requis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3370"/>
        <source>Please choose the interface language</source>
        <translation>Choisir la langue pour l&apos;interface</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3442"/>
        <source>Check for Updates Automatically</source>
        <translation>Vérifier automatiquement les mises à jour de Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3461"/>
        <source>Weekly</source>
        <translation>Chaque semaine</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3466"/>
        <source>Monthly</source>
        <translation>Chaque mois</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3456"/>
        <source>Never</source>
        <translation>Jamais</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="894"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1236"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2044"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2272"/>
        <source>Smooth text and images</source>
        <translation>Texte et images choisis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1324"/>
        <source>Time before a move or resize starts:</source>
        <translation>Durée avant le début de l&apos;action :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1317"/>
        <source>Select item by hovering the mouse</source>
        <translation>Sélectionner l&apos;article en survolant avec la souris</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Built-in</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="522"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3390"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Il est nécessaire de redémarrer le programme pour que les modifications prennent effet.</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="vanished">Barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Update</source>
        <translation>Mise à jour</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="vanished">Arabe</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="vanished">Bulgare</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="vanished">Catalan</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="vanished">Chinois-Simplifié</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="vanished">Chinois-Traditionnel</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="vanished">Tchèque</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="vanished">Danois</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="vanished">Hollandais</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">Anglais</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="vanished">Estonien</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="vanished">Finnois</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="vanished">Français</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="vanished">Galicien</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="vanished">Allemand</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="vanished">Grec</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="vanished">Hébreu</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="vanished">Hongrois</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="vanished">Irlandais</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="vanished">Italien</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished">Japonais</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="vanished">Coréen</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="vanished">Letton</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="vanished">Lithuanien</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="vanished">Norvégien</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="vanished">Norvégien-Ninorsk</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished">Polonais</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="vanished">Portugais</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="vanished">Portugais-Brésil</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="vanished">Roumain</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">Russe</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="vanished">Serbe</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="vanished">Slovaque</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="vanished">Slovène</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="vanished">Espagnol</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="vanished">Suèdois</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="vanished">Thaï</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="vanished">Turc</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="vanished">Ukrainien</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="vanished">Valencien</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Vietnamien</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="203"/>
        <source>Saving Documents</source>
        <translation>Sauvegarde des Documents</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Create backup file</source>
        <translation>Créer un fichier de sauvegarde</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Choisir la destination pour sauvegarder les documents</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Last used folder</source>
        <translation>Dernier répertoire utilisé</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Original documents folder</source>
        <translation>Répertoire d&apos;origine des documents</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1144"/>
        <source>Default font</source>
        <translation>Police par défaut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation>Edition</translation>
    </message>
    <message>
        <source>T_Select directory</source>
        <translation type="vanished">T_Directoire sélectionné</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2855"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2900"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1530"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1847"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1162"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1854"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2512"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="vanished">Armenien</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="151"/>
        <source>Restore last session when application start</source>
        <translation>Restaurer la dernière session au démarrage</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="158"/>
        <source>Restore last view settings when reopening</source>
        <translation>Restaurer les derniers paramètres à la réouverture</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1593"/>
        <source>Enable JavaScript</source>
        <translation>Autorise les sripts Java</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="598"/>
        <source> Always hide document message bar </source>
        <translation>Toujours cacher la barre de messages dans le document </translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2109"/>
        <source>Default Layout and Zoom</source>
        <translation>Zoom et disposition par défaut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2224"/>
        <source>Default page layout</source>
        <translation>Disposition de la page par défaut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2122"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2232"/>
        <source>Automatic</source>
        <translation>Automatique</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2204"/>
        <source>Single Page</source>
        <translation>Page Seule</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2209"/>
        <source>Facing Pages</source>
        <translation>Pages côte à côte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2255"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2127"/>
        <source>Actual Size</source>
        <translation>Taille actuelle</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="984"/>
        <source>Show warning when opening links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <source>Convert static XFA into normal PDF when opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1224"/>
        <source>Page scrolling options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <source>Configure scroll value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1297"/>
        <source>Enable scroll without delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1137"/>
        <source>Create Pencil lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1979"/>
        <source>Create Pencil and Brush lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2132"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2137"/>
        <source>Fit Width</source>
        <translation>Ajuster la Largeur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2142"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2147"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2152"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2157"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2162"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2167"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2172"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2177"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2182"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2187"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="747"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2401"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2288"/>
        <source>Bitmap Images</source>
        <translation>Images Bitmap</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2295"/>
        <source>Vector Images</source>
        <translation>Images Vectorielles</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2383"/>
        <source>Replace Document Colors</source>
        <translation>Remplacer les Couleurs du Document</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2408"/>
        <source>Page Background</source>
        <translation>Arrière-plan de la Page</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="vanished">Toujours Ouvrir l&apos;Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2425"/>
        <source>Theme</source>
        <translation>Thême</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="464"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="479"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="2041"/>
        <source>Select directory</source>
        <translation>Répertoire sélectionné</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1061"/>
        <source>Automatically change font when editing text</source>
        <translation>Changer automatiquement la police lors de l&apos;édition du texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2318"/>
        <source>Resolution</source>
        <translation>Résolution</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2334"/>
        <source>Custom</source>
        <translation>Habitude</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2324"/>
        <source>System PPI</source>
        <translation>System PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>Icons in menus</source>
        <translation>Icônes dans les menus</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Ouvrir les documents comme de nouveaux onglets dans la même fenêtre (redémarrage requis)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="342"/>
        <source>Enable scroll wheel zooming</source>
        <translation>Activer le zoom via la roulette</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1663"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2098"/>
        <source>Pop-up Opacity</source>
        <translation>Opacité de pop-up</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1564"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1820"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2075"/>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1687"/>
        <source>Sticky Note</source>
        <translation>Note</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1803"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1557"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1835"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1946"/>
        <source>Opacity</source>
        <translation>Opacité</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Highlight Text</source>
        <translation>Surligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1697"/>
        <source>Strikeout Text</source>
        <translation>Barrer le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1702"/>
        <source>Underline Text</source>
        <translation>Souligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1537"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1928"/>
        <source>Line Width</source>
        <translation>Largeur de la Ligne</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="656"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="727"/>
        <source>Check Mark</source>
        <translation>Coche</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="728"/>
        <source>Circle</source>
        <translation>Cercle</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="838"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <source>Cross</source>
        <translation>Croix</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Insérer un texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="733"/>
        <source>Key</source>
        <translation>Clé</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="734"/>
        <source>New Paragraph</source>
        <translation>Nouveau paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="735"/>
        <source>Text Note</source>
        <translation>Note de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="736"/>
        <source>Paragraph</source>
        <translation>Paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="737"/>
        <source>Right Arrow</source>
        <translation>Flèche à droite</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="738"/>
        <source>Right Pointer</source>
        <translation>Pointeur à droite</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="853"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="739"/>
        <source>Star</source>
        <translation>Etoile</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="740"/>
        <source>Up Arrow</source>
        <translation>Flèche en haut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="741"/>
        <source>Up Left Arrow</source>
        <translation>Flèche en haut à gauche</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="742"/>
        <source>Graph</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="743"/>
        <source>Paper Clip</source>
        <translation>Clip de papier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="744"/>
        <source>Attachment</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="745"/>
        <source>Tag</source>
        <translation>Marque</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1605"/>
        <source>Show errors and  messages in console</source>
        <translation>Afficher les erreurs et les messages dans la console</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="606"/>
        <source>Link</source>
        <translation>Lien</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="248"/>
        <source>Autosave interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="299"/>
        <source>Autosave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="175"/>
        <source>Show Quick actions on text and comments selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Lock file from opening by other instances of Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Enable logging to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="398"/>
        <source>Log files directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Edit Box</source>
        <translation>Champ de saisie de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="616"/>
        <source>Check box</source>
        <translation>Case à cocher</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <source>Radio button</source>
        <translation>Bouton radio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Combo box</source>
        <translation>Zone de liste modifiable</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>List box</source>
        <translation>Zone de liste</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Button</source>
        <translation>Bouton de validation</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="641"/>
        <source>Signature</source>
        <translation>Signature</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="662"/>
        <source>Borders and Colors</source>
        <translation>Bordures et Couleurs</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="669"/>
        <source>Thin</source>
        <translation>Mince</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="674"/>
        <source>Medium</source>
        <translation>Moyen</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="679"/>
        <source>Thick</source>
        <translation>Epais</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="687"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Border Color</source>
        <translation>Couleur de Bordure</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="694"/>
        <source>Fill Color</source>
        <translation>Couleur de Remplissage</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="702"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="929"/>
        <source>Solid</source>
        <translation>Solide</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="934"/>
        <source>Dashed</source>
        <translation>Pointillés</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="712"/>
        <source>Beveled</source>
        <translation>Biseauté</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="717"/>
        <source>Inset</source>
        <translation>Incruster</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="722"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="939"/>
        <source>Underline</source>
        <translation>Souligner</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="921"/>
        <source>Line Style</source>
        <translation>Style de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="737"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="900"/>
        <source>Line Thickness</source>
        <translation>Épaisseur de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Maximum CPU usage for OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3471"/>
        <source>Once in 3 months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="263"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2527"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="801"/>
        <source>Font</source>
        <translation>Police</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="947"/>
        <source>Highlight</source>
        <translation>Surligner</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="958"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="963"/>
        <source>Invert</source>
        <translation>Inverser</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="968"/>
        <source>OutLine</source>
        <translation>Contour</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Insert</source>
        <translation>Insertion</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>Style</source>
        <translation>Style</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="828"/>
        <source>Check</source>
        <translation>Vérifier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="843"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="848"/>
        <source>Square</source>
        <translation>Carré</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation>La grille</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1384"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">points</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1411"/>
        <source>Width between lines</source>
        <translation>Largeur entre les lignes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1444"/>
        <source>Height between lines</source>
        <translation>Hauteur entre les lignes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Left offset</source>
        <translation>Décalage à gauche</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1437"/>
        <source>Top offset</source>
        <translation>Décalage en haut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1451"/>
        <source>Subdivision</source>
        <translation>Subdivision</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1707"/>
        <source>Measurements</source>
        <translation>Mesures</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1712"/>
        <source>Drawing</source>
        <translation>Dessin</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1098"/>
        <source>Selected text color</source>
        <translation>Couleurs de texte sélectionnées</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>Default</source>
        <translation>Par défaut</translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="vanished">Style sombre</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2431"/>
        <source>Application Style</source>
        <translation>Style d&apos;application</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2610"/>
        <source>Use default program</source>
        <translation>Utiliser un programme par défaut</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>evolution</source>
        <translation>évolution</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2634"/>
        <source>kmail</source>
        <translation>kmail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2639"/>
        <source>thunderbird</source>
        <translation>thunderbird</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2647"/>
        <source>Use SMTP</source>
        <translation>Utiliser SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2670"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2758"/>
        <source>Email address</source>
        <translation>Adresse e-mail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Secure connections</source>
        <translation>Connexions sécurisées</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2726"/>
        <source>NONE</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2736"/>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2718"/>
        <source>SMTP server</source>
        <translation>Serveur SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2744"/>
        <source>SMTP port</source>
        <translation>Port SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2691"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3101"/>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2950"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>Chemin d&apos;accès par défaut aux fichiers de données tesseract ocr</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2923"/>
        <source>Additional tesseract ocr config file</source>
        <translation>Fichier de configuration Tesseract ocr supplémentaire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2943"/>
        <source>Install languages</source>
        <translation>Installer les langues</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="501"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1929"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1949"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1969"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1391"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1484"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1520"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation>Réseau</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1615"/>
        <source>Enable safe reading mode</source>
        <translation>Activer le mode de lecture sécurisé</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2980"/>
        <source>Direct internet connection</source>
        <translation>Connexion Internet directe</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2990"/>
        <source>Manual proxy configuration</source>
        <translation>Configuration du proxy manuel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3006"/>
        <source>HTTP Proxy</source>
        <translation>Proxy HTTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3013"/>
        <source>SOCKS 5 Proxy</source>
        <translation>Proxy SOCKS 5</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3023"/>
        <source>Host</source>
        <translation>Hôte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3033"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2679"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3076"/>
        <source>Authentication</source>
        <translation>Authentification</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3091"/>
        <source>User name</source>
        <translation>Nom d&apos;utilisateur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2519"/>
        <source>Icon set</source>
        <translation>Ensemble d&apos;icônes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation>Clavier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="349"/>
        <source>Show Start page</source>
        <translation>Afficher la Page de Démarrage</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1419"/>
        <source>Points</source>
        <translation>Points</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1424"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1429"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="450"/>
        <source>Load all objects separately</source>
        <translation>Charger tous les objets séparément</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1353"/>
        <source>Always show Object Inspector</source>
        <translation>Toujours Ouvrir l&apos;Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2262"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Interdire les fichiers pour activer le mode Plein écran lors de l&apos;ouverture</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1717"/>
        <source>Typewriter</source>
        <translation>Machine à écrire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>Light</source>
        <translation>Clair</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>Dark</source>
        <translation>Sombre</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <source>Exact match only</source>
        <translation>Correspondance exacte seulement</translation>
    </message>
    <message>
        <source>Redation</source>
        <translation type="vanished">Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation>Certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1360"/>
        <source>Save last editing Tool</source>
        <translation>Enregistrer le dernier outil d&apos;édition</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3228"/>
        <source>Default paths for system certificates</source>
        <translation>Chemins par défaut pour les certificats système</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3176"/>
        <source>Certificate Manager</source>
        <translation>Gestionnaire de certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="810"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>Sous Windows, tous les certificats sont placés dans le système de stockage.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="421"/>
        <source>Alternative method for PDF render</source>
        <translation>Méthode alternative pour le rendu PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="473"/>
        <source>Memory/Speed</source>
        <translation>Mémoire/Vitesse</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="480"/>
        <source>Minimize memory usage</source>
        <translation>Minimize l&apos;usage de la mémoire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="485"/>
        <source>Maximal render speed</source>
        <translation>Vitesse de rendu maximale</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="829"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1139"/>
        <source>System Theme</source>
        <translation>Thème du système</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3238"/>
        <source>Database for Certificate Manager</source>
        <translation>Base de données pour le gestionnaire de certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3298"/>
        <source>Password:</source>
        <translation>Mot de passe :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3254"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3271"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3305"/>
        <source>Path for DB:</source>
        <translation>Chemin pour DB :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation>Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="815"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>Sous macOS, tous les certificats sont placés dans le système de stockage.</translation>
    </message>
    <message>
        <source>Farsi</source>
        <translation type="vanished">Farsi</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation>Autorise l&apos;ouverture du même document dans plusieurs onglets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="998"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1004"/>
        <source>Add full path to filename in export file</source>
        <translation>Ajouter le chemin complet au nom du fichier dans le fichier d&apos;exportation</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="991"/>
        <source>Recreate pdf forms when opening</source>
        <translation>Recréer des formulaires pdf lors de l&apos;ouverture</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="830"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1143"/>
        <source>Light Theme</source>
        <translation>Thème clair</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="831"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1147"/>
        <source>Dark Theme</source>
        <translation>Thème sombre</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation>Barres d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2499"/>
        <source>Standard</source>
        <translation>La norme</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2504"/>
        <source>Office Pro</source>
        <translation>Office Pro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1367"/>
        <source>Edit Text Elements as Blocks</source>
        <translation>Modifier des éléments de texte sous forme de blocs</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2041"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2489"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2532"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2537"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Save recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2217"/>
        <source>Navigation Tab</source>
        <translation>Onglet Navigation</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Page Only</source>
        <translation>Page Seulement</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Bookmarks Panel</source>
        <translation>Panneau des Signets</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2247"/>
        <source>Pages Panel</source>
        <translation>Panneau des Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3334"/>
        <source>Strong verification of signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="255"/>
        <source>PDF Specification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Général</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulaires</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Langues</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Couleur de Surlignage</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Surligner les champs requis</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Choisissez la langue de votre choix pour l&apos;interface</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Vérifier automatiquement les mises à jour de Master PDF Editor</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Chaque semaine</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Chaque mois</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Jamais</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Paramètres</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Parcourir</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Style</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Supprimer l&apos;Objet</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="139"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="159"/>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Save As...</source>
        <translation>Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="896"/>
        <source>Print</source>
        <translation>Imprimer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2432"/>
        <source>Recent Files</source>
        <translation>Fichiers récents</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="743"/>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Exit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="938"/>
        <source>Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Select All</source>
        <translation>Tout sélectionner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>First Page</source>
        <translation>Première Page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Previous Page</source>
        <translation>Page précédente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Next Page</source>
        <translation>Page suivante</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Last Page</source>
        <translation>Dernière Page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="207"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="604"/>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <source>Zoom In</source>
        <translation>Zoom Avant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Zoom Out</source>
        <translation>Zoom Arrière</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Actual Size</source>
        <translation>Taille actuelle</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="291"/>
        <source>Toolbars</source>
        <translation>Barres d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <source>Statusbar</source>
        <translation>Barre d&apos;état</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="289"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <source>Tools</source>
        <translation>Outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>Hand Tool</source>
        <translation>Outil Main</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Register...</source>
        <translation>Enregistrement...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Rechercher des mises à jour</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">Exporter vers</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <location filename="../../src/mainwindow.ui" line="771"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Agrandir les Miniatures de Page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Réduire les Miniatures de Page</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Insérer des Pages du PDF</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Extraire des Pages vers PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Highlight Fields</source>
        <translation>Surligner tous les Champs</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <location filename="../../src/mainwindow.cpp" line="5944"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1127"/>
        <source>Properties</source>
        <translation>Propriétés</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Sélectionner la plage de page</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Toutes les pages</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Page courante</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Uni</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Italique</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Gras</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Gras Italique</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2003"/>
        <source>Bookmarks</source>
        <translation>Signets</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Insertion</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1161"/>
        <source>Highlight Text</source>
        <translation>Surligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <source>Underline Text</source>
        <translation>Souligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1169"/>
        <source>Strikeout Text</source>
        <translation>Barrer le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2011"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="71"/>
        <source>Attachment</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>Check box</source>
        <translation>Case à cocher</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1278"/>
        <source>Radio button</source>
        <translation>Bouton radio</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <location filename="../../src/mainwindow.ui" line="1302"/>
        <source>Button</source>
        <translation>Bouton de validation</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>List box</source>
        <translation>Zone de liste</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1286"/>
        <source>Combo box</source>
        <translation>Zone de liste modifiable</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Edit Box</source>
        <translation>Champ de saisie de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2802"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Enregistrer les modifications dans %s avant de fermer ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="279"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="58"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Aide...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2619"/>
        <source>Cannot open file :
</source>
        <translation>Impossible d&apos;ouvrir le fichier : 
</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="203"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <source>View</source>
        <translation>Affichage</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <source>Edit</source>
        <translation>Edition</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">Il n&apos;y a pas de mise à jour disponible !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Edit Document</source>
        <translation>Éditer le document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1242"/>
        <source>Link</source>
        <translation>Lien</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="426"/>
        <location filename="../../src/mainwindow.ui" line="1386"/>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>Add Sticky Note</source>
        <translation>Ajouter Note</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Note</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <location filename="../../src/mainwindow.cpp" line="5976"/>
        <source>Image</source>
        <translation>Image</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="590"/>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="709"/>
        <source>There was an error opening the document !</source>
        <translation>Une erreur s&apos;est produite à l&apos;ouverture du document !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1075"/>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <source>Page layout</source>
        <translation>Format de la Page</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Insérer une Page vierge </translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Insérer des Pages vierges</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Supprimer les Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1995"/>
        <source>Pages</source>
        <translation>Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Undo</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Redo</source>
        <translation>Rétablir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="880"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Create a new blank PDF</source>
        <translation>Créer un PDF vierge</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="505"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimer (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimer le document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="732"/>
        <location filename="../../src/mainwindow.ui" line="735"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1191"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <source>Send to Back</source>
        <translation>Placer Derrière</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Placer Derrière&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Placer l&apos;Objet sélectionné Derrière.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Send to Background</source>
        <translation type="vanished">Placer à l&apos;Arrière-plan</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="vanished">Placer Devant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Del</source>
        <translation>Suppr</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Alt+Del</source>
        <translation>Alt+Suppr</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_mac_tool_bars.cpp" line="20"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Images</source>
        <translation>Images</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1325"/>
        <source>Home page</source>
        <translation>Page d&apos;accueil sur internet</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Annuler (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Annuler la dernière action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="635"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Contents</source>
        <translation>Contenu sur internet</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Refaire (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Refaire la dernière action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couper (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Couper les Objets sélectionnés pour les avoir en mémoire vive&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copier (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copier les Objets sélectionnés pour les avoir en mémoire vive&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="796"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Select Text</source>
        <translation>Sélectionner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2618"/>
        <source>Open failed</source>
        <translation>Problème à l&apos;ouverture</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="232"/>
        <source>Empty recent files list</source>
        <translation>Vider la liste des fichiers récents</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation type="vanished">Exportation complétée</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1081"/>
        <location filename="../../src/mainwindow.cpp" line="1212"/>
        <location filename="../../src/mainwindow.cpp" line="3025"/>
        <location filename="../../src/mainwindow.cpp" line="4331"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <location filename="../../src/mainwindow.cpp" line="4569"/>
        <source>Save failed</source>
        <translation>La Sauvegarde a échoué</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossible de sauvegarder vers le fichier :</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6062"/>
        <location filename="../../src/mainwindow.cpp" line="6064"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>Open File</source>
        <translation>Ouvrir un fichier</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="vanished">Tous les fichiers (*.pdf *.xps);;Fichiers PDF (*.pdf);;Fichiers XPS (*.xps)</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Propriétés du document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>Find</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>Find Next (F3)</source>
        <translation type="vanished">Rechercher Suivant (F3)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Find Next</source>
        <translation>Rechercher Suivant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1620"/>
        <location filename="../../src/mainwindow.cpp" line="1647"/>
        <source>Can&apos;t find :</source>
        <translation>Impossible de trouver :</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="57"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Une nouvelle version est disponible !
La télécharger ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>Close Without Saving</source>
        <translation>Fermer sans Sauvegarder</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2813"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <location filename="../../src/mainwindow.ui" line="1089"/>
        <source>Rotate Pages</source>
        <translation>Rotation des Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Move Pages</source>
        <translation>Déplacer les Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1930"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Edit Text</source>
        <translation>Editer le texte</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">Description</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="237"/>
        <location filename="../../src/mainwindow.ui" line="2019"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Object Inspector</source>
        <translation>Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1117"/>
        <location filename="../../src/mainwindow.cpp" line="7130"/>
        <location filename="../../src/mainwindow.cpp" line="7192"/>
        <location filename="../../src/mainwindow.cpp" line="7341"/>
        <source>untitled</source>
        <translation>Sans titre</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="vanished">La version non enregistrée va insérer un filigrane</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>Align Objects</source>
        <translation>Aligner les Objets</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Maj+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1210"/>
        <location filename="../../src/mainwindow.ui" line="1213"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <location filename="../../src/mainwindow.ui" line="1705"/>
        <source>Line</source>
        <translation>Ligne</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1218"/>
        <location filename="../../src/mainwindow.ui" line="1221"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <location filename="../../src/mainwindow.ui" line="1727"/>
        <source>Rectangle</source>
        <translation>Rectangle</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1226"/>
        <location filename="../../src/mainwindow.ui" line="1229"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Ellipse</source>
        <translation>Ellipse</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Vue avant Impression</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Left</source>
        <translation>Aligner à Gauche</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>Align Right</source>
        <translation>Aligner à Droite</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1048"/>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Align Top</source>
        <translation>Aligner en Haut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Align Bottom</source>
        <translation>Aligner en Bas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1307"/>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Signature</source>
        <translation>Signature</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <location filename="../../src/mainwindow.ui" line="966"/>
        <source>Set Fit to Page</source>
        <translation>Ajuster à la Page</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">Modifier les Outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3066"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Une erreur est survenue pendant la vérification de la signature !</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Coller (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Coller les Objets sélectionnés à partir de la mémoire vive&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="167"/>
        <source>Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="245"/>
        <source>Navigation Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Forms</source>
        <translation>Formulaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="510"/>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Home</source>
        <translation>Site</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>Reset Forms</source>
        <translation>Réinitialiser les Formulaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Fit Width</source>
        <translation>Ajuster la Largeur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="757"/>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Facing Pages</source>
        <translation>Pages face à face</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Delete Pages</source>
        <translation>Supprimer les Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Edit Forms</source>
        <translation>Editer les Formulaires</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nouveau (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Créer un nouveau PDF vierge&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <source>Bring to Front</source>
        <translation>Placer Devant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Placer en Avant&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Placer l&apos;Objet sélectionné en Avant.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert a Blank Pages</source>
        <translation type="vanished">Insérer des Pages vierges</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1097"/>
        <location filename="../../src/mainwindow.ui" line="1100"/>
        <source>Extract Pages...</source>
        <translation>Extraire des Pages...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1108"/>
        <location filename="../../src/mainwindow.ui" line="1111"/>
        <source>Insert Pages...</source>
        <translation>Insérer des Pages...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <location filename="../../src/mainwindow.ui" line="1237"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <location filename="../../src/mainwindow.ui" line="1749"/>
        <source>Pencil</source>
        <translation>Crayon</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1159"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Fichiers PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Open a PDF file</source>
        <translation>Ouvrir un fichier PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>PgUp</source>
        <translation>PageHaut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>PgDown</source>
        <translation>PageBas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1262"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="vanished">Sauvegarder en XPS est provisoirement non supporté.
Choisir un nom de fichier PDF pour enregistrer.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="vanished">Ouvrir l&apos;Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation>Couper les Pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">Précédent/Suivant</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">Page :</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1906"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="649"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Maj+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1056"/>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <source>Insert Blank Pages</source>
        <translation>Insérer des Pages vierges</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Maj+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1410"/>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Rotation de 90 degrés dans le sens des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1418"/>
        <location filename="../../src/mainwindow.ui" line="1421"/>
        <location filename="../../src/mainwindow.ui" line="1424"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Rotation de 90 degrés dans le sens inverse des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation type="vanished">Ctrl+Maj++</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation type="vanished">Ctrl+Maj+-</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation type="vanished">FDF</translation>
    </message>
    <message>
        <source>Export Data...</source>
        <translation type="vanished">Exporter les données de formulaire...</translation>
    </message>
    <message>
        <source>Import Data...</source>
        <translation type="vanished">Importer des données de formulaire...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7139"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7201"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Fichiers FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <source>Export Form Data...</source>
        <translation>Exporter les données de formulaire...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1434"/>
        <source>Import Form Data...</source>
        <translation>Importer les données de formulaire...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1439"/>
        <source>Export Comments Data...</source>
        <translation>Exporter les commentaires...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1444"/>
        <source>Import Comments Data...</source>
        <translation>Importer les commentaires...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="544"/>
        <source>Select text for copying and pasting</source>
        <translation>Sélectionner le texte pour copier et coller</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Save the document</source>
        <translation>Sauvegarde du Document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="710"/>
        <source>Save the document with a new name</source>
        <translation>Enregistrer le document avec un nouveau nom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>Print the document</source>
        <translation>Impression du document</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modifier le document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner et modifier le texte, les images, les annotations, les champs de formulaire ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="793"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Sélectionner et modifier le texte, les images, les annotations, les champs de formulaire ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="810"/>
        <source>Select text for editing</source>
        <translation>Sélectionner le texte pour l&apos;édition</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Supprimer les objets actuellement sélectionnés</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nouveau (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Créer un nouveau PDF vierge&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="916"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Couper les objets sélectionnés et les placer dans le Presse-papiers</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="930"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Copier les objets sélectionnés et les placer dans le Presse-papiers</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Paste from the Clipboard</source>
        <translation>Coller depuis le Presse-papiers</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <source>Undo the last action</source>
        <translation>Annuler la dernière action</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Redo the previously undone action.</source>
        <translation>Rétablir l&apos;action précédemment annulée.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Send to Back selected object.</source>
        <translation>Placer à l&apos;arrière l&apos;objet sélectionné.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Bring to Front selected object.</source>
        <translation>Placer à l&apos;avant l&apos;objet sélectionné.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Open window with document properties</source>
        <translation>Propriétés du Document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cliquer sur la page pour ajouter une note à cet endroit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <source>Click the page to add a note at that position</source>
        <translation>Cliquer sur la page pour ajouter une note à cet endroit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Insert new text to current page</source>
        <translation>Insérer un nouveau texte dans la page actuelle</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>Insert new image to current page</source>
        <translation>Insérer une nouvelle image dans la page actuelle</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>Insert new link to current page</source>
        <translation>Insérer un nouveau lien vers la page actuelle</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sélectionner le texte (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le texte pour copier et coller&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Maj+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Maj+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Maj+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1449"/>
        <source>Save Optimized As...</source>
        <translation>Fichier PDF optimisé...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation type="vanished">Caractères</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5939"/>
        <source>Font type</source>
        <translation>Type de police</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5941"/>
        <source>Font Embedded</source>
        <translation>Police intégrée</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5950"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5959"/>
        <source> in</source>
        <translation type="unfinished"> po</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5967"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5972"/>
        <location filename="../../src/mainwindow.cpp" line="6196"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5973"/>
        <location filename="../../src/mainwindow.cpp" line="6197"/>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5974"/>
        <source>Filter</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5980"/>
        <source>Path</source>
        <translation>Chemin</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5984"/>
        <source>Shading</source>
        <translation>Ombrer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="1946"/>
        <source>Objects</source>
        <translation>Objets</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6224"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6005"/>
        <location filename="../../src/mainwindow.cpp" line="6211"/>
        <source>Selected</source>
        <translation>Sélectionné</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1463"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5943"/>
        <source>Font Not Embedded</source>
        <translation>Police non intégrée</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Formulaire d&apos;édition (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le formulaire et les annotations pour l&apos;édition&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modifier l&apos;objet texte(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le texte pour l&apos;édition&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Outil manuel (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Utiliser l&apos;outil manuel pour déplacer des pages, ouvrir des liens et sélectionner un texte&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="624"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1476"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1481"/>
        <source>Document Actions</source>
        <translation>Actions de document</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Replace Document Colors</source>
        <translation>Remplacer les Couleurs du Document</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">Vue avant Impression</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Paste to Multiple Pages</source>
        <translation>Coller sur plusieurs pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2069"/>
        <location filename="../../src/mainwindow.ui" line="2072"/>
        <source>Paste at Copy Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2075"/>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Maj+V</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation type="vanished">La version installée de Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>JavaScript Console</source>
        <translation>Console JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>Page Properties</source>
        <translation>Propriétés de la page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1521"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Maj+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF Editor ne trouve pas les en-têtes et les pieds de page dans le document.</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="vanished">Supprimer les en-têtes et les pieds de page du document ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="376"/>
        <source>Watermark</source>
        <translation>Filigrane</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Background</source>
        <translation>Arrière-plan</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="430"/>
        <source>Measurements</source>
        <translation>Mesures</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <location filename="../../src/mainwindow.cpp" line="3180"/>
        <source>Drawing</source>
        <translation>Dessin</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Ctrl+Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1537"/>
        <source>Menu Bar</source>
        <translation>Barre de menu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1540"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>Show Cover Page During Facing</source>
        <translation>Afficher la page de couverture pendant la mise en face</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Full Screen</source>
        <translation>Plein Ecran</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1559"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Maj+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Maj+B</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1590"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Align Center Horizontal</source>
        <translation>Aligner le centre horizontal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Vertical</source>
        <translation>Aligner le centre vertical</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <source>Find Previous</source>
        <translation>Rechercher Précédent</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Shift+F3</source>
        <translation>Maj+F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1619"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Courrier électronique&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Envoyer un fichier par courrier électronique&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <location filename="../../src/mainwindow.ui" line="1644"/>
        <source>Grid</source>
        <translation>Grille</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1647"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Snap to Grid</source>
        <translation>Aligner sur la grille</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1661"/>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Maj+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <location filename="../../src/mainwindow.ui" line="1672"/>
        <source>Distance Tool</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <location filename="../../src/mainwindow.ui" line="1683"/>
        <source>Perimeter Tool</source>
        <translation>Périmètre</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <location filename="../../src/mainwindow.ui" line="1694"/>
        <source>Area Tool</source>
        <translation>Région</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <location filename="../../src/mainwindow.ui" line="1716"/>
        <source>Arrow</source>
        <translation>Flèche</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <location filename="../../src/mainwindow.ui" line="1760"/>
        <source>Attach a File as a Comment</source>
        <translation>Joindre un fichier en tant que commentaire</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1987"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2027"/>
        <source>Signatures</source>
        <translation type="unfinished">Signatures</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2035"/>
        <source>Layers</source>
        <translation type="unfinished">Couches</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2043"/>
        <source>Object TreeView</source>
        <translation type="unfinished">Objet vue arborescente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2051"/>
        <source>Document Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2056"/>
        <source>Organize Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2064"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished">Modifier des éléments de texte sous forme de blocs</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2080"/>
        <source>Pages to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2088"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2096"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2101"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2104"/>
        <source>Manage Header And Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2109"/>
        <source>Add To Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2114"/>
        <source>Open session from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2119"/>
        <source>Save session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2124"/>
        <source>Managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2129"/>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2134"/>
        <source>Action</source>
        <translation type="unfinished">Action</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2139"/>
        <source>Clear recent sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2144"/>
        <source>Save session to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2149"/>
        <source>Current Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2154"/>
        <source>Save session to managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2159"/>
        <source>Save and close current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2164"/>
        <source>Delete across pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3606"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor ne peut pas trouver de filigrane dans le document.</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="vanished">Supprimer les filigranes du document ?</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="vanished">Master PDF Editor ne peut pas trouver d&apos;arrière-plan dans le document.</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="vanished">Supprimer l&apos;arrière-plan du document ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Blank PDF</source>
        <translation>PDF Vierge</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <source>From Scanner</source>
        <translation>À partir du scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <location filename="../../src/mainwindow.ui" line="1771"/>
        <source>Create a new document from scanner</source>
        <translation>Créer un nouveau document à partir du scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <source>From Files</source>
        <translation>A partir de fichiers</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <location filename="../../src/mainwindow.ui" line="1782"/>
        <source>Create a new document from files</source>
        <translation>Créer un document à partir de fichiers</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="obsolete">Fichiers Images (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">Tampon</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <location filename="../../src/mainwindow.ui" line="1801"/>
        <source>Brush</source>
        <translation>Pinceau</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ouvrir un fichier (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ouvrir un fichier PDF ou XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enregistrer (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Enregistrer le document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enregistrer comme PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Enregistrer le document avec un nouveau nom&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Supprimer l&apos;objet (les objets) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Supprimer les objets actuellement sélectionnés&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nouveau (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Créer un nouveau PDF vierge&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer un texte (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer un nouveau texte dans la page actuelle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer une image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer une nouvelle image dans la page actuelle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer un lien (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer une nouvelle lien dans la page actuelle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propriétés (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ouvrir la fenętre avec les propriétés du document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="367"/>
        <source>Header and Footer</source>
        <translation>En-tête et pied de page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>Check Box</source>
        <translation>Case à cocher</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Radio Button</source>
        <translation>Bouton radio</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Combo Box</source>
        <translation>Zone de liste modifiable</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <source>List Box</source>
        <translation>Zone de liste</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Text Field</source>
        <translation>Champ de saisie de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1820"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5938"/>
        <source>Characters</source>
        <translation>Caractères</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Tous les fichiers (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="215"/>
        <source>Page Display</source>
        <translation>Affichage de page</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Go To</source>
        <translation>Navigation de pages</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1721"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Il est nécessaire de redémarrer le programme pour que les modifications prennent effet.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1633"/>
        <source>Send file via email</source>
        <translation>Envoyer un fichier par courrier électronique</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation type="vanished">Tous les fichiers pris en charge (*.pdf *.xps);;Fichiers PDF (*.pdf);;Fichiers XPS (*.xps) Tous les fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Callout</source>
        <translation>Faire appel à</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1835"/>
        <source>Formatted Text</source>
        <translation>Texte formaté</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Texte formaté&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer un nouveau texte formaté dans la page actuelle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Typewriter</source>
        <translation>Machine à écrire</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Default</source>
        <translation>Par défaut</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Formulaire d&apos;édition (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le formulaire pour l&apos;édition&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <location filename="../../src/mainwindow.ui" line="1877"/>
        <source>Redaction</source>
        <translation>Rédaction</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+6)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Outil manuel (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Utiliser l&apos;outil manuel pour déplacer des pages, ouvrir des liens et sélectionner un texte&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {6)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+7)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sélectionner le texte (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le texte pour copier et coller&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {7)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <source>Alt+7</source>
        <translation>Alt+7</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <source>Check for Updates</source>
        <translation>Chercher des mises à jour</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Mark for Redaction</source>
        <translation>Marquer pour la rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1851"/>
        <source>Apply Redactions</source>
        <translation>Appliquer les  Rédactions</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1856"/>
        <source>Redaction Properties</source>
        <translation>Propriétés de Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1864"/>
        <source>Show Redaction ToolBar</source>
        <translation>Montrer la barre d&apos;outils de Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1869"/>
        <source>Search and Redact</source>
        <translation>Rechercher et rédiger</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1882"/>
        <source>Certificate Manager</source>
        <translation>Gestionnaire de Certificats</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1887"/>
        <source>Send Backward</source>
        <translation>Placer Derrière</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1892"/>
        <source>Bring Forward</source>
        <translation>Placer Devant</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1900"/>
        <source>Edit Vector Images</source>
        <translation>Editer  les Images Vectorielles</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1911"/>
        <source>Next View</source>
        <translation>Vue suivante</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1916"/>
        <source>Previous View</source>
        <translation>Vue précédente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1924"/>
        <source>Edit Images</source>
        <translation>Editer les Images</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1935"/>
        <location filename="../../src/mainwindow.cpp" line="3307"/>
        <source>Show Comments List</source>
        <translation>Afficher la liste des commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="462"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation>Vous n&apos;avez pas les droits d&apos;accès à ce document encrypté.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="464"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>C&apos;est encrypté avec un certificat absent du système.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="477"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1043"/>
        <source>File is opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1045"/>
        <source>Use Save As... to save your work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2897"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3147"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="100"/>
        <source>All Reviewers</source>
        <translation>Tous les évaluateurs</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3285"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="80"/>
        <source>Hide All Comments</source>
        <translation>Cacher tous les commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3290"/>
        <source>Show All Comments</source>
        <translation>Montrer tous les commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3592"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3627"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3634"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5319"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>Master PDF Editor ne peut trouver aucune Rédaction dans le document !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6199"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6900"/>
        <source>Failed to restore last open session:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7437"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7438"/>
        <source>Document doesn&apos;t contain any tables with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="79"/>
        <source>Comment View</source>
        <translation>Voir les commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="93"/>
        <source>Show by Type</source>
        <translation>Afficher par Type</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3171"/>
        <source>All Types</source>
        <translation>Tous les Types</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3176"/>
        <source>Notes</source>
        <translation>Notes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3184"/>
        <source>Text Editing Markups</source>
        <translation>Edition de textes des Balises</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3188"/>
        <source>Stamps</source>
        <translation>Timbres</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3192"/>
        <source>Attachments</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="97"/>
        <source>Show by Reviewer</source>
        <translation>Montrer par évaluateur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="107"/>
        <source>Show by Status</source>
        <translation>Afficher par Statut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3217"/>
        <source>All Status</source>
        <translation>Tous les Statuts</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3222"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Montrer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="45"/>
        <source>You already have the latest version!</source>
        <translation>Vous avez déjà la dernière version !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>Tous les fichiers supportés (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;Fichiers PDF (*.pdf *.PDF);;Fichiers FDF (*.fdf *.FDF);;Fichiers XPS (*.xps *.XPS);;Fichiers TIFF (*.tif *.tiff);;Tous les Fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3303"/>
        <source>Hide Comments List</source>
        <translation>Masquer la liste des commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>File is locked by another Master PDF Editor instance, it will be opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="433"/>
        <source>You will be able to save your work, but only to another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="vanished">pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="616"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="635"/>
        <source>Place Initials</source>
        <translation>Placer les Initiales</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="617"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="636"/>
        <source>Create New Initials</source>
        <translation>Créer de nouvelles Initiales</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="619"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="638"/>
        <source>Open Containing Folder</source>
        <translation>Ouvrir le Répertoire</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ouvrir le Fichier&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ouvrir un fichier PDF ou XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Outil Main&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Utiliser l&apos;Outil Main pour déplacer les pages, ouvrir les liens et sélectionner du texte.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sélectionner le Texte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le texte pour copier et coller&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sauvegarde&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sauvegarder le document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sauvegarder Sous...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sauvegarder le document avec un nouveau nom&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>System Print...</source>
        <translation>Système d&apos;impression ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Dialogue du Système d&apos;impression&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimante utilisant un dialogue avec le Système...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editer le Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner et éditer texte, images, annotations, champs de formulaire ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editeur de Texte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le texte pour l&apos;éditer&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Supprimer le ou les Objet(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Supprimer le ou les Objets actuellement sélectionnés&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editer les Formulaires&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner le formulaire pour l&apos;éditer&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nouveau&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Créer un nouveau PDF vierge&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimer&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimer le document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="913"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couper&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Couper les objets sélectionnés et les placer dans le Presse-papiers&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copier&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copier les objets sélectionnés et les placer dans le Presse-papiers&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Coller&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Coller depuis le Presse-papiers&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Annuler&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Annuler la dernière action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Refaire&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Refaire l&apos;action annulée.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1130"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propriétés&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Ouvrir la fenêtre avec les  propriétés du document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer un Texte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer le nouveau texte dans la page courante&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer une Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer la nouvelle image dans la page courante&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insérer un lien&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insérer le nouveau lien dans la page courante&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editer des Images Vectorielles&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner des Images vectorielles pour les éditer&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editer des Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Sélectionner des Images bitmap pour les éditer&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="149"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Pages to Images</source>
        <translation>Pages vers Images</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Pages to Text</source>
        <translation>Pages vers Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1951"/>
        <source>Extract all Images</source>
        <translation>Extraire toutes les Images</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1434"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Images PNG (*.png);;Images BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1956"/>
        <source>Reload</source>
        <translation>Recharger</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1964"/>
        <source>Take a Snapshot</source>
        <translation>Prendre un instantané</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="249"/>
        <source>Red</source>
        <translation>Rouge</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="254"/>
        <source>Blue</source>
        <translation>Bleu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="259"/>
        <source>Yellow</source>
        <translation>Jaune</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="264"/>
        <source>Green</source>
        <translation>Vert</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="63"/>
        <source>What&apos;s new</source>
        <translation>Quoi de neuf</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="551"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>Le fichier que vous essayez d&apos;ouvrir contient des commentaires ou un formulaire censés être inserrés.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>This document cannot be found.</source>
        <translation>Ce document est introuvable</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>Voulez-vous parcourir et tenter de localiser le document ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1672"/>
        <source>Saved Settings</source>
        <translation>Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="26"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation>Impossible de se connecter ! Vérifier que la connection avec Internet est correcte et refaire la recherche des mises à jour.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1969"/>
        <source>Toolbar Settings</source>
        <translation>Paramètres des barres d&apos;outils</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Courrier électronique</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insérer un texte</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Note</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="vanished">Page Seule</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1977"/>
        <source>Continuous</source>
        <translation>En continu</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Bloc de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <source>Insert Initials</source>
        <translation>Insérer les initiales</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5159"/>
        <location filename="../../src/mainwindow.cpp" line="5181"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Réinitialiser toutes les barres d&apos;outils aux paramètres par défaut ?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="302"/>
        <source>Reset toolbars</source>
        <translation>Réinitialiser les barres d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Minimum tools</source>
        <translation type="unfinished">Minimum d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="61"/>
        <source>New Paragraph</source>
        <translation type="unfinished">Nouveau paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="114"/>
        <source>Delete All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="116"/>
        <source>Delete All Visible Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="299"/>
        <source>Maximum tools</source>
        <translation type="unfinished">Maximum d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="82"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="250"/>
        <location filename="../../src/mainwindow_update.cpp" line="357"/>
        <source>Error</source>
        <translation type="unfinished">Erreur</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="252"/>
        <location filename="../../src/mainwindow_update.cpp" line="359"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished">L&apos;activation a échoué ! Vérifier la connexion Internet.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="297"/>
        <source>License is expired!</source>
        <translation type="unfinished">La licence est expirée !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="71"/>
        <location filename="../../src/mainwindow_update.cpp" line="300"/>
        <location filename="../../src/mainwindow_update.cpp" line="504"/>
        <source>Renew</source>
        <translation type="unfinished">Renouveler</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="68"/>
        <source>WARNING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="338"/>
        <source>Too many activations!</source>
        <translation type="unfinished">Trop d&apos;activations !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="394"/>
        <source>Server connection lost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="445"/>
        <source>Failed to connect to License server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="516"/>
        <source>Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <source>Label</source>
        <translation type="unfinished">Étiquette</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6222"/>
        <source>Rotate</source>
        <translation type="unfinished">Rotation</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="54"/>
        <source>Check Mark</source>
        <translation type="unfinished">Coche</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="55"/>
        <source>Circle</source>
        <translation type="unfinished">Cercle</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="56"/>
        <source>Comment</source>
        <translation type="unfinished">Commentaire</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="57"/>
        <source>Cross</source>
        <translation type="unfinished">Croix</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="60"/>
        <source>Key</source>
        <translation type="unfinished">Clé</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="62"/>
        <source>Text Note</source>
        <translation type="unfinished">Note de texte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="63"/>
        <source>Paragraph</source>
        <translation type="unfinished">Paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Right Arrow</source>
        <translation type="unfinished">Flèche à droite</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="65"/>
        <source>Right Pointer</source>
        <translation type="unfinished">Pointeur à droite</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="66"/>
        <source>Star</source>
        <translation type="unfinished">Etoile</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="67"/>
        <source>Up Arrow</source>
        <translation type="unfinished">Flèche en haut</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="68"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished">Flèche en haut à gauche</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="69"/>
        <source>Graph</source>
        <translation type="unfinished">Graphique</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="70"/>
        <source>Paper Clip</source>
        <translation type="unfinished">Clip de papier</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="72"/>
        <source>Tag</source>
        <translation type="unfinished">Marque</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1982"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="62"/>
        <source>Failed opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="67"/>
        <source>File is already opened and opening same file in multiple tabs option is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="72"/>
        <source>File does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="319"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="323"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>Current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="376"/>
        <source>Error loading session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="20"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Zoom Arrière</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="27"/>
        <source>Close</source>
        <translation type="unfinished">Fermer</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="34"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="41"/>
        <source>Remove</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="48"/>
        <source>Zoom In</source>
        <translation type="unfinished">Zoom Avant</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished">Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="65"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="72"/>
        <source>Zoom Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="79"/>
        <source>Show</source>
        <translation type="unfinished">Montrer</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="14"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="82"/>
        <source>Manage Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="113"/>
        <source>All</source>
        <translation type="unfinished">Tout</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="117"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="510"/>
        <source>Header and Footer</source>
        <translation type="unfinished">En-tête et pied de page</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="119"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="513"/>
        <source>Bates Numbering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="263"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="516"/>
        <source>Type</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="517"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="518"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="519"/>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Left</source>
        <translation type="unfinished">Gauche</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Center</source>
        <translation type="unfinished">Centrer</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Right</source>
        <translation type="unfinished">Droite</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="525"/>
        <source>Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="635"/>
        <source>Remove Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="639"/>
        <source>Do you want to remove selected Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="643"/>
        <source>Do you want to remove selected headers/footers from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="657"/>
        <source>Remove all Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="658"/>
        <source>Do you want to remove all headers, footers and Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>Texte reconnu</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="25"/>
        <source>Not Text</source>
        <translation>Pas du texte</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Déplacer les Pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page Courante</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="43"/>
        <source>Destination</source>
        <translation>Destination</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="55"/>
        <source>To:</source>
        <translation>A :</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="65"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>First</source>
        <translation>Première</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="121"/>
        <source>Last</source>
        <translation>Dernière</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Move Pages</source>
        <translation type="obsolete">Déplacer Pages</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Sélectionner la plage de page</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Page courante</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">à:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Pages sélectionnées</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Taille de la Page</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="49"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="86"/>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="vanished">A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="vanished">A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="vanished">A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="vanished">A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="vanished">A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="vanished">A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="vanished">A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="vanished">A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="vanished">A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="vanished">A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="vanished">A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="vanished">Taille de page habituelle</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>Portrait</source>
        <translation>Portrait</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>Landscape</source>
        <translation>Paysage</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="151"/>
        <source>Contents Size</source>
        <translation>Taille du Contenu</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>Left margin</source>
        <translation>Bord à gauche</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="203"/>
        <source>Top margin</source>
        <translation>Bord en haut</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="183"/>
        <source>Right margin</source>
        <translation>Bord à droite</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Bottom margin</source>
        <translation>Bord en bas</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="246"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="252"/>
        <source>Before current page</source>
        <translation>Avant la page courante</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="269"/>
        <source>After current page</source>
        <translation>Après la page courante</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="276"/>
        <source>After last page</source>
        <translation>Après la dernière Page</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="262"/>
        <source>Before first page</source>
        <translation>Avant la première Page</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="286"/>
        <source>Number of pages</source>
        <translation>Nombre de pages</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="312"/>
        <source>Page(s)</source>
        <translation>Pages(s)</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="292"/>
        <source>Create</source>
        <translation>Créer</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="vanished">Lettre</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="vanished">Journal</translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="vanished">B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="vanished">B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="vanished">B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="vanished">B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="vanished">B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="vanished">B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="vanished">Base</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="vanished">Exécutif</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="vanished">Folio</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="vanished">Quarto</translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="vanished">Note</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="vanished">ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="vanished">ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="vanished">ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="vanished">ANSI F</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">pixels</translation>
    </message>
    <message>
        <source>inch</source>
        <translatorcomment>pouces</translatorcomment>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> po</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="122"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Points</source>
        <translation>Points</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>Moteur OCR</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de Page</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page Courante</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="164"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="43"/>
        <source>Languages</source>
        <translation>Langues</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="49"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="194"/>
        <source>Selected</source>
        <translation>Sélectionné</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="36"/>
        <source>Install languages</source>
        <translation>Installer les langues</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="108"/>
        <source>Searchable Text</source>
        <translation>Texte avec recherche</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Editable Text</source>
        <translation>Texte éditable</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="138"/>
        <source>Font Family</source>
        <translation>Famille de Polices</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="vanished">Modifier manuellement tout le texte reconnu</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">auto</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="201"/>
        <source>Force manual text editing if confidence level not achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="171"/>
        <source>Minimal confidence level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Ligne</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="224"/>
        <source>Advanced</source>
        <translation type="unfinished">Avancé</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="258"/>
        <source>Helvetica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="68"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>Arrêter la reconnaissance de documents ?</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="65"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Pas de Propriétés
Il n&apos;y a pas d&apos;objet sélectionné.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="223"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3778"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4059"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2379"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="288"/>
        <source>Property</source>
        <translation>Propriétés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="293"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1597"/>
        <source>Value</source>
        <translation>Valeurs</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Left</source>
        <translation>Gauche</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3153"/>
        <source>Top</source>
        <translation>Haut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2434"/>
        <source>Font Family</source>
        <translation>Famille de Polices</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3790"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2479"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4079"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3725"/>
        <source>Fill Color</source>
        <translation>Couleur de remplissage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2541"/>
        <source>Stroke Color</source>
        <translation>Couleur de Trait</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation type="vanished">Largeur de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3578"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3639"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4029"/>
        <source>Opacity</source>
        <translation>Opacité</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2408"/>
        <source>Image</source>
        <translation>Image</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3163"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2819"/>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2431"/>
        <source>Path</source>
        <translation>Chemin</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3934"/>
        <source>Form Field</source>
        <translation>Champ de Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3857"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Gras</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">Italique</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1892"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1943"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Famille de Polices&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la  Famille de Polices&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3674"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="546"/>
        <source>Goto a Page View</source>
        <translation>Aller à la Vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="551"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="556"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Reset form</source>
        <translation>Réinitialiser le Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="566"/>
        <source>Show/Hide fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="571"/>
        <source>Submit a form</source>
        <translation>Soumettre un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="576"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="478"/>
        <source>Add an Action</source>
        <translation>Ajouter une Action</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="484"/>
        <source>Trigger</source>
        <translation>Déclencher</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="492"/>
        <source>Mouse Up</source>
        <translation>Souris vers le Haut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="497"/>
        <source>Mouse Down</source>
        <translation>Souris vers le Bas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="502"/>
        <source>Mouse Enter</source>
        <translation>Souris Entrer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="507"/>
        <source>Mouse Exit</source>
        <translation>Souris Sortir</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="512"/>
        <source>On Receive Focus</source>
        <translation>Point d&apos;intérêt présent</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="517"/>
        <source>On Lose Focus</source>
        <translation>Point d&apos;intérêt absent</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="538"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="590"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="918"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="600"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3341"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1677"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2269"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3460"/>
        <source>Edit</source>
        <translation>Edition</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="905"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="vanished">Etiquette haute</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="695"/>
        <source>Behavior</source>
        <translation>Comportement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="849"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1821"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1976"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="371"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="854"/>
        <source>Push</source>
        <translation>Pousser</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Outline</source>
        <translation>Contour</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="864"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Invert</source>
        <translation>Inverser</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="vanished">Etiquette basse</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="vanished">Etiquette roulante</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="898"/>
        <source>Item</source>
        <translation>Article</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="931"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1206"/>
        <source>Export Value</source>
        <translation>Exporter la Valeur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="771"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="973"/>
        <source>Up</source>
        <translation>En Haut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="776"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="957"/>
        <source>Down</source>
        <translation>En Bas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1001"/>
        <source>Sort Items</source>
        <translation>Trier les Articles</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="980"/>
        <source>Commit selected value immediately</source>
        <translation>Commettre la valeur sélectionnée immédiatement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="994"/>
        <source>Multiple selection</source>
        <translation>Sélection multiple</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="987"/>
        <source>Allow user to enter custom text</source>
        <translation>Autorise l&apos;utilisateur à mettre son propre texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1126"/>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1133"/>
        <source>Scrollable</source>
        <translation>Défilement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1140"/>
        <source>Check spelling</source>
        <translation>Chercher l&apos;orthographe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1061"/>
        <source>Limit to</source>
        <translation>Limiter à</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1075"/>
        <source>chars</source>
        <translation>Caractères</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1082"/>
        <source>Split into</source>
        <translation>Divisé en</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1054"/>
        <source>Allow Rich Text formatting</source>
        <translation>Autorise le formatage Rich Text</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Multi-line</source>
        <translation>Multi-ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <source>cells</source>
        <translation>Cellules</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1041"/>
        <source>Center</source>
        <translation>Centrer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1046"/>
        <source>Right</source>
        <translation>Droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>Default Value</source>
        <translation>Valeur par défaut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Alignment</source>
        <translation>Alignement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1219"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <source>Style</source>
        <translation>Style</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1230"/>
        <source>Check</source>
        <translation>Vérifier</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1235"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="347"/>
        <source>Circle</source>
        <translation>Cercle</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1240"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="349"/>
        <source>Cross</source>
        <translation>Croix</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Diamond</source>
        <translation>Diamant</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1250"/>
        <source>Square</source>
        <translation>Carré</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1255"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="358"/>
        <source>Star</source>
        <translation>Etoile</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1183"/>
        <source>Checked by Default</source>
        <translation>Vérifié par Défaut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3768"/>
        <source>Line Thickness</source>
        <translation>Épaisseur de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1386"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3718"/>
        <source>Border Color</source>
        <translation>Couleur de Bordure</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3761"/>
        <source>Line Style</source>
        <translation>Style de Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3733"/>
        <source>Solid</source>
        <translation>Solide</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1406"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3738"/>
        <source>Dashed</source>
        <translation>Pointillés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3753"/>
        <source>Underline</source>
        <translation>Souligner</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Highlight</source>
        <translation>Surligner</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>OutLine</source>
        <translation>Contour</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Insert</source>
        <translation>Insertion</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1463"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Pas d&apos;options valables&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3360"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3479"/>
        <source>Format</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Format category</source>
        <translation>Catégorie de Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1826"/>
        <source>Number</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1831"/>
        <source>Percentage</source>
        <translation>Pourcentage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1836"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1841"/>
        <source>Time</source>
        <translation>Heure</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1846"/>
        <source>Special</source>
        <translation>Spécial</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1851"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2006"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="333"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="337"/>
        <source>Custom</source>
        <translation>Habituel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1870"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="131"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1875"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="136"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1557"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1885"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1890"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1895"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1572"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1577"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1905"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1910"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1915"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1920"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1929"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1934"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1939"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1944"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Currency Symbol</source>
        <translation>Symbole de Devise</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1981"/>
        <source>Dollar ($)</source>
        <translation>Dollar ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1986"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <source>Pound (£)</source>
        <translation>Livre (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1996"/>
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="vanished">Rouble (Pуб)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Show parentheses</source>
        <translation>Montrer les parenthèses</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2047"/>
        <source>Decimal Places</source>
        <translation>Décimales</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2054"/>
        <source>Separation Style</source>
        <translation>Style de Séparation</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>Use red text</source>
        <translation>Utiliser le texte rouge</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Date Options</source>
        <translation>Options de Date</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>Time Options</source>
        <translation>Options d&apos;Heure</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2150"/>
        <source>Special Options</source>
        <translation>Options Spéciales</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Format Script</source>
        <translation>Script de Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2242"/>
        <source>KeyStroke Script</source>
        <translation>Script de frappe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>Validate</source>
        <translation>Valider</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Validation Script</source>
        <translation>Script de validation</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2349"/>
        <source>Calculate</source>
        <translation>Calculer</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2370"/>
        <source>Calculation Script</source>
        <translation>Script de calcul</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Fill text</source>
        <translation>Remplissage du Texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2504"/>
        <source>Stroke Text</source>
        <translation>Contour du Texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Fill and Stroke</source>
        <translation>Remplissage et Contour</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Invisible</source>
        <translation>Invisible</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2554"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3626"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4016"/>
        <source>Line Width</source>
        <translation>Largeur de la Ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Character spacing</source>
        <translation>Espacement des Caractères</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Word spacing</source>
        <translation>Espacement des Mots</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2597"/>
        <source>Line spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2758"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2768"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2778"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2788"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2885"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2910"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2935"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2960"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2998"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3017"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2901"/>
        <source>Align Top</source>
        <translation type="unfinished">Aligner en Haut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Align Right</source>
        <translation type="unfinished">Aligner à Droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <source>Align Left</source>
        <translation type="unfinished">Aligner à Gauche</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2995"/>
        <source>Align Bottom</source>
        <translation type="unfinished">Aligner en Bas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <source>Send To Back</source>
        <translation type="unfinished">Envoyer à l&apos;arrière-plan</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3033"/>
        <source>Send Backward</source>
        <translation type="unfinished">Placer Derrière</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3052"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3071"/>
        <source>Bring To Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3143"/>
        <source>Coordinates</source>
        <translation>Coordonnées</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3094"/>
        <source>Absolute</source>
        <translation>Absolues</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3099"/>
        <source>Relative</source>
        <translation>Relatives</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3189"/>
        <source>Geometry</source>
        <translation>Géométrie</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3208"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3832"/>
        <source>Font</source>
        <translation>Police</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3246"/>
        <source>Matrix</source>
        <translation>Matrice</translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="vanished">Chemin fixé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3303"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3379"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3548"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3566"/>
        <source>Fill</source>
        <translation>Remplissage</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3553"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3601"/>
        <source>Stroke</source>
        <translation>Contour</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3591"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3613"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3819"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4042"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3693"/>
        <source>Borders and Colors</source>
        <translation>Bordures et Couleurs</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3700"/>
        <source>Thin</source>
        <translation>Mince</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3705"/>
        <source>Medium</source>
        <translation>Moyen</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3710"/>
        <source>Thick</source>
        <translation>Epais</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3743"/>
        <source>Beveled</source>
        <translation>Biseauté</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3748"/>
        <source>Inset</source>
        <translation>Incruster</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3803"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3867"/>
        <source>ToolTip</source>
        <translation>Info-bulle</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3883"/>
        <source>Orientation</source>
        <translation>Orientation</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3891"/>
        <source>0 Degrees</source>
        <translation>0 Degrés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3896"/>
        <source>90 Degrees</source>
        <translation>90 Degrés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3901"/>
        <source>180 Degrees</source>
        <translation>180 Degrés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3906"/>
        <source>270 Degrees</source>
        <translation>270 Degrés</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3927"/>
        <source>Read Only</source>
        <translation>Lecture Seulement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3942"/>
        <source>Visible</source>
        <translation>Visible</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3947"/>
        <source>Hidden</source>
        <translation>Caché</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3952"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Visible mais non imprimable</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3957"/>
        <source>Hidden but printable</source>
        <translation>Caché mais imprimable</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3965"/>
        <source>Required</source>
        <translation>Requis</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4109"/>
        <source>Locked</source>
        <translation>Verrouillé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1880"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1887"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1900"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1907"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1955"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couleur de remplissage&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la couleur de remplissage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1961"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couleur du trait&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la couleur du trait&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2454"/>
        <source>Shading</source>
        <translation>Ombrer</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="vanished">Image de Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4052"/>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4089"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <source>Maintain aspect ratio</source>
        <translation>Garder les proportions</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code</source>
        <translation>Code postal</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code+4</source>
        <translation>Code postal+4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Phone Number</source>
        <translation>Numéro de téléphone</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Social Security Number</source>
        <translation>Numéro de sécurité sociale</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="346"/>
        <source>Check Mark</source>
        <translation>Coche</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="348"/>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="350"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Insérer un texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="352"/>
        <source>Key</source>
        <translation>Clé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="353"/>
        <source>New Paragraph</source>
        <translation>Nouveau paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="354"/>
        <source>Text Note</source>
        <translation>Note de texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="355"/>
        <source>Paragraph</source>
        <translation>Paragraphe</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="356"/>
        <source>Right Arrow</source>
        <translation>Flèche à droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="357"/>
        <source>Right Pointer</source>
        <translation>Pointeur à droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="359"/>
        <source>Up Arrow</source>
        <translation>Flèche en haut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="360"/>
        <source>Up Left Arrow</source>
        <translation>Flèche en haut à gauche</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="361"/>
        <source>Graph</source>
        <translation>Graphique</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="362"/>
        <source>Paper Clip</source>
        <translation>Clip de papier</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="363"/>
        <source>Attachment</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="364"/>
        <source>Tag</source>
        <translation>Marque</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Rotate</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation type="vanished">Hauteur de la ligne</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2659"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3398"/>
        <source>Selection change</source>
        <translation>Changement de sélection</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3426"/>
        <source>Do nothing</source>
        <translation>Ne fais rien</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3433"/>
        <source>Execute this script</source>
        <translation>Exécuter ce script</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="obsolete">pixels</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="obsolete">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="obsolete">millimètres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2146"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4359"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2151"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4379"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4399"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">Filigrane</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="vanished">Arrière-plan</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">En-tête et pied de page</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3265"/>
        <source>Clipping Path</source>
        <translation>Chemin fixé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2855"/>
        <source>Points</source>
        <translation>points</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2860"/>
        <source>Inches</source>
        <translation>pouces</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2865"/>
        <source>Millimeters</source>
        <translation>millimètres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="702"/>
        <source>Layout</source>
        <translation>Disposition</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Label only</source>
        <translation>Étiquette uniquement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Icon only</source>
        <translation>Icône seulement</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="723"/>
        <source>Icon top, label bottom</source>
        <translation>Icône en haut, étiquette en bas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <source>Label top, icon bottom</source>
        <translation>Étiquette en haut, icône en bas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Icon left, label right</source>
        <translation>Icône à gauche, étiquette à droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>label left, icon right</source>
        <translation>Étiquette à gauche, icone à droite</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Label over icon</source>
        <translation>Étiquette sur l&apos;icône</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="758"/>
        <source>Icon and Label</source>
        <translation>Icône et étiquette</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>Rollover</source>
        <translation>Rouler</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="798"/>
        <source>State</source>
        <translation>Etat</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="805"/>
        <source>Choose Icon...</source>
        <translation>Choisir l&apos;icône ...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="828"/>
        <source>Clear</source>
        <translation>Clair</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>Les boutons avec le même nom et la même valeur sont sélectionnés à l&apos;unisson</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Tous les fichiers (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="751"/>
        <source>Advanced</source>
        <translation>Avancé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4102"/>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2001"/>
        <source>Ruble (₽)</source>
        <translation>Rouble (₽)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3498"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4127"/>
        <source>Always show Object Inspector</source>
        <translation>Toujours Ouvrir l&apos;Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Bloc de texte</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="175"/>
        <source>Object Inspector</source>
        <translation type="unfinished">Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1501"/>
        <source>QRCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1506"/>
        <source>DataMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1517"/>
        <source>Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>ECC Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>X Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1590"/>
        <source>X/Y Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Include field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1637"/>
        <source>Pick...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1689"/>
        <source>Encode using Tab Delmited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1694"/>
        <source>Encode using XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1699"/>
        <source>JavaScript</source>
        <translation type="unfinished">JavaScript</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>Objet vue arborescente</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="285"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="317"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="373"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="obsolete">Géométrie</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Affichage</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="32"/>
        <source>Expand All</source>
        <translation>Développer tout</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="33"/>
        <source>Collapse All</source>
        <translation>Réduire tout</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="92"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="135"/>
        <source>All</source>
        <translation>Tout</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Images</source>
        <translation>Images</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="108"/>
        <source>Paths</source>
        <translation>Chemins</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Shadings</source>
        <translation>Ombres</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>Containers</source>
        <translation>Conteneurs</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Text Fields</source>
        <translation>Champs de texte</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>List Boxes</source>
        <translation>Boîtes à liste</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Combo Boxes</source>
        <translation>Boîtes combinées</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Check Boxes</source>
        <translation>Boîtes à cocher</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Radio Buttons</source>
        <translation>Boutons radio</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="166"/>
        <source>Buttons</source>
        <translation>Boutons</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="171"/>
        <source>Links</source>
        <translation>Liens</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="176"/>
        <source>Signatures</source>
        <translation>Signatures</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>Montrer</translation>
    </message>
    <message>
        <source>Object</source>
        <translation type="obsolete">Objet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="270"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="338"/>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="269"/>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
</context>
<context>
    <name>OptimizeScannedPagesDlg</name>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="14"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished">Pages</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="95"/>
        <source>Apply Adaptive Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="107"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">Images en couleur et en niveaux de gris</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="127"/>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="173"/>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="132"/>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="153"/>
        <source>Black and White Images</source>
        <translation type="unfinished">Images en noir et blanc</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="178"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished">CCITT Group 4</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="183"/>
        <source>JBIG2</source>
        <translation type="unfinished">JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="200"/>
        <source>Small Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="229"/>
        <source>High Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="242"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="248"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="255"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation>Barres d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation>Tous les outils :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation>Outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation>Outils actuels de la barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation>Barres d&apos;outils :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation>Ajouter une barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation>Supprimer la barre d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation>Réinitialiser tout</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation>Maximum d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation>Minimum d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="174"/>
        <source>Please, name new toolbar</source>
        <translation>SVP, nommer la nouvelle barre d&apos;outils</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Commentaires</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Machine à écrire</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Note</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annuler</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rétablir</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="obsolete">Placer Devant</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Couper</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copier</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Coller</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Fichier</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Enregistrer</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Imprimer</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Rechercher</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulaires</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Signature</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Bouton radio</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Zone de liste</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Champ de saisie de texte</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Zone de liste modifiable</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Case à cocher</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objets</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Crayon</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ellipse</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rectangle</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Ligne</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insérer un texte</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Rédaction</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Marquer pour la rédaction</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Editer le texte</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Outil Main</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Affichage</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vue précédente</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Vue suivante</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="obsolete">Zoom</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zoom Arrière</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Zoom Avant</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Ajuster la Page</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">Ajuster la Largeur</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Principal</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Enregistrer sous...</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation type="obsolete">Courrier électronique</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="obsolete">Aligner à Gauche</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="obsolete">Aligner à Droite</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="obsolete">Aligner en Haut</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="obsolete">Aligner en Bas</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="obsolete">Aligner le centre horizontal</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation type="obsolete">Aligner le centre vertical</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation type="obsolete">Placer Derrière</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation type="obsolete">Placer Devant</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Page précédente</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Page suivante</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="obsolete">Taille actuelle</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation type="obsolete">Éditer le document</translation>
    </message>
    <message>
        <source>Edit Images</source>
        <translation type="obsolete">Editer les Images</translation>
    </message>
    <message>
        <source>Edit Vector Images</source>
        <translation type="obsolete">Editer  les Images Vectorielles</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation type="obsolete">Editer les Formulaires</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation type="obsolete">Sélectionner le Texte</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="obsolete">Supprimer les Pages</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation type="obsolete">Couper les Pages</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation type="obsolete">Format de la Page</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation type="obsolete">Extraire des Pages...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation type="obsolete">Insérer des Pages...</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="obsolete">Actions de document</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation type="obsolete">Document JavaScript</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="obsolete">Propriétés de la page</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="obsolete">OCR</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="obsolete">En-tête et pied de page</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="obsolete">Filigrane</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">Arrière-plan</translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="obsolete">Document</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="525"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="557"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Réinitialiser les barres d&apos;outils aux paramètres par défaut ?</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="obsolete">Joindre un fichier en tant que commentaire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="196"/>
        <source>ToolBar with this name already exist.</source>
        <translation>Une barre d&apos;outils avec ce nom existe déjà.</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="obsolete">Cette police ne contient pas ces caractères.
Choisir une autre police.</translation>
    </message>
</context>
<context>
    <name>PageCounterWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Format de la Page</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="167"/>
        <source>Scale contents with size change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="203"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">Garder les proportions</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="247"/>
        <source>Contents Size</source>
        <translation>Taille du Contenu</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="259"/>
        <source>Left margin</source>
        <translation>Bord à gauche</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Top margin</source>
        <translation>Bord en haut</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="293"/>
        <source>Right margin</source>
        <translation>Bord à droite</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="310"/>
        <source>Bottom margin</source>
        <translation>Bord en bas</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="73"/>
        <location filename="../../src/PageLayoutDialog.ui" line="99"/>
        <source>Page Size</source>
        <translation>Taille de la Page</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">Largeur</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">Hauteur</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de page</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page courante</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les pages</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished"> px</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="63"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">pixels</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> po</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Pages paires et impaires</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Pages paires</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Pages impaires</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="86"/>
        <location filename="../../src/PageLayoutDialog.ui" line="154"/>
        <location filename="../../src/PageLayoutDialog.ui" line="174"/>
        <location filename="../../src/PageLayoutDialog.ui" line="190"/>
        <location filename="../../src/PageLayoutDialog.ui" line="266"/>
        <location filename="../../src/PageLayoutDialog.ui" line="283"/>
        <location filename="../../src/PageLayoutDialog.ui" line="300"/>
        <location filename="../../src/PageLayoutDialog.ui" line="317"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="331"/>
        <source>Points</source>
        <translation>points</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="336"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="341"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Top</source>
        <translation>Haut</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="137"/>
        <source>Bottom</source>
        <translation>Bas</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="147"/>
        <source>Left</source>
        <translation>Gauche</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="127"/>
        <source>Right</source>
        <translation>Droite</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="vanished">De</translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="vanished">hors :</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="106"/>
        <source>Orientation</source>
        <translation>Orientation</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="62"/>
        <source>Portrait</source>
        <translation>Portrait</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="119"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="63"/>
        <source>Landscape</source>
        <translation>Paysage</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>Propriétés de la page</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation>Ordre de tabulation</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation>Tri par rangée</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation>Tri par colonne</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation>Utiliser la structure du document</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation>Non spécifié</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation>Ajouter une Action</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation>Déclencher</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation>Action</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translation>Aller à une vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un fichier</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation>Réinitialiser un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translation>Soumettre un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation>Page ouverte</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation>Fermer la page</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="51"/>
        <source>Current Page</source>
        <translation>Page Courante</translation>
    </message>
</context>
<context>
    <name>PageRangeWidget</name>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="55"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="61"/>
        <source>Current page view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Toutes les Pages</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="117"/>
        <source>Pages</source>
        <translation type="unfinished">Pages</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="78"/>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="127"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="86"/>
        <source>All pages in range</source>
        <translation type="unfinished">Toutes les pages dans la gamme</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="91"/>
        <source>Even pages</source>
        <translation type="unfinished">Pages paires</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="96"/>
        <source>Odd pages</source>
        <translation type="unfinished">Pages impaires</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Page Range input is incorrect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation>Paramètres de l&apos;imprimante</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation>Papier</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation>Taille de la Page</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation>Marges</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation>Bord en bas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation>Bord en haut</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation>Bord à gauche</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation>Bord à droite</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation>Résolution</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation>Source de papier</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation>Points</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="320"/>
        <source> pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="339"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="355"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Mot de passe :</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Ce fichier est protégé par un mot de passe. Merci de saisir le mot de passe pour ouvrir ce document</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Entrer le mot de passe</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>Coller à plusieurs endroits</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Plage de Page</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation>Pages</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation>Toutes les Pages</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation>Sauf cas actuel</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation>Placer les Initiales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translation>Comment créer vos  initiales ?</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translation>Taper mes initiales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation>Dessiner mes initiales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translation>Sélectionner l&apos;image de la signature</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation>Entrer ses initiales :</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>Style</source>
        <translation>Style</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation>Famille de Polices</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation>Modifier le style des initiales</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation>Habituel</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translation>Examiner les initiales :</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation>Dessiner des initiales :</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation>Parcourir et sélectionner une image de sa signature</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="77"/>
        <source>Clear</source>
        <translation>Clair</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="105"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Open Image</source>
        <translation>Ouvrir une Image</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Fichiers Images (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>of</source>
        <translation>de</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Cette police ne contient pas ces caractères.
Choisir une autre police.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Vue avant Impression</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="621"/>
        <source>Printer</source>
        <translation>Imprimante</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="634"/>
        <source>Properties</source>
        <translation>Propriétés</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="vanished">Fonction antialiase</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="778"/>
        <location filename="../../src/printdialog/printdialog.ui" line="860"/>
        <source>Center</source>
        <translation>Centrer</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="577"/>
        <source>Print as Grayscale</source>
        <translation>Imprimer en nuances de gris</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="vanished">Proportions</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="707"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignorer les proportions</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="712"/>
        <source>Keep aspect ratio</source>
        <translation>Garder les proportions</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="717"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Garder les proportions en agrandissant</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="342"/>
        <source>Orientation</source>
        <translation>Orientation</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="307"/>
        <source>Portrait</source>
        <translation>Portrait</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="312"/>
        <source>Landscape</source>
        <translation>Paysage</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de page</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les pages</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page courante</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="437"/>
        <source>Number of copies</source>
        <translation>Nombre de copies</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="464"/>
        <source>Collate</source>
        <translation>Collationner</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation>Imprimer</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="vanished">Résolution</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="vanished">Normale</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="vanished">Elevée</translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="vanished">Basse</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="180"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>of:</source>
        <translation>de :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1332"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1708"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1719"/>
        <source>of </source>
        <translation>de </translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="vanished">1200</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="vanished">DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="725"/>
        <source>Actual Size</source>
        <translation>Taille actuelle</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="obsolete">auto</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation type="vanished">Imprimer en tant qu’image</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="361"/>
        <source>Duplex Printing</source>
        <translation>Impression recto verso</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <location filename="../../src/printdialog/printdialog.ui" line="369"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Long side</source>
        <translation>Long côté</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="302"/>
        <location filename="../../src/printdialog/printdialog.ui" line="374"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Short side</source>
        <translation>Petit côté</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Pages paires</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Pages impaires</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="135"/>
        <source>Document and Annotations</source>
        <translation>Document et annotations</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">Tout</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation type="vanished">Sous-ensemble</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation type="vanished">Toutes les pages dans la gamme</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Print:</source>
        <translation>Imprimer:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="270"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="272"/>
        <source>Advanced</source>
        <translation>Avancé</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="751"/>
        <location filename="../../src/printdialog/printdialog.ui" line="880"/>
        <source>Scale</source>
        <translation>Échelle</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="732"/>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="765"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Shrink to printable area</source>
        <translation>Réduire à la zone imprimable</translation>
    </message>
    <message>
        <source>Current view</source>
        <translation type="vanished">Vue actuelle</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="536"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="514"/>
        <source>Poster</source>
        <translation>Affiche</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">Brochure</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="32"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="63"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save Settings</source>
        <translation>Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save current settings as:</source>
        <translation>Enregistrer les paramètres actuels comme :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1583"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Voulez-vous supprimer ce paramètre ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="561"/>
        <source>Multiple</source>
        <translation>Multiple</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <source>Overlay</source>
        <translation>Par dessus</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="901"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1106"/>
        <source>Points</source>
        <translation>Points</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="906"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1111"/>
        <source>Inches</source>
        <translation>Pouces</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="911"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>Millimeters</source>
        <translation>Millimètres</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="867"/>
        <source> pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="977"/>
        <source>Pages per sheet:</source>
        <translation>Pages par feuille :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="970"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1011"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1016"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1021"/>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1026"/>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1031"/>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1036"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1053"/>
        <source>Page order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1061"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1066"/>
        <source>Horizontal Reversed</source>
        <translation>Horizontal inversé</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1071"/>
        <source>Vertical</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1076"/>
        <source>Vertical Reversed</source>
        <translation>Vertical inversé</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1091"/>
        <source>Additional spacing:</source>
        <translation>Espacement supplémentaire :</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1098"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1084"/>
        <source>Center pages in cells</source>
        <translation>Centrer les pages dans les cellules</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="323"/>
        <source>Page Setup</source>
        <translation>Mise en page</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="327"/>
        <source>System Properties</source>
        <translation>Propriétés du système</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="581"/>
        <source>Printer cannot be selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="240"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="266"/>
        <source>There was an error printing the document</source>
        <translation>Il y a eu une erreur lors de l&apos;impression du document</translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="242"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="268"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="60"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source> is already attached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="505"/>
        <source>Replace the file or give it a unique name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="506"/>
        <source>Replace</source>
        <translation type="unfinished">Remplacer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="507"/>
        <source>Rename</source>
        <translation type="unfinished">Renommer</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="508"/>
        <source>Cancel</source>
        <translation type="unfinished">Annuler</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="779"/>
        <source>You don&apos;t have the permission to save attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="823"/>
        <source>You don&apos;t have the permission to open attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="938"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="939"/>
        <source>The removed Attachment cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="57"/>
        <source>Insert</source>
        <translation>Insertion</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Location</source>
        <translation>Location</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="vanished">Page </translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="179"/>
        <source>Attachment Tab</source>
        <translation>Onglet des pièces jointes</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="24"/>
        <source>Attachment</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="175"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="874"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="29"/>
        <source>Add Bookmark</source>
        <translation>Ajouter un Signet</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">Supprimer le Signet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="31"/>
        <source>Bookmark Properties</source>
        <translation>Propriétés des Signets</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="32"/>
        <source>Set Destination</source>
        <translation>Destination prévue</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="274"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="275"/>
        <source>The removed bookmark(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="30"/>
        <source>Delete Bookmark(s)</source>
        <translation>Supprimer le(s) Signet(s)</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="227"/>
        <location filename="../../src/document/qdoctab.cpp" line="348"/>
        <source>untitled</source>
        <translation>Sans titre</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">La mémoire vive est vide</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="82"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="86"/>
        <source>Close All</source>
        <translation>Fermer tout</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Enregistrer</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="106"/>
        <source>Move to New Window</source>
        <translation>Déplacer un onglet vers une nouvelle fenêtre</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="90"/>
        <source>Close All Other Tabs</source>
        <translation>Fermer tous les Autres Onglets</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="74"/>
        <source>Duplicate tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="78"/>
        <source>Rename tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="94"/>
        <source>Close All Tabs to the Right</source>
        <translation>Fermer tous les Onglets à droite</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1895"/>
        <location filename="../../src/document/qdoctab.cpp" line="1920"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>Le presse-papiers ne contient aucune donnée</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2214"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2272"/>
        <source>You don&apos;t have permission to modify the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2278"/>
        <source>Save failed</source>
        <translation type="unfinished">La Sauvegarde a échoué</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished">
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished">Autorise l&apos;ouverture du même document dans plusieurs onglets</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>option needs to be enabled to allow duplicating tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Rename</source>
        <translation type="unfinished">Renommer</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Renaming file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Overwrite file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Would you like to overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3757"/>
        <source>Failed to rename file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>Courrier électronique</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="17"/>
        <source>Send</source>
        <translation>Envoyer</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Fichier</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Edition</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annuler</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rétablir</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copier</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Coller</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Gras</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Italique</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annuler</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rétablir</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copier</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Coller</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Gras</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Italique</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">Gauche</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="vanished">Droite</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="vanished">Une connexion HTTPS est demandée mais le support SSL n&apos;est pas disponible ici</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Erreur inconnue</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="vanished">Requète abandonnée</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="vanished">Pas de serveur disponible pour se connecter</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="vanished">Probleme de longueur du contenu</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="vanished">Le serveur a fermé la connexion de façon inattendue</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="vanished">Connexion refusée (ou délai dépassé)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="vanished">Hôte %1 non trouvé</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="vanished">La requète HTTP a échoué</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="vanished">Réponse HTTP invalide</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="vanished">Méthode d&apos;authentification inconnue</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="vanished">Authentification demandée par le Proxy</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="vanished">Authentification demandée</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="vanished">Invalide corps fragmenté HTTP</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="vanished">Erreur en écrivant la réponse</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">Zoom Avant</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">Zoom Arrière</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="113"/>
        <source>Zoom to Selection</source>
        <translation>Zoom sur la sélection</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="121"/>
        <source>Clear Selections</source>
        <translation>Effacer les sélections</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="16"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>Cette fonction est non disponible dans la version gratuite</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="20"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>La version non enregistrée va insérer un filigrane</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>Build</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Based on</source>
        <translation type="vanished">Basé sur</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <source>32 bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>64 bit</source>
        <translation>64 bit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Enter</source>
        <translation>Souris Entrer</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Exit</source>
        <translation>Souris Sortir</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Down</source>
        <translation>Souris vers le Bas</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Mouse Up</source>
        <translation>Souris vers le Haut</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Receive Focus</source>
        <translation>Point d&apos;intérêt présent</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>On Lose Focus</source>
        <translation>Point d&apos;intérêt absent</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Open</source>
        <translation>Page ouverte</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Close</source>
        <translation>Fermer la page</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Visible</source>
        <translation>Page Visible</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Page Invisible</source>
        <translation>Page Invisible</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Open Page</source>
        <translation>Page ouverte</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Close Page</source>
        <translation>Fermer la page</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>KeyStroke</source>
        <translation>Frappe au clavier</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="997"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Validate</source>
        <translation>Valider</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Calculate</source>
        <translation>Calculer</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Close Document</source>
        <translation>Fermer le document</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Save Document</source>
        <translation>Enregistrer le document</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Document Saved</source>
        <translation>Document enregistré</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Print Document</source>
        <translation>Imprimer le document</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="65"/>
        <source>Document Printed</source>
        <translation>Document imprimé</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Unknown</source>
        <translation>Inconnu</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Goto a Page View</source>
        <translation>Aller à une vue de Page</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Open/execute a File</source>
        <translation>Ouvrir/Exécuter un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Thread</source>
        <translation>Fil</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Open a web link</source>
        <translation>Ouvrir un lien internet</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Sound</source>
        <translation>Son</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Movie</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="98"/>
        <source>Show/Hide fields</source>
        <translation>Montrer/Cacher les Champs</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Submit Form</source>
        <translation>Soumettre un formulaire</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Reset Form</source>
        <translation>Réinitialiser le Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Import Data</source>
        <translation>Importer des données</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="108"/>
        <source>Run a JavaScript</source>
        <translation>Lancer un script Java</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="112"/>
        <source>Rendition</source>
        <translation>Interprétation</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="116"/>
        <source>Goto 3D View</source>
        <translation>Aller à la vue 3D</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="25"/>
        <source>Open with</source>
        <translation>Ouvrir avec</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Reset</source>
        <translation>Réinitialiser</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Set</source>
        <translation>Ensemble</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Brightness</source>
        <translation>Luminosité</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Approved</source>
        <translation>Approuvé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Confidential</source>
        <translation>Confidentiel</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Received</source>
        <translation>Reçu</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Reviewed</source>
        <translation>Révisé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Revised</source>
        <translation>Corrigé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Completed</source>
        <translation>Terminé/Achevé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Draft</source>
        <translation>Provisoire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Emergency</source>
        <translation>Urgence</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>Expired</source>
        <translation>Expiré</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Final</source>
        <translation>Final</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Verified</source>
        <translation>Vérifié</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Void</source>
        <translation>Nul</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>Accepted</source>
        <translation>Accepté</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="173"/>
        <source>Initial</source>
        <translation>Initiale</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="178"/>
        <source>Rejected</source>
        <translation>Rejeté</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>SignHere</source>
        <translation>Signer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Witness</source>
        <translation>Témoin</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Dynamic</source>
        <translation>Dynamique</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Standard</source>
        <translation>La norme</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation>h:MM tt mmmm dd.yyyy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="216"/>
        <source>Icon</source>
        <translation>Icône</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="221"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="226"/>
        <source>Press Help button to get more info.</source>
        <translation>Appuyer sur le bouton Aide pour obtenir plus d&apos;informations.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="231"/>
        <source>Error.</source>
        <translation>Erreur.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="236"/>
        <source>Object</source>
        <translation>Objet</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="246"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="251"/>
        <source>Image</source>
        <translation>Image</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="256"/>
        <source>Path</source>
        <translation>Chemin</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="261"/>
        <source>Shading</source>
        <translation>Ombrer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="241"/>
        <location filename="../../src/app_config.cpp" line="747"/>
        <source>Objects</source>
        <translation>Objets</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="266"/>
        <source>All Objects</source>
        <translation>Tous les objets</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="271"/>
        <source>Forms</source>
        <translation>Formulaires</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="276"/>
        <source>Comments</source>
        <translation>Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="281"/>
        <source>Container</source>
        <translation>Conteneur</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="286"/>
        <source>Sticky Note</source>
        <translation>Note</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="291"/>
        <source>Highlight</source>
        <translation>Surligner</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="296"/>
        <source>Underline</source>
        <translation>Souligner</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="301"/>
        <source>StrikeOut</source>
        <translation>Barrer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="306"/>
        <source>Reply</source>
        <translation>Répondre</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Fichiers FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="426"/>
        <source>Typewriter</source>
        <translation>Machine à écrire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="311"/>
        <source>Text Box</source>
        <translation>Zone de texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="316"/>
        <source>Formatted Text</source>
        <translation>Texte formaté</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="321"/>
        <source>Issued by:</source>
        <translation>Délivré par :</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="326"/>
        <source>Expires</source>
        <translation>Expire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="331"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="336"/>
        <source>Cancelled</source>
        <translation>Annulé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="341"/>
        <source>Confirmed</source>
        <translation>Confirmé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="346"/>
        <source>Not Confirmed</source>
        <translation>Non Confirmé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="351"/>
        <source>Open Object Inspector</source>
        <translation>Ouvrir l&apos;Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="356"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="361"/>
        <source>Review History</source>
        <translation>Historique des révisions</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="366"/>
        <source>Make Current Properties Default</source>
        <translation>Prendre les propriétés actuelles par défaut</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="371"/>
        <source>Error Loading Image!</source>
        <translation>Erreur au chargement de l&apos;image !</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="376"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>Format de date / heure incorrect. Insérer la date / heure pour correspondre au format : </translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="381"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>Le nombre d&apos;activations disponibles est dépassé.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="386"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation>Désactiver la licence sur un autre PC.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="396"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>La licence a expiré. Merci de la renouveler.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="401"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>Impossible de vérifier la licence ! Vérifier la connexion Internet et appuyer sur Vérifier maintenant.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="391"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>La licence ne permet pas d&apos;utiliser cette version. Merci de la renouveler.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="406"/>
        <source>Print using Windows API</source>
        <translation>Iimprimer en utilisant Windows API</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="411"/>
        <source>Do not show this message again</source>
        <translation>Ne plus afficher ce message</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="416"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>Si OpenSSL n&apos;est pas installé,  le chiffrement et la signature ne seront pas possibles.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="436"/>
        <source>Separator</source>
        <translation>Séparateur</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="441"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="446"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="451"/>
        <source>Save As...</source>
        <translation>Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="461"/>
        <source>Toolbars</source>
        <translation>Barres d&apos;outils</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="466"/>
        <source>Email delivery</source>
        <translation>Courrier électronique</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="476"/>
        <source>Print</source>
        <translation>Imprimer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="481"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="486"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="491"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="496"/>
        <source>Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="501"/>
        <source>Delete Object(s)</source>
        <translation>Supprimer le(s) Objet(s)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="506"/>
        <source>Undo</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="511"/>
        <source>Redo</source>
        <translation>Rétablir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="516"/>
        <source>Align Left</source>
        <translation>Aligner à Gauche</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="521"/>
        <source>Align Right</source>
        <translation>Aligner à Droite</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="526"/>
        <source>Align Top</source>
        <translation>Aligner en Haut</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="531"/>
        <source>Align Bottom</source>
        <translation>Aligner en Bas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="536"/>
        <source>Align Center Horizontal</source>
        <translation>Aligner le Centre Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="541"/>
        <source>Align Center Vertical</source>
        <translation>Aligner le Centre Vertical</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="551"/>
        <source>Send To Back</source>
        <translation>Envoyer à l&apos;arrière-plan</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="556"/>
        <source>Send Backward</source>
        <translation>Placer Derrière</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="561"/>
        <source>Bring Forward</source>
        <translation>Avancer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="566"/>
        <source>Bring To Front</source>
        <translation>Mettre au premier plan</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="577"/>
        <source>Grid</source>
        <translation>Grille</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="582"/>
        <source>Snap To Grid</source>
        <translation>Aligner sur la grille</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="587"/>
        <source>View</source>
        <translation>Affichage</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="592"/>
        <source>Previous View</source>
        <translation>Vue précédente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="597"/>
        <source>Next View</source>
        <translation>Vue suivante</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="602"/>
        <source>Previous Page</source>
        <translation>Page précédente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="607"/>
        <source>Next Page</source>
        <translation>Page suivante</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="612"/>
        <source>Zoom Out</source>
        <translation>Zoom Arrière</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="617"/>
        <source>Actual Size</source>
        <translation>Taille actuelle</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="622"/>
        <source>Zoom In</source>
        <translation>Zoom Avant</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="627"/>
        <location filename="../../src/mainwindow.cpp" line="4147"/>
        <source>Fit Page</source>
        <translation>Ajuster la Page</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="632"/>
        <location filename="../../src/mainwindow.cpp" line="4151"/>
        <source>Fit Width</source>
        <translation>Ajuster la Largeur</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="637"/>
        <source>Facing Pages</source>
        <translation>Pages vis à vis</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="642"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Tourner de 90 degrés dans le sens antihoraire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="647"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Tourner de 90 degrés dans le sens des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="652"/>
        <source>Rotate 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="657"/>
        <source>Tools</source>
        <translation>Outils</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="662"/>
        <source>Edit Document</source>
        <translation>Éditer le document</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="667"/>
        <source>Edit Text</source>
        <translation>Editer le texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="672"/>
        <source>Edit Images</source>
        <translation>Editer les Images</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="677"/>
        <source>Edit Vector Images</source>
        <translation>Editer  les Images Vectorielles</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="682"/>
        <source>Edit Forms</source>
        <translation>Editer les Formulaires</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="692"/>
        <source>Hand Tool</source>
        <translation>Outil Main</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="697"/>
        <source>Select Text</source>
        <translation>Sélectionner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="702"/>
        <source>Take Snapshot</source>
        <translation>Prendre un instantané</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="707"/>
        <source>Insert Link</source>
        <translation>Insérer un lien</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="712"/>
        <source>Button</source>
        <translation>Bouton</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="717"/>
        <source>Check Box</source>
        <translation>Case à cocher</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="722"/>
        <source>Combo Box</source>
        <translation>Zone de liste modifiable</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="727"/>
        <source>Text Field</source>
        <translation>Champ de saisie de texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="732"/>
        <source>List Box</source>
        <translation>Zone de liste</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="737"/>
        <source>Radio Button</source>
        <translation>Bouton radio</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="742"/>
        <source>Signature</source>
        <translation>Signature</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="752"/>
        <source>Insert Formatted Text</source>
        <translation>Insérer du texte formaté</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="757"/>
        <source>Insert Text</source>
        <translation>Insérer un texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="762"/>
        <source>Insert Image</source>
        <translation>Insérer une image</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="767"/>
        <source>Line</source>
        <translation>Ligne</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="772"/>
        <source>Rectangle</source>
        <translation>Rectangle</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="777"/>
        <source>Ellipse</source>
        <translation>Ellipse</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="782"/>
        <source>Pencil</source>
        <translation>Crayon</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="787"/>
        <source>Attach a File as a Comment</source>
        <translation>Joindre un fichier en tant que commentaire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="792"/>
        <source>Redaction</source>
        <translation>Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="797"/>
        <source>Mark for Redaction</source>
        <translation>Marquer pour la rédaction</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="802"/>
        <source>Search And Redact</source>
        <translation>Recherche et tri</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="807"/>
        <source>Apply Redaction</source>
        <translation>Appliquer la Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="812"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="817"/>
        <source>Insert Blank Pages</source>
        <translation>Insérer des pages vierges</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="822"/>
        <source>Delete Pages</source>
        <translation>Supprimer les Pages</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="827"/>
        <source>Crop Pages</source>
        <translation>Rogner les Pages</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="832"/>
        <source>Page layout</source>
        <translation>Format de la Page</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="837"/>
        <source>Page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="842"/>
        <source>Rotate Pages</source>
        <translation>Tourner la page</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="847"/>
        <source>Extract Pages...</source>
        <translation>Extraire des Pages...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="852"/>
        <source>Insert Pages...</source>
        <translation>Insérer des Pages...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="857"/>
        <source>Cut Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="862"/>
        <source>Copy Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="867"/>
        <source>Paste Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="872"/>
        <source>Document Actions</source>
        <translation>Actions de document</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="877"/>
        <source>Document JavaScript</source>
        <translation>Document JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="882"/>
        <source>Page Properties</source>
        <translation>Propriétés de la page</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="887"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="892"/>
        <source>Header and Footer</source>
        <translation>En-tête et pied de page</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="897"/>
        <source>Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="902"/>
        <source>Watermark</source>
        <translation>Filigrane</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="907"/>
        <source>Background</source>
        <translation>Arrière-plan</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="917"/>
        <source>Page Counter</source>
        <translation>Compteur de pages</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="922"/>
        <source>New</source>
        <translation>Nouveau</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="927"/>
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="992"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1002"/>
        <source>Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1007"/>
        <source>Show Crop Page Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1012"/>
        <source>Prompt to Scan More Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1017"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1022"/>
        <source>Autosave on. Document will be saved automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1027"/>
        <source>Images</source>
        <translation type="unfinished">Images</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1032"/>
        <source>Vector Images</source>
        <translation type="unfinished">Images Vectorielles</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1037"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1042"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="912"/>
        <location filename="../../src/app_config.cpp" line="932"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="937"/>
        <source>Find</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Commentaire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="962"/>
        <source>Stamp</source>
        <translation>Tampon</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="967"/>
        <source>Comment View</source>
        <translation>Voir les commentaires</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="972"/>
        <source>Place Initials</source>
        <translation>Placer les Initiales</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="431"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="947"/>
        <source>Highlight Text</source>
        <translation>Surligner le Texte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="952"/>
        <source>Draw Comment Tools</source>
        <translation>Dessiner des outils de commentaire</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="957"/>
        <source>Measurement Tools</source>
        <translation>Outils de mesure</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="687"/>
        <source>Edit Tools</source>
        <translation>Modifier les Outils</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="977"/>
        <source>Continuous Page</source>
        <translation>Page continue</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="982"/>
        <source>Single Page</source>
        <translation>Page Seule</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="546"/>
        <source>Align Objects</source>
        <translation type="unfinished">Aligner les Objets</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="571"/>
        <source>Move Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="421"/>
        <source>If NSS is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="987"/>
        <source>No pages selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="471"/>
        <source>System Print...</source>
        <translation type="unfinished">Système d&apos;impression ...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="942"/>
        <source>Label</source>
        <translation type="unfinished">Étiquette</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Combine files in</source>
        <translation type="unfinished">Combinez les fichiers dans</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="456"/>
        <source>Save As Image</source>
        <translation type="unfinished">Sauvegarder comme Image</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="39"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="40"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="41"/>
        <source>Arabic</source>
        <translation type="unfinished">Arabe</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="42"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="43"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="44"/>
        <source>Azerbaijani (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="45"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="46"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="47"/>
        <source>Tibetan Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="49"/>
        <source>Bulgarian</source>
        <translation type="unfinished">Bulgare</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="50"/>
        <source>Catalan</source>
        <translation type="unfinished">Catalan</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="51"/>
        <source>Cebuano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="52"/>
        <source>Czech</source>
        <translation type="unfinished">Tchèque</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="53"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="54"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="55"/>
        <source>Cherokee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished">Danois</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="58"/>
        <source>German</source>
        <translation type="unfinished">Allemand</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="59"/>
        <source>German (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="61"/>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="76"/>
        <source>Greek</source>
        <translation type="unfinished">Grec</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="62"/>
        <source>English</source>
        <translation type="unfinished">Anglais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="63"/>
        <source>English (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="64"/>
        <source>Middle English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="65"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="66"/>
        <source>Estonian</source>
        <translation type="unfinished">Estonien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="67"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="69"/>
        <source>Finnish</source>
        <translation type="unfinished">Finnois</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="70"/>
        <source>French</source>
        <translation type="unfinished">Français</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="71"/>
        <source>Frankish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="72"/>
        <source>Middle French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="73"/>
        <source>Irish</source>
        <translation type="unfinished">Irlandais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="74"/>
        <source>Irish (Uncial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="75"/>
        <source>Galician</source>
        <translation type="unfinished">Galicien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="77"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="78"/>
        <source>Hatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished">Hébreu</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="81"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="82"/>
        <source>Hungarian</source>
        <translation type="unfinished">Hongrois</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="83"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="84"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="85"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="86"/>
        <source>Italian</source>
        <translation type="unfinished">Italien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="87"/>
        <source>Old Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="88"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="89"/>
        <source>Japanese</source>
        <translation type="unfinished">Japonais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="90"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="91"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="92"/>
        <source>Old Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="93"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="94"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="95"/>
        <source>Kyrgyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="96"/>
        <source>Korean</source>
        <translation type="unfinished">Coréen</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="97"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="98"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="99"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="100"/>
        <source>Latvian</source>
        <translation type="unfinished">Letton</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="101"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Lithuanien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="102"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="103"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="104"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="105"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="106"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="107"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="108"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="109"/>
        <source>Dutch</source>
        <translation type="unfinished">Hollandais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="110"/>
        <source>Norwegian</source>
        <translation type="unfinished">Norvégien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="111"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="112"/>
        <source>script and orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="113"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="114"/>
        <source>Polish</source>
        <translation type="unfinished">Polonais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="115"/>
        <source>Portuguese</source>
        <translation type="unfinished">Portugais</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="116"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="117"/>
        <source>Romanain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="118"/>
        <source>Russian</source>
        <translation type="unfinished">Russe</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="119"/>
        <source>Russian (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="120"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="121"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="122"/>
        <source>Slovak</source>
        <translation type="unfinished">Slovaque</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="123"/>
        <source>Slovak Fractur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="124"/>
        <source>Slovenian</source>
        <translation type="unfinished">Slovène</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="125"/>
        <source>Spanish</source>
        <translation type="unfinished">Espagnol</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="126"/>
        <source>Old Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="127"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="128"/>
        <source>Serbian</source>
        <translation type="unfinished">Serbe</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="129"/>
        <source>Serbian (Latin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="130"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="131"/>
        <source>Swedish</source>
        <translation type="unfinished">Suèdois</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="132"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="133"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="134"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="135"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="136"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="137"/>
        <source>Thai</source>
        <translation type="unfinished">Thaï</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="138"/>
        <source>Turkish</source>
        <translation type="unfinished">Turc</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="139"/>
        <source>Uyghur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="140"/>
        <source>Urgu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="141"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="142"/>
        <source>Uzbek (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="143"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamien</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="144"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qsanelib.cpp" line="389"/>
        <source>Document feeder is out of sheets!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="789"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="984"/>
        <source>Error! Check if the file is valid and exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="988"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="111"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="133"/>
        <source> in</source>
        <translation type="unfinished"> po</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="142"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/utils/AppSession.cpp" line="64"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3554"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3682"/>
        <source>Error!</source>
        <translation>Erreur !</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4325"/>
        <source>There was a problem with your form submission.</source>
        <translation>Il y a eu un problème avec le formulaire soumis.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4329"/>
        <source>Your form was successfully submitted!</source>
        <translation>Le formulaire a été soumis avec succès !</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>of</source>
        <translation type="vanished">de</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Page</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="40"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="4231"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4235"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4240"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4285"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>L&apos;action du document PDF tente de soumettre les données du formulaire à un autre emplacement. Procéder ?</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="51"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="593"/>
        <source>Open Document</source>
        <translation>Ouvrir le document</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="61"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="594"/>
        <source>Blank PDF</source>
        <translation>PDF Vierge</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="595"/>
        <source>From Files</source>
        <translation>A partir de fichiers</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="597"/>
        <source>From Scanner</source>
        <translation>À partir du scanner</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="93"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="598"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="99"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="599"/>
        <source>User Guide</source>
        <translation>Guide de l&apos;utilisateur</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="109"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="602"/>
        <source>Register...</source>
        <translation>Enregistrement...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="115"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="603"/>
        <source>Buy Online</source>
        <translation>Acheter en Ligne</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="417"/>
        <source>Create New Document</source>
        <translation>Créer un nouveau document</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="439"/>
        <source>Recent Files</source>
        <translation>Fichiers récents</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="596"/>
        <source>Empty recent files list</source>
        <translation>Vider la liste des fichiers récents</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="421"/>
        <source>Pinned Files</source>
        <translation>Fichiers épinglés</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="957"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>Vous avez atteint la limite de 10 fichiers épinglés.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="193"/>
        <source>Pages</source>
        <translation>Pages</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="vanished">Agrandir les miniatures de page</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="vanished">Réduire les miniatures de page</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="219"/>
        <source>Bookmarks</source>
        <translation>Signets</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="231"/>
        <source>Attachment</source>
        <translation>Pièces jointes</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="242"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="277"/>
        <source>Object Inspector</source>
        <translation>Inspecteur d&apos;objets</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="744"/>
        <source>This document contains interactive form fields</source>
        <translation>Ce document contient des champs de formulaires interactifs</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="745"/>
        <source>Highlight Fields</source>
        <translation>Surligner tous les Champs</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="vanished">Ce document est protégé. Pas de permission pour l&apos;éditer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="753"/>
        <source>Change</source>
        <translation>Changer</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="vanished">Il y a eu une erreur lors de l&apos;impression du document</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Insérer des pages</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4254"/>
        <source>Do you want to open?</source>
        <translation>Voulez-vous ouvrir ?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4261"/>
        <source>Don&apos;t show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5068"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Etes-vous certain du choix de la destination du signet sélectionné à sa localisation courante ?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5161"/>
        <source>untitled</source>
        <translation>sans titre</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">Supprimer les Pages</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">Insérer des Pages Vierges</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">Propriétés de la page</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Tourner de 90 degrés dans le sens des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Tourner de 90 degrés dans le sens inverse des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="vanished">Erreur!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1707"/>
        <source>Error loading font: </source>
        <translation>Erreur lors du chargement de la police:</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="246"/>
        <source>Object TreeView</source>
        <translation>Objet vue arborescente</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="600"/>
        <source>Layers</source>
        <translation>Couches</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="752"/>
        <source>This document is protectedYou do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="805"/>
        <source>Registration</source>
        <translation>Enregistrement</translation>
    </message>
    <message>
        <source>Current zoom will also be accounted for.</source>
        <translation type="vanished">Le zoom actuel sera également pris en compte.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="263"/>
        <source>Signatures</source>
        <translation>Signatures</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3622"/>
        <source>Document must contain at least one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3629"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3015"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5071"/>
        <source>Set current zoom</source>
        <translation>Définir le zoom actuel</translation>
    </message>
</context>
<context>
    <name>QThumbnailsList</name>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="81"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="84"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="132"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="16"/>
        <source>Millimeters (mm)</source>
        <translation>Millimètres (mm)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="17"/>
        <source>Inches (in)</source>
        <translation>Pouces (in)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="18"/>
        <source>Points (pt)</source>
        <translation>Points (pt)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="19"/>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="20"/>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="21"/>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>po</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="59"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="63"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="302"/>
        <location filename="../../src/utils/AppSession.cpp" line="241"/>
        <source>MPE Session file (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="144"/>
        <source>More...</source>
        <translation>Plus...</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="vanished">Couleur d&apos;utilisateur %1</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>User Color 99</source>
        <translation>Couleur d&apos;utilisateur 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Black</source>
        <translation>Noir</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>White</source>
        <translation>Blanc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Red</source>
        <translation>Rouge</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="356"/>
        <source>Dark red</source>
        <translation>Rouge sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Green</source>
        <translation>Vert</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="358"/>
        <source>Dark green</source>
        <translation>Vert sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="359"/>
        <source>Blue</source>
        <translation>Bleu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="360"/>
        <source>Dark blue</source>
        <translation>Bleu sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="361"/>
        <source>Cyan</source>
        <translation>Cyan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="362"/>
        <source>Dark cyan</source>
        <translation>Cyan sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="363"/>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="364"/>
        <source>Dark magenta</source>
        <translation>Magenta sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="365"/>
        <source>Yellow</source>
        <translation>Jaune</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="366"/>
        <source>Dark yellow</source>
        <translation>Jaune sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="367"/>
        <source>Gray</source>
        <translation>Gris</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="368"/>
        <source>Dark gray</source>
        <translation>Gris sombre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="369"/>
        <source>Light gray</source>
        <translation>Gris clair</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="371"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translation>Rédacteur de code de rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation>Ensembles de codes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation>Renommer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation>Entrées de code</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation>Couleur de remplissage de la rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation>Utiliser le texte en superposition</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="76"/>
        <source>Code Sets</source>
        <translation>Ensembles de codes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="83"/>
        <source>Code Entries:</source>
        <translation>Entrées de code :</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="116"/>
        <source>Edit Codes</source>
        <translation>Modifier les codes</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="67"/>
        <source>Redaction Code</source>
        <translation>Code de rédaction</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="133"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="152"/>
        <source>Font</source>
        <translation>Police</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="201"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="60"/>
        <source>Repeat Overlay Text</source>
        <translation>Répéter le texte en superposition</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="140"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="172"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="126"/>
        <source>Auto-size text</source>
        <translation>Texte de taille automatique</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Info d&apos;Enregistrement</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">Ok</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Après que votre ordre soit complèté,
vous recevrez automatiquement
votre code d&apos;enregistrement par e-mail.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Acheter en Ligne</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="386"/>
        <source>Registration Code</source>
        <translation>Code d&apos;enregistrement</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="373"/>
        <source>Activate</source>
        <translation>Activer</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Activation hors-ligne</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="227"/>
        <source>Registered version</source>
        <translation>Version enregistrée</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SVP, envoyer la clé ID et le code d&apos;enregistrement à : &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Dès que vous avez votre code, entrer le &amp;quot;Code d&apos;Activation&amp;quot; ici&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="vanished">Si vous voulez utiliser cette license sur un autre PC
cliquer sur le bouton &quot;Désactiver&quot;.

Ensuite, enregistrer là où vous en avez besoin.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="214"/>
        <source>Deactivate</source>
        <translation>Désactiver</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="319"/>
        <source>Registration Code:</source>
        <translation>Code d&apos;enregistrement:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="366"/>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="422"/>
        <source>Activation Code</source>
        <translation>Code d&apos;activation</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SVP, envoyer la clé ID et le code d&apos;enregistrement à : &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Dès que vous avez votre code, entrer le ici &amp;quot;Code d&apos;Activation&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="349"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Fermer</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="34"/>
        <source>Thanks for registration.</source>
        <translation>Merci pour votre inscription.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="35"/>
        <source>License is deactivated.</source>
        <translation>La licence est désactivée.</translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation type="vanished">Le nombre d&apos;activations disponibles est dépassé.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="37"/>
        <source>Too many activations!</source>
        <translation>Trop d&apos;activations !</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SVP, envoyer la clé ID et le code d&apos;enregistrement à : &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Dès que vous avez votre code, entrer le &amp;quot;Code d&apos;Activation&amp;quot; ici&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="278"/>
        <source>Purchased On:</source>
        <translation>Acheté le :</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="292"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Fin de validité de la licence :</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="40"/>
        <source>License is expired!</source>
        <translation>La licence est expirée !</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="58"/>
        <source>Please, renew your license</source>
        <translation>Merci de la renouveler</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="470"/>
        <source>Renew</source>
        <translation>Renouveler</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="499"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact activations@code-industry.net</source>
        <translation>La désactivation a échoué !
Vérifier la connexion Internet.
Si l&apos;erreur se répète, contacter le activations@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="202"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Si vous voulez utiliser cette license sur un autre PC
cliquer sur le bouton &quot;Désactiver&quot;.

Ensuite, enregistrer là où vous en avez besoin.</translation>
    </message>
    <message>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation type="vanished">La désactivation a échoué !
Vérifier la connexion Internet.
Si l&apos;erreur se répète, contacter le support@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="320"/>
        <location filename="../../src/regdialog.cpp" line="527"/>
        <source>Activation failed! Check internet connection.</source>
        <translation>L&apos;activation a échoué ! Vérifier la connexion Internet.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="291"/>
        <location filename="../../src/regdialog.cpp" line="425"/>
        <source>Incorrect registration code.</source>
        <translation>Code d&apos;enregistrement incorrect</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de page</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Pages</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemple : 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Page courante</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="28"/>
        <source>Direction</source>
        <translation>Direction</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="35"/>
        <source>Clockwise 90 degrees</source>
        <translation>90 degrés dans le sens des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="40"/>
        <source>180 degrees</source>
        <translation>180 degrés</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="45"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>90 degrés dans le sens inverse des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Pages paires et impaires</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Pages paires</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Pages impaires</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="25"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>Largeur</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>Hauteur</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>File Name</source>
        <translation>Nom du fichier</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Pages de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">à :</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Exporter vers l&apos;Image</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="259"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Plage de page</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Toutes les Pages</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>Qualité JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>Compression TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <source>96</source>
        <translation type="vanished">96</translation>
    </message>
    <message>
        <source>120</source>
        <translation type="vanished">120</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>200</source>
        <translation type="vanished">200</translation>
    </message>
    <message>
        <source>240</source>
        <translation type="vanished">240</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>400</source>
        <translation type="vanished">400</translation>
    </message>
    <message>
        <source>500</source>
        <translation type="vanished">500</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Impossible de sauvegarder le fichier :</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Le fichier est en lecture seule ou utilisé par une autre application.</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="vanished">Sauvegarder comme Image</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="445"/>
        <source>All Files (*)</source>
        <translation>Tous les Fichiers (*)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>Multipage</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>Save As TIFF Image</source>
        <translation>Sauvegarder comme Image TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Fichiers TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>Transparent</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="269"/>
        <source>Antialiasing</source>
        <translation>Antialiase</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="26"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="311"/>
        <source>Export:</source>
        <translation>Exporter :</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="319"/>
        <source>Document</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="324"/>
        <source>Document and Annotations</source>
        <translation>Document et annotations</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Master PDF Editor</source>
        <translation type="obsolete">Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation>Supprimer les éléments inutilisés</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation>Ecraser les champs de formulaire</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation>Images en couleur et en niveaux de gris</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation>Compression</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation>Sans perte</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation>Qualité JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="340"/>
        <source>PDF/A Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation>Images en noir et blanc</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation>CCITT Group 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Sauvegarder PDF optimisé sous...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation>Fusionner toutes les couches</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>Balayer...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScanExeDlg.cpp" line="140"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanImageViewerDialog</name>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="39"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="42"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="45"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="68"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="71"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="74"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanPreviewDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="44"/>
        <source>Close</source>
        <translation type="unfinished">Fermer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="51"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="26"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="23"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="18"/>
        <source>Scan</source>
        <translation>Balayage</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="46"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="107"/>
        <source>Output</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="55"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="199"/>
        <source>Source</source>
        <translation type="unfinished">La source</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="414"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="61"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="122"/>
        <source>Before current page</source>
        <translation>Avant la page courante</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="424"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="71"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="132"/>
        <source>After last page</source>
        <translation>Après la dernière Page</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="397"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="78"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="139"/>
        <source>After current page</source>
        <translation>Après la page courante</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="407"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="88"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="149"/>
        <source>Before first page</source>
        <translation>Avant la première Page</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="304"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="174"/>
        <source>Append to Current Document </source>
        <translation>Ajouter au document actuel</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="299"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="181"/>
        <source>Create New Document</source>
        <translation>Créer un nouveau document</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="450"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>Le scanner</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="133"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="105"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="241"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="522"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="183"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>Balayage</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="80"/>
        <source>Preview</source>
        <translation>Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="112"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="248"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="90"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="255"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="97"/>
        <source>Skip empty pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="544"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="36"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1069"/>
        <source>Looking for devices. Please wait.</source>
        <translation>Recherche des périphériques. Attendre...</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="vanished">Recharger</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="vanished">Mode</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="209"/>
        <source>Resolution</source>
        <translation>Résolution</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="315"/>
        <source>Flatbed</source>
        <translation>Scanner à plat</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="322"/>
        <source>Negative Transparency</source>
        <translation>Transparence négative</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <source>Document Feeder</source>
        <translation>Chargeur de documents</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <source>Positive Transparency</source>
        <translation>Transparence positive</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="353"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="139"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="197"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="50"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="47"/>
        <source>untitled</source>
        <translation>sans titre</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="501"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1007"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="350"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="381"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="188"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="225"/>
        <source>Save As PDF</source>
        <translation>Sauvegarder comme PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="503"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1009"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="352"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="383"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="227"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Fichiers PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="64"/>
        <source>Single Page</source>
        <translation>Page Seule</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="65"/>
        <source>All Pages From Feeder</source>
        <translation>Toutes les pages du chargeur</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="462"/>
        <source>Scan:</source>
        <translation>Balayage :</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="482"/>
        <source>Page Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1080"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="130"/>
        <source>Open device. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="193"/>
        <source>Size</source>
        <translation type="unfinished">Dimension</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="571"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="27"/>
        <source>Saved Settings</source>
        <translation type="unfinished">Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="39"/>
        <source>Save</source>
        <translation type="unfinished">Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished">Aucun</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="70"/>
        <source>Delete</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="219"/>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="225"/>
        <source>After scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="318"/>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save Settings</source>
        <translation type="unfinished">Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="418"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="767"/>
        <source>Scan source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="776"/>
        <source>ADF Duplex Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="784"/>
        <source>ADF Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="792"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="801"/>
        <source>Scan mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="833"/>
        <source>Scan resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="845"/>
        <source>X-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="854"/>
        <source>Y-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="obsolete">Luminosité</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="obsolete">Contraste</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="899"/>
        <source>Page width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="916"/>
        <source>Page height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="938"/>
        <source>Top-left x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="956"/>
        <source>Top-left y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="977"/>
        <source>Bottom-right x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="994"/>
        <source>Bottom-right y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>Scanner plus de pages</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>Numérisation complète</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation type="vanished">Aperçu</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Rotation de 90 degrés dans le sens des aiguilles d&apos;une montre</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Rotation de 90 degrés dans le sens inverse des aiguilles d&apos;une montre</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="138"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="204"/>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0  résultat</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Case Sensitive</source>
        <translation>Respect de la casse</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="92"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="102"/>
        <source> result</source>
        <translation> résultat</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="106"/>
        <source> results</source>
        <translation> résultats</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="104"/>
        <source> result(s)</source>
        <translation> résultats</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="23"/>
        <source>Include Comments</source>
        <translation>inclure Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="27"/>
        <source>Whole Words Only</source>
        <translation>Mots complets seulement</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="134"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="183"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="233"/>
        <source>Check All</source>
        <translation>Cocher tout</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation>Marquer les résultats vérifiés pour la rédaction</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">Recherche et Rédaction</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="229"/>
        <source>Uncheck All</source>
        <translation>Décocher tout</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="124"/>
        <source>Case Sensitive</source>
        <translation>Respect de la casse</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="125"/>
        <source>Include Comments</source>
        <translation>inclure Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Whole Words Only</source>
        <translation>Mots complets seulement</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation>Certificat de sécurité</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation>Bénéficiaire</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation>Permissions</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation>Contenu copié pour accessibilité</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation>Modifier le document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation>Commenter</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation>Imprimer le document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Gérer les Pages et les Signets</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Remplir un formulaire ou les zones de signature</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimer le document en haute résolution</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Extract the content of the document</source>
        <translation>Extraire le contenu du document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation>Cryptage</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation>Bénéficiaires</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="35"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="vanished">PDF Sécurité</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Nécessite un mot de passe pour ouvrir le document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Document sans mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Mot de passe confirmé</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Permissions</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Commenter</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Modifier le Document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Contenu copié pour accessibilité</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Impression du document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Extraire le contenu du document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprime une version haute résolution du document</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Remplir un formulaire ou les zones de signature</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Mot de passe pour les permissions</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="259"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Gérer les Pages et les Signets</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="104"/>
        <source>Document Open password does not match.</source>
        <translation>Document sans mot de passe ne fonctionne pas.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="116"/>
        <source>Document Permission password does not match.</source>
        <translation>Document avec mot de passe pour les permissions ne fonctionne pas.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>Cryptage</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation>128 bit RC4</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation>128 bit RC4 {40 ?}</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
</context>
<context>
    <name>SessionsDialog</name>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished">Nouveau</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="32"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="39"/>
        <source>Switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="46"/>
        <source>Import</source>
        <translation type="unfinished">Importer</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished">Exporter</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="60"/>
        <source>Rename</source>
        <translation type="unfinished">Renommer</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="67"/>
        <source>Remove</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="74"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="93"/>
        <source>Session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="98"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="103"/>
        <source>Last Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="108"/>
        <source>Document count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="121"/>
        <source>Store paths to documents relative to session file when exporting sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="140"/>
        <source>Managed Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="184"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>MPE session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="273"/>
        <source>Failed to load sessions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="452"/>
        <location filename="../../src/SessionsDialog.cpp" line="457"/>
        <source>New session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>New session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>Please write new session name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation>Destination choisie</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>Utiliser les barres de défilement, la souris et les outils de zoom pour sélectionner la vue cible, puis appuyer sur Définir le lien pour créer la destination du lien.</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translation>Définir le lien</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation>Habituel</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation>Définir le zoom actuel</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Propriétés des Signatures</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="54"/>
        <source>Signature is VALID</source>
        <translation>La Signature est valide</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Détails</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Signé par :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="502"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="665"/>
        <source>Reason:</source>
        <translation>Raison :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="883"/>
        <source>Date:</source>
        <translation>Date :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Localisation :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Sommaire de validation</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Information de contact du signataire :</translation>
    </message>
    <message>
        <source>Sing As</source>
        <translation type="vanished">Signer comme</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation>Texte à signer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation>Localisation</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation>Raison</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="331"/>
        <source>Lock document after signing</source>
        <translation>Verrouiller le document après la signature</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="353"/>
        <source>Signature Preview</source>
        <translation>Aperçu de la Signature</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="72"/>
        <source>I have reviewed this document</source>
        <translation>J&apos;ai révisé ce document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="73"/>
        <source>I am approving this document</source>
        <translation>J&apos;approuve ce document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="74"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>J&apos;atteste la précision et l&apos;intégrité de ce document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="75"/>
        <source>I agree to specified parts of this document</source>
        <translation>Je suis d&apos;accord avec les parties spécifiques de ce document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="553"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="557"/>
        <source>M.d.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="562"/>
        <source>M.d.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="567"/>
        <source>M.d.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="572"/>
        <source>M.d.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="577"/>
        <source>MM.dd.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="582"/>
        <source>MM.dd.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="587"/>
        <source>MM.dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="592"/>
        <source>MM.dd.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="597"/>
        <source>MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="602"/>
        <source>MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="607"/>
        <source>d.M.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="612"/>
        <source>d.M.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="617"/>
        <source>dd.MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="622"/>
        <source>dd.MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="627"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="632"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="637"/>
        <source>yy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="642"/>
        <source>yy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="647"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="652"/>
        <source>yyyy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="657"/>
        <source>d-MMMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="662"/>
        <source>d-MMMM HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="667"/>
        <source>d-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="672"/>
        <source>d-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="677"/>
        <source>d-MMMM-yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="682"/>
        <source>d-MMMM-yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="687"/>
        <source>dd-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="692"/>
        <source>dd-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="331"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>Open File</source>
        <translation>Ouvrir un Fichier</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation type="vanished">Fichiers p12 (*.p12)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="918"/>
        <source>A password is required to open certificate:</source>
        <translation>Un mot de passe est demandé pour ouvrir le certificat :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="299"/>
        <source>Sign</source>
        <translation>Signer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="787"/>
        <source>Show Image</source>
        <translation>Montrer l&apos;Image</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="812"/>
        <source>Stretch Image</source>
        <translation>Image étendue</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="822"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="464"/>
        <source>Show Text</source>
        <translation>Montrer le Texte</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="476"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Une erreur est survenue pendant la vérification de la signature !</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Open Image</source>
        <translation>Ouvrir une Image</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="189"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Fichiers Image (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Ce document a été altéré ou corrompu depuis qu&apos;il a été signé.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Ce document n&apos;a pas été modifié depuis qu&apos;il a été signé.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="53"/>
        <source>Signature is INVALID</source>
        <translation>La signature est invalide</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="55"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>La validité de la signature est inconnue</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="57"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>L&apos;identité du signataire est inconnue car elle n&apos;a pas été incluse dans votre liste des identités de confiance et aucun des certificats n&apos;a cette liste.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="58"/>
        <source>Error during signature verification.</source>
        <translation>Erreur durant la vérification de signature.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="59"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Détails : la signature en plage d&apos;octets est invalide</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="60"/>
        <source>I am the author of this document</source>
        <translation>Je suis l&apos;auteur de ce document</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="56"/>
        <source>This certificate is not trusted</source>
        <translation>Le certificat n&apos;est pas de confiance</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="vanished">Parcourt...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation>Signer comme</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="400"/>
        <source>Appearance Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="441"/>
        <source>Формат  по ГОСТу</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="473"/>
        <source>Date /Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="543"/>
        <source>Date Format</source>
        <translation type="unfinished">Format de date</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="727"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="733"/>
        <source>Show Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="751"/>
        <source>Rounded Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">Heure</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="483"/>
        <source>Signed By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Custom</source>
        <translation>Habituel</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="703"/>
        <source>E-mail</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="713"/>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Date</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="422"/>
        <source>Text</source>
        <translation type="unfinished">Texte</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="781"/>
        <source>Image</source>
        <translation type="unfinished">Image</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation type="vanished">Signé par </translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="vanished">Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="280"/>
        <source>Saved Settings</source>
        <translation>Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="308"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="293"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save Settings</source>
        <translation>Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save current settings as:</source>
        <translation>Enregistrer les paramètres actuels comme :</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1490"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Etes-vous sûr de vouloir supprimer le paramètre?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="503"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="332"/>
        <source>Certificate Manager</source>
        <translation>Gestionnaire de Certificats</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Tous les fichiers pris en charge (*.p12 *.pfx);; Fichiers p12 (*.p12);; Fichiers pfx (*.pfx);; Tous les Fichiers (*)</translation>
    </message>
    <message>
        <source>Digitally signed by</source>
        <translation type="vanished">Signé par</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation>Signatures</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="286"/>
        <source>Unsigned Signature</source>
        <translation>Signature non signée</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Location</source>
        <translation>Localisation</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <source>Page</source>
        <translation>Page</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="302"/>
        <source>Signed Signature</source>
        <translation>Signature signée</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="305"/>
        <source>Signed by:</source>
        <translation>Signé par :</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="306"/>
        <source>Reason:</source>
        <translation>Raison :</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="346"/>
        <source>Click to view this version</source>
        <translation>Cliquer pour voir cette version</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Document</source>
        <translation type="unfinished">Document</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Emetteur</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Nom Commun (NC)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organisation (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Unité d&apos;Organisation (UO)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Numéro de Série</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algorithme</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Sujet</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Validité</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Pas Avant</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Pas Après</translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation type="vanished">SHA-1 :</translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="vanished">MD5</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Ajouter aux Identités de Confiance</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation>Nom du Fichier</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="98"/>
        <source>Custom</source>
        <translation>Habituel</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation>Gérer les Tampons</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>Tampons personnalisés</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>Editer</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>Tampons</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>Modifier le Tampon</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>Modèle</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="43"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation>Répondre</translation>
    </message>
</context>
<context>
    <name>StickyNoteReply</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Nom de Police:</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Taille de police:</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Couleur du Texte:</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>Éditeur de texte</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="166"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="184"/>
        <source>Add Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="199"/>
        <source>Name</source>
        <translation type="unfinished">Nom</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="224"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="249"/>
        <source>Organization unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="274"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="299"/>
        <source>Email</source>
        <translation type="unfinished">Email</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="324"/>
        <source>Valid since</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="349"/>
        <source>Valid till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="365"/>
        <source>Date</source>
        <translation type="unfinished">Date</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="obsolete">De</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="obsolete">A</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Famille de Polices&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la  Famille de Polices&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couleur de la Police&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la couleur de la police&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Couleur de fond de Police&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Changer la couleur de la police&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ThumbnailForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="22"/>
        <source>Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="29"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="42"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="62"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="75"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.cpp" line="39"/>
        <source>Pages</source>
        <translation type="unfinished">Pages</translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="227"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="233"/>
        <source>Highlight</source>
        <translation type="unfinished">Surligner</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="268"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="271"/>
        <source>StrikeOut</source>
        <translation type="unfinished">Barrer</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="125"/>
        <source>Underline</source>
        <translation type="unfinished">Souligner</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="167"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="170"/>
        <source>Copy</source>
        <translation type="unfinished">Copier</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="101"/>
        <source>Delete</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="104"/>
        <source>Open</source>
        <translation type="unfinished">Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="110"/>
        <source>Red</source>
        <translation type="unfinished">Rouge</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="112"/>
        <source>Blue</source>
        <translation type="unfinished">Bleu</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="114"/>
        <source>Yellow</source>
        <translation type="unfinished">Jaune</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="116"/>
        <source>Green</source>
        <translation type="unfinished">Vert</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="119"/>
        <source>Change</source>
        <translation type="unfinished">Changer</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <source>New</source>
        <translation type="obsolete">Nouveau</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Ouvrir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="696"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="obsolete">Rechercher</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Commentaire</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="obsolete">Tampon</translation>
    </message>
    <message>
        <source>Comment View</source>
        <translation type="obsolete">Voir les commentaires</translation>
    </message>
    <message>
        <source>Place Initials</source>
        <translation type="obsolete">Placer les Initiales</translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="obsolete">Principal</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="obsolete">Affichage</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation type="obsolete">Objets</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation type="obsolete">Commentaires</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="602"/>
        <source>Open a PDF file</source>
        <translation>Ouvrir un fichier PDF</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="obsolete">Montrer</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation type="obsolete">Machine à écrire</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="obsolete">Note</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Annuler</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rétablir</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="obsolete">Placer Devant</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Couper</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copier</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Coller</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Fichier</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Enregistrer</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Imprimer</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulaires</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="obsolete">Signature</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="obsolete">Bouton radio</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="obsolete">Zone de liste</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="obsolete">Champ de saisie de texte</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="obsolete">Zone de liste modifiable</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="obsolete">Case à cocher</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation type="obsolete">Crayon</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="obsolete">Ellipse</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rectangle</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Ligne</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="obsolete">Insérer un texte</translation>
    </message>
    <message>
        <source>Redaction</source>
        <translation type="obsolete">Rédaction</translation>
    </message>
    <message>
        <source>Mark for Redaction</source>
        <translation type="obsolete">Marquer pour la rédaction</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="obsolete">Outils</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation type="obsolete">Editer le texte</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation type="obsolete">Outil Main</translation>
    </message>
    <message>
        <source>Previous View</source>
        <translation type="obsolete">Vue précédente</translation>
    </message>
    <message>
        <source>Next View</source>
        <translation type="obsolete">Vue suivante</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Zoom Arrière</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Zoom Avant</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="obsolete">Ajuster la Page</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="obsolete">Ajuster la Largeur</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>Filigrane</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="648"/>
        <source>Delete</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="662"/>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="670"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="231"/>
        <source>Source</source>
        <translation>La source</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="427"/>
        <source>Text</source>
        <translation>Texte</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="244"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="417"/>
        <source>Scale</source>
        <translation>Échelle</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total des pages :</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="237"/>
        <source>Page Number</source>
        <translation>Page Nombre</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="264"/>
        <source>Font</source>
        <translation>Police</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="270"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="322"/>
        <source>Size</source>
        <translation>Dimension</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="315"/>
        <source>Font Family</source>
        <translation>Famille de Polices</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="380"/>
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="121"/>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Aperçu</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="28"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="45"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="52"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="127"/>
        <source>Rotation</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="145"/>
        <source>Options</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="165"/>
        <source>Opacity</source>
        <translation>Opacité</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="221"/>
        <source>Scale relative to target page</source>
        <translation>Échelle par rapport à la page cible</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="489"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="495"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="630"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="754"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="760"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="791"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="453"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="495"/>
        <source>Vertical distance</source>
        <translation>Distance verticale</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="529"/>
        <source>from</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="562"/>
        <source>Top</source>
        <translation>Haut</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="468"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="567"/>
        <source>Center</source>
        <translation>Centrer</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="572"/>
        <source>Bottom</source>
        <translation>Bas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="488"/>
        <source>Horizontal distance</source>
        <translation>Distance horizontale</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="463"/>
        <source>Left</source>
        <translation>Gauche</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Right</source>
        <translation>Droite</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="580"/>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">points</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">pouces</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">millimètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="80"/>
        <source>Page Range Options...</source>
        <translation>Options de plage de pages...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save Settings</source>
        <translation>Enregistrer les paramètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save current settings as:</source>
        <translation>Enregistrer les paramètres actuels comme :</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="302"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Des paramètres avec ce nom existent déjà. Remplacer les anciens paramètres?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Etes-vous sûr de vouloir supprimer le paramètre?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="420"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="436"/>
        <source> in</source>
        <translation> po</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="454"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>Open File</source>
        <translation>Ouvrir le fichier</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Fichiers PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="499"/>
        <source>There was an error opening the document !</source>
        <translation>Une erreur s&apos;est produite à l&apos;ouverture du document !</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="299"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="629"/>
        <source>Saved Settings</source>
        <translation>Paramètres enregistrés</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="540"/>
        <source>Points</source>
        <translation>points</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="545"/>
        <source>Inches</source>
        <translation>pouces</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="550"/>
        <source>Millimeters</source>
        <translation>millimètres</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Tous les fichiers pris en charge (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="600"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="606"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="613"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSignature</name>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="37"/>
        <source>Digitally signed by</source>
        <translation type="unfinished">Signé par</translation>
    </message>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="38"/>
        <source>Email</source>
        <translation type="unfinished">Email</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Date</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulaire</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation>Couches</translation>
    </message>
</context>
</TS>
