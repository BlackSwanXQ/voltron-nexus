<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR" sourcelanguage="en">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="410"/>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="127"/>
        <source>Registered version.</source>
        <translation>Cópia licenciada.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="179"/>
        <source>Purchased On:</source>
        <translation>Comprada em:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="187"/>
        <source>Maintenance Plan Expires:</source>
        <translation>A assinatura expira em:</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="53"/>
        <source>Registration Info</source>
        <translation>Informação da Licença</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="58"/>
        <source>License Agreement</source>
        <translation>Acordo de Licença</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="126"/>
        <source>Not Registered version.</source>
        <translation>Versão não licenciada.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="48"/>
        <source>Version Info</source>
        <translation>Informação da Versão</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="105"/>
        <source>Built with</source>
        <translation>Compilada com</translation>
    </message>
    <message>
        <source>Legal Notices</source>
        <translation type="vanished">Termos Legais</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="258"/>
        <source>This software uses, with permission, the following copyrighted software.</source>
        <translation>Este software usa, com as devidas licenças, os seguintes componentes de software protegidos por direitos autorais.</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.cpp" line="99"/>
        <source>Please, renew your license</source>
        <translation>Favor renovar sua licença</translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="122"/>
        <source>Third-Party Software</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation>Comandos do Documento</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="96"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="103"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translatorcomment>Aqui e nas expressões a seguir, a rigor, &quot;will&quot; não transmite a ideia de &quot;futuro&quot;.</translatorcomment>
        <translation>Fechar o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translatorcomment>Idem</translatorcomment>
        <translation>Salvar o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translatorcomment>Idem</translatorcomment>
        <translation>O arquivo foi salvo</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translatorcomment>Idem</translatorcomment>
        <translation>Imprimir o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation>A impressão foi feita</translation>
    </message>
</context>
<context>
    <name>AddOpenFilesDialog</name>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="14"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.ui" line="22"/>
        <source>Open PDF files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>File Name</source>
        <translation type="unfinished">Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="18"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/addopenfilesdialog.cpp" line="32"/>
        <source>Add Files</source>
        <translation type="unfinished">Adicionar arquivos</translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation>Config avançada de impressão</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation>Imprimir como imagem</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="63"/>
        <source>Queue In Subset Pages</source>
        <translatorcomment>I found this options inside advanced printing but still unclear about its purpose</translatorcomment>
        <translation>Fila no subgrupo de páginas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="97"/>
        <source>Сompatible with Laser Engraving</source>
        <translation>Compatível com Gravação a Laser</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="246"/>
        <source>Borders and Colors</source>
        <translation>Bordas e Cores</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="256"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="261"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="266"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="271"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="276"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="281"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="286"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="291"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="296"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="301"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="306"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="314"/>
        <source>Border Color</source>
        <translation>Cor da Borda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="321"/>
        <source>Fill Color</source>
        <translation>Cor de Preenchimento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="329"/>
        <source>Solid</source>
        <translatorcomment>That is, &quot;non-dashed&quot;, for example.</translatorcomment>
        <translation>Inteiriço</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="334"/>
        <source>Dashed</source>
        <translation>Pontilhado</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="obsolete">Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="349"/>
        <source>Line Width</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="342"/>
        <source>Line Style</source>
        <translation>Tipo de linha</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation>Opções de Aparência</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation>Exibir durante a impressão</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation>Mostrar quando exibido na tela</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Manter o posicionamento e tamanho do texto da marca d&apos;água contantes ao imprimir em diferentes tamanhos de papel</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Arquivo</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Criar PDF</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Abrir</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">Arquivos recentes</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Ajuda</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">Licenciar...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">Procurar atualizações agora</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Ajuda...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation>Plano de fundo</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="335"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="349"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="357"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="367"/>
        <source>Source</source>
        <translation>Origem</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="405"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="411"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="508"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="514"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="540"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="660"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="449"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total de páginas:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="383"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="484"/>
        <source>Page Number</source>
        <translation>Número da página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="422"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="373"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="26"/>
        <source>Rotation</source>
        <translation>Rotação</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="44"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="64"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="120"/>
        <source>Scale relative to target page</source>
        <translation>Escala relativa à página alvo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="140"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="187"/>
        <source>Vertical distance</source>
        <translation>Distância vertical</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="506"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="514"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="531"/>
        <source>of</source>
        <translation type="unfinished">de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="538"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="166"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="246"/>
        <source>from</source>
        <translatorcomment>Too common a word to translate alone. Depends a lot on context. </translatorcomment>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="282"/>
        <source>Top</source>
        <translation>No topo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="265"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="287"/>
        <source>Center</source>
        <translation>No centro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="292"/>
        <source>Bottom</source>
        <translation>Embaixo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="180"/>
        <source>Horizontal distance</source>
        <translation>Distância horizontal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="260"/>
        <source>Left</source>
        <translation>À esquerda</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="270"/>
        <source>Right</source>
        <translation>À Direita</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="173"/>
        <source>Units</source>
        <translatorcomment>Don&apos;t change to &quot;Unidades&quot;.</translatorcomment>
        <translation>Unidades de Medida</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="566"/>
        <source>Page Range Options...</source>
        <translation>Opções de intervalo de páginas...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save Settings</source>
        <translation>Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="231"/>
        <source>Save current settings as:</source>
        <translation>Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="241"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Já existe uma configuração salva com esse nome. Deseja substituí-la?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="276"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="337"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <source> in</source>
        <translation> pol</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="371"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="415"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Arquivos PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="vanished">Erro na tentativa de abrir o arquivo!</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="316"/>
        <source>Saved Settings</source>
        <translation>Configurações salvas</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="228"/>
        <source>Points</source>
        <translation>Pontos</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="233"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="238"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="391"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos os arquivos válidos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="201"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="207"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatesNumberingOptionsDialog</name>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="32"/>
        <source>Start Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="39"/>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="59"/>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="69"/>
        <source>Number of Digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.ui" line="14"/>
        <source>Bates Numbering Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source>The value must be between </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="56"/>
        <location filename="../../src/batesnumbering/batesnumberingoptionsdialog.cpp" line="71"/>
        <source> and </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Propriedades do marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="115"/>
        <source>Style</source>
        <translatorcomment>Don&apos;t change to &quot;Estilo&quot;.</translatorcomment>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="129"/>
        <source>Plain</source>
        <translation>Sem Formatação</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="134"/>
        <source>Italic</source>
        <translation>Itálico</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="139"/>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="144"/>
        <source>Italic &amp; Bold</source>
        <translation>Negrito e Itálico</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="165"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="179"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="292"/>
        <source>Actions</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="351"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="332"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="185"/>
        <source>Add an Action</source>
        <translation>Adicionar Comando</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="220"/>
        <source>Trigger</source>
        <translation>Acionador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="204"/>
        <source>Action</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="212"/>
        <source>Mouse Up</source>
        <translation>Ao se soltar o botão do mouse</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="228"/>
        <source>Goto a Page View</source>
        <translation>Mostrar Visualização de Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="233"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="238"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço de Internet</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="243"/>
        <source>Reset form</source>
        <translation>Limpar formulário</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="248"/>
        <source>Show/Hide fields</source>
        <translation>Exibir/ocultar campos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="253"/>
        <source>Submit a form</source>
        <translation>Enviar dados de formulário</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="258"/>
        <source>Run a JavaScript</source>
        <translation>Executar código de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="266"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Número da página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="86"/>
        <source>Set current position</source>
        <translatorcomment>Don&apos;t change to &quot;Usar a posição atual&quot;.</translatorcomment>
        <translation>Usar o destino atual</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="96"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="78"/>
        <source>untitled</source>
        <translation>sem nome</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="220"/>
        <source>Do you want to set the current position?</source>
        <translatorcomment>Don&apos;t change to &quot;posição atual&quot;. &quot;Current position&quot; refers to &quot;the current page&quot;.</translatorcomment>
        <translation>Quer mesmo usar o destino atual?</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="222"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
</context>
<context>
    <name>BookmarksForm</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="20"/>
        <source>Bookmarks</source>
        <translation type="unfinished">Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="38"/>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="69"/>
        <source>Set destanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="100"/>
        <source>Delete bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="131"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="162"/>
        <source>Expand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="193"/>
        <source>Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksForm.ui" line="224"/>
        <source>Delete all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificateManagerDlg</name>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="14"/>
        <source>Certificate Manager</source>
        <translation>Gestor de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="24"/>
        <source>Your Certificates</source>
        <translation>Seus Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="33"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="53"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="60"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.ui" line="78"/>
        <source>Trusted System Certificates</source>
        <translation>Certificados confiáveis do sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="44"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="86"/>
        <source>All Supported Files (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Todos os arquivos válidos (*.p12 *.pfx *.cer *.crt *.pem);; p12 Files (*.p12);; pfx Files (*.pfx);; Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="102"/>
        <source>A password is required to open certificate:</source>
        <translation>É necessário informar senha para abrir o certificado:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="114"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <source>Are you sure you want to delete ceritficate?</source>
        <translatorcomment>There&apos;s an error on the source text (ceritficate intead of certificate)</translatorcomment>
        <translation type="vanished">Quer mesmo apagar o certificado?</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="158"/>
        <source>pfx Files (*.pfx)</source>
        <translation>Arquivos pfx (*.pfx)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="160"/>
        <source>crt Files (*.crt)</source>
        <translation>Arquivos crt (*.crt)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="162"/>
        <source>Save File</source>
        <translation>Salvar arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="171"/>
        <source>Please, specify private key password:</source>
        <translation>Favor especificar uma senha:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/CertificateManagerDlg.cpp" line="126"/>
        <source>Are you sure you want to delete certificate?</source>
        <translation>Quer mesmo apagar o certificado?</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Criação de Novo Documento Usando Arquivos Externos</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="181"/>
        <source>Add Files</source>
        <translation>Adicionar arquivos</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="164"/>
        <source>Add Folder</source>
        <translation>Adicionar pasta</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="211"/>
        <source>Add Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="267"/>
        <source>Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="298"/>
        <source>Down</source>
        <translation>Descer</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="237"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="278"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="196"/>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="124"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Salvar</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="84"/>
        <source>untitled</source>
        <translation>sem nome</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="126"/>
        <source>Add Headers and Footers to Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="142"/>
        <source>Total pages</source>
        <translation>Total de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="198"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="129"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="197"/>
        <source>Total Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="488"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="921"/>
        <source>Save As PDF</source>
        <translation>Salvar como PDF</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="490"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="923"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1002"/>
        <source>File</source>
        <translation type="unfinished">Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1003"/>
        <source>has already been added to the list. Please choose a different file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1051"/>
        <source> is already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1052"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1074"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="1073"/>
        <source>are already added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Todos os formatos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="600"/>
        <source>Select directory</source>
        <translation>Escolher diretório</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="956"/>
        <source>Save failed</source>
        <translation>Falha na tentativa de salvar</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Não foi possível salvar para o arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="957"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente-leitura ou estar sendo usado por outro programa.</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="34"/>
        <source>Output</source>
        <translation>Saída</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="101"/>
        <source>Append to Current Document </source>
        <translation>Adicionar ao documento atual </translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="108"/>
        <source>Create New Document</source>
        <translation>Criar um novo documento</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="43"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="20"/>
        <source>Add files to which Headers and Footers or Bates Numbers should be placed. Bates Numbers will appear in the specified order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="27"/>
        <source>Save and close files after numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="49"/>
        <source>Before current page</source>
        <translation>Antes da página atual</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="59"/>
        <source>After last page</source>
        <translation>Depois da última página</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="66"/>
        <source>After current page</source>
        <translation>Depois da página atual</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="76"/>
        <source>Before first page</source>
        <translation>Antes da primeira página</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="309"/>
        <source>Show</source>
        <translation type="unfinished">Exibir</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Todos os arquivos válidos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="137"/>
        <source>Import Bookmarks</source>
        <translation>Importar Favoritos</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Insert Pages</source>
        <translation>Inserir Páginas</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="550"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Todos os arquivos válidos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="42"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="49"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="553"/>
        <source>All Supported Files (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation type="unfinished">Todos os arquivos válidos (*.pdf *.PDF *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Todos os arquivos (*)</translation>
    </message>
</context>
<context>
    <name>DeleteAcrossPagesDialog</name>
    <message>
        <location filename="../../src/DeleteAcrossPagesDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="14"/>
        <source>Delete Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.ui" line="23"/>
        <source>Do you want to delete all headers, footers and Bates numbers on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="obsolete">Quer mesmo apagar os cabeçalhos e rodapés do arquivo?</translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="22"/>
        <source>Do you want to delete all watermarks on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeleteHeaderAndFooterDialog.cpp" line="27"/>
        <source>Do you want to delete all backgrounds on the selected pages from the document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Quer mesmo apagar estas páginas? O operação não poderá ser desfeita.</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translatorcomment>Please, leave as it is.</translatorcomment>
        <translation>Remover Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translatorcomment>That&apos;s corret. Don&apos;t change translation above. </translatorcomment>
        <translation type="vanished">Da página</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="50"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>AVISO: As páginas removidas não poderão ser recuperadas com o comando desfazer.</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Botão</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Opacidade</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texto</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Aparência</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">Cor</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Autor:</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">Assunto:</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">Bloqueado</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Configurações</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation>Medidor de Distância</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation>Medida</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation>Distância:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation>Ângulo:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation>Localização do Cursor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation>Configuração de Unidades e Realce</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="276"/>
        <source>Scale Ratio:</source>
        <translation>Proporção:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="251"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="256"/>
        <source>in</source>
        <translation>pol</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="261"/>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="269"/>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="283"/>
        <source>Annotation:</source>
        <translation>Observação:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation>º</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="32"/>
        <source>Distance</source>
        <translation>Distância</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="36"/>
        <source>Perimeter</source>
        <translation>Perímetro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="43"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="46"/>
        <source> sq</source>
        <translatorcomment>There no official abreviation to Square in portuguese. We use the ² simbol together with km, m and so on. Eg. km², m² et cetera. </translatorcomment>
        <translation> qd</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="222"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="225"/>
        <source> in</source>
        <translation> pol</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="229"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
</context>
<context>
    <name>DlgChangeFont</name>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="14"/>
        <source>Change Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="39"/>
        <source>Current font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="46"/>
        <source>Change to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="66"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished">Alterar automaticamente a fonte quando se editar texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.ui" line="84"/>
        <source>Exact match only</source>
        <translation type="unfinished">Só levar em conta correspondência exata</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="21"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished">Esta fonte não contém esses caracteres.
Tente escolher outra fonte.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="28"/>
        <source>Change</source>
        <translation type="unfinished">Alterar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/texteditor/DlgChangeFont.cpp" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Família de fontes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a família de fontes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation>Posição do ícone</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation>Ajustar às margens</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation>Quando ajustar:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation>Proporcionalmente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation>Sem proporcionalidade</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation>Botão</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation>O ícone é muito grande</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Use esta área para modificar a forma pela qual deseja ajustar o ícone dentro do botão</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation>O íconte é muito pequeno</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation>Número da Página e Formato da Data</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation>Formato da Data</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation>Formato do Número das Páginas</translation>
    </message>
    <message>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="14"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="16"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation>Número da página inicial</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="51"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="18"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="20"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="21"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>of</source>
        <translatorcomment>Too common to translate out of context.</translatorcomment>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="53"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="54"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="27"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="29"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="31"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="33"/>
        <location filename="../../src/utils/headerandfooterutils.cpp" line="34"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translatorcomment>Don&apos;t change to &quot;Opções de Intervalo de Páginas&quot;.</translatorcomment>
        <translation>Especificação de Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Páginas ímpares</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Editar texto</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Salvar a imagem como arquivo</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Propriedades do Componente...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Recortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copiar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Excluir</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="41"/>
        <source>Select All</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Colar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Salvar como</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="48"/>
        <source>Add Sticky Note</source>
        <translation>Adicionar Comentário de Balão Móvel</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="49"/>
        <source>Highlight Text</source>
        <translation>Adicionar Comentário de Texto Destacado</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="50"/>
        <source>Strikeout Text</source>
        <translatorcomment>Don&apos;t change to &quot;Texto Tachado&quot;</translatorcomment>
        <translation>Adicionar Comentário de Texto Riscado</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="51"/>
        <source>Underline Text</source>
        <translation>Adicionar Comentário de Texto Sublinhado</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="52"/>
        <source>Add Bookmark</source>
        <translation>Adicionar Marcador</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2456"/>
        <location filename="../../src/docpage/docpage.cpp" line="2496"/>
        <source>Goto a Page View</source>
        <translatorcomment>Please, don&apos;t change to &quot;Ir para/Exibir uma Visualização de Página&quot;.</translatorcomment>
        <translation>Ir para a página conforme especificado no comando</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2465"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2475"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2486"/>
        <source>Run a JavaScript</source>
        <translation>Executar Comando de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="3975"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="70"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="82"/>
        <source>Set Status</source>
        <translatorcomment>Here, &quot;set status&quot; means &quot;Status atual&quot;, &quot;status definido/especificado&quot; etc. Please, don&apos;t change to &quot;Aplicar/Definir Status&quot;.</translatorcomment>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1087"/>
        <location filename="../../src/docpage/docpage.cpp" line="1090"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1678"/>
        <source>The selected area has been copied</source>
        <translation>Feita a captura e copiada na Área de Transferência</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation type="vanished">Copiar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="vanished">Recortar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Colar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="131"/>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="132"/>
        <source>Options</source>
        <translatorcomment>Don&apos;t change to &quot;Opções&quot;.</translatorcomment>
        <translation>Propriedades</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Editar texto</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="136"/>
        <source>Signature options</source>
        <translation>Opções de assinatura</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="vanished">Desfazer</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="139"/>
        <location filename="../../src/docpage/docpage_base.cpp" line="2622"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Open Image</source>
        <translation>Abri Imagem</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation type="vanished">ERRO na tentativa de carregar a imagem!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="140"/>
        <source>Set Fit to Page</source>
        <translation>Ajustar à Página</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="141"/>
        <source>Save Image to file</source>
        <translation>Salvar a imagem como arquivo</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Salvar como...</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1940"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Imagens PNG (*.png);;Imagens BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1950"/>
        <source>PNG Images (*.png)</source>
        <translation>Imagens PNG (*.png)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Arquivos de imagem (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>ERROR Loading Image !</source>
        <translation type="vanished">ERRO na tentativa de carregar a imagem!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="134"/>
        <source>Edit Image</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Editar a imagem</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="143"/>
        <source>Edit Path Nodes</source>
        <translation>Editar Ramos de Caminhos</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1656"/>
        <source>Edit the image and press Replace</source>
        <translation>Edite a imagem e clique em Substituir</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1658"/>
        <source>Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1659"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2593"/>
        <source>Delete Node</source>
        <translation>Apagar nó</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1705"/>
        <source>Image Files (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; All Files (*)</source>
        <translation>Arquivos de Imagem (*.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm);; Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="594"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="609"/>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="137"/>
        <source>Clear Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="135"/>
        <source>Replace Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1650"/>
        <source>An error occurred when attempting to open external application for editing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Editor de Comandos de Javascript</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">Ir para a página</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">automático</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">Topo</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Esquerda</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">Número da página</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">Zoom (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Abrir/Executar um Arquivo</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">Editar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation>Selecionar Campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation>Desselecionar Tudo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation>Método</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="187"/>
        <source>Show/Hide Fields</source>
        <translation>Exibir/Ocultar Campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="221"/>
        <source>Reset Form</source>
        <translatorcomment>Don&apos;t change to &quot;Redefinir o Forumário&quot;. Here, &quot;reset&quot; means to &quot;set the default blank status of the form/field back again&quot;, that being the same as &quot;Zerar o Formulário&quot;.</translatorcomment>
        <translation>Limpar o Formulário</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="vanished">Introduza um arquivo:</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="vanished">Introduza um site da web:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Opções</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="vanished">Modo Zoom</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Personalizar</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Herdar Zoom</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajustar a Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">Ajustar a Largura</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">AjusteV</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">AjusteR</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">AjusteB</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">AjusteBH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">AjusteBV</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation>Arquivo local</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translatorcomment>Don&apos;t change to &quot;Uso anônimo&quot;. The developer may have mispelled the word. </translatorcomment>
        <translation>Usuário anônimo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation>Necessário informar nome de usuário e senha</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation>Nome de usuário</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="115"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="117"/>
        <source>All Files (*.*)</source>
        <translation>Todos os arquivos (*.*)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="191"/>
        <source>Select Field</source>
        <translation>Selecionar Campo</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Action</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a file:</source>
        <translation>Especifique um arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Exibir a página especificada abaixo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="122"/>
        <source>Page Number</source>
        <translation>Número da página</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="129"/>
        <source>Zoom Mode</source>
        <translation>Tipo de Zoom</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="115"/>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="98"/>
        <source>X</source>
        <translation>Coordenada X</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="136"/>
        <source>Y</source>
        <translation>Coordenada Y</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">AjusteV</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">AjusteR</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">AjusteB</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">AjusteBH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">AjusteBV</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="230"/>
        <source>auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Enter a web site:</source>
        <translation>Digite um endereço de site:</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="171"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="173"/>
        <source>All Files (*.*)</source>
        <translation>Todos os arquivos (*.*)</translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="vanished">XYZ</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="vanished">Ajuste</translation>
    </message>
    <message>
        <source>FitH</source>
        <translation type="vanished">Ajuste Horz</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="114"/>
        <source>Named Action</source>
        <translation>Nome do Comando</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="150"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="155"/>
        <source>Fit Page</source>
        <translation>Ajustar à página</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="160"/>
        <source>Fit Width</source>
        <translation>Ajustar à largura do painel</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="165"/>
        <source>Fit Height</source>
        <translation>Ajustar à altura do painel</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="170"/>
        <source>Fit Visible</source>
        <translation>Ajustar à área visível</translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="223"/>
        <source> =  -1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditTabOrderDlg</name>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="14"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditTabOrderDlg.ui" line="20"/>
        <source>Forms</source>
        <translation type="unfinished">Formulários</translation>
    </message>
</context>
<context>
    <name>ExportCSVDialog</name>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="20"/>
        <source>Export to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="50"/>
        <source>File Name</source>
        <translation type="unfinished">Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="78"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="88"/>
        <source>Separator</source>
        <translation type="unfinished">Separador</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="103"/>
        <source>Semicolon ( ; )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="129"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="146"/>
        <source>Comma ( , )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.ui" line="153"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="38"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="47"/>
        <source>Export</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="111"/>
        <source>Export to csv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="113"/>
        <source>csv files (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportCSVDialog.cpp" line="149"/>
        <location filename="../../src/ExportCSVDialog.cpp" line="178"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="77"/>
        <source>Extract pages as a single file</source>
        <translation>Extrair páginas na forma de arquivo unitário</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Extrair Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="141"/>
        <source>Create a bookmark with the name of imported document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="130"/>
        <source>Save As PDF</source>
        <translation>Salvar como PDF</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="132"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Não foi possível salvar o arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="170"/>
        <location filename="../../src/ExportPageDialog.cpp" line="271"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente-leitura ou estar sendo usado por outro programa.</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>The file &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="242"/>
        <source>&quot; already exists. Do you wish to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="43"/>
        <source>Export Pages</source>
        <translation>Exportar Páginas</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="vanished">Exportar Páginas</translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation type="vanished">Exportar Marcadores</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="124"/>
        <source>Export bookmarks</source>
        <translation>Importar marcadores</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="134"/>
        <source>Delete pages after extracting</source>
        <translation>Apagar páginas depois de extrair</translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="23"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="88"/>
        <source>Export to text</source>
        <translation>Exportar como texto</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="64"/>
        <source>Extract pages as a single file</source>
        <translation>Extrair páginas na forma de arquivo único</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="35"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="43"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="90"/>
        <source>txt files (*.txt)</source>
        <translation>Arquivos TXT (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Não foi possível salvar o arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="124"/>
        <location filename="../../src/ExportTextDialog.cpp" line="151"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente-leitura ou estar em uso por outro programa.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Propriedades do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Informações do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Palavras-chave</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Criador</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Produtor</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="313"/>
        <source>Initial View</source>
        <translation>Visualização Inicial</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Imagens</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="612"/>
        <source>Fonts</source>
        <translation>Fontes</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="628"/>
        <source>Fonts used in this document</source>
        <translation>Fontes usadas neste documento</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Proteção</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Senha de Usuário</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Senha do Proprietário</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation>Proteção com Senha</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation>Sem proteção por senha</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="202"/>
        <source>Printing the document</source>
        <translation>Imprimir o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="189"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir uma versão de alta resolução do arquivo</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Extrair texto e gráficos</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extração Avançada de texto e gráficos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="254"/>
        <source>Modifying document</source>
        <translation>Modificar o arquivo</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Modificar anotações ou campos de formulário</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="215"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Preencher campos de formulário ou de assinatura</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="267"/>
        <source>Manage Pages and bookmarks</source>
        <translatorcomment>Don&apos;t change to &quot;Favoritos&quot;.</translatorcomment>
        <translation>Editar Páginas e Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="587"/>
        <source>Open to Page:</source>
        <translation>Abrir na Página:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="594"/>
        <source>of :</source>
        <translation>de:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Informações do PDF</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Modo de Página:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Page Only</source>
        <translation>Página Única</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Bookmarks Panel</source>
        <translation>Exibir o Painel de Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Pages Panel</source>
        <translation>Exibir o Painel de Prévia de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="526"/>
        <source>Attachments Panel</source>
        <translation>Exibir o Painel de Anexos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Layers Panel</source>
        <translation>Exibir o Painel de Camadas</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="vanished">Tela Cheia</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="141"/>
        <source>Change</source>
        <translation>Alterar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="161"/>
        <source>Permissions</source>
        <translation>Permissões de Manuseio</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="176"/>
        <source>Extract the content of the document</source>
        <translatorcomment>Don&apos;t change, includind &quot;o&quot; to the string. </translatorcomment>
        <translation>Extrair conteúdo do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="228"/>
        <source>Content copying for accessibility</source>
        <translation>Copiar conteúdo protegido por direitos autorais</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="241"/>
        <source>Commenting</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="vanished">Executar comando de JavaScript no arquivo Aberto</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="714"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="783"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="742"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="723"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="724"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>O documento é protegido. Favor digitar a senha de permissão de edição:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="746"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Senha incorreta. Favor digitar a senha do proprietário.</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="319"/>
        <source>User Interface Options</source>
        <translation>Opções da interface de usuário</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="325"/>
        <source>Hide tool bar</source>
        <translation>Ocultar a Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="332"/>
        <source>Hide menu bar</source>
        <translation>Ocultar a Barra de Menus</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="339"/>
        <source>Hide Window Controls</source>
        <translation>Ocultar os botões de comando da interface gráfica</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="349"/>
        <source>Windows Options</source>
        <translation>Opções de janela</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="369"/>
        <source>Center window on screen</source>
        <translation>Centralizar janela na tela</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="355"/>
        <source>Display document title</source>
        <translation>Exibir o nome do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="362"/>
        <source>Open in Full Screen mode</source>
        <translation>Abrir em modo de tela cheia</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="392"/>
        <source>Layout and Destination</source>
        <translation>Layout e Destino</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="498"/>
        <source>Navigation Tab:</source>
        <translation>Guia de navegação:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="541"/>
        <source>Page layout:</source>
        <translation>Layout de página:</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <location filename="../../src/FileSettings.cpp" line="248"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page</source>
        <translation>Página única</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Single Page Continuous</source>
        <translation>Página única contínua</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up (Facing)</source>
        <translation>Duas páginas (lado a lado)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Duas páginas contínuas (lado a lado)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up (Cover Page)</source>
        <translation>Duas páginas (lado a lado, com a capa)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="579"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>Duas páginas contínuas (lado a lado, com capa)</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <source>Actual Size</source>
        <translatorcomment>Here &quot;actual&quot; means &quot;original (size)&quot;, as set by the author of the document.</translatorcomment>
        <translation>Tamanho Real</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <source>Fit Page</source>
        <translation>Ajustar à página</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <source>Fit Width</source>
        <translation>Ajustar à largura</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="268"/>
        <source>Fit Height</source>
        <translation>Ajustar à altura</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <location filename="../../src/FileSettings.cpp" line="273"/>
        <source>Fit Visible</source>
        <translation>Ajustar à área visível</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="490"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="637"/>
        <location filename="../../src/FileSettings.ui" line="727"/>
        <source>Actions</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="643"/>
        <source>Document Open Actions</source>
        <translatorcomment>Don&apos;t change &quot;Ações de Abertura do Documento&quot;</translatorcomment>
        <translation>Comandos a Acionar na Abertura do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="649"/>
        <source>Add an Action</source>
        <translation>Adicionar comando</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Goto a Page View</source>
        <translation>Ir para a página especificada</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Reset form</source>
        <translation>Limpar o formulário</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Show/Hide fields</source>
        <translation>Exibir/ocultar campos</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Submit a form</source>
        <translatorcomment>Please, don&apos;t change to &quot;Enviar dados DE formulário&quot; or to &quot;Enviar um Formulário&quot;.</translatorcomment>
        <translation>Enviar dados do formulário</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="699"/>
        <source>Run a JavaScript</source>
        <translation>Executar comando de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="707"/>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="133"/>
        <source>Certificate Encryption</source>
        <translatorcomment>Please, don&apos;t change to &quot;Encriptação/Cifragem de/do Certificado&quot;. </translatorcomment>
        <translation>Proteção com Certificado</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Aparência</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Opções</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Comandos</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Apagar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Fechar</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Estilo</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Cor</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Adicionar</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Bloqueado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nome</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Bordas e Cores</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Dica de Ferramentas</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientação</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Tipo de linha</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Espessura da Linha</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Cor de Preenchimento</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Cor da Borda</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Acima</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Abaixo</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Propriedades do Documento</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texto</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Tamanho</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">Inserir</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
</context>
<context>
    <name>HeaderAndFooterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save Settings</source>
        <translation type="unfinished">Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="353"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="365"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="403"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="569"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="593"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="621"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished">Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="166"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="257"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="291"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="296"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="301"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">Margem esquerda</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">Margem direita</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="obsolete">Margem superior</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="obsolete">Margem inferior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="328"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="347"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="361"/>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="369"/>
        <source>Save</source>
        <translation type="unfinished">Salvar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="522"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="536"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="553"/>
        <source>of</source>
        <translation type="unfinished">de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="560"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="588"/>
        <source>Page Range Options...</source>
        <translation type="unfinished">Opções de intervalo de páginas...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="150"/>
        <source>Page number and date format</source>
        <translation type="unfinished">Números da página e formato da data</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="28"/>
        <source>Show Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="41"/>
        <source>Insert Page Number</source>
        <translation type="unfinished">Inserir número de página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="48"/>
        <source>Insert Date</source>
        <translation type="unfinished">Inserir data</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="55"/>
        <source>Insert Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="70"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="76"/>
        <source>Color</source>
        <translation type="unfinished">Cor</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="96"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="116"/>
        <source>Font Family</source>
        <translation type="unfinished">Família de Fontes</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="178"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="188"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="198"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="247"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Use Page Range of the currently edited Pagemark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="408"/>
        <source>Right Footer Text</source>
        <translation type="unfinished">Texto do rodapé direito</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="469"/>
        <source>Center Header Text</source>
        <translation type="unfinished">Texto do cabeçalho central</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="439"/>
        <source>Left Footer Text</source>
        <translation type="unfinished">Texto do rodapé esquerdo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="476"/>
        <source>Right Header Text</source>
        <translation type="unfinished">Texto do cabeçalho direito</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="432"/>
        <source>Center Footer Text</source>
        <translation type="unfinished">Texto do rodapé central</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="425"/>
        <source>Left Header Text</source>
        <translation type="unfinished">Texto do cabeçalho esquerdo</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation type="vanished">Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="vanished">Margem superior</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="vanished">Margem direita</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="vanished">Margem inferior</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="vanished">Margem esquerda</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Fonte</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Cor</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Tamanho</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="vanished">Família de Fontes</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Configurações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Apagar</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Nenhum</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Salvar</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation type="vanished">Texto do rodapé direito</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation type="vanished">Texto do cabeçalho central</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation type="vanished">Texto do rodapé esquerdo</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation type="vanished">Texto do cabeçalho direito</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation type="vanished">Texto do rodapé central</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation type="vanished">Texto do cabeçalho esquerdo</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation type="vanished">Inserir data</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation type="vanished">Inserir número de página</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation type="vanished">Números da página e formato da data</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="vanished">Opções de intervalo de páginas...</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="vanished">Salvar configurações</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="vanished">Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="vanished">Já existe uma configuração salva com este nome. Deseja substituí-la?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="vanished">Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="vanished"> ?</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="vanished">Margem</translation>
    </message>
    <message>
        <source>Units</source>
        <translatorcomment>Don&apos;t change to &quot;Unidades&quot;.</translatorcomment>
        <translation type="vanished">Unidade de medida</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> pol</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation type="vanished">Configurações salvas</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="vanished">Margem</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="vanished">Pontos</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="vanished">Polegadas</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="vanished">Milímetro</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation type="vanished">Inserir Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="vanished">Nome do Arquivo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="vanished">Procurar</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="vanished">Posição</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="vanished">Depois da última página</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="vanished">Antes da primeira página</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Abrir Arquivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation type="vanished">Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total de páginas:</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation type="vanished">Erro: Este PDF é protegido por senha.</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation type="vanished">Antes da página</translation>
    </message>
    <message>
        <source>After page</source>
        <translation type="vanished">Depois da página</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation type="vanished">Importar Marcadores</translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="vanished">Senha</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="vanished">O arquivo é protegido por senha. Favor digitá-la para abri-lo:</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation type="vanished">Erro: Este PDF é protegido por senha.</translation>
    </message>
</context>
<context>
    <name>InitialsDlg</name>
    <message>
        <location filename="../../src/initials/InitialsDlg.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation>Adicionar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="165"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
</context>
<context>
    <name>InteractiveCPDFReader</name>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="39"/>
        <source>Словарь в форме хранящейся в памяти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="52"/>
        <source>Команда(или help для их описания) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="88"/>
        <source>Вводимые ключи</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="101"/>
        <source>Черновик для записей</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="130"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="146"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="162"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="178"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="194"/>
        <source>5</source>
        <translation type="unfinished">5</translation>
    </message>
    <message>
        <location filename="../../src/interactivecpdfreader.ui" line="207"/>
        <source>Скопировать текущий 
словарь в черновик</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation>Console JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation>Executar</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation>Fechar o arquivo atual</translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation>Sempre na frente</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation>Documento JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="30"/>
        <source>Function Name</source>
        <translation>Nome da Função</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="55"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="62"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="69"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Editor de Java Script</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Nome da Função</translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="126"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="205"/>
        <source>Press shortcut</source>
        <translation>Aperte ao mesmo tempo as teclas do atalho desejadas para especificá-las</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation>Atalhos de Teclado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="43"/>
        <source>Reset All</source>
        <translation>Restaurar a padronização</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="35"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="50"/>
        <source>Shortcut</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="56"/>
        <source>Reset</source>
        <translation>Restaurar padrão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="30"/>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="129"/>
        <source>Key sequence has potential conflicts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacApplication</name>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="465"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="470"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/MacApplication.mm" line="478"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation type="obsolete">Página Anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation type="obsolete">Página Seguinte</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Forms</source>
        <translation>Formulários</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="119"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="542"/>
        <source>Highlight color</source>
        <translation>Cor de Realce</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="562"/>
        <source>Required field highlight color</source>
        <translation>Realce dos campos de preenchimento requerido</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3370"/>
        <source>Please choose the interface language</source>
        <translation>Escolha o idioma de interface de sua preferência</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3442"/>
        <source>Check for Updates Automatically</source>
        <translation>Procurar atualizações automaticamente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3461"/>
        <source>Weekly</source>
        <translation>Semanalmente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3466"/>
        <source>Monthly</source>
        <translation>Mensalmente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3456"/>
        <source>Never</source>
        <translation>Nunca (Aviso: NÃO RECOMENDADO)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="894"/>
        <source>Options</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1236"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2044"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2272"/>
        <source>Smooth text and images</source>
        <translation>Suavizar texto e imagens</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1324"/>
        <source>Time before a move or resize starts:</source>
        <translatorcomment>Don&apos;t change. &quot;Page component&quot;. A page is a document component itself. </translatorcomment>
        <translation>Tempo de espera para acionar comando de reposição ou redimensionamento de componente:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1317"/>
        <source>Select item by hovering the mouse</source>
        <translation>Selecionar componente de página ao pairar o ponteiro do mouse</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Built-in</source>
        <translation>Construir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="522"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2590"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3390"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>É necessário reiniciar o programa para que as alterações tenham efeito.</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="vanished">Barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="124"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="568"/>
        <source>Update</source>
        <translation>Atualizações</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="vanished">Árabe</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation type="vanished">Búlgaro</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation type="vanished">Catalão</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation type="vanished">Chinês Simplificado</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation type="vanished">Chinês Tradicional</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation type="vanished">Tcheco</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation type="vanished">Dinamarquês</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation type="vanished">Holandês</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">Inglês</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation type="vanished">Estoniano</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation type="vanished">Finlandês</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="vanished">Francês</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation type="vanished">Galego</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="vanished">Alemão</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation type="vanished">Grego</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation type="vanished">Hebraico</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation type="vanished">Húngaro</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation type="vanished">Irlandês</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation type="vanished">Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished">Japonês</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation type="vanished">Coreano</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation type="vanished">Letão</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation type="vanished">Lituano</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation type="vanished">Norueguês</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation type="vanished">Norueguês Contemporâneo</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished">Polonês</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="vanished">Português</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation type="vanished">Português (do Brasil)</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation type="vanished">Romeno</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">Russo</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation type="vanished">Sérvio</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation type="vanished">Eslovaco</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation type="vanished">Esloveno</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation type="vanished">Espanhol</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation type="vanished">Sueco</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation type="vanished">Tailandês</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation type="vanished">Turco</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation type="vanished">Ucraniano</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation type="vanished">Valenciano</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Vietnamita</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="203"/>
        <source>Saving Documents</source>
        <translation>Salvando Documentos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="222"/>
        <source>Create backup file</source>
        <translation>Criar cópia de segurança de arquivos modificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Escolher o destino de salvamento de arquivos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Last used folder</source>
        <translation>Última pasta usada</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Original documents folder</source>
        <translation>Mesma pasta dos arquivos originais</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Procurar...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1144"/>
        <source>Default font</source>
        <translation>Fonte padrão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Editing</source>
        <translation>Edição</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="229"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2855"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2900"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="788"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1530"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1847"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1162"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1854"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2512"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation type="vanished">Armênio</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="139"/>
        <source>History</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="151"/>
        <source>Restore last session when application start</source>
        <translation>Reabrir os arquivos acessados anteriormente ao se executar o programa</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="158"/>
        <source>Restore last view settings when reopening</source>
        <translation>Restaurar as últimas configurações na reabertura de arquivos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1593"/>
        <source>Enable JavaScript</source>
        <translation>Ativar Uso de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="598"/>
        <source> Always hide document message bar </source>
        <translation> Sempre ocultar a barra de mensagens do arquivo </translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2109"/>
        <source>Default Layout and Zoom</source>
        <translation>Padrão de Formato e Zoom de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2224"/>
        <source>Default page layout</source>
        <translation>Formato padrão de página</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2122"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2232"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2204"/>
        <source>Single Page</source>
        <translation>Página Simples</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2209"/>
        <source>Facing Pages</source>
        <translation>Duas páginas, Lado a Lado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2255"/>
        <source>Zoom</source>
        <translation>Zoom de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2127"/>
        <source>Actual Size</source>
        <translation>Tamanho Real</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="984"/>
        <source>Show warning when opening links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1014"/>
        <source>Convert static XFA into normal PDF when opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1224"/>
        <source>Page scrolling options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1271"/>
        <source>Configure scroll value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1297"/>
        <source>Enable scroll without delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1137"/>
        <source>Create Pencil lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1979"/>
        <source>Create Pencil and Brush lines as single object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2132"/>
        <source>Fit Page</source>
        <translation>Ajustar à Página</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2137"/>
        <source>Fit Width</source>
        <translation>Ajustar à Largura</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2142"/>
        <source>25%</source>
        <translation>Exibir com 25%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2147"/>
        <source>50%</source>
        <translation>Exibir com 50%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2152"/>
        <source>75%</source>
        <translation>Exibir com 75%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2157"/>
        <source>100%</source>
        <translation>Exibir com 100%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2162"/>
        <source>125%</source>
        <translation>Exibir com 125%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2167"/>
        <source>150%</source>
        <translation>Exibir com 150%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2172"/>
        <source>200%</source>
        <translation>Exibir com 200%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2177"/>
        <source>300%</source>
        <translation>Exibir com 300%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2182"/>
        <source>400%</source>
        <translation>Exibir com 400%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2187"/>
        <source>600%</source>
        <translation>Exibir com 600%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="747"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2401"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2288"/>
        <source>Bitmap Images</source>
        <translation>Imagens Bitmap</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2295"/>
        <source>Vector Images</source>
        <translation>Imagens Vetoriais</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2383"/>
        <source>Replace Document Colors</source>
        <translation>Substituir Cores do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2408"/>
        <source>Page Background</source>
        <translation>Fundo da Página</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <source>Display</source>
        <translation>Visualização</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation type="vanished">Sempre exibir o Inspecionador de Componente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2425"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="vanished">Estilo Fusion Dark</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="464"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="479"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="2041"/>
        <source>Select directory</source>
        <translation>Escolher pasta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1061"/>
        <source>Automatically change font when editing text</source>
        <translation>Alterar automaticamente a fonte quando se editar texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2318"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2334"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2324"/>
        <source>System PPI</source>
        <translation>Sistema PPI</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2469"/>
        <source>Icons in menus</source>
        <translation>Ícones em menus</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="182"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Abrir arquivo em novas guias e na mesma janela (requer reinicialização)</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="342"/>
        <source>Enable scroll wheel zooming</source>
        <translation>Habilitar zoom com o botão de rolagem do mouse</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1663"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2098"/>
        <source>Pop-up Opacity</source>
        <translation>Opacidade dos balões</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1564"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1820"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1959"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2075"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1687"/>
        <source>Sticky Note</source>
        <translatorcomment>Actually, the component doesn&apos;t have much of a &quot;persistent characteristic&quot;, but a &quot;flexible, mobile&quot; one, since it can be moved around its page at will, as opposed to certain other set components.</translatorcomment>
        <translation>Nota Móvel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1803"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1557"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1835"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1946"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1692"/>
        <source>Highlight Text</source>
        <translation>Texto Realçado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1697"/>
        <source>Strikeout Text</source>
        <translatorcomment>Don&apos;t change to &quot;Texto Tachado&quot;. Too formal for the average user.</translatorcomment>
        <translation>Texto Riscado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1702"/>
        <source>Underline Text</source>
        <translation>Texto Sublinhado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1537"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1928"/>
        <source>Line Width</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Comments</source>
        <translation>Comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="656"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="727"/>
        <source>Check Mark</source>
        <translation>Sinal de conferido</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="833"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="728"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="838"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <source>Cross</source>
        <translation>Cruz</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="vanished">Inserir Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="733"/>
        <source>Key</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="734"/>
        <source>New Paragraph</source>
        <translation>Novo Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="735"/>
        <source>Text Note</source>
        <translation>Nota de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="736"/>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="737"/>
        <source>Right Arrow</source>
        <translation>Seta para a direita</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="738"/>
        <source>Right Pointer</source>
        <translatorcomment>Don&apos;t change to &quot;Seta&quot;.</translatorcomment>
        <translation>Ponteiro para a direita</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="853"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="739"/>
        <source>Star</source>
        <translation>Estrela</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="740"/>
        <source>Up Arrow</source>
        <translation>Seta para cima</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="741"/>
        <source>Up Left Arrow</source>
        <translation>Seta para baixo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="742"/>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="743"/>
        <source>Paper Clip</source>
        <translation>Clipe de Papel</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="744"/>
        <source>Attachment</source>
        <translation>Anexo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="745"/>
        <source>Tag</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1605"/>
        <source>Show errors and  messages in console</source>
        <translation>Exibir erros e mensagens no console</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="606"/>
        <source>Link</source>
        <translation>Ligação/Remissão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="248"/>
        <source>Autosave interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="299"/>
        <source>Autosave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="306"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="175"/>
        <source>Show Quick actions on text and comments selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="196"/>
        <source>Lock file from opening by other instances of Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Enable logging to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="398"/>
        <source>Log files directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Edit Box</source>
        <translation>Campo de edição</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="616"/>
        <source>Check box</source>
        <translation>Lista de opções ticáveis</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="621"/>
        <source>Radio button</source>
        <translation>Botão radial</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Combo box</source>
        <translatorcomment>Don&apos;t change. Note the &quot;Combo&quot; term.</translatorcomment>
        <translation>Lista de Opções com Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>List box</source>
        <translation>Lista de opções</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Button</source>
        <translation>Botão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="641"/>
        <source>Signature</source>
        <translation>Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="662"/>
        <source>Borders and Colors</source>
        <translation>Bordas e Cores</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="669"/>
        <source>Thin</source>
        <translation>Fina</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="674"/>
        <source>Medium</source>
        <translation>Média</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="679"/>
        <source>Thick</source>
        <translation>Grossa</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="687"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Border Color</source>
        <translation>Cor da Borda</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="694"/>
        <source>Fill Color</source>
        <translation>Cor de Preenchimento</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="702"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="929"/>
        <source>Solid</source>
        <translation>Inteiriço</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="707"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="934"/>
        <source>Dashed</source>
        <translation>Pontilhado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="712"/>
        <source>Beveled</source>
        <translation>Chanfrado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="717"/>
        <source>Inset</source>
        <translatorcomment>Don&apos;t change to &quot;inserir&quot;. Note that the term is &quot;INSET&quot;, without an &quot;R&quot;, and NOT &quot;inseRt&quot;, with an &quot;R&quot;.</translatorcomment>
        <translation>Sulcado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="722"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="939"/>
        <source>Underline</source>
        <translation>Sublinhado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="921"/>
        <source>Line Style</source>
        <translation>Tipo de linha</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="737"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="900"/>
        <source>Line Thickness</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2957"/>
        <source>Maximum CPU usage for OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3471"/>
        <source>Once in 3 months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="263"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2527"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="801"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="947"/>
        <source>Highlight</source>
        <translation>Destaque</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="958"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="963"/>
        <source>Invert</source>
        <translation>Inverter</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="968"/>
        <source>OutLine</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="973"/>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="817"/>
        <source>Style</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="828"/>
        <source>Check</source>
        <translation>Marcar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="843"/>
        <source>Diamond</source>
        <translation>Diamante</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="848"/>
        <source>Square</source>
        <translation>Quadrado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>Grid</source>
        <translation>Grade</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>OCR</source>
        <translation>Reconhecimento de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1384"/>
        <source>Units</source>
        <translation>Usar esta unidade</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1411"/>
        <source>Width between lines</source>
        <translation>Espaçamento entre linhas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1444"/>
        <source>Height between lines</source>
        <translatorcomment>Please, don&apos;t change to &quot;Altura entre as Linhas&quot;.</translatorcomment>
        <translation>Espaço entre linhas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1404"/>
        <source>Left offset</source>
        <translation>Deslocamento esquerdo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1437"/>
        <source>Top offset</source>
        <translation>Deslocamento superior</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1451"/>
        <source>Subdivision</source>
        <translation>Subdivisão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1707"/>
        <source>Measurements</source>
        <translation>Medidas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1712"/>
        <source>Drawing</source>
        <translation>Desenho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1098"/>
        <source>Selected text color</source>
        <translatorcomment>Don&apos;t change to &quot;Cor selecionada&quot;, &quot;Cor de texto usada&quot;.</translatorcomment>
        <translation>Usar esta cor de texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2451"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <source>Fusion</source>
        <translation type="vanished">Fusão</translation>
    </message>
    <message>
        <source>Plastique</source>
        <translation type="vanished">Plastique</translation>
    </message>
    <message>
        <source>CleanLooks</source>
        <translation type="vanished">CleanLooks</translation>
    </message>
    <message>
        <source>Motif</source>
        <translation type="vanished">Motif</translation>
    </message>
    <message>
        <source>CDE</source>
        <translation type="vanished">CDE</translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="vanished">Tema escuro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2431"/>
        <source>Application Style</source>
        <translation>Aparência do programa</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2610"/>
        <source>Use default program</source>
        <translation>Usar o programa padrão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2629"/>
        <source>evolution</source>
        <translation>evolution</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2634"/>
        <source>kmail</source>
        <translation>kmail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2639"/>
        <source>thunderbird</source>
        <translation>thunderbird</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2647"/>
        <source>Use SMTP</source>
        <translation>Usar SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2670"/>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2758"/>
        <source>Email address</source>
        <translation>Endereço de E-Mail</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2751"/>
        <source>Secure connections</source>
        <translation>Conexão segura</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2726"/>
        <source>NONE</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2731"/>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2736"/>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2718"/>
        <source>SMTP server</source>
        <translation>Servidor SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2708"/>
        <source>User</source>
        <translation>Usuário</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2744"/>
        <source>SMTP port</source>
        <translation>Porta SMTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2691"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3101"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2950"/>
        <source>Default path to tesseract ocr data files</source>
        <translation>Caminho dos arquivos de dados do Tesseract OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2923"/>
        <source>Additional tesseract ocr config file</source>
        <translation>Configurações adicionais para o Tesseract OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2943"/>
        <source>Install languages</source>
        <translation>Adicionar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="501"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1861"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1929"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1949"/>
        <source> in</source>
        <translation> pol</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1969"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1391"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1458"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1484"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1520"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="109"/>
        <source>Network</source>
        <translation>Rede</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1615"/>
        <source>Enable safe reading mode</source>
        <translation>Habilitar modo de leitura segura</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2980"/>
        <source>Direct internet connection</source>
        <translation>Conexão direta com a internet</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2990"/>
        <source>Manual proxy configuration</source>
        <translation>Configuração manual de proxy</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3006"/>
        <source>HTTP Proxy</source>
        <translation>Proxy HTTP</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3013"/>
        <source>SOCKS 5 Proxy</source>
        <translation>Proxy SOCKS 5</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3023"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3033"/>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2679"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3076"/>
        <source>Authentication</source>
        <translation>Autenticação</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3091"/>
        <source>User name</source>
        <translation>Nome de usuário</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2519"/>
        <source>Icon set</source>
        <translation>Família de ícones</translation>
    </message>
    <message>
        <source>KDE</source>
        <translation type="vanished">KDE</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>Keyboard</source>
        <translation>Atalhos de Teclado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="349"/>
        <source>Show Start page</source>
        <translation>Mostrar a página inicial do Master PDF Editor ao abri-lo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1419"/>
        <source>Points</source>
        <translation>Pontos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1424"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1429"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="450"/>
        <source>Load all objects separately</source>
        <translation>Carregar componentes separadamente</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1353"/>
        <source>Always show Object Inspector</source>
        <translatorcomment>Don&apos;t change to &quot;Inspecionador de Componente&quot; or &quot;Painel de Propriedades&quot;.</translatorcomment>
        <translation>Sempre exibir o Painel de Propriedades</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2262"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Impedir que arquivos sejam abertos em tela cheia</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1717"/>
        <source>Typewriter</source>
        <translation>Máquina de Escrever Virtual</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2456"/>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2461"/>
        <source>Dark</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <source>Exact match only</source>
        <translation>Só levar em conta correspondência exata</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="114"/>
        <source>Certificates</source>
        <translation>Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1360"/>
        <source>Save last editing Tool</source>
        <translation>Salvar a última ferramenta de edição</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3228"/>
        <source>Default paths for system certificates</source>
        <translation>Caminho padrão dos certificados do sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3176"/>
        <source>Certificate Manager</source>
        <translation>Gestor de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="810"/>
        <source>In Windows, all certificates are located in system storage.</source>
        <translation>No Windows, eles ficam no armazenamento do sistema.</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="421"/>
        <source>Alternative method for PDF render</source>
        <translation>Usar método alternativo para renderizar o PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="473"/>
        <source>Memory/Speed</source>
        <translation>Memória/Velocidade</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="480"/>
        <source>Minimize memory usage</source>
        <translation>Uso mínimo de memória</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="485"/>
        <source>Maximal render speed</source>
        <translation>Velocidade máxima de renderização</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="829"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1139"/>
        <source>System Theme</source>
        <translation>Tema do sistema</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3238"/>
        <source>Database for Certificate Manager</source>
        <translation>Banco de dados do Gestor de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3298"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3254"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3271"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3305"/>
        <source>Path for DB:</source>
        <translation>Caminho do Banco de Dados:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Redaction</source>
        <translation>Revisão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="815"/>
        <source>In macOS, all certificates are located in system storage.</source>
        <translation>No macOS, eles ficam no armazenamento do sistema.</translation>
    </message>
    <message>
        <source>Farsi</source>
        <translation type="vanished">Persa</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="189"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation>Permitir a abertura do mesmo arquivo em várias guias</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="998"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1004"/>
        <source>Add full path to filename in export file</source>
        <translation>Adicionar o caminho completo ao nome do arquivo exportado</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="991"/>
        <source>Recreate pdf forms when opening</source>
        <translation>Recriar formulários de PDF ao abri-lo</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="830"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1143"/>
        <source>Light Theme</source>
        <translation>Tema Claro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="831"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1147"/>
        <source>Dark Theme</source>
        <translation>Tema Escuro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Toolbars</source>
        <translation>Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1367"/>
        <source>Edit Text Elements as Blocks</source>
        <translation>Editar Componentes de Texto como Blocos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2499"/>
        <source>Standard</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2504"/>
        <source>Office Pro</source>
        <translation>Office Pro</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2041"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>Tooltip Display Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2489"/>
        <source>Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2532"/>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2537"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="165"/>
        <source>Save recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2217"/>
        <source>Navigation Tab</source>
        <translation>Guia de navegação</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2237"/>
        <source>Page Only</source>
        <translation>Página Única</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <source>Bookmarks Panel</source>
        <translation>Exibir o Painel de Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2247"/>
        <source>Pages Panel</source>
        <translation>Exibir o Painel de Prévia de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="3334"/>
        <source>Strong verification of signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="255"/>
        <source>PDF Specification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulários</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Português</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Cor de Realce</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Cor de Campos de Preenchimento Requerido:</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Favor escolher seu idioma:</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Procurar atualizações automaticamente:</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Semanalmente</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Mensalmente</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nunca</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Configurações</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Procurar...</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Estilo</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Apagar Componente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="139"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="496"/>
        <source>Open</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="159"/>
        <location filename="../../src/mainwindow.ui" line="1806"/>
        <source>New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Save As...</source>
        <translation>Salvar como...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="896"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2432"/>
        <source>Recent Files</source>
        <translation>Arquivos recentes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="743"/>
        <location filename="../../src/mainwindow.ui" line="746"/>
        <source>Exit</source>
        <translation>Fechar o Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="910"/>
        <source>Cut</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="938"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>First Page</source>
        <translation>Primeira Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="571"/>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <source>Previous Page</source>
        <translation>Página Anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <source>Next Page</source>
        <translation>Página Seguinte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="593"/>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <source>Last Page</source>
        <translation>Última Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="207"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="604"/>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <source>Zoom In</source>
        <translation>Aumentar Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="629"/>
        <location filename="../../src/mainwindow.ui" line="632"/>
        <source>Zoom Out</source>
        <translation>Diminuir Zoom</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="618"/>
        <location filename="../../src/mainwindow.ui" line="621"/>
        <source>Actual Size</source>
        <translation>Tamanho Atual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="291"/>
        <source>Toolbars</source>
        <translation>Barras de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <source>Statusbar</source>
        <translation>Barra de Status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="289"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="521"/>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>Hand Tool</source>
        <translation>Selecionador de Componente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Register...</source>
        <translation>Licenciar...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="vanished">Procurar atualização</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation type="vanished">Exportar como</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="768"/>
        <location filename="../../src/mainwindow.ui" line="771"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Ampliar Miniaturas de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="776"/>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Reduzir Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Inserir Página(s) de PDF</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Extrair Página(s) na forma de PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Highlight Fields</source>
        <translation>Realçar Campos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <location filename="../../src/mainwindow.cpp" line="5944"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1127"/>
        <source>Properties</source>
        <translation>Propriedades do Arquivo</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Todas as páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Sem Formatação</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Negrito Itálico</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2003"/>
        <source>Bookmarks</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="vanished">Inserir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1161"/>
        <source>Highlight Text</source>
        <translation>Realçar texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <source>Underline Text</source>
        <translation>Sublinhar texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1166"/>
        <location filename="../../src/mainwindow.ui" line="1169"/>
        <source>Strikeout Text</source>
        <translatorcomment>Don&apos;t change to &quot;Tachar Texto&quot;, &quot;Texto Tachado&quot;, &quot;Texto Riscado&quot;. Além de simples e fácil de entender, fica claro que se trata de &quot;riscar o texto com &apos;ferramenta&apos; de comentário&quot;, ou seja riscá-lo e explicar por quê.</translatorcomment>
        <translation>Riscar Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2011"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="71"/>
        <source>Attachment</source>
        <translation>Anexo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>Check box</source>
        <translation>Quadrículo de opção</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1278"/>
        <source>Radio button</source>
        <translation>Botão Radial</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <location filename="../../src/mainwindow.ui" line="1302"/>
        <source>Button</source>
        <translation>Botão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>List box</source>
        <translation>Caixa de listagem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1286"/>
        <source>Combo box</source>
        <translation>Lista de Opções com Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1259"/>
        <source>Edit Box</source>
        <translation>Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="363"/>
        <source>Document</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2802"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Gostaria de salvar as alterações em %s antes de fechá-lo?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="279"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="58"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Ajuda...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2619"/>
        <source>Cannot open file :
</source>
        <translation>Não foi possível abrir o arquivo:
</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="203"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <source>View</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation type="vanished">Sua versão do programa é a mais atual!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="787"/>
        <source>Edit Document</source>
        <translation>Edição do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1242"/>
        <source>Link</source>
        <translation>Criar ligação/remissão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="426"/>
        <location filename="../../src/mainwindow.ui" line="1386"/>
        <source>Comments</source>
        <translation>Comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1144"/>
        <source>Add Sticky Note</source>
        <translation>Anotação Móvel</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Anotação</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1196"/>
        <location filename="../../src/mainwindow.cpp" line="5976"/>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="590"/>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <location filename="../../src/mainwindow.cpp" line="709"/>
        <source>There was an error opening the document !</source>
        <translation>Erro na tentativa de imprimir o arquivo!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1075"/>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <source>Page layout</source>
        <translation>Formato de Página</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Inserir páginas</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Inserir páginas</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Excluir páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1995"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="880"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Create a new blank PDF</source>
        <translation>Criar um novo PDF em branco</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="883"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="505"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="699"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimir (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir o documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="732"/>
        <location filename="../../src/mainwindow.ui" line="735"/>
        <source>Close</source>
        <translation>Fechar o arquivo atual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1191"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1205"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1010"/>
        <source>Send to Back</source>
        <translation>Enviar para trás</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enviar para Trás&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Envia para trás do outro o componente selecionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="827"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="838"/>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_mac_tool_bars.cpp" line="20"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Images</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1139"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1325"/>
        <source>Home page</source>
        <translation>Página Oficial do MasterPDF Editor</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Desfazer (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Desfazer a última operação&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="991"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="635"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Refazer (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Refazer a operação desfeita anteriormente.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1005"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Recortar (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Transferir os componentes selecionados para a Área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="919"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copiar (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copiar os componentes selecionados na Área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="958"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="796"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="538"/>
        <source>Select Text</source>
        <translatorcomment>Submenu command under &quot;Ferramentas&quot; menu. </translatorcomment>
        <translation>Selecionador de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="855"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1315"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2618"/>
        <source>Open failed</source>
        <translation>Falha na tentativa de abrir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="232"/>
        <source>Empty recent files list</source>
        <translation>Apagar a lista de arquivos recentes</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation type="vanished">Feita a exportação</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1081"/>
        <location filename="../../src/mainwindow.cpp" line="1212"/>
        <location filename="../../src/mainwindow.cpp" line="3025"/>
        <location filename="../../src/mainwindow.cpp" line="4331"/>
        <location filename="../../src/mainwindow.cpp" line="4449"/>
        <location filename="../../src/mainwindow.cpp" line="4569"/>
        <source>Save failed</source>
        <translation>Falha na tentativa de salvar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Não foi possível salvar o arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <location filename="../../src/mainwindow.cpp" line="1213"/>
        <location filename="../../src/mainwindow.cpp" line="3026"/>
        <location filename="../../src/mainwindow.cpp" line="4332"/>
        <location filename="../../src/mainwindow.cpp" line="4450"/>
        <location filename="../../src/mainwindow.cpp" line="4570"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente-leitura ou estar em uso por outro programa.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6062"/>
        <location filename="../../src/mainwindow.cpp" line="6064"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="vanished">Todos os arquivos (*.pdf *.xps);;Arquivos PDF (*.pdf);;Arquivos XPS (*.xps)</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Propriedades do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1320"/>
        <source>Contents</source>
        <translatorcomment>Contents here means &quot;Tópicos da Ajuda&quot;, &quot;Sumário&quot;, and not &quot;Conteúdo&quot; instead. Thus, &quot;Ajuda&quot;.</translatorcomment>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <location filename="../../src/mainwindow.ui" line="1471"/>
        <source>Find</source>
        <translation>Localizar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1460"/>
        <source>Find Next</source>
        <translation>Localizar seguinte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="57"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Foi publicada uma nova versão! 
Gostaria de baixá-la agora?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2809"/>
        <source>Close Without Saving</source>
        <translation>Fechar sem salvar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2813"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="738"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <location filename="../../src/mainwindow.ui" line="1089"/>
        <source>Rotate Pages</source>
        <translation>Girar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1067"/>
        <location filename="../../src/mainwindow.ui" line="1070"/>
        <source>Move Pages</source>
        <translation>Mover Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1930"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Edit Text</source>
        <translation>Edição de Texto</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">Descrição</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>Object Inspector</source>
        <translation>Painel de Propriedades de Componente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1117"/>
        <location filename="../../src/mainwindow.cpp" line="7130"/>
        <location filename="../../src/mainwindow.cpp" line="7192"/>
        <location filename="../../src/mainwindow.cpp" line="7341"/>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="vanished">A versão não licenciada insere uma marca d&apos;água</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>Align Objects</source>
        <translation>Alinhar componentes de página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1210"/>
        <location filename="../../src/mainwindow.ui" line="1213"/>
        <location filename="../../src/mainwindow.ui" line="1702"/>
        <location filename="../../src/mainwindow.ui" line="1705"/>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1218"/>
        <location filename="../../src/mainwindow.ui" line="1221"/>
        <location filename="../../src/mainwindow.ui" line="1724"/>
        <location filename="../../src/mainwindow.ui" line="1727"/>
        <source>Rectangle</source>
        <translation>Retângulo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1226"/>
        <location filename="../../src/mainwindow.ui" line="1229"/>
        <location filename="../../src/mainwindow.ui" line="1735"/>
        <location filename="../../src/mainwindow.ui" line="1738"/>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Prévia de Impressão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <location filename="../../src/mainwindow.ui" line="1035"/>
        <source>Align Left</source>
        <translation>À esquerda</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1040"/>
        <location filename="../../src/mainwindow.ui" line="1043"/>
        <source>Align Right</source>
        <translation>À direita</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1048"/>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Align Top</source>
        <translation>Em cima</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Align Bottom</source>
        <translation>Embaixo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1307"/>
        <location filename="../../src/mainwindow.ui" line="1310"/>
        <source>Signature</source>
        <translation>Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <location filename="../../src/mainwindow.ui" line="966"/>
        <source>Set Fit to Page</source>
        <translation>Ajustar à Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3066"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Erro na tentativa de verificação da assinatura!</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colar (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cola conteúdo da Área de Transferência na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="167"/>
        <source>Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="245"/>
        <source>Navigation Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <source>Forms</source>
        <translation>Formulários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="510"/>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Home</source>
        <translation>Início</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>End</source>
        <translation>Fim</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="654"/>
        <location filename="../../src/mainwindow.ui" line="657"/>
        <source>Reset Forms</source>
        <translation>Limpar Formulários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Fit Page</source>
        <translation>Ajustar à Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Fit Width</source>
        <translation>Ajustar à Largura</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="749"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="757"/>
        <location filename="../../src/mainwindow.ui" line="760"/>
        <source>Facing Pages</source>
        <translatorcomment>Two pages shown side by side on the program viewing pane.</translatorcomment>
        <translation>Páginas Lado a Lado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Delete Pages</source>
        <translation>Apagar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="846"/>
        <location filename="../../src/mainwindow.ui" line="852"/>
        <location filename="../../src/mainwindow.ui" line="1790"/>
        <source>Edit Forms</source>
        <translation>Editar Formulários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1021"/>
        <source>Bring to Front</source>
        <translation>Trazer para a frente de todos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Trazer para Frente&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Traz para a frente de todos o componente selecionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1097"/>
        <location filename="../../src/mainwindow.ui" line="1100"/>
        <source>Extract Pages...</source>
        <translation>Extrair Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1108"/>
        <location filename="../../src/mainwindow.ui" line="1111"/>
        <source>Insert Pages...</source>
        <translation>Inserir Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <location filename="../../src/mainwindow.ui" line="1237"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <location filename="../../src/mainwindow.ui" line="1749"/>
        <source>Pencil</source>
        <translation>Lápis</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1159"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="502"/>
        <source>Open a PDF file</source>
        <translation>Abrir um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>PgUp</source>
        <translation>Página acima</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>PgDown</source>
        <translation>Página abaixo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <location filename="../../src/mainwindow.ui" line="1526"/>
        <location filename="../../src/mainwindow.ui" line="1572"/>
        <location filename="../../src/mainwindow.ui" line="1585"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1262"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="vanished">Salvar em XPS é incompatível. Escolha o nome de arquivo PDF para salvar.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1092"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation type="vanished">Abrir o Painel de Propriedades</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1399"/>
        <location filename="../../src/mainwindow.ui" line="1402"/>
        <source>Crop Pages</source>
        <translation>Fazer Recorte de Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1405"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation type="vanished">Anterior/Próximo</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation type="vanished">Ferramentas de Edição</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation type="vanished">Página:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1906"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="649"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="727"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="977"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1056"/>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <source>Insert Blank Pages</source>
        <translation>Inserir Páginas em Branco</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation type="vanished">Ctrl+Shift++</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation type="vanished">Ctrl+Shift+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="813"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1410"/>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1418"/>
        <location filename="../../src/mainwindow.ui" line="1421"/>
        <location filename="../../src/mainwindow.ui" line="1424"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Girar 90 graus no sentido anti-horário</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7139"/>
        <location filename="../../src/mainwindow.cpp" line="7160"/>
        <location filename="../../src/mainwindow.cpp" line="7163"/>
        <location filename="../../src/mainwindow.cpp" line="7201"/>
        <location filename="../../src/mainwindow.cpp" line="7221"/>
        <location filename="../../src/mainwindow.cpp" line="7224"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Arquivos FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1429"/>
        <source>Export Form Data...</source>
        <translation>Exportar Dados de Formulário...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1434"/>
        <source>Import Form Data...</source>
        <translation>Importar Dados de Formulário...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1439"/>
        <source>Export Comments Data...</source>
        <translation>Exportar Comentários...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1444"/>
        <source>Import Comments Data...</source>
        <translation>Importar Comentários...</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt; &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Abrir Arquivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Abrir um arquivo PDF ou XPS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="544"/>
        <source>Select text for copying and pasting</source>
        <translation>Selecionar texto para copiar e colar</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; 
p, li { white-space: pre-wrap; }
 &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Salvar (Ctrl+S)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Salva alterações no arquivo atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Save the document</source>
        <translation>Salvar o arquivo</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
 p, li { white-space: pre-wrap; } 
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Sans Serif&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Salvar como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Salva o arquivo atual com um novo nome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="710"/>
        <source>Save the document with a new name</source>
        <translation>Salvar o arquivo com um novo nome</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="724"/>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>Print the document</source>
        <translation>Imprimir o arquivo</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar o arquivo atual (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite selecionar e editar texto, imagens, anotações, campos de formulário...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="793"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Selecionar e editar texto, imagens, anotações, campos de formulário...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="810"/>
        <source>Select text for editing</source>
        <translation>Seleciona texto para edição</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
 p, li { white-space: pre-wrap; }
 &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Apagar componentes (Del)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Apaga os componentes selecionados&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Delete the currently selected object(s)</source>
        <translation>Apagar o(s) componente(s) selecionado(s)</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Novo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Criar um novo PDF em branco&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="916"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Transferir os componentes selecionados para a Área de Transferência</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="930"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Copiar os componentes selecionados na Área de Transferência</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Paste from the Clipboard</source>
        <translation>Colar da Área de Transferência</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="988"/>
        <source>Undo the last action</source>
        <translation>Desfaz a última operação</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1002"/>
        <source>Redo the previously undone action.</source>
        <translation>Refaz a operação desfeita antes.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1016"/>
        <source>Send to Back selected object.</source>
        <translation>Envia para trás de todos o componente selecionado.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1027"/>
        <source>Bring to Front selected object.</source>
        <translation>Traz para a frente de todos o componente selecionado.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Propriedades (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Abre o painel de propriedades do arquivo&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1133"/>
        <source>Open window with document properties</source>
        <translation>Abrir o painel de propriedades do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1147"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Anotação&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Clique na página para adicionar uma nota nessa posição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <source>Click the page to add a note at that position</source>
        <translation>Clique na página para adicionar uma nota nessa posição</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Permite adicionar texto à página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Insert new text to current page</source>
        <translation>Insere novo texto a página atual</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Imagem (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Permite inserir uma imagem na página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1202"/>
        <source>Insert new image to current page</source>
        <translation>Insere nova imagem na página atual</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Remissão (Ctrl+L)&lt;/span&gt;
&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Permite criar uma ligação na página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>Insert new link to current page</source>
        <translation>Permite inserir uma ligação/remissão na página atual</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Selecionar Texto (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite selecionar texto para copiá-lo e colá-lo onde quiser&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="713"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1103"/>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1449"/>
        <source>Save Optimized As...</source>
        <translation>Salvar otimizado como...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1452"/>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation type="vanished">Caracteres</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5939"/>
        <source>Font type</source>
        <translation>Tipo de fonte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5941"/>
        <source>Font Embedded</source>
        <translation>Fonte Incorporada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5950"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5959"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5967"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5972"/>
        <location filename="../../src/mainwindow.cpp" line="6196"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5973"/>
        <location filename="../../src/mainwindow.cpp" line="6197"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5974"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5980"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5984"/>
        <source>Shading</source>
        <translation>Sombreamento</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="1946"/>
        <source>Objects</source>
        <translation>Componentes</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6224"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6005"/>
        <location filename="../../src/mainwindow.cpp" line="6211"/>
        <source>Selected</source>
        <translation>Selecionado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1463"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1620"/>
        <location filename="../../src/mainwindow.cpp" line="1647"/>
        <source>Can&apos;t find :</source>
        <translation>Não consegui achar:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5943"/>
        <source>Font Not Embedded</source>
        <translation>Fonte Não Incorporada</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulário (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona formulário e anotações para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Texto (Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona o texto para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ferramenta mão (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use a ferramenta de mão para mover as páginas, acionar ligações e selecionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="624"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="671"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="763"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1476"/>
        <source>Document JavaScript</source>
        <translatorcomment>Please, don&apos;t change to &quot;Documento de JavaScript&quot;.</translatorcomment>
        <translation>Comandos de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1481"/>
        <source>Document Actions</source>
        <translation>Comando Internos do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1489"/>
        <source>Replace Document Colors</source>
        <translation>Substituir Cores do Arquivo</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>html tags here?</translatorcomment>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Visualizar impressão (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1494"/>
        <source>Paste to Multiple Pages</source>
        <translation>Colar em múltiplas páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2069"/>
        <location filename="../../src/mainwindow.ui" line="2072"/>
        <source>Paste at Copy Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2075"/>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Shift+V</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation type="vanished">Sua versão de Qt instalada</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1502"/>
        <source>JavaScript Console</source>
        <translation>Console de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1510"/>
        <source>Page Properties</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1505"/>
        <source>Ctrl+J</source>
        <translation>Crtl+J</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1518"/>
        <location filename="../../src/mainwindow.ui" line="1564"/>
        <location filename="../../src/mainwindow.ui" line="1577"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1521"/>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>O Master PDF Editor não achou nenhum cabeçalho ou rodapé no arquivo.</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="vanished">Quer mesmo apagar os cabeçalhos e rodapés do arquivo?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="376"/>
        <source>Watermark</source>
        <translation>Marca D&apos;Água</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Background</source>
        <translation>Plano de Fundo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="430"/>
        <source>Measurements</source>
        <translation>Medida</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="438"/>
        <location filename="../../src/mainwindow.cpp" line="3180"/>
        <source>Drawing</source>
        <translation>Desenho</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1497"/>
        <source>Ctrl+Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1537"/>
        <source>Menu Bar</source>
        <translation>Barra de menu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1540"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1548"/>
        <source>Show Cover Page During Facing</source>
        <translatorcomment>&quot;Página usada como capa&quot;, that&apos;s what the author actually meant by this.</translatorcomment>
        <translation>Mostrar a capa em visualização lado a lado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1556"/>
        <source>Full Screen</source>
        <translation>Tela Cheia</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1559"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1567"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1580"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1590"/>
        <location filename="../../src/mainwindow.ui" line="1593"/>
        <source>Align Center Horizontal</source>
        <translation>Horizontalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1598"/>
        <location filename="../../src/mainwindow.ui" line="1601"/>
        <source>Align Center Vertical</source>
        <translation>Verticalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1606"/>
        <source>Find Previous</source>
        <translation>Localizar anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1619"/>
        <location filename="../../src/mainwindow.ui" line="1622"/>
        <source>OCR</source>
        <translation>OCR</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1627"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1630"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>html tags here?</translatorcomment>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Entrega de E-Mail&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1641"/>
        <location filename="../../src/mainwindow.ui" line="1644"/>
        <source>Grid</source>
        <translation>Grade</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1647"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1655"/>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Snap to Grid</source>
        <translation>Fixar pela grade</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1661"/>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1669"/>
        <location filename="../../src/mainwindow.ui" line="1672"/>
        <source>Distance Tool</source>
        <translation>Medidor de distância</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1680"/>
        <location filename="../../src/mainwindow.ui" line="1683"/>
        <source>Perimeter Tool</source>
        <translation>Medidor de perímetro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1691"/>
        <location filename="../../src/mainwindow.ui" line="1694"/>
        <source>Area Tool</source>
        <translation>Medidor de área</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1713"/>
        <location filename="../../src/mainwindow.ui" line="1716"/>
        <source>Arrow</source>
        <translation>Seta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1757"/>
        <location filename="../../src/mainwindow.ui" line="1760"/>
        <source>Attach a File as a Comment</source>
        <translation>Adicionar arquivo como comentário</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1987"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2027"/>
        <source>Signatures</source>
        <translation type="unfinished">Assinaturas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2035"/>
        <source>Layers</source>
        <translation type="unfinished">Camadas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2043"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2051"/>
        <source>Document Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2056"/>
        <source>Organize Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2064"/>
        <source>Edit Text Elements as Blocks</source>
        <translation type="unfinished">Editar Componentes de Texto como Blocos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2080"/>
        <source>Pages to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2088"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2096"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2101"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2104"/>
        <source>Manage Header And Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2109"/>
        <source>Add To Multiple Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2114"/>
        <source>Open session from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2119"/>
        <source>Save session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2124"/>
        <source>Managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2129"/>
        <source>here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2134"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2139"/>
        <source>Clear recent sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2144"/>
        <source>Save session to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2149"/>
        <source>Current Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2154"/>
        <source>Save session to managed sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2159"/>
        <source>Save and close current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="2164"/>
        <source>Delete across pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3606"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>O Master PDF Editor não achou nenhuma marca d&apos;água no arquivo.</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="vanished">Quer mesmo apagar as marcas d&apos;água do arquivo?</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="vanished">O Master PDF Editor não achou nenhum plano de fundo no arquivo.</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="vanished">Quer mesmo apagar os planos de fundo do arquivo?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="874"/>
        <source>Blank PDF</source>
        <translation>PDF em branco</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1765"/>
        <source>From Scanner</source>
        <translation>Do Scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1768"/>
        <location filename="../../src/mainwindow.ui" line="1771"/>
        <source>Create a new document from scanner</source>
        <translation>Criar um novo documento a partir do Scanner</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1776"/>
        <source>From Files</source>
        <translation>Usando arquivos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1779"/>
        <location filename="../../src/mainwindow.ui" line="1782"/>
        <source>Create a new document from files</source>
        <translation>Criar novo documento usando arquivos</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="obsolete">Arquivos de imagem (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="vanished">Carimbo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1798"/>
        <location filename="../../src/mainwindow.ui" line="1801"/>
        <source>Brush</source>
        <translation>Pincel</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Abrir Arquivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir um arquivo PDF ou XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salva alterações no arquivo atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salva o arquivo atual com um novo nome&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Apagar componentes (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Apaga os componentes selecionados&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Novo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Criar um novo PDF em branco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite adicionar texto à página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Imagem (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite inserir uma imagem na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Remissão (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite criar uma remissão na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propriedades (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abre o painel de propriedades do arquivo atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="367"/>
        <source>Header and Footer</source>
        <translation>Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>Check Box</source>
        <translatorcomment>Don&apos;t change. It&apos;s the same as &quot;Quadrículo optativo&quot;, but easier to understand by the user.</translatorcomment>
        <translation>Quadrículo de seleção</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Radio Button</source>
        <translation>Botão Radial</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1283"/>
        <source>Combo Box</source>
        <translatorcomment>Shorter Wiktionary
combo box
noun
A GUI widget that is a combination of a dropdown list or list box and a single-line textbox, allowing the user either to type a value directly into the control or choose from the list of existing options.</translatorcomment>
        <translation>Lista de Opções com Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <source>List Box</source>
        <translation>Lista de Opções</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1256"/>
        <source>Text Field</source>
        <translation>Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1817"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1820"/>
        <source>F12</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5938"/>
        <source>Characters</source>
        <translation>Caracteres</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="vanished">Todos os formatos (*.pdf *.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="85"/>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="215"/>
        <source>Page Display</source>
        <translatorcomment>Not necessary - &quot;redudant&quot;, in a way - to specify &quot;Exibição de&quot; here. </translatorcomment>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="225"/>
        <source>Go To</source>
        <translation>Ir para</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="237"/>
        <location filename="../../src/mainwindow.ui" line="2019"/>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1721"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>É necessário reiniciar o programa para efetivar as alterações.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1633"/>
        <source>Send file via email</source>
        <translation>Entrega de E-Mail</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation type="vanished">Todos os arquivos válidos (*.pdf *.xps);;Arquivos PDF (*.pdf);;Arquivos XPS (*.xps)</translation>
    </message>
    <message>
        <source>Text Box</source>
        <translation type="vanished">Caixa de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1830"/>
        <source>Callout</source>
        <translation>Balão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1835"/>
        <source>Formatted Text</source>
        <translation>Texto formatado</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Texto Formatado (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite adicionar texto formatado à página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1825"/>
        <source>Typewriter</source>
        <translation>Máquina de Escrever Virtual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulário (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona formulário para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <location filename="../../src/mainwindow.ui" line="1877"/>
        <source>Redaction</source>
        <translation>Revisão</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+6)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ferramenta mão (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use a ferramenta mão para mover as páginas, links abertos e selecionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {6)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Alt+6</source>
        <translation>Alt+6</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+7)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Selecionar Texto (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona texto para copiar e colar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; {600;?} {7)?}</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="547"/>
        <source>Alt+7</source>
        <translation>Alt+7</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <source>Check for Updates</source>
        <translation>Procurar atualizações</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Mark for Redaction</source>
        <translation>Marcar para revisão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1851"/>
        <source>Apply Redactions</source>
        <translation>Aplicar Revisões</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1856"/>
        <source>Redaction Properties</source>
        <translation>Propriedades da Revisão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1864"/>
        <source>Show Redaction ToolBar</source>
        <translation>Exibir a Barra de Revisão</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1869"/>
        <source>Search and Redact</source>
        <translation>Localizar e Revisar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1882"/>
        <source>Certificate Manager</source>
        <translation>Gestor de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1887"/>
        <source>Send Backward</source>
        <translation>Enviar para o fundo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1892"/>
        <source>Bring Forward</source>
        <translation>Pôr na frente</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1900"/>
        <source>Edit Vector Images</source>
        <translation>Edição de Imagens Vetoriais</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1911"/>
        <source>Next View</source>
        <translatorcomment>Don&apos;t change to &quot;Exibição Seguinte&quot;.</translatorcomment>
        <translation>Visualização Seguinte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1916"/>
        <source>Previous View</source>
        <translatorcomment>Don&apos;t change to &quot;Exibição Anterior&quot;. It doesn&apos;t fit in well in the context. </translatorcomment>
        <translation>Visualização Anterior</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1924"/>
        <source>Edit Images</source>
        <translation>Edição de Imagens</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1935"/>
        <location filename="../../src/mainwindow.cpp" line="3307"/>
        <source>Show Comments List</source>
        <translation>Exibir a lista de comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="462"/>
        <source>You do not have access right to this encrypted document.</source>
        <translation>Você não tem permissão de acessar este arquivo protegido por senha.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="464"/>
        <source>It is encrypted with certificate absent from your system.</source>
        <translation>Está cifradamente protegido com um certificado inexistente em seu sistema.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="477"/>
        <source>There was an error opening the document!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1043"/>
        <source>File is opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1045"/>
        <source>Use Save As... to save your work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2897"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3147"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="100"/>
        <source>All Reviewers</source>
        <translation>Todos os revisores</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3285"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="80"/>
        <source>Hide All Comments</source>
        <translation>Ocultar todos os comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3290"/>
        <source>Show All Comments</source>
        <translation>Exibir todos os comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3592"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3613"/>
        <source>Master PDF Editor can&apos;t find any Watermarks on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3627"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3634"/>
        <source>Master PDF Editor can&apos;t find any Backgrounds on the specified pages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5319"/>
        <source>Master PDF Editor can&apos;t find any Redaction in the document!</source>
        <translation>O Master PDF Editor não achou nenhuma revisão no arquivo!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6199"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6900"/>
        <source>Failed to restore last open session:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7437"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="7438"/>
        <source>Document doesn&apos;t contain any tables with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="79"/>
        <source>Comment View</source>
        <translation>Exibir o Painel de Comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="93"/>
        <source>Show by Type</source>
        <translation>Exibir por tipo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3171"/>
        <source>All Types</source>
        <translation>Todos os tipos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3176"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3184"/>
        <source>Text Editing Markups</source>
        <translation>Destaques na edição de texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3188"/>
        <source>Stamps</source>
        <translation>Carimbos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3192"/>
        <source>Attachments</source>
        <translation>Anexos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="97"/>
        <source>Show by Reviewer</source>
        <translation>Exibir por Revisor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="107"/>
        <source>Show by Status</source>
        <translation>Exibir por status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3217"/>
        <source>All Status</source>
        <translation>Todos os status</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3222"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="vanished">Exibir</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="45"/>
        <source>You already have the latest version!</source>
        <translation>Sua versão é a mais atual!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6058"/>
        <source>All Supported Files (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;PDF Files (*.pdf *.PDF);;FDF Files (*.fdf *.FDF);;XPS Files (*.xps *.XPS);;TIFF Files (*.tif *.tiff);;All Files (*)</source>
        <translation>Todos os arquivos válidos (*.pdf *.xps *.PDF *.XPS *.tif *.tiff *.fdf);;Arquivos PDF (*.pdf *.PDF);;Arquivos FDF (*.fdf *.FDF);;Arquivos XPS(*.xps *.XPS);;Arquivos TIFF (*.tif *.tiff);;Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3303"/>
        <source>Hide Comments List</source>
        <translation>Ocultar a lista de comentários</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="431"/>
        <source>File is locked by another Master PDF Editor instance, it will be opened in read only mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="433"/>
        <source>You will be able to save your work, but only to another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="vanished">pt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="616"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="635"/>
        <source>Place Initials</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Iniciais</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="617"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="636"/>
        <source>Create New Initials</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Criar Iniciais</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="619"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="638"/>
        <source>Open Containing Folder</source>
        <translation>Abrir pasta</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Abrir Arquivo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir um arquivo PDF ou XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>Don&apos;t change to &quot;mover/movimentar páginas&quot;.</translatorcomment>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ferramenta de mão&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use a ferramenta de mão para rolar páginas, abrir ligações/remissões e selecionar textos.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Selecionar Texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona texto para copiá-lo e colá-lo onde desejado&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salva alterações no arquivo atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar como...&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salva o arquivo atual com um novo nome&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>System Print...</source>
        <translation>Painel de Impressão do SO...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;System Print Dialog&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print using system dialog...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Painel de Impressão do SO&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprime o arquivo atual mostrando o painel de impressão do sistema...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar o Arquivo Atual&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite selecionar e editar texto, imagens, anotações, campos de formulário ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Objects&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar componentes de texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecionar texto para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Excluir componente(s)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Excluir o(s) componente(s) atualmente selecionado(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Forms&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulários&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Selecionar formulário para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="877"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Novo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Criar um novo PDF em branco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimir&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir o documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="913"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Recortar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Corta a seleção de componente(s) e os coloca na área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copiar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copia a seleção de componente(s) e s coloca na área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colar&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cola conteúdo da Área de Transferência na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Desfazer&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Desfazer a última ação&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="999"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Refazer&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Refaz a última ação desfeita.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1130"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propriedades&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abre o painel de propriedades do arquivo atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir texto&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite adicionar texto simples à página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir imagem&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite inserir uma imagem na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir remissão&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite criar uma remissão na página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Vector Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select vector Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar imagem vetorial&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite editar a imagem vetorial selecionada&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1927"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Images&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select bitmap Images for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar imagens&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Permite selecionar imagem de bitmap para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="149"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Pages to Images</source>
        <translation>Páginas como Imagens</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1614"/>
        <source>Pages to Text</source>
        <translation>Páginas como Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1951"/>
        <source>Extract all Images</source>
        <translatorcomment>Don&apos;t modify translation above. It&apos;s correct indeed.</translatorcomment>
        <translation>Só extraindo as imagens</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1434"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Imagens PNG (*.png);;Imagens BMP (*.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1956"/>
        <source>Reload</source>
        <translation>Recarregar arquivos abertos</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1964"/>
        <source>Take a Snapshot</source>
        <translation>Captura de Tela da Página Atual</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="249"/>
        <source>Red</source>
        <translation>Vermelho</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="254"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="259"/>
        <source>Yellow</source>
        <translation>Amarelo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="264"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="63"/>
        <source>What&apos;s new</source>
        <translation>Que há de novo?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="551"/>
        <source>The file you are attempting to open contains comments or form data that are supposed to be placed on</source>
        <translation>O arquivo que você está tentando abrir contém comentários ou dados de formulário destinados a ser postos em</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>This document cannot be found.</source>
        <translation>Não achei o documento especificado.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="553"/>
        <source>Would you like to browse and attempt to locate this document?</source>
        <translation>Gostaria de tentar localizar este arquivo?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1672"/>
        <source>Saved Settings</source>
        <translation>Feito o salvamento das configurações</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="26"/>
        <source>Cannot connect! Please verify that you are connected to the Internet and check for updates again.</source>
        <translation>Não foi possível conectar ao servidor! Favor verificar se você está mesmo conectado à Internet e tente procurar atualizações de novo.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1969"/>
        <source>Toolbar Settings</source>
        <translation>Configurar a Barra de Ferramentas</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="vanished">Uma Página</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1977"/>
        <source>Continuous</source>
        <translation>Contínua</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Bloco de Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="5159"/>
        <location filename="../../src/mainwindow.cpp" line="5181"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Quer mesmo restaurar a padronização das barras de ferramentas?</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="302"/>
        <source>Reset toolbars</source>
        <translation>Restaurar Barras de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <source>Insert Initials</source>
        <translation>Inserir Iniciais</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="296"/>
        <source>Minimum tools</source>
        <translation type="unfinished">Mínimo de ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="61"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="114"/>
        <source>Delete All Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="116"/>
        <source>Delete All Visible Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="299"/>
        <source>Maximum tools</source>
        <translation type="unfinished">Máximo de ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="82"/>
        <source>Show All Comments with text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="250"/>
        <location filename="../../src/mainwindow_update.cpp" line="357"/>
        <source>Error</source>
        <translation type="unfinished">Erro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="252"/>
        <location filename="../../src/mainwindow_update.cpp" line="359"/>
        <source>Activation failed! Check internet connection.</source>
        <translation type="unfinished">Falha na tentativa de ativação! Verifique sua conexão de Internet.</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="297"/>
        <source>License is expired!</source>
        <translation type="unfinished">Licença expirada!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="71"/>
        <location filename="../../src/mainwindow_update.cpp" line="300"/>
        <location filename="../../src/mainwindow_update.cpp" line="504"/>
        <source>Renew</source>
        <translation type="unfinished">Renovar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="68"/>
        <source>WARNING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="338"/>
        <source>Too many activations!</source>
        <translation type="unfinished">Ativações em demasia!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="394"/>
        <source>Server connection lost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="445"/>
        <source>Failed to connect to License server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="516"/>
        <source>Verify Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <source>Label</source>
        <translation type="unfinished">Título</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="6222"/>
        <source>Rotate</source>
        <translation type="unfinished">Girar</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="54"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="55"/>
        <source>Circle</source>
        <translation type="unfinished">Círculo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="56"/>
        <source>Comment</source>
        <translation type="unfinished">Comentário</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="57"/>
        <source>Cross</source>
        <translation type="unfinished">Cruz</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="60"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="62"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="63"/>
        <source>Paragraph</source>
        <translation type="unfinished">Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="64"/>
        <source>Right Arrow</source>
        <translation type="unfinished">Seta para a direita</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="65"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="66"/>
        <source>Star</source>
        <translation type="unfinished">Estrela</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="67"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="68"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="69"/>
        <source>Graph</source>
        <translation type="unfinished">Gráfico</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="70"/>
        <source>Paper Clip</source>
        <translation type="unfinished">Clipe de Papel</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="72"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1982"/>
        <source>Edit Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="62"/>
        <source>Failed opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="67"/>
        <source>File is already opened and opening same file in multiple tabs option is off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="72"/>
        <source>File does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="319"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="323"/>
        <location filename="../../src/mainwindow_appsessions.cpp" line="328"/>
        <source>Current session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="376"/>
        <source>Error loading session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_appsessions.cpp" line="406"/>
        <source>session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageHeaderAndFooterDialog</name>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="20"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="27"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="34"/>
        <source>Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="41"/>
        <source>Remove</source>
        <translation type="unfinished">Remover</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="48"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="55"/>
        <source>Add</source>
        <translation type="unfinished">Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="65"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="72"/>
        <source>Zoom Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="79"/>
        <source>Show</source>
        <translation type="unfinished">Exibir</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.ui" line="14"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="82"/>
        <source>Manage Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="113"/>
        <source>All</source>
        <translation type="unfinished">Todas</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="117"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="510"/>
        <source>Header and Footer</source>
        <translation type="unfinished">Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="119"/>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="513"/>
        <source>Bates Numbering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="263"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="516"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="517"/>
        <source>Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="518"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="519"/>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="520"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="525"/>
        <source>Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="635"/>
        <source>Remove Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="639"/>
        <source>Do you want to remove selected Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="643"/>
        <source>Do you want to remove selected headers/footers from this document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="657"/>
        <source>Remove all Headers and Footers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/manageheaderandfooterdialog.cpp" line="658"/>
        <source>Do you want to remove all headers, footers and Bates numberings from this document?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation>Texto reconhecido</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation>Original</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="25"/>
        <source>Not Text</source>
        <translation>Não é texto</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Mover Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Página de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="43"/>
        <source>Destination</source>
        <translation>Destino</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="55"/>
        <source>To:</source>
        <translation>Para:</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="65"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>First</source>
        <translation>Primeira</translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="121"/>
        <source>Last</source>
        <translation>Última</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Tamanho da Página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="49"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="86"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>A0</source>
        <translation type="vanished">A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation type="vanished">A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation type="vanished">A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation type="vanished">A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation type="vanished">A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation type="vanished">A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation type="vanished">A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation type="vanished">A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation type="vanished">A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation type="vanished">A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation type="vanished">A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation type="vanished">Personalizar o tamanho da página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="151"/>
        <source>Contents Size</source>
        <translation>Tamanho do Conteúdo</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>Left margin</source>
        <translation>Margem esquerda</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="203"/>
        <source>Top margin</source>
        <translation>Margem superior</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="183"/>
        <source>Right margin</source>
        <translation>Margem direita</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Bottom margin</source>
        <translation>Margem inferior</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="246"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="252"/>
        <source>Before current page</source>
        <translation>Antes da página atual</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="269"/>
        <source>After current page</source>
        <translation>Após a página atual</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="276"/>
        <source>After last page</source>
        <translation>Após a última página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="262"/>
        <source>Before first page</source>
        <translation>Antes da primeira página</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="286"/>
        <source>Number of pages</source>
        <translation>Número de páginas</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="312"/>
        <source>Page(s)</source>
        <translation>Página(s)</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="292"/>
        <source>Create</source>
        <translation>Criar</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation type="vanished">Carta</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation type="vanished">Tablóide</translation>
    </message>
    <message>
        <source>B0</source>
        <translation type="vanished">B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation type="vanished">B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation type="vanished">B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation type="vanished">B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation type="vanished">B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation type="vanished">B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation type="vanished">Confirmação</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation type="vanished">Executivo</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation type="vanished">Folha de papel</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation type="vanished">In-quarto</translation>
    </message>
    <message>
        <source>Note</source>
        <translation type="vanished">Nota</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation type="vanished">ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation type="vanished">ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation type="vanished">ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation type="vanished">ANSI F</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Ponto</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="122"/>
        <source>Units</source>
        <translation>Usar esta unidade</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="vanished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Points</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation>Módulo de OCR</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="164"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="43"/>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="49"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="194"/>
        <source>Selected</source>
        <translation>Selecionado</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="36"/>
        <source>Install languages</source>
        <translation>Adicionar idiomas</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="108"/>
        <source>Searchable Text</source>
        <translation>Texto pesquisável</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="118"/>
        <source>Editable Text</source>
        <translation>Texto editável</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="138"/>
        <source>Font Family</source>
        <translation>Família de Fontes</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="vanished">Editar manualmente o texto reconhecido</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">automático</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="201"/>
        <source>Force manual text editing if confidence level not achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="171"/>
        <source>Minimal confidence level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="obsolete">Linha</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="224"/>
        <source>Advanced</source>
        <translation type="unfinished">Avançado</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="258"/>
        <source>Helvetica</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation>Fazer OCR</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="68"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>Quer mesmo interromper o reconhecimento do arquivo?</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="65"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Sem Propriedades. Nenhum componente selecionado.</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="223"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3778"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4059"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2379"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="288"/>
        <source>Property</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="293"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1021"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1597"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3153"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2434"/>
        <source>Font Family</source>
        <translation>Família de Fontes</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3790"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2479"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4079"/>
        <source>Type</source>
        <translatorcomment>Please, don&apos;t change to &quot;Tipo&quot;, &quot;Estilo&quot;, &quot;Propriedade&quot;. It&apos;s perfect as it is.</translatorcomment>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2528"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3725"/>
        <source>Fill Color</source>
        <translation>Cor de preenchimento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2541"/>
        <source>Stroke Color</source>
        <translatorcomment>Don&apos;t change to &quot;Cor do Contorno&quot; here. </translatorcomment>
        <translation>Cor do traçado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3578"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3639"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4029"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2408"/>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3163"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2819"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2431"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3934"/>
        <source>Form Field</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3857"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1892"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1943"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Família de fontes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a família de fontes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3674"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="546"/>
        <source>Goto a Page View</source>
        <translation>Exibir página conforme especificado no comando</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="551"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="556"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Reset form</source>
        <translatorcomment>Don&apos;t change to &quot;ressetar&quot;</translatorcomment>
        <translation>Limpar o formulário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="566"/>
        <source>Show/Hide fields</source>
        <translation>Exibir/ocultar campos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="571"/>
        <source>Submit a form</source>
        <translatorcomment>Please, don&apos;t change to &quot;Enviar dados de formulário&quot;</translatorcomment>
        <translation>Enviar dados do formulário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="576"/>
        <source>Run a JavaScript</source>
        <translation>Executar comando de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="478"/>
        <source>Add an Action</source>
        <translation>Adicionar comando</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="484"/>
        <source>Trigger</source>
        <translatorcomment>Please, don&apos;t change to &quot;Acionador&quot;, &quot;Disparador&quot;, &quot;Ação&quot; etc.</translatorcomment>
        <translation>Acionar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="492"/>
        <source>Mouse Up</source>
        <translation>Ao se soltar botão do mouse</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="497"/>
        <source>Mouse Down</source>
        <translatorcomment>Don&apos;t change to &quot;Ao se clicar&quot;, &quot;Ao se dar um clique&quot;, for the action or command is triggered right upon, and not right after, the user pressing the mouse button.</translatorcomment>
        <translation>Ao se apertar o botão do mouse</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="502"/>
        <source>Mouse Enter</source>
        <translatorcomment>On mouse pointer enter field or component area.</translatorcomment>
        <translation>Ao se pairar o ponteiro sobre o componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="507"/>
        <source>Mouse Exit</source>
        <translatorcomment>On mouse pointer exit field or component.</translatorcomment>
        <translation>Ao se retirar o ponteiro do componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="512"/>
        <source>On Receive Focus</source>
        <translation>Quando selecionado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="517"/>
        <source>On Lose Focus</source>
        <translation>Quando desselecionado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="538"/>
        <source>Action</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="590"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="918"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="600"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3341"/>
        <source>Actions</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1677"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2235"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2269"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2341"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3460"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="632"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="905"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation type="vanished">Acima do Rótulo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="695"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="849"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1821"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1976"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="371"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="854"/>
        <source>Push</source>
        <translatorcomment>Too out of context to know contextual meaning for sure.</translatorcomment>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Outline</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="864"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Invert</source>
        <translation>Inverter</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation type="vanished">A baixo do Rótulo</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation type="vanished">Em torno do Rótulo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="898"/>
        <source>Item</source>
        <translation>Item</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="931"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1206"/>
        <source>Export Value</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Valor Exportável</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="771"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="973"/>
        <source>Up</source>
        <translation>Acima</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="776"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="957"/>
        <source>Down</source>
        <translation>Abaixo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1001"/>
        <source>Sort Items</source>
        <translation>Ordenar itens</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="980"/>
        <source>Commit selected value immediately</source>
        <translation>Aplicar imediatamente o valor selecionado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="994"/>
        <source>Multiple selection</source>
        <translation>Seleção múltipla</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="987"/>
        <source>Allow user to enter custom text</source>
        <translation>Permitir que usuário digite texto personalizado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1126"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1133"/>
        <source>Scrollable</source>
        <translation>Rolável</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1140"/>
        <source>Check spelling</source>
        <translation>Verificar ortografia</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1061"/>
        <source>Limit to</source>
        <translation>Limitar a</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1075"/>
        <source>chars</source>
        <translation>caracteres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1082"/>
        <source>Split into</source>
        <translation>Dividir em</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1054"/>
        <source>Allow Rich Text formatting</source>
        <translation>Permitir texto RTF</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <source>Multi-line</source>
        <translation>Multilinha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1096"/>
        <source>cells</source>
        <translation>células</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1041"/>
        <source>Center</source>
        <translation>Centralizado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1046"/>
        <source>Right</source>
        <translation>À direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1106"/>
        <source>Default Value</source>
        <translation>Valor Padrão</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1028"/>
        <source>Alignment</source>
        <translation>Alinhamento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1219"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3227"/>
        <source>Style</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1230"/>
        <source>Check</source>
        <translation>Marcar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1235"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="347"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1240"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="349"/>
        <source>Cross</source>
        <translation>Cruz</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Diamond</source>
        <translation>Losango</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1250"/>
        <source>Square</source>
        <translation>Quadrado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1255"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="358"/>
        <source>Star</source>
        <translation>Estrela</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1183"/>
        <source>Checked by Default</source>
        <translation>Marcado por Padrão</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3768"/>
        <source>Line Thickness</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1386"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3718"/>
        <source>Border Color</source>
        <translation>Cor da Borda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3761"/>
        <source>Line Style</source>
        <translation>Tipo de Linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3733"/>
        <source>Solid</source>
        <translation>Inteiriço</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1406"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3738"/>
        <source>Dashed</source>
        <translation>Pontilhado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1411"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3753"/>
        <source>Underline</source>
        <translation>jSublinhado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Highlight</source>
        <translation>Realce</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>OutLine</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Insert</source>
        <translatorcomment>O tipo de linha. Don&apos;t change to &quot;Inserir&quot;. &quot;INSET&quot; was mispelled as &quot;InSERT&quot; by authors.</translatorcomment>
        <translation>Sulcado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1463"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt; &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Sans Serif&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Assinatura.&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nenhuma opção disponível&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3360"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3479"/>
        <source>Format</source>
        <translatorcomment>Don&apos;t change. it&apos;s exactly this.</translatorcomment>
        <translation>Dados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1807"/>
        <source>Format category</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Tipo de dados</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1826"/>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1831"/>
        <source>Percentage</source>
        <translation>Porcentagem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1836"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1841"/>
        <source>Time</source>
        <translation>Horário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1846"/>
        <source>Special</source>
        <translation>Especial</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1851"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2006"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="333"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="337"/>
        <source>Custom</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1870"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="131"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1875"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="136"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1557"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1885"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1890"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1567"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1895"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1572"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1900"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1577"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1905"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1910"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1915"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1920"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1929"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1934"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1939"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1944"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1958"/>
        <source>Currency Symbol</source>
        <translation>Símbolo de Moeda Corrente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1981"/>
        <source>Dollar ($)</source>
        <translation>Dólar ($)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1986"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1991"/>
        <source>Pound (£)</source>
        <translation>Libra (£)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1996"/>
        <source>Yen (¥)</source>
        <translation>Iene (¥)</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation type="vanished">Rublo (Руб)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2027"/>
        <source>Show parentheses</source>
        <translation>Exibir parênteses</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2047"/>
        <source>Decimal Places</source>
        <translation>Casas Decimais</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2054"/>
        <source>Separation Style</source>
        <translation>Tipo de Separação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2061"/>
        <source>Use red text</source>
        <translation>Usar texto vermelho</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>Date Options</source>
        <translation>Opções de Data</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2117"/>
        <source>Time Options</source>
        <translation>Opções de Horário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2150"/>
        <source>Special Options</source>
        <translation>Opções Especiais</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2208"/>
        <source>Format Script</source>
        <translation>Comando de Formatação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2242"/>
        <source>KeyStroke Script</source>
        <translation>Comando de Teclagem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>Validate</source>
        <translation>Validar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2314"/>
        <source>Validation Script</source>
        <translation>Comando de Validação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2349"/>
        <source>Calculate</source>
        <translation>Calcular</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2370"/>
        <source>Calculation Script</source>
        <translation>Comando de Cálculo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2499"/>
        <source>Fill text</source>
        <translation>Preenchimento do texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2504"/>
        <source>Stroke Text</source>
        <translatorcomment>That&apos;s the same as &quot;só com o traçado, a linha que delimita o caracter&quot;.</translatorcomment>
        <translation>Texto Delineado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2509"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3558"/>
        <source>Fill and Stroke</source>
        <translatorcomment>That&apos;s the same as &quot;Preenchimento e Traçado (do Texto)&quot;, but simpler as it is. </translatorcomment>
        <translation>Preenchimento e Contorno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Invisible</source>
        <translation>Invisível</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2554"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3626"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4016"/>
        <source>Line Width</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2583"/>
        <source>Character spacing</source>
        <translation>Espaço entre caracteres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Word spacing</source>
        <translation>Espaço entre palavras</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2597"/>
        <source>Line spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2758"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2768"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2778"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2788"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2882"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished">Verticalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2885"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2910"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2935"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2960"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2998"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3017"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3036"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2901"/>
        <source>Align Top</source>
        <translation type="unfinished">Em cima</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Align Right</source>
        <translation type="unfinished">À direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <source>Align Left</source>
        <translation type="unfinished">À esquerda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished">Horizontalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2995"/>
        <source>Align Bottom</source>
        <translation type="unfinished">Embaixo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <source>Send To Back</source>
        <translation type="unfinished">Enviar para o fundo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3033"/>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3052"/>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3071"/>
        <source>Bring To Front</source>
        <translation type="unfinished">Pôr na frente de tudo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3143"/>
        <source>Coordinates</source>
        <translation>Coordenadas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3094"/>
        <source>Absolute</source>
        <translation>Absolutas</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3099"/>
        <source>Relative</source>
        <translation>Relativa</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3189"/>
        <source>Geometry</source>
        <translatorcomment>Random House Webster&apos;s Unabridged Dictionary
geometry
/jee om&quot;i tree/, n.
[...]
5. the shape or form of a surface or solid.

But, PLEASE, don&apos;t change to &quot;Formato&quot;.
</translatorcomment>
        <translation>Formatação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3208"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3832"/>
        <source>Font</source>
        <translatorcomment>Don&apos;t change to &quot;Fonte&quot;.</translatorcomment>
        <translation>Propriedades dos Caracteres</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3246"/>
        <source>Matrix</source>
        <translatorcomment>Don&apos;t change to &quot;Matriz&quot; or to &quot;Molde&quot;.</translatorcomment>
        <translation>Dimensões</translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation type="vanished">Cliping Path</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3303"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3379"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3548"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3566"/>
        <source>Fill</source>
        <translation>Preenchimento</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3553"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3601"/>
        <source>Stroke</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3591"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3613"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3819"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4042"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3693"/>
        <source>Borders and Colors</source>
        <translation>Bordas e Cores</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3700"/>
        <source>Thin</source>
        <translation>Fina</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3705"/>
        <source>Medium</source>
        <translation>Médio</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3710"/>
        <source>Thick</source>
        <translation>Grossa</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3743"/>
        <source>Beveled</source>
        <translation>Chanfrado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3748"/>
        <source>Inset</source>
        <translatorcomment>Don&apos;t change to &quot;inserir&quot;. Note that the term is &quot;INSET&quot;, without an &quot;R&quot;, and NOT &quot;inseRt&quot;, with an &quot;R&quot;.</translatorcomment>
        <translation>Sulcado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3803"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3867"/>
        <source>ToolTip</source>
        <translation>Dicas da Ferramenta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3883"/>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3891"/>
        <source>0 Degrees</source>
        <translation>0 Graus</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3896"/>
        <source>90 Degrees</source>
        <translation>90 Graus</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3901"/>
        <source>180 Degrees</source>
        <translation>180 Graus</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3906"/>
        <source>270 Degrees</source>
        <translation>270 Graus</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3927"/>
        <source>Read Only</source>
        <translation>Somente-Leitura</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3942"/>
        <source>Visible</source>
        <translation>Visível</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3947"/>
        <source>Hidden</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3952"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Visível, mas sem impressão</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3957"/>
        <source>Hidden but printable</source>
        <translation>Oculto, mas imprimível</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3965"/>
        <source>Required</source>
        <translation>Preenchimento necessário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4109"/>
        <source>Locked</source>
        <translation>Bloqueado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1880"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1887"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1900"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1907"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1955"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor da Fonte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a cor de preenchimento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1961"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor do Contorno da Fonte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a cor do contorno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2454"/>
        <source>Shading</source>
        <translation>Sombreamento</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation type="vanished">Formato da Imagem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4052"/>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4089"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <source>Maintain aspect ratio</source>
        <translation>Manter proporção</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code</source>
        <translation>CEP</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Zip Code+4</source>
        <translation>Zip Code+4</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Phone Number</source>
        <translation>Número de Telefone</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="340"/>
        <source>Social Security Number</source>
        <translation>Número da Previdência Social</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="346"/>
        <source>Check Mark</source>
        <translation>Marca de selecionado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="348"/>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="350"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translatorcomment>Don&apos;t change to &quot;Inserir texto&quot;.</translatorcomment>
        <translation type="obsolete">Inserção de texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="352"/>
        <source>Key</source>
        <translatorcomment>It&apos;s literally a &quot;key/chave&quot; iconical symbol here. Don&apos;t change.</translatorcomment>
        <translation>Chave</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="353"/>
        <source>New Paragraph</source>
        <translation>Novo parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="354"/>
        <source>Text Note</source>
        <translation>Anotação</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="355"/>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="356"/>
        <source>Right Arrow</source>
        <translation>Seta para a direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="357"/>
        <source>Right Pointer</source>
        <translatorcomment>Don&apos;t change to &quot;Seta para a direita&quot;, &quot;Ponteiro para a direita&quot;.</translatorcomment>
        <translation>Ponta de seta para a direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="359"/>
        <source>Up Arrow</source>
        <translation>Seta apontando para cima</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="360"/>
        <source>Up Left Arrow</source>
        <translatorcomment>Don&apos;t change to &quot;Seta ascendente para a esquerda&quot;.</translatorcomment>
        <translation>Seta apontando para cima e para a esquerda</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="361"/>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="362"/>
        <source>Paper Clip</source>
        <translation>Clipe de Papel</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="363"/>
        <source>Attachment</source>
        <translation>Anexo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="364"/>
        <source>Tag</source>
        <translatorcomment>Don&apos;t change to &quot;Rótulo&quot;.</translatorcomment>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3123"/>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation type="vanished">Altura da linha</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2640"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2659"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3398"/>
        <source>Selection change</source>
        <translation>Mudança de seleção</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3426"/>
        <source>Do nothing</source>
        <translation>Não fazer nada</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3433"/>
        <source>Execute this script</source>
        <translation>Executar este comando</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Units</source>
        <translatorcomment>Don&apos;t change to &quot;Unidades&quot;.</translatorcomment>
        <translation>Unidade de medida</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Ponto</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2146"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4359"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2151"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4379"/>
        <source> in</source>
        <translation> pol</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2155"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="4399"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="vanished">Marca D&apos;Água</translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="obsolete">Plano de Fundo</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="vanished">Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3265"/>
        <source>Clipping Path</source>
        <translatorcomment>Don&apos;t change to &quot;Delimitador de Recorte&quot;. It&apos;s not the case at all here - I tested this feature. In the context, it&apos;s almost the same as &quot;Linhas Delimitadoras do Componente&quot;.</translatorcomment>
        <translation>Redimensionador do Componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2855"/>
        <source>Points</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2860"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2865"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="702"/>
        <source>Layout</source>
        <translation>Disposição</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="713"/>
        <source>Label only</source>
        <translation>Apenas Nome</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Icon only</source>
        <translation>Apenas Ícones</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="723"/>
        <source>Icon top, label bottom</source>
        <translation>Ícones em cima, nome embaixo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <source>Label top, icon bottom</source>
        <translation>Nome em cima, ícones embaixo</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Icon left, label right</source>
        <translation>Ícone à esquerda, nome à direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>label left, icon right</source>
        <translation>Nome à esquerda, ícone à direita</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <source>Label over icon</source>
        <translation>Nome sobre os ícones</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="758"/>
        <source>Icon and Label</source>
        <translation>Ícone e Nome</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="781"/>
        <source>Rollover</source>
        <translation>Rolagem</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="798"/>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="805"/>
        <source>Choose Icon...</source>
        <translation>Escolher ícone...</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="828"/>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Label</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1307"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Botões com o mesmo nome e valor selecionados ao mesmo tempo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos os formatos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="751"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4102"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2001"/>
        <source>Ruble (₽)</source>
        <translation>Rublo (₽)</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3498"/>
        <source>Settings</source>
        <translatorcomment>Don&apos;t change to &quot;Configurações&quot; or to &quot;Opções&quot;.</translatorcomment>
        <translation>Configurações do Componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="4127"/>
        <source>Always show Object Inspector</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Sempre exibir o Painel de Propriedades</translation>
    </message>
    <message>
        <source>Text Block</source>
        <translation type="vanished">Bloco de Texto</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="175"/>
        <source>Object Inspector</source>
        <translation type="unfinished">Painel de Propriedades de Componente</translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1501"/>
        <source>QRCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1506"/>
        <source>DataMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1517"/>
        <source>Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>ECC Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>X Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1590"/>
        <source>X/Y Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Include field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1637"/>
        <source>Pick...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1689"/>
        <source>Encode using Tab Delmited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1694"/>
        <source>Encode using XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1699"/>
        <source>JavaScript</source>
        <translation type="unfinished">JavaScript</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation>Lista de Componentes</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="79"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="285"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="317"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="373"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="obsolete">Formato</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <source>View</source>
        <translation type="vanished">Exibir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="32"/>
        <source>Expand All</source>
        <translation>Expandir tudo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="33"/>
        <source>Collapse All</source>
        <translation>Recolher tudo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="92"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="135"/>
        <source>All</source>
        <translation>Todas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="103"/>
        <source>Images</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="108"/>
        <source>Paths</source>
        <translation>Caminhos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Shadings</source>
        <translation>Sombreamentos</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>Containers</source>
        <translation>Containers</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="141"/>
        <source>Text Fields</source>
        <translation>Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="146"/>
        <source>List Boxes</source>
        <translation>Lista de seleção</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="151"/>
        <source>Combo Boxes</source>
        <translatorcomment>Don&apos;t change. Note the &quot;Combo&quot; term.</translatorcomment>
        <translation>Listas de Opções com Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="156"/>
        <source>Check Boxes</source>
        <translation>Caixa de seleção</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="161"/>
        <source>Radio Buttons</source>
        <translation>Botões de seleção</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="166"/>
        <source>Buttons</source>
        <translation>Botões</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="171"/>
        <source>Links</source>
        <translation>Ligações/Remissões</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="176"/>
        <source>Signatures</source>
        <translation>Assinaturas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <source>Object</source>
        <translation type="obsolete">Componente</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="270"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="338"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="269"/>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
</context>
<context>
    <name>OptimizeScannedPagesDlg</name>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="14"/>
        <source>Optimize Scanned Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="29"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="39"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="49"/>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="79"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="95"/>
        <source>Apply Adaptive Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="107"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished">Imagens a cores e em preto-e-branco graduado</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="127"/>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="173"/>
        <source>ZIP</source>
        <translation type="unfinished">ZIP</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="132"/>
        <source>JPEG</source>
        <translation type="unfinished">JPEG</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="153"/>
        <source>Black and White Images</source>
        <translation type="unfinished">Imagens em Preto e Branco</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="178"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished">CCITT Group 4</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="183"/>
        <source>JBIG2</source>
        <translation type="unfinished">JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="200"/>
        <source>Small Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="229"/>
        <source>High Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="242"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="248"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/OptimizeScannedPagesDlg.ui" line="255"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionToolBarForm</name>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="20"/>
        <source>Tollbars</source>
        <translation>Barras de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="71"/>
        <source>All tools:</source>
        <translation>Todas as ferramentas:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="85"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="159"/>
        <source>Current toolbar tools:</source>
        <translation>Ferramentas da Barra atual:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="248"/>
        <source>Toolbars:</source>
        <translation>Barras de Ferramentas:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="265"/>
        <source>Add Toolbar</source>
        <translation>Criar Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="272"/>
        <source>Delete Toolbar</source>
        <translation>Apagar Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="288"/>
        <source>Reset All</source>
        <translation>Restaurar a padronização</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="295"/>
        <source>Maximum tools</source>
        <translation>Máximo de ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.ui" line="300"/>
        <source>Minimum tools</source>
        <translation>Mínimo de ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="174"/>
        <source>Please, name new toolbar</source>
        <translation>Especifique o nome da nova Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="525"/>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="557"/>
        <source>Are you sure you want to reset all toolbars to default settings?</source>
        <translation>Quer mesmo restaurar a padronização das barras de ferramentas?</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/OptionToolBarForm.cpp" line="196"/>
        <source>ToolBar with this name already exist.</source>
        <translation>Já existe uma barra de ferramentas com este nome.</translation>
    </message>
</context>
<context>
    <name>PDFTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Esta fonte não contém esses caracteres.
Tente escolher outra fonte.</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Formato da Página</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="167"/>
        <source>Scale contents with size change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="203"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished">Manter proporção</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="247"/>
        <source>Contents Size</source>
        <translation>Tamanho do Conteúdo</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="259"/>
        <source>Left margin</source>
        <translation>Margem esquerda</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Top margin</source>
        <translation>Margem superior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="293"/>
        <source>Right margin</source>
        <translation>Margem direita</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="310"/>
        <source>Bottom margin</source>
        <translation>Margem inferior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="73"/>
        <location filename="../../src/PageLayoutDialog.ui" line="99"/>
        <source>Page Size</source>
        <translation>Tamanho da Página</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">Altura</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="63"/>
        <source>Units</source>
        <translatorcomment>Don&apos;t change to &quot;Unidades&quot;.</translatorcomment>
        <translation>Unidade de medida</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Ponto</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <source> in</source>
        <translation type="vanished"> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="vanished"> mm</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Páginas ímpares</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="86"/>
        <location filename="../../src/PageLayoutDialog.ui" line="154"/>
        <location filename="../../src/PageLayoutDialog.ui" line="174"/>
        <location filename="../../src/PageLayoutDialog.ui" line="190"/>
        <location filename="../../src/PageLayoutDialog.ui" line="266"/>
        <location filename="../../src/PageLayoutDialog.ui" line="283"/>
        <location filename="../../src/PageLayoutDialog.ui" line="300"/>
        <location filename="../../src/PageLayoutDialog.ui" line="317"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="331"/>
        <source>Points</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="336"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="341"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="137"/>
        <source>Bottom</source>
        <translation>Inferior</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="147"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="127"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="vanished">De</translation>
    </message>
    <message>
        <source>of:</source>
        <translation type="vanished">de:</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="106"/>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="62"/>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="119"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="63"/>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation>Propriedades de Página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="41"/>
        <source>Tab Order</source>
        <translation>Ordem das Guias</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="60"/>
        <source>Use Row Order</source>
        <translation>Ordenar por Linhas</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="67"/>
        <source>Use Column Order</source>
        <translation>Ordenar por Coluna</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="53"/>
        <source>Use Document Structure</source>
        <translation>Usar Estrutura do Documento</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="74"/>
        <source>Unspecified</source>
        <translation>Não especificado</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="111"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="117"/>
        <source>Actions</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="192"/>
        <source>Add an Action</source>
        <translation>Adicionar comando</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="205"/>
        <source>Trigger</source>
        <translation>Acionador</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="obsolete">Botão do Mouse Solto</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="198"/>
        <source>Action</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Goto a Page View</source>
        <translatorcomment>Don&apos;t change to &quot;Ir para uma Visualização/Exibição de Página&quot;. The above translation is the same as &quot;Exibir uma Visualização de Página Específica&quot;, that is, previously set/configured by the document&apos;s author.</translatorcomment>
        <translation>Acionar uma visualização de página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="255"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um arquivo</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="260"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="265"/>
        <source>Reset form</source>
        <translation>Limpar o formulário</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="270"/>
        <source>Show/Hide fields</source>
        <translation>Exibir/ocultar campos</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="275"/>
        <source>Submit a form</source>
        <translatorcomment>Please, don&apos;t change to &quot;Enviar dados de formulário&quot;.</translatorcomment>
        <translation>Enviar dados de formulário</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="280"/>
        <source>Run a JavaScript</source>
        <translation>Executar comando de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="212"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="132"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="151"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="236"/>
        <source>Open Page</source>
        <translation>Abrir página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="241"/>
        <source>Close Page</source>
        <translation>Fechar página</translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="30"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="51"/>
        <source>Current Page</source>
        <translation>Página atual</translation>
    </message>
</context>
<context>
    <name>PageRangeWidget</name>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="55"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="61"/>
        <source>Current page view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Todas as Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="117"/>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="78"/>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="127"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="86"/>
        <source>All pages in range</source>
        <translation type="unfinished">Todas as páginas no intervalo</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="91"/>
        <source>Even pages</source>
        <translation type="unfinished">Páginas pares</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.ui" line="96"/>
        <source>Odd pages</source>
        <translation type="unfinished">Páginas ímpares</translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pagerangewidget/PageRangeWidget.cpp" line="444"/>
        <source>Page Range input is incorrect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation>Configurações de Impressão</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation>Papél</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation>Largura:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation>Tamanho da página:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation>Margens</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation>Margem inferior</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation>Margem superior</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation>Margem esquerda</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation>Margem direita</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translatorcomment>Usually would be PPP (Pontos por Polegada) but DPI is very usual</translatorcomment>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="315"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="325"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="340"/>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="455"/>
        <source>Paper Source</source>
        <translation>Origem do Papel</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="399"/>
        <source>Points</source>
        <translation>Pontos</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Inches</source>
        <translation>Polegadas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="409"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="320"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="339"/>
        <source> in</source>
        <translation> pl</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.cpp" line="355"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>96</source>
        <translation type="unfinished">96</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>100</source>
        <translation type="unfinished">100</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>200</source>
        <translation type="unfinished">200</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>240</source>
        <translation type="unfinished">240</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="320"/>
        <source>400</source>
        <translation type="unfinished">400</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="330"/>
        <source>760</source>
        <translation type="unfinished">760</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="335"/>
        <source>800</source>
        <translation type="unfinished">800</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="345"/>
        <source>2400</source>
        <translation type="unfinished">2400</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Arquivo protegido por senha. Favor informá-la para acessá-lo.</translation>
    </message>
    <message>
        <location filename="../../src/security/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Informe a Senha</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation>Colar para múltiplas páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="45"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="71"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="91"/>
        <source>All pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="101"/>
        <source>Except current one</source>
        <translation>Exceto a atual</translation>
    </message>
</context>
<context>
    <name>PlaceInitialsDlg</name>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="14"/>
        <source>Place Initials</source>
        <translation>Especificação de Iniciais</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="26"/>
        <source>How would like to create your initials?</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Que tipo de iniciais deseja criar?</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="33"/>
        <source>Type my initials</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Digitando minhas iniciais</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="38"/>
        <source>Draw my initials</source>
        <translation>Desenhando minhas iniciais</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="43"/>
        <source>Select signature image</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Usando imagem como assinatura</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="90"/>
        <source>Enter your initials:</source>
        <translation>Digite suas iniciais:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="97"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="241"/>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>Style</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="128"/>
        <source>Font Family</source>
        <translation>Família de Fontes</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="167"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="197"/>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="353"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="234"/>
        <source>Change Initials Style</source>
        <translation>Alteração do Tipo de Iniciais</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="261"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="275"/>
        <source>Review Initials:</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Prévia das Iniciais:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="315"/>
        <source>Draw Initials:</source>
        <translation>Iniciais Desenhadas:</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="386"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="425"/>
        <source>Browse and select an image of your signature</source>
        <translation>Procurar uma imagem para sua assinatura</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.ui" line="445"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="77"/>
        <source>Clear</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="105"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Open Image</source>
        <translation>Abrir imagem</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="198"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Arquivos de imagem (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/initials/PlaceInitialsDlg.cpp" line="264"/>
        <source>of</source>
        <translation>de</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="vanished">Esta fonte não contém esses caracteres.
Tente escolher outra fonte.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation type="vanished">Visualizar Impressão</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="621"/>
        <source>Printer</source>
        <translation>Impressora</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="634"/>
        <source>Properties</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="vanished">Suavizar Bordas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="778"/>
        <location filename="../../src/printdialog/printdialog.ui" line="860"/>
        <source>Center</source>
        <translation>Centralizar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="577"/>
        <source>Print as Grayscale</source>
        <translation>Imprimir com escala de cinza</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation type="vanished">Proporção da Tela</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="707"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignorar Proporção da Tela</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="712"/>
        <source>Keep aspect ratio</source>
        <translation>Manter Proporção da Tela</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="717"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Manter a proporção expandindo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="342"/>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="307"/>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="312"/>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="437"/>
        <source>Number of copies</source>
        <translation>Número de cópias</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="464"/>
        <source>Collate</source>
        <translation>Agrupar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation type="vanished">Resolução</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="180"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="231"/>
        <source>of:</source>
        <translation>de:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1332"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1708"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="1719"/>
        <source>of </source>
        <translation>de </translation>
    </message>
    <message>
        <source>72</source>
        <translation type="vanished">72</translation>
    </message>
    <message>
        <source>150</source>
        <translation type="vanished">150</translation>
    </message>
    <message>
        <source>300</source>
        <translation type="vanished">300</translation>
    </message>
    <message>
        <source>600</source>
        <translation type="vanished">600</translation>
    </message>
    <message>
        <source>900</source>
        <translation type="vanished">900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation type="vanished">1200</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation type="vanished">DPI</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="725"/>
        <source>Actual Size</source>
        <translatorcomment>&quot;Actual&quot; here means &quot;Real&quot;, the page size originally meant by the document&apos;s author to be shown this way, and not &quot;atual&quot;, contextually speaking, of course.</translatorcomment>
        <translation>Tamanho Real</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">automático</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation type="vanished">Imprimir como imagem</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="361"/>
        <source>Duplex Printing</source>
        <translation>Imprimir com Duplex</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="46"/>
        <location filename="../../src/printdialog/printdialog.ui" line="369"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="379"/>
        <source>Long side</source>
        <translation>Lado amplo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="302"/>
        <location filename="../../src/printdialog/printdialog.ui" line="374"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Short side</source>
        <translation>Lado estreito</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="obsolete">Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Páginas ímpares</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Document</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="135"/>
        <source>Document and Annotations</source>
        <translation>Arquivo e anotações</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">Todas</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation type="vanished">Subconjunto</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation type="vanished">Todas as páginas no intervalo</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="161"/>
        <source>Print:</source>
        <translation>Imprimir:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="270"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="272"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="751"/>
        <location filename="../../src/printdialog/printdialog.ui" line="880"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="732"/>
        <location filename="../../src/printdialog/printdialog.ui" line="799"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="765"/>
        <source>Fit Page</source>
        <translation>Exibir o tamanho original</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="758"/>
        <source>Shrink to printable area</source>
        <translation>Ajustar à Área Passível de Impressão</translation>
    </message>
    <message>
        <source>Current view</source>
        <translation type="vanished">Exibição Atual</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="536"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="514"/>
        <source>Poster</source>
        <translation>Pôster</translation>
    </message>
    <message>
        <source>Booklet</source>
        <translation type="vanished">Livreto</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="20"/>
        <source>Saved Settings</source>
        <translation>Feito o salvamento das configurações</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="32"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="63"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save Settings</source>
        <translation>Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1573"/>
        <source>Save current settings as:</source>
        <translation>Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1583"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Já existe uma configuração salva com esse nome. Deseja substituí-la?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="1620"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="561"/>
        <source>Multiple</source>
        <translation>Multiplicar</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="792"/>
        <source>Overlay</source>
        <translation>Sobrecamada</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="901"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1106"/>
        <source>Points</source>
        <translation>Pontos</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="906"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1111"/>
        <source>Inches</source>
        <translation>Polegadas</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="911"/>
        <location filename="../../src/printdialog/printdialog.ui" line="1116"/>
        <source>Millimeters</source>
        <translation>Milímetros</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="867"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="977"/>
        <source>Pages per sheet:</source>
        <translation>Páginas por folha:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="970"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1011"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1016"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1021"/>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1026"/>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1031"/>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1036"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1053"/>
        <source>Page order:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1061"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1066"/>
        <source>Horizontal Reversed</source>
        <translation>Horizontal Invertida</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1071"/>
        <source>Vertical</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1076"/>
        <source>Vertical Reversed</source>
        <translation>Vertical Invertida</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1091"/>
        <source>Additional spacing:</source>
        <translation>Espaçamento adicional:</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1098"/>
        <source>pt</source>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="1084"/>
        <source>Center pages in cells</source>
        <translation>Centralizar páginas nas células</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="323"/>
        <source>Page Setup</source>
        <translation>Configurar Página</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="327"/>
        <source>System Properties</source>
        <translation>Propriedades do Sistema</translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="581"/>
        <source>Printer cannot be selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintingMode</name>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="240"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="266"/>
        <source>There was an error printing the document</source>
        <translation>Erro na tentativa de imprimir o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/printmodes/printingmode.cpp" line="242"/>
        <location filename="../../src/printmodes/printingmode.cpp" line="268"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="60"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source>File </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="504"/>
        <source> is already attached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="505"/>
        <source>Replace the file or give it a unique name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="506"/>
        <source>Replace</source>
        <translation type="unfinished">Substituir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="507"/>
        <source>Rename</source>
        <translation type="unfinished">Renomear</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="508"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="779"/>
        <source>You don&apos;t have the permission to save attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="823"/>
        <source>You don&apos;t have the permission to open attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="938"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="939"/>
        <source>The removed Attachment cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Salvar como...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="57"/>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="44"/>
        <source>Location</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="vanished">Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="179"/>
        <source>Attachment Tab</source>
        <translation>Aba Anexos</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="vanished">Abrir</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="24"/>
        <source>Attachment</source>
        <translation>Anexos</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="vanished">Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="175"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="874"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="29"/>
        <source>Add Bookmark</source>
        <translation>Adicionar marcador</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation type="vanished">Apagar Marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="31"/>
        <source>Bookmark Properties</source>
        <translation>Propriedades do Marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="32"/>
        <source>Set Destination</source>
        <translatorcomment>Don&apos;t change. </translatorcomment>
        <translation>Usar esta página como destino do marcador</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="274"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="275"/>
        <source>The removed bookmark(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="30"/>
        <source>Delete Bookmark(s)</source>
        <translation>Apagar marcador(es)</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="227"/>
        <location filename="../../src/document/qdoctab.cpp" line="348"/>
        <source>untitled</source>
        <translation>sem nome</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="vanished">A Área de Transferência não contém nenhum dado</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="82"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="86"/>
        <source>Close All</source>
        <translation>Fechar Tudo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="vanished">Salvar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="vanished">Salvar como...</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="106"/>
        <source>Move to New Window</source>
        <translation>Mover para uma nova janela</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="90"/>
        <source>Close All Other Tabs</source>
        <translation>Fechar Todas as Outras Guias</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="74"/>
        <source>Duplicate tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="78"/>
        <source>Rename tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="94"/>
        <source>Close All Tabs to the Right</source>
        <translation>Fechar Todas as Outras Guias à Direitra</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="1895"/>
        <location filename="../../src/document/qdoctab.cpp" line="1920"/>
        <source>The clipboard doesn&apos;t contain any data</source>
        <translation>A Área de Transferência não contém dados.</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2214"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2272"/>
        <source>You don&apos;t have permission to modify the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2278"/>
        <source>Save failed</source>
        <translation type="unfinished">Falha na tentativa de salvar</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="2279"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>Allow opening same document in multiple tabs</source>
        <translation type="unfinished">Permitir a abertura do mesmo arquivo em várias guias</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3227"/>
        <source>option needs to be enabled to allow duplicating tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Rename</source>
        <translation type="unfinished">Renomear</translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>Renaming file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3692"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Overwrite file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3710"/>
        <source>Would you like to overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="3757"/>
        <source>Failed to rename file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation>Entrega de E-Mail</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation>Para</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="17"/>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Arquivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Refazer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Colar</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Refazer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Colar</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="vanished">Conexão HTTPS requisitada, mas o suporte a SSL não compilado em</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Erro desconhecido</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="vanished">Requisição abortada</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="vanished">Nenhum servidor configurado para se conectar a</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="vanished">Tamanho do conteúdo inválido</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="vanished">Inesperado encerramento da conexão pelo servidor</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="vanished">Conexão recusada (tempo de espera esgotado)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="vanished">Não achei o servidor %1</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="vanished">Requisição HTTP falhou</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="vanished">Cabeçalho de resposta HTTP inválido</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="vanished">Método de autenticação desconhecido</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="vanished">Autenticação de proxy necessária</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="vanished">Autenticação necessária</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="vanished">HTTP com partes do corpo inválidas</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="vanished">Erro na tentativa de enviar resposta ao dispositivo</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="vanished">Ampliar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="vanished">Reduzir</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="113"/>
        <source>Zoom to Selection</source>
        <translation>Aplicar zoom conforme a seleção</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajustar à Página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="121"/>
        <source>Clear Selections</source>
        <translation>Apagar seleção</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="16"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation>Você não pode usar esta função na versão gratuita</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="20"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>A versão sem licença insere uma marca d&apos;água</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>Build</source>
        <translation>Build</translation>
    </message>
    <message>
        <source>Based on</source>
        <translation type="vanished">Baseada em</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="36"/>
        <location filename="../../src/app_config.cpp" line="52"/>
        <source>32 bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="40"/>
        <location filename="../../src/app_config.cpp" line="44"/>
        <location filename="../../src/app_config.cpp" line="48"/>
        <location filename="../../src/app_config.cpp" line="56"/>
        <source>64 bit</source>
        <translation>64 bit</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Mouse Enter</source>
        <translation>Entrada do Ponteiro</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Mouse Exit</source>
        <translation>Saída do Ponteiro</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Mouse Down</source>
        <translation>Botão do Mouse Premido</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Mouse Up</source>
        <translation>Botão do Mouse Solto</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>On Receive Focus</source>
        <translatorcomment>Please, don&apos;t change to &quot;Ao ganhar/receber foco&quot;.</translatorcomment>
        <translation>Ao ser selecionado</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>On Lose Focus</source>
        <translatorcomment>Please, don&apos;t change to &quot;Ao perder foco/o foco&quot;.</translatorcomment>
        <translation>Ao ser desselecionado</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>Page Open</source>
        <translation>Ao se abrir página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Page Close</source>
        <translation>Ao se fechar página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Page Visible</source>
        <translation>Página visível</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Page Invisible</source>
        <translation>Página invisível</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Open Page</source>
        <translation>Abrir página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Close Page</source>
        <translation>Fechar página</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>KeyStroke</source>
        <translation>Ao teclar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="997"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Validate</source>
        <translation>Validar</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="55"/>
        <source>Calculate</source>
        <translation>Cálculo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="57"/>
        <source>Close Document</source>
        <translation>Fechar documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="59"/>
        <source>Save Document</source>
        <translation>Salvar documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="61"/>
        <source>Document Saved</source>
        <translation>Feito o salvamento do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="63"/>
        <source>Print Document</source>
        <translation>Imprimir o documento</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="65"/>
        <source>Document Printed</source>
        <translation>Documento impresso</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Unknown</source>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Goto a Page View</source>
        <translatorcomment>Please, don&apos;t change to &quot;Ir para uma Visualização/Exibição de Página&quot;.</translatorcomment>
        <translation>Exibir página conforme especificado no comando</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="88"/>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Thread</source>
        <translatorcomment>Doesn&apos;t make sense OUT OF context. It&apos;s better to verify this one.</translatorcomment>
        <translation>Seção</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Open a web link</source>
        <translation>Abrir um endereço da Internet</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Sound</source>
        <translation>Som</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Movie</source>
        <translation>Filme</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="98"/>
        <source>Show/Hide fields</source>
        <translation>Exibir/ocultar campos</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="102"/>
        <source>Submit Form</source>
        <translatorcomment>Don&apos;t change to &quot;Enviar formulário&quot; or &quot;Enviar dados DE formulário&quot;. </translatorcomment>
        <translation>Enviar dados pelo formulário</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Reset Form</source>
        <translation>Limpar o Formulário</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="106"/>
        <source>Import Data</source>
        <translation>Importar dados</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="108"/>
        <source>Run a JavaScript</source>
        <translation>Executar código de JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="112"/>
        <source>Rendition</source>
        <translatorcomment>Doesn&apos;t make sense without context. Verify this one.</translatorcomment>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="116"/>
        <source>Goto 3D View</source>
        <translation>Ir para Exibição em 3D</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="25"/>
        <source>Open with</source>
        <translation>Abrir com</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Reset</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Set</source>
        <translation>Definir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Brightness</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Approved</source>
        <translation>Aprovado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Confidential</source>
        <translation>Confidencial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Received</source>
        <translation>Recebido</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Reviewed</source>
        <translation>Revista</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Revised</source>
        <translation>Revisado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Completed</source>
        <translatorcomment>Please, don&apos;t change to &quot;ConcluídO, Completo/a, Completado/a, Terminado/a&quot;.</translatorcomment>
        <translation>Concluída</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Draft</source>
        <translation>Rascunho</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Emergency</source>
        <translation>Emergência</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>Expired</source>
        <translation>Expirada</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Final</source>
        <translation>Final</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Verified</source>
        <translatorcomment>Don&apos;t change. It refers to &quot;redação, revisão&quot; etc. So it&apos;s a feminine noun.</translatorcomment>
        <translation>Verificada</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Void</source>
        <translatorcomment>Contextually, it seems better thant &quot;Nulo, Invalidado, Inválido&quot;. Don&apos;t change to &quot;Vazio&quot;, &quot;Em branco&quot;.</translatorcomment>
        <translation>Sem efeito</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>Accepted</source>
        <translatorcomment>Don&apos;t change. It refers to &quot;redação, revisão&quot; etc. So it&apos;s a feminine noun.</translatorcomment>
        <translation>Aceita</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="173"/>
        <source>Initial</source>
        <translation>Inicial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="178"/>
        <source>Rejected</source>
        <translatorcomment>Don&apos;t change. It refers to &quot;redação, revisão&quot; etc. So it&apos;s a feminine noun.</translatorcomment>
        <translation>Rejeitada</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>SignHere</source>
        <translation>Assine aqui</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Witness</source>
        <translation>Testemunha</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Dynamic</source>
        <translation>Dinâmico</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Standard</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation>h:MM tt mmmm dd.yyyy</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="216"/>
        <source>Icon</source>
        <translation>Ícone</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="221"/>
        <source>Info</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="226"/>
        <source>Press Help button to get more info.</source>
        <translation>Clique em Ajuda para obter mais informação.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="231"/>
        <source>Error.</source>
        <translation>Erro.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="236"/>
        <source>Object</source>
        <translation>Componente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="246"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="251"/>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="256"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="261"/>
        <source>Shading</source>
        <translation>Sombreamento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="241"/>
        <location filename="../../src/app_config.cpp" line="747"/>
        <source>Objects</source>
        <translation>Componentes</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="266"/>
        <source>All Objects</source>
        <translation>Todos os componentes</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="271"/>
        <source>Forms</source>
        <translation>Formulários</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="276"/>
        <source>Comments</source>
        <translation>Comentários</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="281"/>
        <source>Container</source>
        <translation>Container</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="286"/>
        <source>Sticky Note</source>
        <translation>Nota Flutuante</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="291"/>
        <source>Highlight</source>
        <translation>Destaque</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="296"/>
        <source>Underline</source>
        <translation>Sublinhado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="301"/>
        <source>StrikeOut</source>
        <translation>Riscado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="306"/>
        <source>Reply</source>
        <translation>Resposta</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="61"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="64"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Arquivos FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="426"/>
        <source>Typewriter</source>
        <translation>Máquina de Escrever Virtual</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="311"/>
        <source>Text Box</source>
        <translation>Caixa de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="316"/>
        <source>Formatted Text</source>
        <translation>Texto formatado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="321"/>
        <source>Issued by:</source>
        <translation>Emitido por:</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="326"/>
        <source>Expires</source>
        <translation>Expira em</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="331"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="336"/>
        <source>Cancelled</source>
        <translation>Cancelada</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="341"/>
        <source>Confirmed</source>
        <translation>Confirmado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="346"/>
        <source>Not Confirmed</source>
        <translation>Não confirmado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="351"/>
        <source>Open Object Inspector</source>
        <translatorcomment>That&apos;s the short form for &quot;Painel de Propriedades do Componente&quot;, that is, &quot;the selected page object&quot;.</translatorcomment>
        <translation>Abrir o Painel de Propriedades</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="356"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="361"/>
        <source>Review History</source>
        <translation>Rever o Histórico</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="366"/>
        <source>Make Current Properties Default</source>
        <translation>Tornar padrão as configurações atuais</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="371"/>
        <source>Error Loading Image!</source>
        <translation>Erro na tentativa de carregar a imagem!</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="376"/>
        <source>Incorrect date/time format. Please, insert date/time to match format: </source>
        <translation>Data ou formato de hora incorretos. Favor informar a data/hora de forma correta: </translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="381"/>
        <source>You have exceeded the number of available activations.</source>
        <translation>Você excedeu o número de ativações possíveis.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="386"/>
        <source>Please, deactivate your license on another PC.</source>
        <translation>Favor desativar sua licença no outro PC.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="396"/>
        <source>Your license is expired. Please, renew your license.</source>
        <translation>Sua lincença expirou. Favor renovar.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="401"/>
        <source>Impossible to verify your license! Check your internet connection and press Verify Now</source>
        <translation>Não foi possível confirmar sua licença! Verifique sua conexão com a internet e clique Verificar Agora</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="391"/>
        <source>Your license doesn&apos;t allow to use this version. Please, renew your license.</source>
        <translation>Sua licença não permite usar esta versão. Favor renovar a licença.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="406"/>
        <source>Print using Windows API</source>
        <translation>Imprimir usando a API do Windows</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="411"/>
        <source>Do not show this message again</source>
        <translation>Não exibir esta mensagem de novo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="416"/>
        <source>If OpenSSL is not installed, encryption and signature functionality will be unavailable.</source>
        <translation>Se a OpenSSL não estiver instalada, proteção cifrada e assinatura de arquivos não poderão ser usadas.</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="431"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="436"/>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="441"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="446"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="451"/>
        <source>Save As...</source>
        <translation>Salvar como...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="461"/>
        <source>Toolbars</source>
        <translation>Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="466"/>
        <source>Email delivery</source>
        <translation>Entrega de E-Mail</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="476"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="481"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="486"/>
        <source>Cut</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="491"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="496"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="501"/>
        <source>Delete Object(s)</source>
        <translatorcomment>Não alterar para o famigerado &quot;objeto(s)&quot;.</translatorcomment>
        <translation>Apagar componente(s)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="506"/>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="511"/>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="516"/>
        <source>Align Left</source>
        <translation>À esquerda</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="521"/>
        <source>Align Right</source>
        <translation>À direita</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="526"/>
        <source>Align Top</source>
        <translation>Em cima</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="531"/>
        <source>Align Bottom</source>
        <translation>Embaixo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="536"/>
        <source>Align Center Horizontal</source>
        <translation>Horizontalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="541"/>
        <source>Align Center Vertical</source>
        <translation>Verticalmente, no centro</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="551"/>
        <source>Send To Back</source>
        <translation>Enviar para o fundo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="556"/>
        <source>Send Backward</source>
        <translation>Enviar para trás</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="561"/>
        <source>Bring Forward</source>
        <translation>Trazer para frente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="566"/>
        <source>Bring To Front</source>
        <translation>Pôr na frente de tudo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="577"/>
        <source>Grid</source>
        <translation>Grade</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="582"/>
        <source>Snap To Grid</source>
        <translation>Alinhar pela Grande</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="587"/>
        <source>View</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="592"/>
        <source>Previous View</source>
        <translation>Visualização Anterior</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="597"/>
        <source>Next View</source>
        <translation>Visualização Seguinte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="602"/>
        <source>Previous Page</source>
        <translation>Página Anterior</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="607"/>
        <source>Next Page</source>
        <translation>Página Seguinte</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="612"/>
        <source>Zoom Out</source>
        <translation>Reduzir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="617"/>
        <source>Actual Size</source>
        <translation>Tamanho Real</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="622"/>
        <source>Zoom In</source>
        <translation>Ampliar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="627"/>
        <location filename="../../src/mainwindow.cpp" line="4147"/>
        <source>Fit Page</source>
        <translation>Ajudar à Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="632"/>
        <location filename="../../src/mainwindow.cpp" line="4151"/>
        <source>Fit Width</source>
        <translation>Ajustar à Largura</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="637"/>
        <source>Facing Pages</source>
        <translation>Páginas Lado a Lado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="642"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Girar 90 graus em Sentido Antihorário</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="647"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="652"/>
        <source>Rotate 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="657"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="662"/>
        <source>Edit Document</source>
        <translation>Edição do Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="667"/>
        <source>Edit Text</source>
        <translation>Edição de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="672"/>
        <source>Edit Images</source>
        <translation>Edição de Imagens</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="677"/>
        <source>Edit Vector Images</source>
        <translation>Edição de Imagens Vetoriais</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="682"/>
        <source>Edit Forms</source>
        <translation>Editar Formulários</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="692"/>
        <source>Hand Tool</source>
        <translation>Selecionador de Componente</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="697"/>
        <source>Select Text</source>
        <translation>Selecionador de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="702"/>
        <source>Take Snapshot</source>
        <translation>Tirar instantâneo da Atual</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="707"/>
        <source>Insert Link</source>
        <translation>Inserir Ligação</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="712"/>
        <source>Button</source>
        <translation>Botão</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="717"/>
        <source>Check Box</source>
        <translation>Quadrículo de seleção</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="722"/>
        <source>Combo Box</source>
        <translation>Lista de Opções com Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="727"/>
        <source>Text Field</source>
        <translation>Campo de Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="732"/>
        <source>List Box</source>
        <translation>Lista de Opções</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="737"/>
        <source>Radio Button</source>
        <translation>Botão Radial</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="742"/>
        <source>Signature</source>
        <translation>Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="752"/>
        <source>Insert Formatted Text</source>
        <translation>Inserir Texto Formatado</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="757"/>
        <source>Insert Text</source>
        <translation>Inserir Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="762"/>
        <source>Insert Image</source>
        <translation>Inserir Imagem</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="767"/>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="772"/>
        <source>Rectangle</source>
        <translation>Retângulo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="777"/>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="782"/>
        <source>Pencil</source>
        <translation>Lápis</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="787"/>
        <source>Attach a File as a Comment</source>
        <translation>Adicionar arquivo como comentário</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="792"/>
        <source>Redaction</source>
        <translation>Revisão</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="797"/>
        <source>Mark for Redaction</source>
        <translation>Marcar para revisão</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="802"/>
        <source>Search And Redact</source>
        <translation>Localizar e Revisar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="807"/>
        <source>Apply Redaction</source>
        <translation>Efetivar Revisão</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="812"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="817"/>
        <source>Insert Blank Pages</source>
        <translation>Inserir Páginas em Branco</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="822"/>
        <source>Delete Pages</source>
        <translation>Apagar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="827"/>
        <source>Crop Pages</source>
        <translation>Fazer Recorte de Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="832"/>
        <source>Page layout</source>
        <translation>Formato de Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="837"/>
        <source>Page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="842"/>
        <source>Rotate Pages</source>
        <translation>Girar Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="847"/>
        <source>Extract Pages...</source>
        <translation>Extrair Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="852"/>
        <source>Insert Pages...</source>
        <translation>Inserir Páginas...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="857"/>
        <source>Cut Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="862"/>
        <source>Copy Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="867"/>
        <source>Paste Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="872"/>
        <source>Document Actions</source>
        <translation>Comandos do Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="877"/>
        <source>Document JavaScript</source>
        <translation>JavaScript do Documento</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="882"/>
        <source>Page Properties</source>
        <translation>Propriedades da Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="887"/>
        <source>OCR</source>
        <translation>Reconhec. de Texto (OCR)</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="892"/>
        <source>Header and Footer</source>
        <translation>Cabeçalhos e Rodapé</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="897"/>
        <source>Bates Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="902"/>
        <source>Watermark</source>
        <translation>Marca D&apos;Água</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="907"/>
        <source>Background</source>
        <translation>Plano de Fundo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="912"/>
        <location filename="../../src/app_config.cpp" line="932"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="917"/>
        <source>Page Counter</source>
        <translation>Contador de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="922"/>
        <source>New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="927"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="937"/>
        <source>Find</source>
        <translation>Localizar</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="992"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1002"/>
        <source>Initials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1007"/>
        <source>Show Crop Page Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1012"/>
        <source>Prompt to Scan More Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1017"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1022"/>
        <source>Autosave on. Document will be saved automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1027"/>
        <source>Images</source>
        <translation type="unfinished">Imagens</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1032"/>
        <source>Vector Images</source>
        <translation type="unfinished">Imagens Vetoriais</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1037"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="1042"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Comentário</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="962"/>
        <source>Stamp</source>
        <translation>Carimbo</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="967"/>
        <source>Comment View</source>
        <translation>Exibir o Painel de Comentários</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="972"/>
        <source>Place Initials</source>
        <translation>Incluir Iniciais Autorais</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="947"/>
        <source>Highlight Text</source>
        <translation>Destacar Texto</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="952"/>
        <source>Draw Comment Tools</source>
        <translation>Ferramentas de Comentários Gráficos</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="957"/>
        <source>Measurement Tools</source>
        <translation>Ferramentas de Medição</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="687"/>
        <source>Edit Tools</source>
        <translation>Ferramentas de Edição</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="977"/>
        <source>Continuous Page</source>
        <translation>Páginas Contínuas</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="982"/>
        <source>Single Page</source>
        <translation>Uma Página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="546"/>
        <source>Align Objects</source>
        <translation type="unfinished">Alinhar componentes de página</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="571"/>
        <source>Move Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="421"/>
        <source>If NSS is not installed, encryption and signature functionality will be unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="987"/>
        <source>No pages selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="471"/>
        <source>System Print...</source>
        <translation type="unfinished">Painel de Impressão do SO...</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="942"/>
        <source>Label</source>
        <translation type="unfinished">Título</translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Combine files in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="456"/>
        <source>Save As Image</source>
        <translation type="unfinished">Salvar como Imagem</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="39"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="40"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="41"/>
        <source>Arabic</source>
        <translation type="unfinished">Árabe</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="42"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="43"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="44"/>
        <source>Azerbaijani (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="45"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="46"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="47"/>
        <source>Tibetan Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="49"/>
        <source>Bulgarian</source>
        <translation type="unfinished">Búlgaro</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="50"/>
        <source>Catalan</source>
        <translation type="unfinished">Catalão</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="51"/>
        <source>Cebuano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="52"/>
        <source>Czech</source>
        <translation type="unfinished">Tcheco</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="53"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="54"/>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="55"/>
        <source>Cherokee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="56"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="57"/>
        <source>Danish</source>
        <translation type="unfinished">Dinamarquês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="58"/>
        <source>German</source>
        <translation type="unfinished">Alemão</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="59"/>
        <source>German (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="61"/>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="76"/>
        <source>Greek</source>
        <translation type="unfinished">Grego</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="62"/>
        <source>English</source>
        <translation type="unfinished">Inglês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="63"/>
        <source>English (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="64"/>
        <source>Middle English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="65"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="66"/>
        <source>Estonian</source>
        <translation type="unfinished">Estoniano</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="67"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="68"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="69"/>
        <source>Finnish</source>
        <translation type="unfinished">Finlandês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="70"/>
        <source>French</source>
        <translation type="unfinished">Francês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="71"/>
        <source>Frankish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="72"/>
        <source>Middle French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="73"/>
        <source>Irish</source>
        <translation type="unfinished">Irlandês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="74"/>
        <source>Irish (Uncial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="75"/>
        <source>Galician</source>
        <translation type="unfinished">Galego</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="77"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="78"/>
        <source>Hatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished">Hebraico</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="81"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="82"/>
        <source>Hungarian</source>
        <translation type="unfinished">Húngaro</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="83"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="84"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="85"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="86"/>
        <source>Italian</source>
        <translation type="unfinished">Italiano</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="87"/>
        <source>Old Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="88"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="89"/>
        <source>Japanese</source>
        <translation type="unfinished">Japonês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="90"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="91"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="92"/>
        <source>Old Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="93"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="94"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="95"/>
        <source>Kyrgyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="96"/>
        <source>Korean</source>
        <translation type="unfinished">Coreano</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="97"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="98"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="99"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="100"/>
        <source>Latvian</source>
        <translation type="unfinished">Letão</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="101"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Lituano</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="102"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="103"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="104"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="105"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="106"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="107"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="108"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="109"/>
        <source>Dutch</source>
        <translation type="unfinished">Holandês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="110"/>
        <source>Norwegian</source>
        <translation type="unfinished">Norueguês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="111"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="112"/>
        <source>script and orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="113"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="114"/>
        <source>Polish</source>
        <translation type="unfinished">Polonês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="115"/>
        <source>Portuguese</source>
        <translation type="unfinished">Português</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="116"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="117"/>
        <source>Romanain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="118"/>
        <source>Russian</source>
        <translation type="unfinished">Russo</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="119"/>
        <source>Russian (Fast)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="120"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="121"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="122"/>
        <source>Slovak</source>
        <translation type="unfinished">Eslovaco</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="123"/>
        <source>Slovak Fractur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="124"/>
        <source>Slovenian</source>
        <translation type="unfinished">Esloveno</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="125"/>
        <source>Spanish</source>
        <translation type="unfinished">Espanhol</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="126"/>
        <source>Old Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="127"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="128"/>
        <source>Serbian</source>
        <translation type="unfinished">Sérvio</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="129"/>
        <source>Serbian (Latin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="130"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="131"/>
        <source>Swedish</source>
        <translation type="unfinished">Sueco</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="132"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="133"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="134"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="135"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="136"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="137"/>
        <source>Thai</source>
        <translation type="unfinished">Tailandês</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="138"/>
        <source>Turkish</source>
        <translation type="unfinished">Turco</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="139"/>
        <source>Uyghur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="140"/>
        <source>Urgu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="141"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="142"/>
        <source>Uzbek (Cyrillic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="143"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamita</translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="144"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qsanelib.cpp" line="389"/>
        <source>Document feeder is out of sheets!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="789"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="984"/>
        <source>Error! Check if the file is valid and exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/qutils.cpp" line="988"/>
        <source>Error!</source>
        <translation type="unfinished">Erro!</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="111"/>
        <source> pt</source>
        <translation type="unfinished"> pt</translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="133"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/PageSizeConversions.cpp" line="142"/>
        <source> mm</source>
        <translation type="unfinished"> mm</translation>
    </message>
    <message>
        <location filename="../../src/utils/AppSession.cpp" line="64"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="3554"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="3682"/>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4325"/>
        <source>There was a problem with your form submission.</source>
        <translation>Houve um problema com o envio do formulário.</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4329"/>
        <source>Your form was successfully submitted!</source>
        <translation>Feito o envio de seu formulário!</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>of</source>
        <translation type="vanished">de</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="vanished">Página</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="40"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="4231"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4235"/>
        <source> in</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4240"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="4285"/>
        <source>PDF document action attempts to submit form data to another location. Proceed?</source>
        <translation>O documento de PDF está tentando enviar dados de formulário para outro local? Devo permitir?</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="51"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="593"/>
        <source>Open Document</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="61"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="594"/>
        <source>Blank PDF</source>
        <translation>PDF em branco</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="71"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="595"/>
        <source>From Files</source>
        <translation>Usando arquivos</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="81"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="597"/>
        <source>From Scanner</source>
        <translation>Do Scanner</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="93"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="598"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="99"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="599"/>
        <source>User Guide</source>
        <translation>Manual do usuário</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="109"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="602"/>
        <source>Register...</source>
        <translation>Licenciar...</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="115"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="603"/>
        <source>Buy Online</source>
        <translation>Comprar Online</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="417"/>
        <source>Create New Document</source>
        <translation>Criar um novo arquivo</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="439"/>
        <source>Recent Files</source>
        <translation>Arquivos Recentes</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="87"/>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="596"/>
        <source>Empty recent files list</source>
        <translation>Apagar a lista de arquivos recentes</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="421"/>
        <source>Pinned Files</source>
        <translation>Arquivos Fixados na Lista</translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="957"/>
        <source>You have reached the limit of 10 pinned files.</source>
        <translation>Você alcançou o limite de 10 arquivos fixados.</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="193"/>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation type="vanished">Ampliar as Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation type="vanished">Reduzir as Miniaturas de Páginas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="219"/>
        <source>Bookmarks</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="231"/>
        <source>Attachment</source>
        <translation>Anexos</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="242"/>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="277"/>
        <source>Object Inspector</source>
        <translation>Painel de Propriedades de Componente</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="744"/>
        <source>This document contains interactive form fields</source>
        <translation>Este documento contém campos de formulário interativos</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="745"/>
        <source>Highlight Fields</source>
        <translation>Realçar Campos</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="vanished">Este é um arquivo protegido contra modificações. Você não tem permissão para editá-lo</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="753"/>
        <source>Change</source>
        <translation>Alterar</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation type="vanished">Erro na tentativa de imprimir o arquivo</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Inserir páginas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4254"/>
        <source>Do you want to open?</source>
        <translation>Quer mesmo abrir?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="4261"/>
        <source>Don&apos;t show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5068"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Quer mesmo usar o local atual como o destino do marcador selecionado?</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5161"/>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation type="vanished">Apagar Páginas</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation type="vanished">Inserir Páginas em Branco</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="vanished">Propriedades da página</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Girar 90 graus sentido anti-horário</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="vanished">Erro!</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1707"/>
        <source>Error loading font: </source>
        <translation>ERRO ao Carregar: </translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="246"/>
        <source>Object TreeView</source>
        <translation>Árvore de componentes</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="600"/>
        <source>Layers</source>
        <translation>Camadas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="752"/>
        <source>This document is protectedYou do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="805"/>
        <source>Registration</source>
        <translation>Registro</translation>
    </message>
    <message>
        <source>Current zoom will also be accounted for.</source>
        <translation type="vanished">Zoom atual será levado em consideração.</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="263"/>
        <source>Signatures</source>
        <translation>Assinaturas</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3622"/>
        <source>Document must contain at least one page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3629"/>
        <source>Loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3015"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="5071"/>
        <source>Set current zoom</source>
        <translation>Usar o zoom atual</translation>
    </message>
</context>
<context>
    <name>QThumbnailsList</name>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="81"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="84"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/qthumbnailslist.cpp" line="132"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="16"/>
        <source>Millimeters (mm)</source>
        <translation>Milímetros (mm)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="17"/>
        <source>Inches (in)</source>
        <translation>Polegadas (in)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="18"/>
        <source>Points (pt)</source>
        <translation>Pontos (pt)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="19"/>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="20"/>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="21"/>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="59"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="63"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="302"/>
        <location filename="../../src/utils/AppSession.cpp" line="241"/>
        <source>MPE Session file (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="144"/>
        <source>More...</source>
        <translation>Mais...</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="vanished">Usar cor %1</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>User Color 99</source>
        <translation>Usar Cor 99</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Black</source>
        <translation>Preto</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="354"/>
        <source>White</source>
        <translation>Branco</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="355"/>
        <source>Red</source>
        <translation>Vermelho</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="356"/>
        <source>Dark red</source>
        <translation>Vermelho escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="357"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="358"/>
        <source>Dark green</source>
        <translation>Verde escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="359"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="360"/>
        <source>Dark blue</source>
        <translation>Azul escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="361"/>
        <source>Cyan</source>
        <translation>Ciano</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="362"/>
        <source>Dark cyan</source>
        <translation>Ciano escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="363"/>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="364"/>
        <source>Dark magenta</source>
        <translation>Magenta escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="365"/>
        <source>Yellow</source>
        <translation>Amarelo</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="366"/>
        <source>Dark yellow</source>
        <translation>Amarelo escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="367"/>
        <source>Gray</source>
        <translation>Cinza</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="368"/>
        <source>Dark gray</source>
        <translation>Cinza escuro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="369"/>
        <source>Light gray</source>
        <translation>Cinza claro</translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="371"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
</context>
<context>
    <name>RedactionCodesDlg</name>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="14"/>
        <source>Redaction Code Editor</source>
        <translatorcomment>Reading isolated doen&apos;t seem to make sence. Would like to understand better the context.</translatorcomment>
        <translation>Editor para revisão de código</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="30"/>
        <source>Code Sets</source>
        <translation>Grupos de código</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="49"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="150"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="56"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="157"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="76"/>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="180"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="101"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="108"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionCodesDlg.ui" line="134"/>
        <source>Code Entries</source>
        <translation>Entradas de código</translation>
    </message>
</context>
<context>
    <name>RedactionDlg</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulário</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="41"/>
        <source>Redacted Area Fill Color</source>
        <translation>Cor da área revisada</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="48"/>
        <source>Use Overlay Text</source>
        <translation>Usar camada de texto sobreposta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="76"/>
        <source>Code Sets</source>
        <translation>Codificações de Caracteres</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="83"/>
        <source>Code Entries:</source>
        <translation>Entradas de código:</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="116"/>
        <source>Edit Codes</source>
        <translation>Editar Códigos</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="67"/>
        <source>Redaction Code</source>
        <translation>Código de revisão</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="133"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="152"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="201"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="60"/>
        <source>Repeat Overlay Text</source>
        <translatorcomment>Don&apos;t change.</translatorcomment>
        <translation>Replicar camada de texto sobreposta</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="140"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="172"/>
        <source>auto</source>
        <translation>automático</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/RedactionDlg.ui" line="126"/>
        <source>Auto-size text</source>
        <translation>Redimensionar texto automaticamente</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Dados do Licenciamento</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Assim que seu pedido for concluído,
você automaticamente
receberá o sua Licença por e-mail.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation>Comprar Online</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="386"/>
        <source>Registration Code</source>
        <translation>Código da Licença</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="373"/>
        <source>Activate</source>
        <translation>Ativar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation>Ativação Offline</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="227"/>
        <source>Registered version</source>
        <translation>Versão licenciada</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Favor enviar a Chave de Identificação e a Licença a: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: activations@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;activations@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Depois que você receber seu código, digite-o no campo  &amp;quot;Código de Ativação&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="vanished">Se quiser usar esta licença em outro PC, 
clique no botão &quot;Desativar&quot;. 

Em seguida, licencie o programa onde você precisar fazê-lo.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="214"/>
        <source>Deactivate</source>
        <translation>Desativar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="319"/>
        <source>Registration Code:</source>
        <translation>Código da Licença:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="366"/>
        <source>Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="422"/>
        <source>Activation Code</source>
        <translation>Código de Ativação</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Por favor, envie a Chave de Identificação e Licença a: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Depois que tiver recebido a licença, digite-a no campo  &amp;quot;Código de Ativação&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="349"/>
        <source>ID</source>
        <translation>Chave de Identificação</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Fechar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="34"/>
        <source>Thanks for registration.</source>
        <translation>Obrigado por licenciar.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="35"/>
        <source>License is deactivated.</source>
        <translation>Sua licença está desativada.</translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation type="vanished">Você excedeu o número de ativações possíveis.</translation>
    </message>
    <message>
        <source>Many activations!</source>
        <translation type="vanished">Muitas ativações!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="37"/>
        <source>Too many activations!</source>
        <translation>Ativações em demasia!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Favor enviar a Chave de Identificação e a Licença a: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Depois que você receber seu código, digite-o no campo  &amp;quot;Código de Ativação&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="278"/>
        <source>Purchased On:</source>
        <translation>Licença comprada em:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="292"/>
        <source>Maintenance Plan Expires:</source>
        <translation>Sua assinatura de licenciado expira em:</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="40"/>
        <source>License is expired!</source>
        <translation>Licença expirada!</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="58"/>
        <source>Please, renew your license</source>
        <translation>Favor renovar a licença</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="470"/>
        <source>Renew</source>
        <translation>Renovar</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="499"/>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact activations@code-industry.net</source>
        <translation>Falha na tentativa de desativação!
Verifique sua conexão de Internet.
Caso o erro persista, contate-nos pelo email activations@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="202"/>
        <source>If you want to register that license on another PC click the &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Se quiser usar esta licença em outro PC, clique no botão &quot;Desativar&quot;. 

Em seguida, licencie o programa onde precisar fazê-lo.</translation>
    </message>
    <message>
        <source>Deactivation failed!
Check internet connection.
If error is repeated, contact support@code-industry.net</source>
        <translation type="vanished">Falha na tentativa de desativação!
Verifique sua conexão de Internet.
Caso o erro persista, contate-nos pelo email support@code-industry.net</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="320"/>
        <location filename="../../src/regdialog.cpp" line="527"/>
        <source>Activation failed! Check internet connection.</source>
        <translation>Falha na tentativa de ativação! Verifique sua conexão de Internet.</translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="291"/>
        <location filename="../../src/regdialog.cpp" line="425"/>
        <source>Incorrect registration code.</source>
        <translation>Licença inválida.</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="vanished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="vanished">Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Da página</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até a:</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="28"/>
        <source>Direction</source>
        <translation>Direção</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="35"/>
        <source>Clockwise 90 degrees</source>
        <translation>90 graus no sentido horário</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="40"/>
        <source>180 degrees</source>
        <translation>180 graus</translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="45"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>90 graus no sentido anti-horário</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="vanished">Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="vanished">Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="vanished">Páginas ímpares</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="25"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Exportar como Imagem</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="259"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="vanished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="vanished">Todas as Páginas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation>Qualidade do JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation>Compressão TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Salvar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Não é possível salvar o arquivo:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="91"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente-leitura ou estar em uso por outro programa.</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation type="vanished">Salvar como Imagem</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="445"/>
        <source>All Files (*)</source>
        <translation>Todos os arquivos (*)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation>Várias Páginas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>Save As TIFF Image</source>
        <translation>Salvar como Imagem TIFF</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="426"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Arquivos TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="269"/>
        <source>Antialiasing</source>
        <translation>Suavizar Bordas</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="26"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="311"/>
        <source>Export:</source>
        <translation>Exportar:</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="319"/>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="324"/>
        <source>Document and Annotations</source>
        <translation>Documentos e anotações</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="323"/>
        <source>Remove unused elements</source>
        <translation>Remover componentes não usados</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="313"/>
        <source>Flatten form fields</source>
        <translation>Nivelar campos de formulário</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="166"/>
        <source>Color and Grayscale Images</source>
        <translation>Imagens a cores e em preto-e-branco graduado</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="57"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="178"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="211"/>
        <source>Compression</source>
        <translation>Compressão</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="110"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="231"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="236"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="244"/>
        <source>Lossless</source>
        <translation>Sem perdas</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="264"/>
        <source>JPEG Quality</source>
        <translation>Qualidade de JPEG</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="340"/>
        <source>PDF/A Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="45"/>
        <source>Black and White Images</source>
        <translation>Imagens em Preto e Branco</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="115"/>
        <source>CCITT Group 4</source>
        <translation>CCITT Group 4</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="120"/>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation>Salvar otimizado como...</translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="333"/>
        <source>Merge all layers</source>
        <translation>Mesclar todas as camadas</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation>Digitalizando...</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScanExeDlg.cpp" line="140"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanImageViewerDialog</name>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="39"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="42"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="45"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="68"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="71"/>
        <location filename="../../src/scanner/ScanImageViewerDialog.ui" line="74"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">Girar 90 graus no sentido horário</translation>
    </message>
</context>
<context>
    <name>ScanPreviewDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="44"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanPreviewDialog.ui" line="51"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="26"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="23"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="18"/>
        <source>Scan</source>
        <translation>Digitalizar</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Configurações</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="46"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="107"/>
        <source>Output</source>
        <translation>Saída</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="55"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="199"/>
        <source>Source</source>
        <translation type="unfinished">Origem</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="414"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="61"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="122"/>
        <source>Before current page</source>
        <translation>Antes de sua página atual</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="424"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="71"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="132"/>
        <source>After last page</source>
        <translation>Depois de sua última página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="397"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="78"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="139"/>
        <source>After current page</source>
        <translation>Depois de sua página atual</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="407"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="88"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="149"/>
        <source>Before first page</source>
        <translation>Antes de sua primeira página</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="304"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="174"/>
        <source>Append to Current Document </source>
        <translation>Adicionar ao arquivo aberto </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="299"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="181"/>
        <source>Create New Document</source>
        <translation>Criar um novo arquivo</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="450"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="133"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="105"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="241"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Deskew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="522"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="183"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation>Scanner</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="80"/>
        <source>Preview</source>
        <translation>Prévia</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="112"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="248"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="90"/>
        <source>Remove background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="255"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="97"/>
        <source>Skip empty pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="544"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="36"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1069"/>
        <source>Looking for devices. Please wait.</source>
        <translation>Procurando aparelhos periféricos. Favor aguardar.</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="vanished">Recarregar arquivos abertos</translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="vanished">Modo</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="209"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="315"/>
        <source>Flatbed</source>
        <translation>Mesa</translation>
    </message>
    <message>
        <source>Postive Transparency</source>
        <translation type="vanished">Transparência positiva</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="322"/>
        <source>Negative Transparency</source>
        <translation>Transparência negativa</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="324"/>
        <source>Document Feeder</source>
        <translation>Alimentador de documento</translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <source>Positive Transparency</source>
        <translation>Transparência positiva</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="353"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="139"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="197"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="119"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="50"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="47"/>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="501"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1007"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="350"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="381"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="188"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="225"/>
        <source>Save As PDF</source>
        <translation>Salvar como PDF</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="503"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1009"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="352"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="383"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="190"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="227"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="64"/>
        <source>Single Page</source>
        <translation>Página única</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="65"/>
        <source>All Pages From Feeder</source>
        <translation>Todas as páginas do alimentador</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="462"/>
        <source>Scan:</source>
        <translation>Digitalizar:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="482"/>
        <source>Page Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="1080"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="130"/>
        <source>Open device. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="193"/>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="571"/>
        <source>Error open device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="27"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="39"/>
        <source>Save</source>
        <translation type="unfinished">Salvar</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="70"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="219"/>
        <source>Additional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="225"/>
        <source>After scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="318"/>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save Settings</source>
        <translation type="unfinished">Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="408"/>
        <source>Save current settings as:</source>
        <translation type="unfinished">Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="418"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished">Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="475"/>
        <source> ?</source>
        <translation type="unfinished"> ?</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="767"/>
        <source>Scan source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="776"/>
        <source>ADF Duplex Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="784"/>
        <source>ADF Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="792"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="801"/>
        <source>Scan mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="833"/>
        <source>Scan resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="845"/>
        <source>X-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="854"/>
        <source>Y-resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="obsolete">Brilho</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="obsolete">Contraste</translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="899"/>
        <source>Page width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="916"/>
        <source>Page height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="938"/>
        <source>Top-left x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="956"/>
        <source>Top-left y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="977"/>
        <source>Bottom-right x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="994"/>
        <source>Bottom-right y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation>Digitalizar outras páginas</translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation>Feita a digitalização</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Preview</source>
        <translation type="vanished">Prévia</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="vanished">Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="vanished">Girar 90 graus no sentido anti-horário</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="138"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="204"/>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="62"/>
        <source>0 result</source>
        <translation>0 resultado</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Case Sensitive</source>
        <translation>Levar em conta maiúsculas e minúsculas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="92"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="102"/>
        <source> result</source>
        <translation> resultado</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="106"/>
        <source> results</source>
        <translation> resultados</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="104"/>
        <source> result(s)</source>
        <translation> resultado(s)</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="23"/>
        <source>Include Comments</source>
        <translatorcomment>Please, don&apos;t suppress &quot;os&quot;.</translatorcomment>
        <translation>Incluir os comentários</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="27"/>
        <source>Whole Words Only</source>
        <translatorcomment>Don&apos;t change to &quot;Apenas palavras inteiras&quot; or to &quot;Só procurar termos ou expressÕES inteiros&quot;. It&apos;s only possible to search for ONE piece of whole expression at a time.</translatorcomment>
        <translation>Só procurar termos ou expressão inteiros</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="69"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="134"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="183"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="233"/>
        <source>Check All</source>
        <translation>Verificar tudo</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="105"/>
        <source>Mark Checked Results for Redaction</source>
        <translation>Enviar os marcados para revisão</translation>
    </message>
    <message>
        <source>Search and Redact</source>
        <translation type="vanished">Pesquisa e Revisão</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="229"/>
        <source>Uncheck All</source>
        <translation>Desmarcar todos</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="124"/>
        <source>Case Sensitive</source>
        <translation>Levar em conta maiúsculas e minúsculas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="125"/>
        <source>Include Comments</source>
        <translation>Incluir Comentários</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Whole Words Only</source>
        <translation>Só levar em conta termos ou expressão inteiros</translation>
    </message>
</context>
<context>
    <name>SecurityCertificateDialog</name>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="14"/>
        <source>Certificate Security</source>
        <translation>Segurança do Certificado</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="51"/>
        <source>Recipient</source>
        <translation>Destinatário</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="64"/>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="82"/>
        <source>Content copying for accessibility</source>
        <translation>Copiar conteúdo para acessibilidade</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="98"/>
        <source>Modifying document</source>
        <translation>Modificar o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="114"/>
        <source>Commenting</source>
        <translation>Incluir comentários</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="130"/>
        <source>Printing the document</source>
        <translation>Imprimir o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="194"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Gerenciar Páginas e Marcadores</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="146"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Preencher formulário ou campos de assinatura</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="162"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir uma versão de alta resolução do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="178"/>
        <source>Extract the content of the document</source>
        <translation>Extrair conteúdo do arquivo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="210"/>
        <source>Encryption</source>
        <translation>Tipo de Cifragem</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="216"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="226"/>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="272"/>
        <source>Recipients</source>
        <translation>Destinatários</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.ui" line="278"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="35"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="42"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityCertificateDialog.cpp" line="33"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation type="vanished">Proteção do PDF</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Solicitar senha para abri-lo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Senha para abrir o arquivo</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="71"/>
        <location filename="../../src/security/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Confirme a senha</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Incluir comentários</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Modificar o documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Copiar conteúdo para acessibilidade</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Imprimir o documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Extrair conteúdo do documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir uma versão de alta resolução do documento</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Preencher campos de formulário ou de assinatura</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Senha de Permissões</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="259"/>
        <source>Manage Pages and bookmarks</source>
        <translatorcomment>Don&apos;t change to &quot;Gerir/Gerenciar Páginas e Favoritos/Marcadores&quot;.</translatorcomment>
        <translation>Editar páginas e marcadores de página</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="104"/>
        <source>Document Open password does not match.</source>
        <translation>As senhas de permissão de acesso ao arquivo não correspondem.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.cpp" line="116"/>
        <source>Document Permission password does not match.</source>
        <translation>As senhas de permissão de edição de arquivo não correspondem.</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation>Tipo e Nível de Cifragem</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="303"/>
        <source>256 bit AES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="293"/>
        <source>128 bit RC4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="14"/>
        <source>Password Security</source>
        <translation>Proteção de Arquivo com Senha</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="288"/>
        <source>40 bit RC4</source>
        <translation>40 bit RC4</translation>
    </message>
    <message>
        <location filename="../../src/security/SecurityDialog.ui" line="298"/>
        <source>128 bit AES</source>
        <translation>128 bit AES</translation>
    </message>
</context>
<context>
    <name>SessionsDialog</name>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="25"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="32"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="39"/>
        <source>Switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="46"/>
        <source>Import</source>
        <translation type="unfinished">Importar</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="53"/>
        <source>Export</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="60"/>
        <source>Rename</source>
        <translation type="unfinished">Renomear</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="67"/>
        <source>Remove</source>
        <translation type="unfinished">Remover</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="74"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="93"/>
        <source>Session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="98"/>
        <source>Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="103"/>
        <source>Last Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="108"/>
        <source>Document count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="121"/>
        <source>Store paths to documents relative to session file when exporting sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.ui" line="140"/>
        <source>Managed Sessions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="184"/>
        <source>Autosave session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="229"/>
        <source>MPE session files (*.mpesession)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="273"/>
        <source>Failed to load sessions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="452"/>
        <location filename="../../src/SessionsDialog.cpp" line="457"/>
        <source>New session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>New session name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SessionsDialog.cpp" line="454"/>
        <source>Please write new session name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetLinkDlg</name>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="14"/>
        <source>Set Destination</source>
        <translation>Especificar Destino</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="20"/>
        <source>Use the scrollbars, mouse and zoom tools to select the target view, then press Set Link to create the Link destination</source>
        <translation>Use as barras de rolagem, o mouse e as ferramentas de zoom para selecionar a exibição desejada. Depois, clique em Criar Remissão para criar a ligação de destino</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="46"/>
        <source>Set Link</source>
        <translatorcomment>That is, &quot;ligação&quot;. &quot;Remissão&quot; means &quot;remeter, enviar, levar (para algum lugar)&quot;. It&apos;s the right Portuguese word for the good old &quot;hipervínculo&quot;, which is kind of obsolete now.</translatorcomment>
        <translation>Criar remissão</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="53"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="60"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../src/forms/SetLinkDlg.ui" line="80"/>
        <source>Set current zoom</source>
        <translation>Usar o zoom atual</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Propriedades da Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="54"/>
        <source>Signature is VALID</source>
        <translation>A assinatura é VÁLIDA</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Detalhes</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Assinado por:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="456"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="502"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="665"/>
        <source>Reason:</source>
        <translation>Razão:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="883"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Local:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Resumo da Validade</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Informações de Contato do Assinante:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="247"/>
        <source>Text For Signing</source>
        <translation>Texto da Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="260"/>
        <source>Location</source>
        <translation>Local</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="267"/>
        <source>Reason</source>
        <translation>Razão</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="331"/>
        <source>Lock document after signing</source>
        <translation>Bloquear o documento após a assinatura</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="353"/>
        <source>Signature Preview</source>
        <translation>Visualizar Assinatura</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="72"/>
        <source>I have reviewed this document</source>
        <translation>Revisei este documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="73"/>
        <source>I am approving this document</source>
        <translation>Estou processando a aprovação deste documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="74"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Atesto a exatidão e integridade deste documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="75"/>
        <source>I agree to specified parts of this document</source>
        <translation>Concordo com determinadas partes deste documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="553"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="557"/>
        <source>M.d.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="562"/>
        <source>M.d.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="567"/>
        <source>M.d.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="572"/>
        <source>M.d.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="577"/>
        <source>MM.dd.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="582"/>
        <source>MM.dd.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="587"/>
        <source>MM.dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="592"/>
        <source>MM.dd.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="597"/>
        <source>MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="602"/>
        <source>MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="607"/>
        <source>d.M.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="612"/>
        <source>d.M.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="617"/>
        <source>dd.MM.yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="622"/>
        <source>dd.MM.yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="627"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="632"/>
        <source>dd.MM.yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="637"/>
        <source>yy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="642"/>
        <source>yy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="647"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="652"/>
        <source>yyyy-MM-dd HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="657"/>
        <source>d-MMMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="662"/>
        <source>d-MMMM HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="667"/>
        <source>d-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="672"/>
        <source>d-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="677"/>
        <source>d-MMMM-yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="682"/>
        <source>d-MMMM-yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="687"/>
        <source>dd-MMMM-yy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="692"/>
        <source>dd-MMMM-yy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="331"/>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation type="vanished">Arquivo p12 (*.p12)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="918"/>
        <source>A password is required to open certificate:</source>
        <translation>É necessário uma senha para abrir o certificado:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="299"/>
        <source>Sign</source>
        <translation>Assinar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="787"/>
        <source>Show Image</source>
        <translation>Exibir a imagem</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="812"/>
        <source>Stretch Image</source>
        <translation>Ampliar a imagem</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="822"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="464"/>
        <source>Show Text</source>
        <translation>Exibir Texto</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="476"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Erro na tentativa de verificação da assinatura!</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="188"/>
        <source>Open Image</source>
        <translation>Abrir Imagem</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="189"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Arquivos de imagem (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="51"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>O documento foi alterado ou corrompido desde que as assinaturas foram aplicadas.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="52"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Não houve alteração no arquivo desde que as assinaturas foram aplicadas.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="53"/>
        <source>Signature is INVALID</source>
        <translation>A assinatura é INVÁLIDA</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="55"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>A validade da assinatura é DESCONHECIDA</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="57"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>A identidade do assinante é desconhecida, pois não foi incluída em sua lista de identidades confiáveis e nenhum de seus certificados matrizes são identidades confiáveis.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="58"/>
        <source>Error during signature verification.</source>
        <translation>Erro durante a verificação da assinatura.</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="59"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Motivo: o intervalo de bytes da assinatura são inválidos</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="60"/>
        <source>I am the author of this document</source>
        <translation>Sou o autor deste documento</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="56"/>
        <source>This certificate is not trusted</source>
        <translation>Este certificado não é confiável</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="vanished">Procurar...</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="237"/>
        <source>Sign As</source>
        <translation>Assinar como</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="400"/>
        <source>Appearance Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="441"/>
        <source>Формат  по ГОСТу</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="473"/>
        <source>Date /Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="543"/>
        <source>Date Format</source>
        <translation type="unfinished">Formato da Data</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="727"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="733"/>
        <source>Show Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="751"/>
        <source>Rounded Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">Horário</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="483"/>
        <source>Signed By</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="703"/>
        <source>E-mail</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="713"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Data</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="422"/>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="781"/>
        <source>Image</source>
        <translation type="unfinished">Imagem</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation type="vanished">Assinado digitalmente por </translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="vanished">E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="280"/>
        <source>Saved Settings</source>
        <translation>Configurações salvas</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="308"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="293"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="301"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save Settings</source>
        <translation>Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1478"/>
        <source>Save current settings as:</source>
        <translation>Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1490"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Já existe uma configuração salva com esse nome. Deseja substituí-la?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="1536"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="503"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="332"/>
        <source>Certificate Manager</source>
        <translation>Gestor de Certificados</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="911"/>
        <source>All Supported Files (*.p12 *.pfx);; p12 Files (*.p12);; pfx Files (*.pfx);; All Files (*)</source>
        <translation>Todos os arquivos válidos (*.p12 *.pfx);; Arquivos p12 (*.p12);; Arquivos pfx (*.pfx);; Todos os arquivos (*)</translation>
    </message>
    <message>
        <source>Digitally signed by</source>
        <translation type="vanished">Digitalmente assinado por</translation>
    </message>
</context>
<context>
    <name>SignatureFormTab</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulário</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.ui" line="88"/>
        <source>Signatures</source>
        <translation>Assinaturas</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="286"/>
        <source>Unsigned Signature</source>
        <translation>Assinatura Anônima</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Location</source>
        <translation>Local</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="290"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="329"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="302"/>
        <source>Signed Signature</source>
        <translation>Assinatura Identificada</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="305"/>
        <source>Signed by:</source>
        <translation>Assinado por:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="306"/>
        <source>Reason:</source>
        <translation>Razão:</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="346"/>
        <source>Click to view this version</source>
        <translation>Clique para ver este versão</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="292"/>
        <location filename="../../src/leftTab/certificate/SignatureFormTab.cpp" line="331"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Emissor</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Nome Comum (CN)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Empresa (O)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Unidade da Empresa (OU)</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Número de Série</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algoritmo</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Validade</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Não Antes</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Não Depois</translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation type="vanished">SHA-1:</translation>
    </message>
    <message>
        <source>MD5</source>
        <translation type="vanished">MD5</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Adicionar a Identidades Confiáveis</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="298"/>
        <source>Data</source>
        <translation>Dados</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="285"/>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="vanished">Configurações</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="98"/>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.ui" line="72"/>
        <source>Manage Stamps</source>
        <translation>Gerenciar carimbos</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation>Carimbos Personalizados</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation>Prévia</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation>Carimbos</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation>Edição de Carimbo</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation>Modelo</translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Formulário</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="43"/>
        <source>Options</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="74"/>
        <source>Reply</source>
        <translation>Resposta</translation>
    </message>
</context>
<context>
    <name>StickyNoteReply</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulário</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Nome da Fonte</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Tamanho da fonte</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Cor do texto</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation>Editor de Texto</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="166"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="184"/>
        <source>Add Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="199"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="224"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="249"/>
        <source>Organization unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="274"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="299"/>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="324"/>
        <source>Valid since</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="349"/>
        <source>Valid till</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.ui" line="365"/>
        <source>Date</source>
        <translation type="unfinished">Data</translation>
    </message>
    <message>
        <source>From</source>
        <translation type="obsolete">De</translation>
    </message>
    <message>
        <source>To</source>
        <translation type="obsolete">Para</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="36"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Família de fontes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a família de fontes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="42"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor da Fonte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Mudar a cor da fonte&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/signature/TextEditDlg.cpp" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor de Fonto&lt;/span&gt;&lt;/p&gt;&lt;p&gt; Mudar a cor de fundo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ThumbnailForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulário</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="22"/>
        <source>Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="29"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="42"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="62"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="75"/>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/thumbnail/ThumbnailForm.cpp" line="39"/>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
</context>
<context>
    <name>ToolBarCommentsForm</name>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="227"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="233"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="268"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="271"/>
        <source>StrikeOut</source>
        <translation type="unfinished">Riscado</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="122"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="125"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="167"/>
        <location filename="../../src/forms/ToolBarCommentsForm.ui" line="170"/>
        <source>Copy</source>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="101"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="104"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="110"/>
        <source>Red</source>
        <translation type="unfinished">Vermelho</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="112"/>
        <source>Blue</source>
        <translation type="unfinished">Azul</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="114"/>
        <source>Yellow</source>
        <translation type="unfinished">Amarelo</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="116"/>
        <source>Green</source>
        <translation type="unfinished">Verde</translation>
    </message>
    <message>
        <location filename="../../src/forms/ToolBarCommentsForm.cpp" line="119"/>
        <source>Change</source>
        <translation type="unfinished">Alterar</translation>
    </message>
</context>
<context>
    <name>ToolBarSettings</name>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="602"/>
        <source>Open a PDF file</source>
        <translation>Abrir um arquivo PDF</translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/ToolBarSettings.cpp" line="696"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation>Marca D&apos;Água</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="vanished">Configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="648"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="662"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="670"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="231"/>
        <source>Source</source>
        <translation>Origem</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="427"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="244"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="417"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="vanished">Total de páginas:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="237"/>
        <source>Page Number</source>
        <translation>Número da página</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="264"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="270"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="322"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="315"/>
        <source>Font Family</source>
        <translation>Família de Fontes</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="380"/>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="121"/>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Preview</source>
        <translation type="unfinished">Prévia</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="28"/>
        <source>Preview Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="45"/>
        <source>of</source>
        <translation type="unfinished">de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="52"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="127"/>
        <source>Rotation</source>
        <translation>Rotação</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="145"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="165"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="221"/>
        <source>Scale relative to target page</source>
        <translation>Escala relativa à página visada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="364"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="489"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="495"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="630"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="754"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="760"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="791"/>
        <source>Total pages: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="453"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="495"/>
        <source>Vertical distance</source>
        <translation>Distância vertical</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="522"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="529"/>
        <source>from</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="562"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="468"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="567"/>
        <source>Center</source>
        <translation>Centralizar</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="572"/>
        <source>Bottom</source>
        <translation>Inferior</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="488"/>
        <source>Horizontal distance</source>
        <translation>Distância horizontal</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="463"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="473"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="580"/>
        <source>Units</source>
        <translatorcomment>Don&apos;t change to &quot;Unidades&quot;.</translatorcomment>
        <translation>Unidade de medida</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="vanished">Ponto</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="vanished">Polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="vanished">Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="80"/>
        <source>Page Range Options...</source>
        <translation>Opções de intervalo de páginas...</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save Settings</source>
        <translation>Salvar configurações</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source>Save current settings as:</source>
        <translation>Salvar as configurações atuais como:</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="302"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Já existe uma configuração salva com esse nome. Deseja substituí-la?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source>Are you sure you want to delete the setting </source>
        <translation>Quer mesmo apagar as configurações </translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="338"/>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="420"/>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="436"/>
        <source> in</source>
        <translation> pol</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="454"/>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="vanished">Arquivos PDF (*.pdf *.PDF)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="499"/>
        <source>There was an error opening the document !</source>
        <translation>Erro na tentativa de abrir o arquivo!</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="299"/>
        <source>auto</source>
        <translation>automático</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="629"/>
        <source>Saved Settings</source>
        <translation>Feito o salvamento da configuração</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="540"/>
        <source>Points</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="545"/>
        <source>Inches</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="550"/>
        <source>Millimeters</source>
        <translation>Milímetro</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="476"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Todos os arquivos válidos (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="600"/>
        <source>Place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="606"/>
        <source>On the Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="613"/>
        <source>In the Foreground</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSignature</name>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="37"/>
        <source>Digitally signed by</source>
        <translation type="unfinished">Digitalmente assinado por</translation>
    </message>
    <message>
        <location filename="../../src/signature/widgetsignature.cpp" line="38"/>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="obsolete">Data</translation>
    </message>
</context>
<context>
    <name>layerForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Formulário</translation>
    </message>
    <message>
        <location filename="../../src/leftTab/layer/layerform.ui" line="27"/>
        <source>Layers</source>
        <translation>Camadas</translation>
    </message>
</context>
</TS>
